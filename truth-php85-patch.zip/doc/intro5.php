<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "오시는 길 | 진리의동산교회";
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "1";
$p_num = "5";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro5">

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">
                <div id="intro5-1">
                    <div id="daumRoughmapContainer1792392445820" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%;"></div>
                    <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://t1.kakaocdn.net/kakaomapweb/roughmap/loader/prod/roughmapLoader.js"></script>
                    <script charset="UTF-8">
                        new daum.roughmap.Lander({
                            "timestamp" : "1792392445820",
                            "key" : "3iu3x53m2ti",
                            "mapHeight" : "460"
                        }).render();
                    </script>
                </div>

                 <div id="btnWrap">
                    <a href="" target="_blank" class="mbtn3">티맵</a>
                    <a href="" target="_blank" class="mbtn4">카카오맵</a>
                    <a href="" target="_blank" class="mbtn5">네이버 지도</a>
                </div>
                    
                <div id="intro5-2">
                    <dl>
                        <dt>주소</dt>
                        <dd>경기도 화성시 만세구 남양읍 고향의봄길 71-7</dd>
                    </dl>
                    <dl>
                        <dt>대중교통 안내</dt>
                        <dd>
                            <h4>(임시)서희스타힐스4차 정류장</h4>
                            <div class="nosun">
                                <div class="tag tag1">마을</div>
                                <dl>
                                    <dd>20-3</dd>
                                    <dd>20-4</dd>
                                    <dd>20-6</dd>
                                    <dd>5</dd>
                                    <dd>H3</dd>
                                    <dd>공영2(삼존)</dd>
                                    <dd>공영2(송정)</dd>
                                </dl>
                            </div>
                        </dd>
                    </dl>
                </div>
        </div>

    </div>

</div>




<?php include "../inc/bottom.php"; ?>