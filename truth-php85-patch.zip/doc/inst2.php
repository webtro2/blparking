<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "바울 선교회 | 진리의동산교회";
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "3";
$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="inst2">

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">
                 (자료 필요)
        </div>

    </div>

</div>




<?php include "../inc/bottom.php"; ?>