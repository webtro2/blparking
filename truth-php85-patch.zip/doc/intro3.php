<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "섬기는 사람들 | 진리의동산교회";
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "1";
$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css">
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro3">

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">

            <div id="intro3">
                <div id="titWrap" class="titWrap"><h3>간사</h3></div>
                <div id="contWrap">
                    <ul id="intro3-list">
                        <li><div class="img"><a data-fancybox="intro3-1" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                        <li><div class="img"><a data-fancybox="intro3-1" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                        <li><div class="img"><a data-fancybox="intro3-1" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                    </ul>
                </div>
            </div>


            <div id="intro3" class="s-Part">
                <div id="titWrap" class="titWrap"><h3>전도사</h3></div>
                <div id="contWrap">
                    <ul id="intro3-list">
                        <li><div class="img"><a data-fancybox="intro3-2" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                        <li><div class="img"><a data-fancybox="intro3-2" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                    </ul>
                </div>
            </div>

            <div id="intro3" class="s-Part">
                <div id="titWrap" class="titWrap"><h3>목사</h3></div>
                <div id="contWrap">
                    <ul id="intro3-list">
                        <li><div class="img"><a data-fancybox="intro3-3" href="/images/sub/intro3-3_img1.png"><img src="/images/sub/intro3-3_img1.png" alt=""></a></div><dl><dt>윤시온</dt><dd>담임목사</dd></dl></li>
                    </ul>
                </div>
            </div>
            
            <div id="intro3" class="s-Part">
                <div id="titWrap" class="titWrap"><h3>선교사</h3></div>
                <div id="contWrap">
                    <ul id="intro3-list">
                        <li><div class="img"><a data-fancybox="intro3-4" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                    </ul>
                </div>
            </div>


            <div id="intro3" class="s-Part">
                <div id="titWrap" class="titWrap"><h3>협력선교사</h3></div>
                <div id="contWrap">
                    <ul id="intro3-list">
                        <li><div class="img"><a data-fancybox="intro3-4" href="/images/sub/intro3_img0.png"><img src="/images/sub/intro3_img0.png" alt=""></a></div><dl><dt>성명</dt><dd>설명 준비중</dd></dl></li>
                    </ul>
                </div>
            </div>


            <div id="intro3" class="s-Part">
                <div id="titWrap" class="titWrap"><h3>협력선교기관</h3></div>
                <div id="contWrap">
                    <div id="borderBox">
                        <p>· 일본복음선교회(JEM)</p>
                    </div>
                </div>
            </div>


        </div>

    </div>

</div>


<script>
    document.querySelectorAll('#intro3-list li').forEach(function(li) {
    const link = li.querySelector('a[data-fancybox]');
    const dl = li.querySelector('dl');

    if (link && dl) {
        link.setAttribute('data-caption', dl.outerHTML);
    }
});
</script>
<script>
$(document).on('afterLoad.fb', function(e, instance, slide) {
    var $link = slide.opts.$orig;

    if (!$link || !$link.closest('#intro3-list').length) return;

    instance.$refs.container.addClass('intro3-fancybox');

    var $content = slide.$slide.find('.fancybox-content');

    $content.find('.intro3-fancy-caption').remove();

    $('<div class="intro3-fancy-caption"></div>')
        .html($link.attr('data-caption'))
        .appendTo($content);
});
</script>
<?php include "../inc/bottom.php"; ?>