<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "교회연혁 | 진리의동산교회";
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "1";
$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro4">

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">
            <div id="intro4-1">
                <div id="borderBox" data-aos="fade-up">
                    <p>
                        [진리의동산교회]는 대한예수교장로회총회(합동), 경기서노회 소속입니다. <br> 2004년 12월 5일, &#x3C;안산동산교회>에서 ‘큰 숲 운동’으로  &#x3C;은혜의동산교회>가 첫 번째로 분립개척되었습니다. <br> &#x3C;은혜의동산교회>는 2014년 부터 2년에 한 번씩 분립개척을 시작했고 2027년 1월 1일 [진리의동산교회]가 7번째로 분립개척되었습니다
                    </p>
                </div>
            </div>

            <div id="intro4-2" class="s-Part2" data-aos="fade-up">
                <div id="titWrap"><h3>큰 숲 운동 (분립개척)</h3></div>
                <ol>
                    <li><span>2014년</span><p>행복한동산교회</p></li>
                    <li><span>2016년</span><p>맑은샘동산교회</p></li>
                    <li><span>2019년</span><p>하나숲동산교회</p></li>
                    <li><span>2021년</span><p>가스펠센터처치</p></li>
                    <li><span>2023년</span><p>은혜샘교회</p></li>
                    <li><span>2025년</span><p>드림동산교회</p></li>
                    <li><span>2027년</span><p>진리의동산교회</p></li>
                </ol>
            </div>

             <div id="intro4-3" class="s-Part">
                <div id="halfWrap">
                    <div id="titWrap" data-aos="fade-up">
                        <h3>진리의동산교회가<br>지나온 길</h3>
                    </div>

                    <div id="contWrap">
                        <div class="historyTimeline">

                            <div class="item" data-aos="fade-up">
                                <div class="box">
                                    <div class="date">2027년 1월 3일 (주일)</div>
                                    <h4>진리의동산교회 첫 주일예배</h4>
                                    <p>예정</p>
                                </div>
                            </div>

                            <div class="item" data-aos="fade-up">
                                <div class="box">
                                    <div class="date">2026년 12월 31일 (목요일)</div>
                                    <h4>진리의동산교회 파송예배</h4>
                                    <p>송구영신예배와 함께 진행</p>
                                </div>
                            </div>

                            <div class="item" data-aos="fade-up">
                                <div class="box">
                                    <div class="date">2026년 12월 13일 (주일)</div>
                                    <h4>진리의동산교회 설립예배</h4>
                                    <p>진리의동산교회의 시작을 알리는 설립예배</p>
                                </div>
                            </div>

                            <div class="item" data-aos="fade-up">
                                <div class="box">
                                    <div class="date">2026년 9월 20일 (주일)</div>
                                    <h4>진리의동산교회 설립을 위한 공동의회</h4>
                                    <p>오후 3시, 새가족교육실(비전센터 4층)</p>
                                </div>
                            </div>

                            <div class="item" data-aos="fade-up">
                                <div class="box">
                                    <div class="date">2026년 8월 30일 (주일)</div>
                                    <h4>분립개척 2차 신청자 모임</h4>
                                    <p>오후 2시, 새가족교육실(비전센터 4층)</p>
                                </div>
                            </div>

                            <div class="item" data-aos="fade-up">
                                <div class="box">
                                    <div class="date">2026년 6월 28일 (주일)</div>
                                    <h4>분립개척 1차 신청자 모임</h4>
                                    <p>오후 7시, 고청실(쉐마센터 3층)</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
               
            </div>


        </div>

    </div>

</div>




<?php include "../inc/bottom.php"; ?>