<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "담임목사 인사말 | 진리의동산교회";
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "1";
$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro2">

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">
            <div class="greeting">
                <div class="txt" data-aos="fade-up">
                    <h3>진리의동산교회 홈페이지를 <br>찾아주신 여러분을 <span>진심으로 환영합니다.</span></h3>
                    <p>한 그루의 나무가 자라고, 그 곁에 또 다른 나무가 자라, <br>아름다운 동산을 이루는 모습을 꿈꿉니다. <br>나무는 하루아침에 자라지 않습니다. <br>햇빛과 비를 맞으며 조금씩 자라갑니다.</p>

                    <p>우리의 믿음도 그렇습니다. <br>때로는 흔들리고 넘어지기도 하지만 <br>하나님의 말씀에 깊이 뿌리를 내리고 <br>그리스도의 은혜 안에 머물 때 <br>우리는 함께 자라갈 수 있습니다.</p>

                    <p>하나님을 기쁨으로 예배하고, 말씀으로 한 사람을 세우며 <br>복음으로 가정을 든든히 세워, 삶의 자리에서 믿음으로 살아내는 교회</p>

                    <p>함께 말씀에 뿌리내리고 <br>함께 그리스도를 닮아가며 <br>함께 아름다운 진리의 동산을 이루어 가겠습니다.</p>

                    <p>진리 안에 뿌리내리고, 그리스도 안에 함께 자라갑니다. <br><span>Rooted in Truth, Growing in Christ.</span></p>
                </div>

                <div class="img" data-aos="fade-up">
                    <img src="/images/sub/intro2_img.webp" alt="진리의동산교회 담임목사 윤시온">
                </div>
            </div>
        </div>

    </div>

</div>




<?php include "../inc/bottom.php"; ?>