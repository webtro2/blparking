<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "교회비전 | 진리의동산교회";
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "1";
$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro1">

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">


            <div id="intro1-1">
                <div class="img"><img src="/images/sub/intro1-1_img1.png" alt="진리의동산교회 로고 의미"></div>
            </div>


            <div id="halfWrap" class="s-Part">
                <div id="titWrap">
                    <h3>진리의동산교회 <br>로고의 의미</h3>
                </div>
                <div id="contWrap">
                    <div id="intro1-2">
                        <div class="item">
                            <div class="img"><img src="/images/sub/intro1-2_img1.png" alt="로고 의미"></div>
                            <div class="txt">
                                <h4>하단 대지(갈색 곡선)</h4>
                                <p class="c1">든든하게 받치고 있는 대지/언덕</p>
                                <ul class="dot">
                                    <li><p>진리 안에 뿌리내림</p></li>
                                    <li><p>하나님의 말씀과 진리의 터 위에 견고히 뿌리내리는 신앙의 기초</p></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="img"><img src="/images/sub/intro1-2_img2.png" alt="로고 의미"></div>
                            <div class="txt">
                                <h4>중앙 십자가</h4>
                                <p class="c2">우뚝 선 십자가</p>
                                <ul class="dot">
                                    <li><p>그리스도 중심성</p></li>
                                    <li><p>예수 그리스도를 교회와 삶의 중심으로 삼고 거하는 모습</p></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="img"><img src="/images/sub/intro1-2_img3.png" alt="로고 의미"></div>
                            <div class="txt">
                                <h4>양옆 형상(사람&새싹)</h4>
                                <p class="c3">십자가를 중심으로 늘어선 사람 형상과 푸른 잎사귀/새싹</p>
                                <ul class="dot">
                                    <li><p>그리스도 안에 자라남</p></li>
                                    <li><p>영적 성장 : 진리 안에서 싹을 틔우고 자라는 생명력</p></li>
                                    <li><p>예배와 동역 : 성도들이 함께 모여 예배하고 성장하는 공동체</p></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="img"><img src="/images/sub/intro1-2_img4.png" alt="로고 의미"></div>
                            <div class="txt">
                                <h4>전체구도(진리의 동산)</h4>
                                <p class="c4">대지 위에 십자가와 생명이 어우러진 형상</p>
                                <ul class="dot">
                                    <li><p>하나님의 은혜와 진리 안에서 풍성하게 피어나는 영적 동산</p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>




<?php include "../inc/bottom.php"; ?>