<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH . '/head.sub.boa.php');
include_once(G5_LIB_PATH . '/latest.lib.php');
include_once(G5_LIB_PATH . '/outlogin.lib.php');
include_once(G5_LIB_PATH . '/poll.lib.php');
include_once(G5_LIB_PATH . '/visit.lib.php');
include_once(G5_LIB_PATH . '/connect.lib.php');
include_once(G5_LIB_PATH . '/popular.lib.php');


$s_num = "";
$p_num = "";

$login = "/pg/bbs/login.php";
$register = "/pg/bbs/register.php";
$register2 = "/pg/bbs/register_form.php";
$register3 = "/pg/bbs/register_result.php";
$cert = "/pg/bbs/member_cert_refresh.php";
$search = "/pg/bbs/search.php";
$confirm = "/pg/bbs/member_confirm.php";

$mstr = strtok($_SERVER['REQUEST_URI'], '?');

if ($bo_table == "word1") {
    $s_num = "2";
    $p_num = "1";
} elseif ($bo_table == "word2") {
    $s_num = "2";
    $p_num = "2";
} elseif ($bo_table == "word3") {
    $s_num = "2";
    $p_num = "3";
} elseif ($bo_table == "word4") {
    $s_num = "2";
    $p_num = "4";
} elseif ($bo_table == "comm2") {
    $s_num = "4";
    $p_num = "2";
} elseif ($bo_table == "comm3") {
    $s_num = "4";
    $p_num = "3";
} elseif ($bo_table == "comm4") {
    $s_num = "4";
    $p_num = "4";
} elseif ($bo_table == "comm5") {
    $s_num = "4";
    $p_num = "5";
} elseif ($bo_table == "comm6") {
    $s_num = "4";
    $p_num = "6";
} elseif ($mstr == $login) {
    $s_num = "5";
    $p_num = "1";
} elseif ($mstr == $confirm) {
    $s_num = "5";
    $p_num = "1";
} elseif ($mstr == $login2) {
    $s_num = "5";
    $p_num = "1";
} elseif ($mstr == $register) {
    $s_num = "5";
    $p_num = "2";
} elseif ($mstr == $register2) {
    $s_num = "5";
    $p_num = "2";
} elseif ($mstr == $register3) {
    $s_num = "5";
    $p_num = "2";
} elseif ($mstr == $cert) {
    $s_num = "5";
    $p_num = "2";
} elseif ($mstr == $search) {
    $s_num = "5";
    $p_num = "5";
} elseif (($fm_id ?? '') == "1") {
    $s_num = "7";
    $p_num = "2";
}
?>



<?php include __DIR__ . "/../inc/head.php"; ?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>
<?php include __DIR__ . "/../inc/s_visual_board.php"; ?>



<?php
$is_utility_page = in_array($mstr, [$login, $register, $register2, $register3, $cert, $search, $confirm]);
$pageCont_class = $is_utility_page ? ' class="board"' : '';
?>
<?php if ($is_utility_page) { ?>
    <style>
        .s_visual {
            display: none;
        }
    </style>
<?php } ?>
<!-- Sub Content -->
<div id="subContent">
    <div id="pageCont" style="font-size:15px;" <?php echo $pageCont_class; ?>>

        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">