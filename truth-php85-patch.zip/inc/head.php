<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include_once "_common.php";
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="ko" />
    <meta name="viewport" content="initial-scale=1.0, width=device-width" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="shortcut icon" href="/favi.ico">
    <meta property="og:image" content="/og_img.png">
    <meta property="og:image:width" content="800">
    <meta property="og:image:height" content="400">

    <?php
    $site_title = isset($page_title) && $page_title ? $page_title : (isset($g5['title']) && $g5['title'] ? $g5['title'] : "진리의동산교회");
    ?>
    <title><?php echo $site_title; ?></title>

    <meta property="og:title" content="<?php echo $site_title; ?>" />
    <?php
    $request_uri = $_SERVER['REQUEST_URI'];

    if ($request_uri === '/index.php' || $request_uri === '/index.php/') {
        $request_uri = '/';
    }

    $canonical_url = "https://7truth.org" . $request_uri;
    ?>
    <link rel="canonical" href="<?php echo htmlspecialchars($canonical_url, ENT_QUOTES, 'UTF-8'); ?>">
    <script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="/js/common.js"></script>
    <script type="text/javascript" src="/js/sub.js"></script>

    <link rel="stylesheet" type="text/css" href="/css/default.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/layout.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/sub.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/scont.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/aos.css?v=1" />
    <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
    <link href="https://cdn.jsdelivr.net/gh/sun-typeface/SUIT@2/fonts/static/woff2/SUIT.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200..900&display=swap" rel="stylesheet">

    <!-- slick -->
    <script src="/js/slick/slick.min.js"></script>
    <link rel="stylesheet" href="/js/slick/slick-theme.css">
    <link rel="stylesheet" href="/js/slick/slick.css">

</head>

<body>

    <div id="wrap">