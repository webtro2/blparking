<!-- header -->
<div id="header">
    <div class="inner">
        <div class="l_cont">
            <h1 id="logo">
                <a href="/"></a>
            </h1>
        </div>

        <div class="r_cont">
            <ul class="top">
                <?php if ($is_member) { ?>
                    <li><a href="/pg/bbs/logout.php">로그아웃</a></li>
                    <li><a href="<?php echo G5_BBS_URL ?>/member_confirm.php?url=<?php echo G5_BBS_URL ?>/register_form.php">정보수정</a></li>
                <?php } else { ?>
                    <li><a href="/pg/bbs/login.php">로그인</a></li>
                    <li><a href="/pg/bbs/register.php">회원가입</a></li>
                <?php } ?>
                <li><a href="javascript:GoPage('intro5')">오시는 길</a></li>
                <li><a href="https://www.youtube.com/@truthgardenchurch" target="_blank">유튜브</a></li>
                <li><a href="https://blog.naver.com/truth_garden_church" target="_blank">블로그</a></li>
                <li><a href="https://www.instagram.com/truth_garden_church" target="_blank">인스타그램</a></li>
            </ul>
            <div class="bottom">
                <div class="pcGnb">
                    <?php include __DIR__ . "/nav.php" ?>
                </div>

                <div class="button_box">
                    <button type="button" class="searchToggle" aria-label="검색창 열기"><img src="/images/common/search.webp" alt="검색"></button>
                    <div class="menuToggle">
                        <span class="t"></span>
                        <span class="m"></span>
                        <span class="b"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //header -->

<!-- search layer -->
<div class="search_wrap">
    <div class="search_bg"></div>
    <div class="search_box">
        <div class="inner">
            <form name="fsearchbox" method="get" action="<?php echo defined('G5_BBS_URL') ? G5_BBS_URL : '/pg/bbs'; ?>/search.php" onsubmit="return fsearchbox_submit(this);">
                <input type="hidden" name="sfl" value="wr_subject||wr_content">
                <input type="hidden" name="sop" value="and">
                <div class="input_box">
                    <input type="text" name="stx" id="sch_stx" placeholder="검색어를 입력해 주세요." maxlength="50" autocomplete="off">
                    <button type="submit" class="sch_submit" aria-label="검색"><img src="/images/common/search.webp" alt="검색"></button>
                </div>
            </form>
            <button type="button" class="search_close" aria-label="검색창 닫기">
                <span></span>
                <span></span>
            </button>
        </div>
    </div>
</div>
<!-- //search layer -->

<div class="mo_bg"></div>

<div class="moGnb">
    <div class="inner">
        <div class="m_top">
            <ul class="top">
                <?php if ($is_member) { ?>
                    <li><a href="/pg/bbs/logout.php">로그아웃</a></li>
                    <li><a href="/pg/bbs/member_confirm.php?url=<?php echo G5_BBS_URL ?>/register_form.php">정보수정</a></li>
                <?php } else { ?>
                    <li><a href="/pg/bbs/login.php">로그인</a></li>
                    <li><a href="/pg/bbs/register.php">회원가입</a></li>
                <?php } ?>
                <li><a href="javascript:GoPage('intro5')">오시는 길</a></li>
            </ul>
        </div>
        <div class="bottom">
            <?php include __DIR__ . "/nav.php" ?>
        </div>
        <div class="m_sns">
            <ul>
                <li><a href="https://www.youtube.com/@truthgardenchurch" target="_blank"><img src="/images/common/youtube.webp" alt="유튜브"></a></li>
                <li><a href="https://blog.naver.com/truth_garden_church" target="_blank"><img src="/images/common/blog.webp" alt="블로그"></a></li>
                <li><a href="https://www.instagram.com/truth_garden_church" target="_blank"><img src="/images/common/insta.webp" alt="인스타그램"></a></li>
            </ul>
        </div>
    </div>
</div>