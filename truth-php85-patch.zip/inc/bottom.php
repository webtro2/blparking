<ul class="quick">
    <li><a href="javascript:GoPage('word1')">주일<br>설교</a></li>
    <li><a href="javascript:GoPage('comm2')">교회<br>주보</a></li>
    <li><a href="https://www.youtube.com/@truthgardenchurch" target="_blank"><img src="/images/common/youtube.webp" alt=""></a></li>
    <li><a href="https://blog.naver.com/truth_garden_church" target="_blank"><img src="/images/common/blog.webp" alt=""></a></li>
    <li><a href="https://www.instagram.com/truth_garden_church" target="_blank"><img src="/images/common/insta.webp" alt=""></a></li>
    <li class="go_top"><a href="javascript:void(0);" onclick="$('html, body').animate({scrollTop: 0}, 400); return false;">↑</a></li>
</ul>

<!-- footer -->
<div id="footer">
    <div class="inner">
        <div class="top">
            <div class="l_cont">
                <div class="f_logo"><img src="/images/common/f_logo.webp" alt=""></div>
                <div class="info">
                    <h3>진리의동산교회</h3>
                    <p>
                        <span>경기도 화성시 만세구 남양읍 고향의봄길 71-7</span><br>
                        <span>전화번호 : 031-000-0000</span>
                        <span>팩스번호 : 031-000-0000</span>
                    </p>
                </div>
            </div>

            <div class="r_cont">
                <ul class="list">
                    <li><a href="javascript:GoPage('terms')">이용약관</a></li>
                    <li><a href="javascript:GoPage('privacy')"><b>개인정보처리방침</b></a></li>
                </ul>
                <ul class="sns">
                    <li><a href="https://www.youtube.com/@truthgardenchurch" target="_blank"><img src="/images/common/footer_youtube.webp" alt=""></a></li>
                    <li><a href="https://blog.naver.com/truth_garden_church" target="_blank"><img src="/images/common/footer_blog.webp" alt=""></a></li>
                    <li><a href="https://www.instagram.com/truth_garden_church" target="_blank"><img src="/images/common/footer_insta.webp" alt=""></a></li>
                </ul>
            </div>
        </div>

        <div class="bottom">
            <p>Copyright &copy; 2026 진리의동산교회. All Rights Reserved.</p>
            <p><a href="https://webtro.co.kr" target="_blank">Designed By 웹트로</a></p>
        </div>
    </div>
</div>
<!-- //footer -->


</div>

<script type="text/javascript">
    $(function() {
        subFunc.snb("<?php  echo ($s_num ?? ''); ?>", "<?php  echo ($p_num ?? ''); ?>");
    });
</script>
<script src="/js//aos/aos.js"></script>
<script>
    AOS.init({
        duration: 600,
        offset: 0,
        delay: 100,
        easing: 'ease-out-quad',
    });
</script>

</body>

</html>