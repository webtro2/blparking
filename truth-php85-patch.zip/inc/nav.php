<ul class="gnb">
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('intro1')">교회소개</a></div>
        <?php  include __DIR__ . "/s_gnb1.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('word1')">말씀과 찬양</a></div>
        <?php  include __DIR__ . "/s_gnb2.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('inst1')">교회기관</a></div>
        <?php  include __DIR__ . "/s_gnb3.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('comm1')">교회소식</a></div>
        <?php  include __DIR__ . "/s_gnb4.php" ?>
    </li>
</ul>