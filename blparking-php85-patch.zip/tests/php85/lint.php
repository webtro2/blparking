<?php
// Syntax checking only; application files are never executed.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$root = dirname(__DIR__, 2);
$passed = $failed = 0;
foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root)) as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') continue;
    $lines = array();
    $command = escapeshellarg(PHP_BINARY)
        . ' -d short_open_tag=0 -d error_reporting=-1 -d display_errors=1 -d log_errors=0 -l '
        . escapeshellarg($file->getPathname()) . ' 2>&1';
    exec($command, $lines, $status);
    $output = implode("\n", $lines);
    if ($status !== 0 || preg_match('/(?:Warning|Deprecated|Fatal error|Parse error):/', $output)) {
        $failed++;
        fwrite(STDERR, $output . "\n");
    } else {
        $passed++;
    }
}
echo "PHP " . PHP_VERSION . ": $passed passed, $failed failed\n";
exit($failed || !$passed ? 1 : 0);
