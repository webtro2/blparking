<?php
// Run from CLI: php tests/php85/regression.php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$root = dirname(__DIR__, 2);
define('PHP85_TEST_DIR', sys_get_temp_dir() . '/blparking-php85-' . bin2hex(random_bytes(8)));
mkdir(PHP85_TEST_DIR, 0700);
register_shutdown_function(function () { foreach (glob(PHP85_TEST_DIR . '/*') as $f) unlink($f); rmdir(PHP85_TEST_DIR); });
ob_start();
error_reporting(E_ALL);
set_error_handler(function($severity,$message,$file,$line) {if (!(error_reporting() & $severity)) return false; throw new ErrorException($message,0,$severity,$file,$line);});
define('_GNUBOARD_',true);
define('G5_FILE_PERMISSION',0644);
$failures = 0;
function check($name,$fn) {try{$fn();echo "PASS $name\n";}catch(Throwable $e){global $failures; $failures++; echo "FAIL $name: ".$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
check('password hashing',function() use ($root) {require $root . '/lib/pbkdf2.compat.php';$h=create_hash('test-password');if(!validate_password('test-password',$h)||validate_password('wrong',$h))throw new Exception('password mismatch');});
check('PHPMailer MIME',function() use ($root) {require $root . '/plugin/PHPMailer/PHPMailerAutoload.php';$m=new PHPMailer();$m->setFrom('sender@example.invalid');$m->addAddress('recipient@example.invalid');$m->Subject='PHP85';$m->Body='test';if(!$m->preSend()||!str_contains($m->getSentMIMEMessage(),'PHP85'))throw new Exception('MIME missing');});
check('HTML sanitizing',function() use ($root) {require $root . '/plugin/htmlpurifier/HTMLPurifier.standalone.php';$c=HTMLPurifier_Config::createDefault();$c->set('Cache.DefinitionImpl',null);$h=new HTMLPurifier($c);$out=$h->purify('<p>Hello<script>alert(1)</script><a href="javascript:alert(1)">x</a></p>');if(str_contains($out,'script')||!str_contains($out,'Hello'))throw new Exception('unsafe HTML');});
check('Excel writing',function() use ($root) {require $root . '/lib/Excel/php_writeexcel/class.writeexcel_workbook.inc.php';require $root . '/lib/Excel/php_writeexcel/class.writeexcel_worksheet.inc.php';$w=new writeexcel_workbook(PHP85_TEST_DIR . '/php85-test.xls');$s=$w->addworksheet();$s->write(0,0,'PHP85');$s->write(1,0,42);$s->write(2,0,'=SUM(A1:A2)');$w->close();if(filesize(PHP85_TEST_DIR . '/php85-test.xls')<512)throw new Exception('empty workbook');});
check('legacy JSON',function() use ($root) {require $root . '/plugin/sms5/JSON.php';$j=new Services_JSON();$s=$j->encode(array('hello'=>'world'));if($j->decode($s)->hello!=='world')throw new Exception('JSON mismatch');});

check('captcha image', function() use ($root) {require $root . '/plugin/kcaptcha/kcaptcha.lib.php';$c=new KCAPTCHA();$c->setKeyString('123456');ob_start();try{$c->image();$img=ob_get_contents();}finally{ob_end_clean();}if(substr($img,0,2)!=="\xff\xd8")throw new Exception('invalid JPEG');});
check('thumbnail',function() use ($root) {require $root . '/lib/thumbnail.lib.php';$im=imagecreatetruecolor(180,120);imagejpeg($im,PHP85_TEST_DIR . '/php85-original.jpg');unset($im);$file=thumbnail('php85-original.jpg',PHP85_TEST_DIR,PHP85_TEST_DIR,90,60,true);$size=getimagesize(PHP85_TEST_DIR . '/' . $file);if($size[0]!==90 || $size[1]!==60)throw new Exception('incorrect thumbnail size');});
check('common utilities', function() use ($root) {
    require $root . '/lib/common.lib.php';
    global $view, $member, $is_admin;
    $view = array('mb_id' => 'other');
    $member = array('mb_id' => 'admin');
    $is_admin = 'super';
    $html = bad_tag_convert('<embed src="test">');
    if (!str_contains($html, 'class="embedx"') || html_symbol(null) !== '') {
        throw new Exception('common helper regression');
    }
    $cipher = new str_encrypt('php85-test-salt');
    if ($cipher->decrypt($cipher->encrypt('PHP85 test')) !== 'PHP85 test') {
        throw new Exception('legacy encryption round trip failed');
    }
});
exit($failures ? 1 : 0);
