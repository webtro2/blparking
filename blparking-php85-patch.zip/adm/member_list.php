<?php
$sub_menu = "200100";
include_once('./_common.php');

auth_check($auth[$sub_menu] ?? '', 'r');

$sql_common = " from {$g5['member_table']} ";

$sql_search = " where (1) ";
if ($stx) {
    $sql_search .= " and ( ";
    switch ($sfl) {
        case 'mb_point' :
            $sql_search .= " ({$sfl} >= '{$stx}') ";
            break;
        case 'mb_level' :
            $sql_search .= " ({$sfl} = '{$stx}') ";
            break;
        case 'mb_tel' :
        case 'mb_hp' :
            $sql_search .= " ({$sfl} like '%{$stx}') ";
            break;
		case 'mb_1' :
			$sql = " select ca_id, ca_name from {$g5['g5_mem_category_table']}
						  where ca_name like '%$stx%' ";
			$row = sql_fetch($sql);
            $sql_search .= " ({$sfl} like '%{$row['ca_id']}') ";
            break;
        default :
            $sql_search .= " ({$sfl} like '{$stx}%') ";
            break;
    }
    $sql_search .= " ) ";
}

if ($is_admin != 'super')
    $sql_search .= " and mb_level <= '{$member['mb_level']}' ";

if (!$sst) {
    $sst = "mb_datetime";
    $sod = "desc";
}

$sql_order = " order by {$sst} {$sod} ";

$sql = " select count(*) as cnt {$sql_common} {$sql_search} {$sql_order} ";
$row = sql_fetch($sql);
$total_count = $row['cnt'];

$rows = $config['cf_page_rows'];
$total_page  = ceil($total_count / $rows);  // 전체 페이지 계산
if ($page < 1) $page = 1; // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record = ($page - 1) * $rows; // 시작 열을 구함

// 탈퇴회원수
$sql = " select count(*) as cnt {$sql_common} {$sql_search} and mb_leave_date <> '' {$sql_order} ";
$row = sql_fetch($sql);
$leave_count = $row['cnt'];

// 차단회원수
$sql = " select count(*) as cnt {$sql_common} {$sql_search} and mb_intercept_date <> '' {$sql_order} ";
$row = sql_fetch($sql);
$intercept_count = $row['cnt'];

$listall = '<a href="'.$_SERVER['SCRIPT_NAME'].'" class="ov_listall">전체목록</a>';

$g5['title'] = '회원관리';
include_once('./admin.head.php');

$sql = " select * {$sql_common} {$sql_search} {$sql_order} limit {$from_record}, {$rows} ";
$result = sql_query($sql);

$colspan = 16;
?>

<?php
$memstx = $memstx ?? '';
$memsfl = $memsfl ?? '';
$memsave_stx = $memsave_stx ?? '';
$mempage = $mempage ?? 1;
$memsst = $memsst ?? '';
$memsod = $memsod ?? 'asc';
$memwhere = " where ";
$memsql_search = "";
if ($memstx != "") {
    if ($memsfl != "") {
        $memsql_search .= " $memwhere $sfl like '%$memstx%' ";
        $memwhere = " and ";
    }
    if ($memsave_stx && ($memsave_stx != $memstx))
        $mempage = 1;
}

$memsql_common = " from {$g5['g5_mem_category_table']} ";
if ($is_admin != 'super')
    $memsql_common .= " $memwhere ca_mb_id = '{$member['mb_id']}' ";
$memsql_common .= $memsql_search;


// 테이블의 전체 레코드수만 얻음
$memsql = " select count(*) as cnt " . $memsql_common;

$memrow = sql_fetch($memsql);

$memtotal_count = $memrow['cnt'];

$memrows = $config['cf_page_rows'];
$memtotal_page  = ceil($memtotal_count / $memrows);  // 전체 페이지 계산
if ($mempage < 1) { $mempage = 1; } // 페이지가 없으면 첫 페이지 (1 페이지)
$memfrom_record = ($mempage - 1) * $memrows; // 시작 열을 구함

if (!$memsst)
{
    $memsst  = "ca_id";
    $memsod = "asc";
}
$memsql_order = "order by $memsst $memsod";

// 출력할 레코드를 얻음

$memsql  = " select *
             $memsql_common
             $memsql_order
             limit $memfrom_record, $memrows ";
$memresult = sql_query($memsql);
?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>
    .card {width:350px;}
    #hd_login_msg{display:none}
    li.cate{cursor: pointer}
    /* Absolute Center Spinner */
    .loading {
        display: none;
        position: fixed;
        z-index: 999;
        height: 2em;
        width: 2em;
        overflow: visible;
        margin: auto;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
    }

    /* Transparent Overlay */
    .loading:before {
        content: '';
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.3);
    }

    /* :not(:required) hides these rules from IE9 and below */
    .loading:not(:required) {
        /* hide "loading..." text */
        font: 0/0 a;
        color: transparent;
        text-shadow: none;
        background-color: transparent;
        border: 0;
    }

    .loading:not(:required):after {
        content: '';
        display: block;
        font-size: 10px;
        width: 1em;
        height: 1em;
        margin-top: -0.5em;
        -webkit-animation: spinner 1500ms infinite linear;
        -moz-animation: spinner 1500ms infinite linear;
        -ms-animation: spinner 1500ms infinite linear;
        -o-animation: spinner 1500ms infinite linear;
        animation: spinner 1500ms infinite linear;
        border-radius: 0.5em;
        -webkit-box-shadow: rgba(0, 0, 0, 0.75) 1.5em 0 0 0, rgba(0, 0, 0, 0.75) 1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) 0 1.5em 0 0, rgba(0, 0, 0, 0.75) -1.1em 1.1em 0 0, rgba(0, 0, 0, 0.5) -1.5em 0 0 0, rgba(0, 0, 0, 0.5) -1.1em -1.1em 0 0, rgba(0, 0, 0, 0.75) 0 -1.5em 0 0, rgba(0, 0, 0, 0.75) 1.1em -1.1em 0 0;
        box-shadow: rgba(0, 0, 0, 0.75) 1.5em 0 0 0, rgba(0, 0, 0, 0.75) 1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) 0 1.5em 0 0, rgba(0, 0, 0, 0.75) -1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) -1.5em 0 0 0, rgba(0, 0, 0, 0.75) -1.1em -1.1em 0 0, rgba(0, 0, 0, 0.75) 0 -1.5em 0 0, rgba(0, 0, 0, 0.75) 1.1em -1.1em 0 0;
    }

    /* Animation */

    @-webkit-keyframes spinner {
        0% {
            -webkit-transform: rotate(0deg);
            -moz-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            -o-transform: rotate(0deg);
            transform: rotate(0deg);
        }
        100% {
            -webkit-transform: rotate(360deg);
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -o-transform: rotate(360deg);
            transform: rotate(360deg);
        }
    }
    @-moz-keyframes spinner {
        0% {
            -webkit-transform: rotate(0deg);
            -moz-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            -o-transform: rotate(0deg);
            transform: rotate(0deg);
        }
        100% {
            -webkit-transform: rotate(360deg);
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -o-transform: rotate(360deg);
            transform: rotate(360deg);
        }
    }
    @-o-keyframes spinner {
        0% {
            -webkit-transform: rotate(0deg);
            -moz-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            -o-transform: rotate(0deg);
            transform: rotate(0deg);
        }
        100% {
            -webkit-transform: rotate(360deg);
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -o-transform: rotate(360deg);
            transform: rotate(360deg);
        }
    }
    @keyframes spinner {
        0% {
            -webkit-transform: rotate(0deg);
            -moz-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            -o-transform: rotate(0deg);
            transform: rotate(0deg);
        }
        100% {
            -webkit-transform: rotate(360deg);
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -o-transform: rotate(360deg);
            transform: rotate(360deg);
        }
    }
</style>

<table>
	<tr>
		<td style="width:400px;">
			<div class="loading">Loading&#8230;</div>
			<div class="container-fluid">
				<p class="py-2 border-bottom h6">부서관리</p>
				<div class="row">
					<div class="col cate-wrap" data-depth="1"></div>
				</div>
			</div>
			<div id="crisCsFileSel" style="display: none">
				<input type="hidden" name="mo_ca_id" id="mo_ca_id">

				<input type="text" name="mo_ca_name" id="mo_ca_name" class="form-control form-control-sm" placeholder="부서명">
			</div>
		</td>
		<td>
			<div class="local_ov01 local_ov">
				<?php echo $listall ?>
				<span class="btn_ov01"><span class="ov_txt">총회원수 </span><span class="ov_num"> <?php echo number_format($total_count) ?>명 </span></span>
				<a href="?sst=mb_intercept_date&amp;sod=desc&amp;sfl=<?php echo $sfl ?>&amp;stx=<?php echo $stx ?>" class="btn_ov01"> <span class="ov_txt">차단 </span><span class="ov_num"><?php echo number_format($intercept_count) ?>명</span></a>
				<a href="?sst=mb_leave_date&amp;sod=desc&amp;sfl=<?php echo $sfl ?>&amp;stx=<?php echo $stx ?>" class="btn_ov01"> <span class="ov_txt">탈퇴  </span><span class="ov_num"><?php echo number_format($leave_count) ?>명</span></a>
			</div>

			<form id="fsearch" name="fsearch" class="local_sch01 local_sch" method="get">

			<label for="sfl" class="sound_only">검색대상</label>
			<select name="sfl" id="sfl">
				<option value="mb_id"<?php echo get_selected(($_GET['sfl'] ?? ''), "mb_id"); ?>>회원아이디</option>
				<option value="mb_1"<?php echo get_selected(($_GET['sfl'] ?? ''), "mb_1"); ?>>부서명</option>
				<option value="mb_name"<?php echo get_selected(($_GET['sfl'] ?? ''), "mb_name"); ?>>이름</option>
				<option value="mb_level"<?php echo get_selected(($_GET['sfl'] ?? ''), "mb_level"); ?>>권한</option>
				<option value="mb_tel"<?php echo get_selected(($_GET['sfl'] ?? ''), "mb_tel"); ?>>전화번호</option>
				<option value="mb_hp"<?php echo get_selected(($_GET['sfl'] ?? ''), "mb_hp"); ?>>휴대폰번호</option>
			</select>
			<label for="stx" class="sound_only">검색어<strong class="sound_only"> 필수</strong></label>
			<input type="text" name="stx" value="<?php echo $stx ?>" id="stx" required class="required frm_input">
			<input type="submit" class="btn_submit" value="검색">

			</form>

			<div class="local_desc01 local_desc">
				<p>
					회원자료 삭제 시 다른 회원이 기존 회원아이디를 사용하지 못하도록 회원아이디, 이름, 닉네임은 삭제하지 않고 영구 보관합니다.
				</p>
			</div>
			
			<form name="fmemberlist" id="fmemberlist" action="./member_list_update.php" onsubmit="return fmemberlist_submit(this);" method="post">
			<input type="hidden" name="sst" value="<?php echo $sst ?>">
			<input type="hidden" name="sod" value="<?php echo $sod ?>">
			<input type="hidden" name="sfl" value="<?php echo $sfl ?>">
			<input type="hidden" name="stx" value="<?php echo $stx ?>">
			<input type="hidden" name="page" value="<?php echo $page ?>">
			<input type="hidden" name="token" value="">

			<div class="tbl_head01 tbl_wrap">
				<table>
				<caption><?php echo $g5['title']; ?> 목록</caption>
				<thead>
				<tr>
					<th scope="col" id="mb_list_chk">
						<label for="chkall" class="sound_only">회원 전체</label>
						<input type="checkbox" name="chkall" value="1" id="chkall" onclick="check_all(this.form)">
					</th>
					<th scope="col" id="mb_list_id"><?php echo subject_sort_link('mb_id') ?>아이디</a></th>
					<th scope="col" id="mb_list_name"><?php echo subject_sort_link('mb_name') ?>이름</a></th>
					<th scope="col" id="mb_list_cate">부서명</th>
					<th scope="col" id="mb_list_auth">상태</th>
					<th scope="col" id="mb_list_deny"><?php echo subject_sort_link('mb_level', '', 'desc') ?>권한</a></th>
					<th scope="col" id="mb_list_mobile">휴대폰</th>
					<th scope="col" id="mb_list_tel">전화번호</th>
					<th scope="col" id="mb_list_join"><?php echo subject_sort_link('mb_datetime', '', 'desc') ?>가입일</a></th>
					<th scope="col" id="mb_list_lastcall"><?php echo subject_sort_link('mb_today_login', '', 'desc') ?>최종접속</a></th>
					<th scope="col" id="mb_list_mng">관리</th>
				</tr>
				</thead>
				<tbody>
				<?php
				for ($i=0; $row=sql_fetch_array($result); $i++) {
					// 접근가능한 그룹수
					$sql2 = " select count(*) as cnt from {$g5['group_member_table']} where mb_id = '{$row['mb_id']}' ";
					$row2 = sql_fetch($sql2);
					$group = '';
					if ($row2['cnt'])
						$group = '<a href="./boardgroupmember_form.php?mb_id='.$row['mb_id'].'">'.$row2['cnt'].'</a>';

					if ($is_admin == 'group') {
						$s_mod = '';
					} else {
						$s_mod = '<a href="./member_form.php?'.$qstr.'&amp;w=u&amp;mb_id='.$row['mb_id'].'" class="btn btn_03">수정</a>';
					}
					$s_grp = '<a href="./boardgroupmember_form.php?mb_id='.$row['mb_id'].'" class="btn btn_02">그룹</a>';

					$leave_date = $row['mb_leave_date'] ? $row['mb_leave_date'] : date('Ymd', G5_SERVER_TIME);
					$intercept_date = $row['mb_intercept_date'] ? $row['mb_intercept_date'] : date('Ymd', G5_SERVER_TIME);

					$mb_nick = get_sideview($row['mb_id'], get_text($row['mb_nick']), $row['mb_email'], $row['mb_homepage']);

					$mb_id = $row['mb_id'];
					$leave_msg = '';
					$intercept_msg = '';
					$intercept_title = '';
					if ($row['mb_leave_date']) {
						$mb_id = $mb_id;
						$leave_msg = '<span class="mb_leave_msg">탈퇴함</span>';
					}
					else if ($row['mb_intercept_date']) {
						$mb_id = $mb_id;
						$intercept_msg = '<span class="mb_intercept_msg">차단됨</span>';
						$intercept_title = '차단해제';
					}
					if ($intercept_title == '')
						$intercept_title = '차단하기';

					$address = $row['mb_zip1'] ? print_address($row['mb_addr1'], $row['mb_addr2'], $row['mb_addr3'], $row['mb_addr_jibeon']) : '';

					$bg = 'bg'.($i%2);

					switch($row['mb_certify']) {
						case 'hp':
							$mb_certify_case = '휴대폰';
							$mb_certify_val = 'hp';
							break;
						case 'ipin':
							$mb_certify_case = '아이핀';
							$mb_certify_val = '';
							break;
						case 'admin':
							$mb_certify_case = '관리자';
							$mb_certify_val = 'admin';
							break;
						default:
							$mb_certify_case = '&nbsp;';
							$mb_certify_val = 'admin';
							break;
					}
				?>

				<tr class="<?php echo $bg; ?>">
					<td headers="mb_list_chk" class="td_chk">
						<input type="hidden" name="mb_id[<?php echo $i ?>]" value="<?php echo $row['mb_id'] ?>" id="mb_id_<?php echo $i ?>">
						<label for="chk_<?php echo $i; ?>" class="sound_only"><?php echo get_text($row['mb_name']); ?> <?php echo get_text($row['mb_nick']); ?>님</label>
						<input type="checkbox" name="chk[]" value="<?php echo $i ?>" id="chk_<?php echo $i ?>">
					</td>
					<td headers="mb_list_id" class="td_name sv_use">
						<?php echo $mb_id ?>
						<?php
						//소셜계정이 있다면
						if(function_exists('social_login_link_account')){
							if( $my_social_accounts = social_login_link_account($row['mb_id'], false, 'get_data') ){
								
								echo '<div class="member_social_provider sns-wrap-over sns-wrap-32">';
								foreach( (array) $my_social_accounts as $account){     //반복문
									if( empty($account) || empty($account['provider']) ) continue;
									
									$provider = strtolower($account['provider']);
									$provider_name = social_get_provider_service_name($provider);
									
									echo '<span class="sns-icon sns-'.$provider.'" title="'.$provider_name.'">';
									echo '<span class="ico"></span>';
									echo '<span class="txt">'.$provider_name.'</span>';
									echo '</span>';
								}
								echo '</div>';
							}
						}
						?>
					</td>
					<td headers="mb_list_name" class="td_mbname"><?php echo get_text($row['mb_name']); ?></td>
					<td headers="mb_list_cate" class="td_mbcate">
						<select name="mb_1" id="mb_1">
						<?php
						$sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} order by ca_id desc";
						$result2 = sql_query($sql2);
						for ($i=0; $row2=sql_fetch_array($result2); $i++) {
						?>
						<option value="<?php echo $row2['ca_id'];?>"<?php echo get_selected($row2['ca_id'], $row['mb_1']); ?>><?php echo $row2['ca_name']; ?></option>
						<?php } ?>
					</select>
					</td>
					<td headers="mb_list_auth" class="td_mbstat">
						<?php
						if ($leave_msg || $intercept_msg) echo $leave_msg.' '.$intercept_msg;
						else echo "정상";
						?>
					</td>
					<td headers="mb_list_auth" class="td_mbstat">
						<?php echo get_member_level_select("mb_level[$i]", 1, $member['mb_level'], $row['mb_level']) ?>
					</td>
					<td headers="mb_list_mobile" class="td_tel"><?php echo get_text($row['mb_hp']); ?></td>
					<td headers="mb_list_tel" class="td_tel"><?php echo get_text($row['mb_tel']); ?></td>
					<td headers="mb_list_join" class="td_date"><?php echo substr($row['mb_datetime'],2,8); ?></td>
					<td headers="mb_list_lastcall" class="td_date"><?php echo substr($row['mb_today_login'],2,8); ?></td>
					<td headers="mb_list_mng" class="td_mng td_mng_s"><?php echo $s_mod ?><?php echo $s_grp ?></td>
				</tr>

				<?php
				}
				if ($i == 0)
					echo "<tr><td colspan=\"".$colspan."\" class=\"empty_table\">자료가 없습니다.</td></tr>";
				?>
				</tbody>
				</table>
			</div>
		</td>
	</tr>
</table>



<div class="btn_fixed_top">
    <input type="submit" name="act_button" value="선택수정" onclick="document.pressed=this.value" class="btn btn_02">
    <input type="submit" name="act_button" value="선택삭제" onclick="document.pressed=this.value" class="btn btn_02">
    <?php if ($is_admin == 'super') { ?>
    <a href="<?php echo G5_ADMIN_URL; ?>/member_form.php" id="member_add" class="btn btn_01">회원추가</a>
    <?php } ?>

</div>


</form>

<?php echo get_paging(G5_IS_MOBILE ? $config['cf_mobile_pages'] : $config['cf_write_pages'], $page, $total_page, '?'.$qstr.'&amp;page='); ?>

<script>
function fmemberlist_submit(f)
{
    if (!is_checked("chk[]")) {
        alert(document.pressed+" 하실 항목을 하나 이상 선택하세요.");
        return false;
    }

    if(document.pressed == "선택삭제") {
        if(!confirm("선택한 자료를 정말 삭제하시겠습니까?")) {
            return false;
        }
    }

    return true;
}
</script>


<script src="<?php echo G5_ADMIN_URL ?>/admin.js?ver=<?php echo G5_JS_VER; ?>"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>
<script>
    var $loading = $('.loading').hide();
    $(document)
        .ajaxStart(function () {
            $loading.show();
        })
        .ajaxStop(function () {
            $loading.hide();
        });
    $(document).ready(function () {

        function get_cate_list(depth,ca_id){
            var $cate_wrap = $(".cate-wrap[data-depth="+depth+"]");

            if($cate_wrap.length==0){
                alert(depth+'부서 cate-wrap을 만들어주세요.');
                return false;
            }
            $(".cate-wrap").each(function (i,e) {
               var e_depth = $(e).data('depth');
               if(e_depth>depth){
                   $(e).html('');
               }
            });
            $.post('<?=G5_ADMIN_URL?>/memcategorylist_newwin_get.php',{ca_id:ca_id},function (html) {
                $cate_wrap.html(html)
                $cate_wrap.find("input[name=ca_name]").focus().select();
            },'html');
        }

        get_cate_list(1);

        $(document).on('submit','.cate-wrap form',function () {

            var $this = $(this);
            var $cate_wrap = $this.closest('.cate-wrap');
            var depth = $cate_wrap.data('depth');
            var parent_ca_id = $this.find('input[name=parent_ca_id]').val();

            var token = get_ajax_token();

            if(!token) {
                alert("토큰 정보가 올바르지 않습니다.");
                return false;
            }



            if(typeof this.token === "undefined")
                $this.prepend('<input type="hidden" name="token" value="">');

            $this.find("input[name=token]").val(token);

            this.action = '<?=G5_ADMIN_URL?>/memcategoryformupdate.php';
            this.method = 'post';
            $this.ajaxSubmit({
                dataType:'html',
                success: function(html) {
                    var chk = check_error(html);
                    if(chk!==true){
                        alert(chk);
                        return false;
                    }
                    get_cate_list(depth,parent_ca_id);
                },
                error: function () {
                    alert('서버에러')
                }
            });

            return false;
        });

        /*$(document).on('click','li.cate',function () {
            var $this = $(this);
            var depth = $this.closest('.cate-wrap').data('depth');
            var ca_id = $this.data('ca-id');
            get_cate_list(depth+1,ca_id)
        });*/

        $(document).on('click','li.list-group-item .cate-delete',function (e) {
            e.preventDefault();
            e.stopPropagation();

            if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n정말 삭제하시겠습니까?")==false) {
                return false;
            }

            var $cate_wrap = $(this).closest('.cate-wrap');
            var depth = $cate_wrap.data('depth');
            var parent_ca_id = $cate_wrap.find('input[name=parent_ca_id]').val();
            var href = $(this).attr('href');


            var token = get_ajax_token();
            if(!token) {
                alert("토큰 정보가 올바르지 않습니다.");
                return false;
            }
            href = href+"&token="+token;

            $.ajax({
                url: href,
                success: function (html) {

                    var chk = check_error(html);
                    if(chk!==true){
                        alert(chk);
                        return false;
                    }
                    alert('삭제완료');
                    get_cate_list(depth,parent_ca_id);
                },
                fail: function () {
                    alert('서버에러')
                },
                dataType: 'html'
            })
        });

        $(document).on('click','li.list-group-item .cate-mod',function (e) {
            e.preventDefault();
            e.stopPropagation();
			


            var $cate_wrap = $(this).closest('.cate-wrap');
            var depth = $cate_wrap.data('depth');
            var parent_ca_id = $cate_wrap.find('input[name=parent_ca_id]').val();
            var ca_id =$(this).data('code');
            var ca_name =$(this).data('coname');
            var ca_name2 =$(this).data('coname2');
            $("#mo_ca_id").val(ca_id);
            $("#mo_ca_name").val(ca_name);
            //$("#mo_ca_name2").val(ca_name2);
            // 다이얼로그 띄우기
            $("#crisCsFileSel").dialog({
                resizable    : false,
                autoOpen: false,
                height: 180,
                width: 500,
                modal: true,
                buttons: {
                    "수정": function() {

                    },
                    "취소": function() {
                        $( this ).dialog( "close" );
                       // self.close();
                    }
                }
            });

            $("#crisCsFileSel").dialog( "open" );

            // 확인버튼 클릭하기
            $('.ui-button:contains("수정")').click(function(){
                ca_name =$("#mo_ca_name").val();
                 mod_update(ca_id, ca_name,parent_ca_id,depth);
            });
            //닫기버튼 클릭시 데이타 지우기
            //$(".ui-dialog-titlebar-close").click(function(){
            //    $("#item_list").empty();
            //    $("#search_item").height(49);
            //    $("#search_name").val("");
            //});



        });

        function mod_update(ca_id,ca_name,parent_ca_id,depth){
            ca_name = ca_name.replace("&","|");
            $.ajax({
                type     : "POST"
                ,url      : "./memajaxmod_update.php"
                ,data     : "ca_id="+ca_id+"&ca_name="+ca_name
                ,async    : false
                ,success  : function(data) {
                    alert('수정완료');
                    get_cate_list(depth,parent_ca_id);
                    $(".ui-dialog-titlebar-close").trigger('click');
                }
                ,error    : function(jqXHR, textStatus, errorThrown) {
                    alert(jqXHR.status + " - " + jqXHR.statusText);
                }
            });
        }

        function check_error(html){
            var myRegExp1 = /validation_check/;
            var myRegExp2 = /<p class="cbg">([\s\S]+)<\/p>/gm;
            var err_msg ='';

            if(myRegExp1.test(html)){

                err_msg = myRegExp2.exec(html)[1].replace(/<br>/gi, "\n").replace(/<br>/gi, "\n").trim();
                return err_msg;
            }
            return true;

        }
    })
</script>



<?php
include_once ('./admin.tail.php');
?>
