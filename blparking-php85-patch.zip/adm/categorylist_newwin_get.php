<?php
$sub_menu = '400200';
include_once('./_common.php');
$where = array();
$sql_where = '';

$len = strlen($ca_id);
if ($len == 10)
    alert("분류를 더 이상 추가할 수 없습니다.\\n\\n5단계 분류까지만 가능합니다.");

$len2 = $len + 1;

$sql = " select MAX(SUBSTRING(ca_id,$len2,2)) as max_subid from {$g5['g5_shop_category_table']}
              where SUBSTRING(ca_id,1,$len) = '$ca_id' ";
$row = sql_fetch($sql);

$subid = base_convert($row['max_subid'], 36, 10);
$subid += 36;
if ($subid >= 36 * 36)
{
    //alert("분류를 더 이상 추가할 수 없습니다.");
    // 빈상태로
    $subid = "  ";
}
$subid = base_convert($subid, 10, 36);
$subid = substr("00" . $subid, -2);
$subid = $ca_id . $subid;

if($ca_id){
    $len2 =  strlen($ca_id) + 2;
    $where[] = " ca_id like '$ca_id%' and length(ca_id) = $len2 ";
}else{
    $where[] = " length(ca_id) = 2 ";
}

if(count($where)){
    $sql_where = "where ".implode('and',$where);
}


$sql  = " select * from {$g5['g5_shop_category_table']}  $sql_where order by ca_id asc ";

$result = sql_query($sql);



?>

<div class="card">
    <?php if($ca_id){?>
        <div class="card-header">
            <?php 
            $parent = sql_fetch("select * from {$g5['g5_shop_category_table']} where ca_id = '{$ca_id}'");
            ?>
            <?=$parent['ca_name']?>의 하위분류
        </div>
    <?php }?>
    <div class="card-body">
        <form action="">
            <div class="form-group">
                <input type="hidden" name="parent_ca_id" value="<?=$ca_id?>">
                <input type="hidden" name="ca_id" value="<?=$subid?>">
                <input type="hidden" name="ca_skin_dir" value="theme/basic">
                <input type="hidden" name="ca_skin" value="list.10.skin.php">
                <input type="hidden" name="ca_img_width" value="230">
                <input type="hidden" name="ca_img_height" value="230">
                <input type="hidden" name="ca_list_mod" value="3">
                <input type="hidden" name="ca_list_row" value="5">
                <input type="hidden" name="ca_mobile_skin" value="list.10.skin.php">
                <input type="hidden" name="ca_mobile_img_width" value="230">
                <input type="hidden" name="ca_mobile_img_height" value="230">
                <input type="hidden" name="ca_mobile_list_mod" value="3">
                <input type="hidden" name="ca_mobile_list_row" value="5">
                <input type="hidden" name="ca_stock_qty" value="99999">
                <input type="hidden" name="ca_use" value="1">
                <input type="hidden" name="codedup" value="1">


                <input type="text" name="ca_name" class="form-control form-control-sm"  required placeholder="분류명">
            </div>
            <button type="submit" class="btn btn-sm btn-outline-dark btn-block" >만들기</button>

        </form>
    </div>
    <ul class="list-group list-group-flush cate-list">
        <?php for ($i=0;$row=sql_fetch_array($result);$i++){
            ?>
            <li class="list-group-item cate " data-ca-id="<?=$row['ca_id']?>">
                <?=$row['ca_name']?>
                <a href="<?=G5_ADMIN_URL?>/category/categoryformupdate.php?w=d&ca_id=<?=$row['ca_id']?>" class="cate-delete float-right"><span class="badge badge-danger p-1">삭제</span></a>
                <a href="<?=G5_ADMIN_URL?>/category/categoryformupdate.php?w=d&ca_id=<?=$row['ca_id']?>" class="cate-mod float-right" data-coname="<?=$row['ca_name']?>"  data-coname2="<?=$row['ca_name2']?>" data-code="<?=$row['ca_id']?>" ><span class="badge badge-danger2 p-1">수정</span></a>
            </li>
        <?php }?>
        <?php if($i==0){?>
            <li class="list-group-item">등록 된 분류가 없습니다.</li>
        <?php }?>
    </ul>
</div>