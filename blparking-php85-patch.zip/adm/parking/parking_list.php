<?php
$sub_menu = '200200';
include_once('./_common.php');

auth_check($auth[$sub_menu] ?? '', "r");

//내용(컨텐츠)정보 테이블이 있는지 검사한다.
if(!sql_query(" DESCRIBE {$g5['parking_list']} ", false)) {
   sql_query(" CREATE TABLE IF NOT EXISTS `{$g5['parking_list']}` (
			  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
			  `car_nem` varchar(255) NOT NULL DEFAULT '',
			  `mb_id` varchar(100) NOT NULL DEFAULT '',
			  `ca_id` varchar(100) NOT NULL DEFAULT '',
			  `pk_up_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			  `pk_out_chk` int(11) NOT NULL DEFAULT '0',
			  `pk_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			  `pk_end_chk` int(11) NOT NULL DEFAULT '0',
			  `pk_end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			  PRIMARY KEY (`pk_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 ", true);
}


$g5['title'] = '주차장 출차관리';
include_once (G5_ADMIN_PATH.'/admin.head.php');
include_once(G5_PLUGIN_PATH.'/jquery-ui/datepicker.php');

$where = array();
foreach (array('doc', 'sort1', 'sort2', 'sel_field', 'od_status', 'search', 'fr_date', 'to_date', 'fr_date2', 'to_date2') as $filter_name) {
    if (!isset($$filter_name) || !is_string($$filter_name)) $$filter_name = '';
}

$doc = strip_tags($doc);
$sort1 = in_array($sort1, array('pk_id', 'car_nem' , 'mbname', 'caname', 'pk_out_time', 'pk_out_chk', 'pk_end_time')) ? $sort1 : '';
$sort2 = in_array($sort2, array('desc', 'asc')) ? $sort2 : 'desc';
$sel_field = get_search_string($sel_field);
if( !in_array($sel_field, array('pk_id', 'car_nem', 'mbname', 'caname', 'pk_out_time', 'pk_out_chk', 'pk_end_time')) ){   //검색할 필드 대상이 아니면 값을 제거
    $sel_field = '';
}
$od_status = get_search_string($od_status);
$search = get_search_string($search);
if(! preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $fr_date) ) $fr_date = '';
if(! preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $to_date) ) $to_date = '';

$sql_search = "";

//$sql = "select * from {$g5['parking_list']} where ca_id = ".$row['ca_id'];

if ($search != "") {
	if ($sel_field == 'caname') { // 부서명
		$sql = "select * from {$g5['g5_mem_category_table']} where ca_name = '".$search."' ";
		$caid = sql_fetch($sql);
		$where[] = " ca_id = '{$caid['ca_id']}' ";
	} else if ($sel_field == 'mbname') { // 회원명
		$sql = "select * from {$g5['member_table']} where mb_name = '".$search."' ";
		$mbid = sql_fetch($sql);
		$where[] = " mb_id = '{$mbid['mb_id']}' ";
	} else { // 차량번호
		$where[] = " $sel_field like '%$search%' ";
	}
    if ($save_search != $search) {
        $page = 1;
    }
}


if ($fr_date && $to_date) {
    $where[] = " pk_out_time between '$fr_date 00:00:00' and '$to_date 23:59:59' ";
}

if ($fr_date2 && $to_date2) {
    $where[] = " pk_end_time between '$fr_date2 00:00:00' and '$to_date2 23:59:59' ";
}

if ($where) {
    $sql_search = ' where '.implode(' and ', $where);
}

if ($sel_field == "")  $sel_field = "pk_id";
if ($sort1 == "") $sort1 = "pk_id";
if ($sort2 == "") $sort2 = "desc";

$sql_common = " from {$g5['parking_list']} $sql_search ";

$sql = " select count(pk_id) as cnt " . $sql_common;
$row = sql_fetch($sql);
$total_count = $row['cnt'];

$rows = $config['cf_page_rows'];
$total_page  = ceil($total_count / $rows);  // 전체 페이지 계산
if ($page < 1) { $page = 1; } // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record = ($page - 1) * $rows; // 시작 열을 구함

$sql  = " select * 
           $sql_common
           order by $sort1 $sort2
           limit $from_record, $rows ";
$result = sql_query($sql);

// 주문자기준을 상품기준으로 통합변경
$chk_cnt = 0;


$qstr1 = "fr_date=$fr_date&amp;to_date=$to_date&amp;fr_date2=$fr_date2&amp;to_date2=$to_date2&amp;sel_field=$sel_field&amp;search=$search&amp;save_search=$search";

$qstr = "$qstr1&amp;sort1=$sort1&amp;sort2=$sort2&amp;page=$page";

$listall = '<a href="'.$_SERVER['SCRIPT_NAME'].'" class="ov_listall">전체목록</a>';
$colspan = 6;

?>


<div class="local_ov01 local_ov">
    <?php echo $listall; ?>
    <span class="btn_ov01"><span class="ov_txt">전체 출차내역</span><span class="ov_num"> <?php echo number_format($total_count); ?>건</span></span>
</div>


<form name="frmorderlist" class="local_sch01 local_sch">
<input type="hidden" name="doc" value="<?php echo $doc; ?>">
<input type="hidden" name="sort1" value="<?php echo $sort1; ?>">
<input type="hidden" name="sort2" value="<?php echo $sort2; ?>">
<input type="hidden" name="page" value="<?php echo $page; ?>">
<input type="hidden" name="save_search" value="<?php echo $search; ?>">

<label for="sel_field" class="sound_only">검색대상</label>
<select name="sel_field" id="sel_field">
    <option value="pk_nem" <?php echo get_selected($sel_field, 'car_nem'); ?>>차번호</option>
    <option value="caname" <?php echo get_selected($sel_field, 'caname'); ?>>부서명</option>
    <option value="mbname" <?php echo get_selected($sel_field, 'mbname'); ?>>회원명</option>
</select>

<label for="search" class="sound_only">검색어<strong class="sound_only"> 필수</strong></label>
<input type="text" name="search" value="<?php echo $search; ?>" id="search" required class="required frm_input" autocomplete="off">
<input type="submit" value="검색" class="btn_submit">

</form>

<form class="local_sch03 local_sch">
<div class="sch_last">
    <strong>출차일자</strong>
    <input type="text" id="fr_date"  name="fr_date" value="<?php echo $fr_date; ?>" class="frm_input" size="10" maxlength="10"> ~
    <input type="text" id="to_date"  name="to_date" value="<?php echo $to_date; ?>" class="frm_input" size="10" maxlength="10">
    <button type="button" onclick="javascript:set_date('오늘');">오늘</button>
    <button type="button" onclick="javascript:set_date('어제');">어제</button>
    <button type="button" onclick="javascript:set_date('이번주');">이번주</button>
    <button type="button" onclick="javascript:set_date('이번달');">이번달</button>
    <button type="button" onclick="javascript:set_date('지난주');">지난주</button>
    <button type="button" onclick="javascript:set_date('지난달');">지난달</button>
    <button type="button" onclick="javascript:set_date('전체');">전체</button>
    <input type="submit" value="검색" class="btn_submit">
</div>
</form>


<form name="forderlist" id="forderlist" onsubmit="return forderlist_submit(this);" method="post" autocomplete="off">

<div class="tbl_head01 tbl_wrap">
    <table id="sodr_list">
    <caption>출차 내역 목록</caption>
    <thead>
    <tr>
        <th scope="col" id="mb_list_chk">
			<label for="chkall" class="sound_only">전체선택</label>
			<input type="checkbox" name="chkall" value="1" id="chkall" onclick="check_all(this.form)">
		</th>
		<th scope="col" id="mb_list_id"><?php echo subject_sort_link('pk_id') ?>출차코드</a></th>
		<th scope="col" id="mb_list_name"><?php echo subject_sort_link('car_nem') ?>차번호</a></th>
		<th scope="col" id="mb_list_cate">부서명</th>
		<th scope="col" id="mb_list_auth">회원명</th>
		<th scope="col" id="mb_list_join"><?php echo subject_sort_link('pk_up_time', '', 'desc') ?>출차요청시간</a></th>
		<th scope="col" id="mb_list_join"><?php echo subject_sort_link('pk_out_time', '', 'desc') ?>출차시간</a></th>
    </tr>
    </thead>
    <tbody>
	<?php
	for ($i=0; $row=sql_fetch_array($result); $i++) {

        $bg = 'bg'.($i%2);
        $td_color = 0;
		$mb = get_member($row['mb_id']);
		
		$sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = ".$row['ca_id']." order by ca_id desc";
		$row2 = sql_fetch($sql2);
	?>
	<tr class="<?php echo $bg; ?>">
		<td headers="mb_list_chk" class="td_chk">
			<input type="hidden" name="pk_id[<?php echo $i ?>]" value="<?php echo $row['pk_id'] ?>" id="pk_id_<?php echo $i ?>">
			<label for="chk_<?php echo $i; ?>" class="sound_only">차량번호<?php echo get_text($row['car_nem']); ?> <?php echo get_text($row['car_nem']); ?></label>
			<input type="checkbox" name="chk[]" value="<?php echo $i ?>" id="chk_<?php echo $i ?>">
		</td>
		<td headers="mb_list_id" class="td_name sv_use"><?php echo $row['pk_id']; ?></td>
		<td headers="mb_list_id" class="td_name"><?php echo $row['car_nem']; ?></td>
		<td headers="mb_list_name" class="td_name"><?php echo $row2['ca_name']; ?></td>
		<td headers="mb_list_auth" class="td_name"><?php echo $mb['mb_name']; ?></td>
		<td headers="mb_list_tel" class="td_date"><?php echo $row['pk_up_time']; ?></td>
		<td headers="mb_list_tel" class="td_date"><?php echo $row['pk_out_time']; ?></td>
	</tr>
	<?php } 
		if ($i == 0)
			echo "<tr><td colspan=\"".$colspan."\" class=\"empty_table\">자료가 없습니다.</td></tr>";
	?>
	</tbody>
	</table>

</div>

<div class="btn_fixed_top">
    <input type="submit" value="선택삭제" class="btn btn_01" onclick="document.pressed=this.value">
</div>
</form>

<?php echo get_paging(G5_IS_MOBILE ? $config['cf_mobile_pages'] : $config['cf_write_pages'], $page, $total_page, "{$_SERVER['SCRIPT_NAME']}?$qstr&amp;page="); ?>


<script>
$(function(){
    $("#fr_date, #fr_date2, #to_date, #to_date2").datepicker({ changeMonth: true, changeYear: true, dateFormat: "yy-mm-dd", showButtonPanel: true, yearRange: "c-99:c+99", maxDate: "+0d" });
});

function set_date(today)
{
    <?php
    $date_term = date('w', G5_SERVER_TIME);
    $week_term = $date_term + 7;
    $last_term = strtotime(date('Y-m-01', G5_SERVER_TIME));
    ?>
    if (today == "오늘") {
        document.getElementById("fr_date").value = "<?php echo G5_TIME_YMD; ?>";
        document.getElementById("to_date").value = "<?php echo G5_TIME_YMD; ?>";
    } else if (today == "어제") {
        document.getElementById("fr_date").value = "<?php echo date('Y-m-d', G5_SERVER_TIME - 86400); ?>";
        document.getElementById("to_date").value = "<?php echo date('Y-m-d', G5_SERVER_TIME - 86400); ?>";
    } else if (today == "이번주") {
        document.getElementById("fr_date").value = "<?php echo date('Y-m-d', strtotime('-'.$date_term.' days', G5_SERVER_TIME)); ?>";
        document.getElementById("to_date").value = "<?php echo date('Y-m-d', G5_SERVER_TIME); ?>";
    } else if (today == "이번달") {
        document.getElementById("fr_date").value = "<?php echo date('Y-m-01', G5_SERVER_TIME); ?>";
        document.getElementById("to_date").value = "<?php echo date('Y-m-d', G5_SERVER_TIME); ?>";
    } else if (today == "지난주") {
        document.getElementById("fr_date").value = "<?php echo date('Y-m-d', strtotime('-'.$week_term.' days', G5_SERVER_TIME)); ?>";
        document.getElementById("to_date").value = "<?php echo date('Y-m-d', strtotime('-'.($week_term - 6).' days', G5_SERVER_TIME)); ?>";
    } else if (today == "지난달") {
        document.getElementById("fr_date").value = "<?php echo date('Y-m-01', strtotime('-1 Month', $last_term)); ?>";
        document.getElementById("to_date").value = "<?php echo date('Y-m-t', strtotime('-1 Month', $last_term)); ?>";
    } else if (today == "전체") {
        document.getElementById("fr_date").value = "";
        document.getElementById("to_date").value = "";
    }
}

function set_date2(today)
{
    <?php
    $date_term = date('w', G5_SERVER_TIME);
    $week_term = $date_term + 7;
    $last_term = strtotime(date('Y-m-01', G5_SERVER_TIME));
    ?>
    if (today == "오늘") {
        document.getElementById("fr_date2").value = "<?php echo G5_TIME_YMD; ?>";
        document.getElementById("to_date2").value = "<?php echo G5_TIME_YMD; ?>";
    } else if (today == "어제") {
        document.getElementById("fr_date2").value = "<?php echo date('Y-m-d', G5_SERVER_TIME - 86400); ?>";
        document.getElementById("to_date2").value = "<?php echo date('Y-m-d', G5_SERVER_TIME - 86400); ?>";
    } else if (today == "이번주") {
        document.getElementById("fr_date2").value = "<?php echo date('Y-m-d', strtotime('-'.$date_term.' days', G5_SERVER_TIME)); ?>";
        document.getElementById("to_date2").value = "<?php echo date('Y-m-d', G5_SERVER_TIME); ?>";
    } else if (today == "이번달") {
        document.getElementById("fr_date2").value = "<?php echo date('Y-m-01', G5_SERVER_TIME); ?>";
        document.getElementById("to_date2").value = "<?php echo date('Y-m-d', G5_SERVER_TIME); ?>";
    } else if (today == "지난주") {
        document.getElementById("fr_date2").value = "<?php echo date('Y-m-d', strtotime('-'.$week_term.' days', G5_SERVER_TIME)); ?>";
        document.getElementById("to_date2").value = "<?php echo date('Y-m-d', strtotime('-'.($week_term - 6).' days', G5_SERVER_TIME)); ?>";
    } else if (today == "지난달") {
        document.getElementById("fr_date2").value = "<?php echo date('Y-m-01', strtotime('-1 Month', $last_term)); ?>";
        document.getElementById("to_date2").value = "<?php echo date('Y-m-t', strtotime('-1 Month', $last_term)); ?>";
    } else if (today == "전체") {
        document.getElementById("fr_date2").value = "";
        document.getElementById("to_date2").value = "";
    }
}
</script>

<script>

function forderlist_submit(f)
{
    if (!is_checked("chk[]")) {
        alert(document.pressed+" 하실 항목을 하나 이상 선택하세요.");
        return false;
    }

    if(document.pressed == "선택삭제") {
        if(!confirm("선택한 자료를 정말 삭제하시겠습니까?")) {
            return false;
        }
    }
	f.action = "./parking_list_del.php";
    return true;
}


</script>

<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');
?>