<?php 
include_once ("./_common.php");
$ca_name =str_replace("|","&",$ca_name);
$ca_name2 =str_replace("|","&",$ca_name2);
$sql ="update {$g5['g5_mem_category_table']} set ca_name ='{$ca_name}' where ca_id = '{$ca_id}' ";
sql_query($sql);
echo $sql;
?>