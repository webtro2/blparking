<?php
include_once("./_common.php");

if ($is_admin || ($_POST['ca_id'] == 10)) {
	$sql_s = '';
} else {
	$sql_s = "ca_id = '".$_POST['ca_id']."' and ";
}
?>
<script type="text/javascript">
function Play() {
    var audio = new Audio();
    audio.src = "bell.wav";
	audio.play();
}
</script>

<?php 

$sql = "select * from {$g5['parking_list']} where ".$sql_s."pk_end_chk = '0' order by pk_id desc";
$rs = sql_query($sql);
for ($i=0; $row=sql_fetch_array($rs); $i++) {
?>
	<tr class=" even">						
		<td class="">
			<?php echo $row['car_nem']; ?>									
		</td>
		<td class="td_caname">
			<?php
				$sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = ".$row['ca_id'];
				$row2 = sql_fetch($sql2);
			?>
			<?php echo $row2['ca_name']; ?>	
		</td>
		<td class="td_pkenddate"><span class="sv_member">
			<?php echo (!empty($row['pk_up_time']) && $row['pk_up_time'] !== '0000-00-00 00:00:00') ? getTime_Format($row['pk_up_time']) : '대기'; ?>
		</span></td>
		<td class="td_pkenddate"><span class="sv_member">
			<?php echo (!empty($row['pk_out_time']) && $row['pk_out_time'] !== '0000-00-00 00:00:00') ? getTime_Format($row['pk_out_time']) : '대기'; ?>
		</span></td>
		<td class="td_pkchk">
			<?php if ($row['pk_out_chk'] == 1) {?>
			<a href="#" class="d-none d-sm-inline-block btn btn-sm btn-gray shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 출차완료</a>
			<?php } else { ?>
			<?php $pkup_url2 = "mode=u&amp;pkid=".$row['pk_id'] ; ?>
			<script>Play()</script>
			<a href="<?php echo G5_THEME_URL; ?>/parkingout_up.php?<?php echo $pkup_url2; ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 출차대기</a>
			<?php  } ?>
		</td>
		<td class="td_pkchk">
			<?php if ($row['pk_end_chk'] == 1) {?>
			<a href="#" class="d-none d-sm-inline-block btn btn-sm btn-gray shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 퇴장</a>
			<?php } else { ?>
			<?php $pkup_url2 = "mode=d&amp;pkid=".$row['pk_id'] ; ?>
			<a href="<?php echo G5_THEME_URL; ?>/parkingout_up.php?<?php echo $pkup_url2; ?>" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 퇴장</a>
			<?php } ?>
		</td>
	</tr>
<?php } ?>