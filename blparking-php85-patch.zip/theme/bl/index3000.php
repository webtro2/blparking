<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

// 상단매뉴 숨기기
$head_mem_chk = 0; // 수기려면 0

include_once(G5_THEME_PATH.'/head.php');

if(defined('_INDEX_')) { // index에서만 실행
	include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
}
$test_color = array();
$test_color[0] = "text-primary";
$test_color[1] = "text-success";
$test_color[2] = "text-danger";
$test_color[3] = "text-info";
$test_color[4] = "text-warning";

$bl_color = array();
$bl_color[0] = "border-left-primary";
$bl_color[1] = "border-left-success";
$bl_color[2] = "border-left-danger";
$bl_color[3] = "border-left-info";
$bl_color[4] = "border-left-warning";
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
		  <?php
		  $sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = ".$member['mb_1'];
		  $row2 = sql_fetch($sql2);
		  ?>
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
			<h1 class="h1 mt-3 text-gray-800" style="margin:0 auto;"><?php echo $row2['ca_name']; ?> 출차<?php //echo '엽력'?></h1>
		  </div>

		  <div class="row">

            <div class="col-xl-6 col-md-6 mb-4">
				<?php echo display_banner('메인', 'mainbanner.skin.php'); ?>
			</div>

            <div class="col-xl-6 col-md-6 mb-4">
			<?php 
			$sql = "select * from {$g5['parking_list']} where pk_end_chk = '0' and ca_id = '{$member['mb_1']}' order by pk_id desc";
			$rs = sql_query($sql);
			for ($i=0; $row=sql_fetch_array($rs); $i++) {
			?>
				<!--목록출력-->
				<!-- Content Row -->
				  <div class="row">
					<!-- Earnings (Monthly) Card Example -->
					<div class="col-xl-12 col-md-12 mb-4">
					  <div class="card <?php echo $bl_color[0]; ?> shadow h-auto py-2">
						<div class="card-body">
						  <div class="row no-gutters align-items-center">
							<div class="col mr-2">
							  <div style="font-size:4rem" class="mb-1 font-weight-bold <?php echo $test_color[0]; ?> text-uppercase"><?php echo $row['car_nem']; ?></div>
							  <div style="font-size:2.5rem" class="font-weight-bold text-black text-uppercase mb-2">차량이 출차되었습니다.</div>
							</div>
							<div class="col-auto">
								<?php if ($row['pk_out_chk'] == 1) { ?>
									<i class="fas fa-volume-up fa-3x <?php echo $test_color[0]; ?>"></i>
								<?php } else { ?>
									<i class="fas fa-volume-up fa-3x text-gray-300"></i>
								<?php } ?>
							</div>
						  </div>
						</div>
					  </div>
					</div>

				  </div>
				<!--목록출력 끝-->
			<?php } ?>
			</div>

		  </div>
		  

          

        </div>
        <!-- /.container-fluid -->

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>