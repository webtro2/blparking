<?php
include_once('../../common.php');

// 오전오후 체크
function getTime_Format($date_str) {    

	$mons = date("m", strtotime($date_str));
	$days = date("d", strtotime($date_str));
	$hour = date("H", strtotime($date_str));
	$minute = date("i", strtotime($date_str));
	$ss = date("s", strtotime($date_str));

	if($hour > 12) {
		$hour = $hour - 12;
		$result = $mons."월 / ".$days."일 / PM ".$hour."시 : ".$minute."분 : ".$ss."초";
	} else {
		$result = $mons."월 / ".$days."일 / AM ".$hour."시 : ".$minute."분 : ".$ss."초";
	}
	return $result;
}

// Y년 m월 d일 H시 i분 s초
function getDatetime_Format($date_str) {
    return date("m월 d일 (h시 : i분 : s초)", strtotime($date_str));
}


?>