<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

// 상단매뉴 숨기기
$head_mem_chk = 0; // 수기려면 0

include_once(G5_THEME_PATH.'/head.php');

?>

        <!-- Begin Page Content -->
        <div class="container-fluid" style="padding:20px;">

          <!-- Page Heading -->
		  <?php
		  $sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = ".$member['mb_1'];
		  $row2 = sql_fetch($sql2);
		  ?>
          <!--<div class="d-sm-flex align-items-center justify-content-between mb-4">
			<h1 class="h1 mt-3 text-gray-800" style="margin:0 auto;"><?php echo $row2['ca_name']; ?> 출차<?php //echo '엽력'?></h1>
		  </div>-->

		  <div class="row mt-3">

            <div class="col-xl-7 col-md-7">
				<?php echo display_banner('메인', 'mainbanner.skin.php'); ?>
			</div>

            <div class="col-xl-5 col-md-5" id="plist">
			
			</div>

		  </div>
		  
        </div>
        <!-- /.container-fluid -->
        

		<script>
			function ParkingList() {
				

				$.ajax({
					type     : "POST"
					,url      : "<?php echo G5_THEME_URL; ?>/parkingoutlist.php"
					,data     : "ca_id=<?php  echo $member['mb_1'] ?>"
					,async    : false
					,success  : function(data) {
						//alert(data);
						document.getElementById("plist").innerHTML=data;
					}
					,error    : function(jqXHR, textStatus, errorThrown) {
						alert(jqXHR.status + " - " + jqXHR.statusText);
					}
				});
		    }   
			
			
		</script>

		<script>
        ParkingList();
        // setInterval("ParkingList()", 10000);
		var timer = setInterval( function () {ParkingList()}, 5000);

		/*$(document).ready(function() {
			var timer = setInterval( function () {ParkingList()}, 1000);
		}); */
       </script>





<?php
include_once(G5_THEME_PATH.'/tail.php');
?>