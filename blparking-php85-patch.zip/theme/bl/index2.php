<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

// 상단매뉴 숨기기
$head_mem_chk = 0; // 수기려면 0

include_once(G5_THEME_PATH.'/head.php');

if(defined('_INDEX_')) { // index에서만 실행
	include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
}
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
		  <?php
		  $sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = ".$member['mb_1'];
		  $row2 = sql_fetch($sql2);
		  ?>
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
			<h1 class="h1 mt-3 text-gray-800" style="margin:0 auto;"><?php echo $row2['ca_name']; ?> 출차<?php //echo '엽력'?></h1>
			
		  </div>

			<div class="card shadow mb-4">
				<!-- Card Header - Dropdown -->
				<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
					<h6 class="m-0 font-weight-bold text-primary">출차관리리스트</h6>
					<a class="btn_admin btn" href="#" data-toggle="modal" data-target="#logoutModal">
						<i class="fas fa-sign-out-alt fa-3x mr-2 font-weight-bold" style="font-size:25px;"></i>
					</a>
				</div>
				<!--- ./card-header py-3 d-flex flex-row align-items-center justify-content-between --->
				
				<!-- Card Body -->
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-bordered" width="100%" cellspacing="0">
							<thead>
								<tr>					
								<th>차량번호</th>
								<th>부서명</th>
								<th>출차요청시간</th>
								<th>출차시간</th>
								<th>출차여부</th>
								<th>정리</th>
								</tr>
							</thead>
							<tbody id="pklist">	
							
							</tbody>
						</table>
					</div>
					<!--- ./table-responsive --->
				</div>
				<!--- ./card-body --->
			</div>
			<!--- ./card shadow mb-4 --->
		  
		  <?php // 최신글
		  //echo latest('theme/basic', 'notice', 6, 24);
		  //echo latest('theme/middle', 'notice', 6, 24);
		  //echo latest('theme/thin', 'notice', 6, 24);
		  
		  //echo latest('theme/pic_block', 'gallery', 4, 23);
		  ?>
		  

        </div>
        <!-- /.container-fluid -->

		
		<script>
			function ParkingList() {
				

				$.ajax({
					type     : "POST"
					,url      : "<?php echo G5_THEME_URL; ?>/parkingout_data.php"
					,data     : "ca_id=<?php  echo $member['mb_1'] ?>"
					,async    : false
					,success  : function(data) {
						//alert(data);
						document.getElementById("pklist").innerHTML=data;
					}
					,error    : function(jqXHR, textStatus, errorThrown) {
						alert(jqXHR.status + " - " + jqXHR.statusText);
					}
				});
		    }   
			
			
		</script>

		<script>
        ParkingList();
        // setInterval("ParkingList()", 10000);

		$(document).ready(function() {
			var timer = setInterval( function () {ParkingList()}, 5000);
		});

 
       </script>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>