<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

// 상단매뉴 숨기기
$head_mem_chk = 1; // 수기려면 0

include_once(G5_THEME_PATH.'/head.php');

if(defined('_INDEX_')) { // index에서만 실행
	include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
}
?>

<style>
.form-group {
	width:400px;
}
.form-group, .btn-user {
	float: left;
}
.p-5 {
	margin:0 auto;
	width:610px;
}
</style>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
		  <?php
		  $sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = '".$member['mb_1']."' ";
		  $row2 = sql_fetch($sql2);

		  if ($is_admin) {
			  $ca_title = '';
		  } else {
			  if ($member['mb_level'] >= 5) { // 레벨5이상시 전체리스트 출력
				$ca_title = '';
			  } else {
				$ca_title = $row2['ca_name'];
			  }
		  }
		  ?>
          <!--<div class="d-sm-flex align-items-center justify-content-between mb-4">
			<h1 class="h1 mt-3 text-gray-800" style="margin:0 auto;"><?php echo $ca_title; ?> 출차<?php //echo '엽력'?></h1>
		  </div>-->
		 
			<div class="card shadow mb-4">
				<!-- Card Header - Dropdown -->
				<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
					<h6 class="m-0 font-weight-bold text-primary">출차관리리스트</h6>
				</div>
				<!--- ./card-header py-3 d-flex flex-row align-items-center justify-content-between --->
				
				<!-- Card Body -->
				<div class="card-body">

					<div class="row">
						<div class="col-xl-12 col-md-12 mb-4">
							<div style="widht:100%;">
							<div class="p-5">
								<div class="text-center">
									<h1 class="h4 text-gray-900 mb-3"><a href="<?php echo G5_URL.'/index.php' ; ?>"><?php echo $g5['title']; ?> 출차입력</a></h1>
								</div>
								<form name="frmnewwin" action="<?php echo G5_THEME_URL; ?>/parkingout_up.php" onsubmit="return frmnewwin_check(this);" method="post">
								<input type="hidden" name="mode" value="in">
								<input type="hidden" name="token" value="">
									
									<div class="form-group mr-3">
										<input type="text" name="pk_carnem" id="pk_carnem" required style="ime-mode:active" class="form-control required" placeholder="차량번호">
									</div>
									<button type="submit" class="btn btn-primary btn-user">출차등록</button>
								</form>
							</div>
							<!--- ./p-5 --->
							</div>
						</div>
						<div class="col-xl-12 col-md-12 mb-4">
							<div class="table-responsive">
							<table class="table table-bordered" width="100%" cellspacing="0">
								<thead>
									<tr>					
									<th>차량번호</th>
									<th>부서명</th>
									<th>출차요청시간</th>
									<th>출차시간</th>
									<th>출차여부</th>
									<th>정리</th>
									</tr>
								</thead>
								<tbody id="pklist">							
								
								</tbody>
							</table>
							</div>
							<!--- ./table-responsive --->
						</div>
					</div>
					
				</div>
				<!--- ./card-body --->
			</div>
			<!--- ./card shadow mb-4 --->
		  
		  <?php // 최신글
		  //echo latest('theme/basic', 'notice', 6, 24);
		  //echo latest('theme/middle', 'notice', 6, 24);
		  //echo latest('theme/thin', 'notice', 6, 24);
		  
		  //echo latest('theme/pic_block', 'gallery', 4, 23);
		  ?>
		  

        </div>
        <!-- /.container-fluid -->


<script type="text/javascript" >
  $(document).ready(function(){ 
   // 페이지 로딩시 포커스 주기
   if(!$('input[name="pk_carnem"]').val()){
    $('input[name="pk_carnem"]').focus();
   }
   //}else // if(!$('input[name="password"]').val()){
   // $('input[name="password"]').focus();
   //}

  });
 </script>


<script>
	function ParkingList() {
		$.ajax({
			type     : "POST"
			,url      : "<?php echo G5_THEME_URL; ?>/parkingin_data.php"
			,data     : "ca_id=<?php  echo $member['mb_1'] ?>"
			,async    : false
			,success  : function(data) {
				//alert(data);
				document.getElementById("pklist").innerHTML=data;
			}
			,error    : function(jqXHR, textStatus, errorThrown) {
				alert(jqXHR.status + " - " + jqXHR.statusText);
			}
		});
	}   

ParkingList();


$(document).ready(function() {
	var timer = setInterval( function () {ParkingList()}, 5000);
});


</script>

<script>
function frmnewwin_check(f)
{
errmsg = "";
errfld = "";

check_field(f.pk_carnem, "차량번호를 입력하세요.");

if (errmsg != "") {
alert(errmsg);
errfld.focus();
return false;
}
return true;
}
</script>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>