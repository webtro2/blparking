<?php
include_once("./_common.php");

$pkmb = get_member($member['mb_id']); 

if (($_REQUEST['mode'] ?? '') == '') {
	alert('잘못된 접근입니다.');
}

if (($_GET['mode'] ?? '') == 'u') {
	sql_query(" update {$g5['parking_list']} set pk_out_time = '".G5_TIME_YMDHIS."', pk_out_chk = '1' where pk_id = '{$_GET['pkid']}' ");
	$msg = '변경되었습니다';
	$url = G5_URL.'/index2.php';
} else if (($_GET['mode'] ?? '') == 'd') {
	sql_query(" update {$g5['parking_list']} set pk_end_time = '".G5_TIME_YMDHIS."', pk_end_chk = '1' where pk_id = '{$_GET['pkid']}' ");
	$msg = '정리되었습니다';
	$url = G5_URL.'/index2.php';
} else if (($_POST['mode'] ?? '') == 'in') {
	$sql = " insert {$g5['parking_list']}
                    ( car_nem, mb_id, ca_id, pk_up_time )
             values ( '{$_POST['pk_carnem']}', '{$pkmb['mb_id']}', '{$pkmb['mb_1']}', '".G5_TIME_YMDHIS."' ) ";
    sql_query($sql);
	$msg = '등록되었습니다';
	$url = G5_URL.'/index.php';
}
alert($msg, $url);
?>