<?php
include_once("./_common.php");

if ($is_admin) {
	$sql_s = '';
} else {
	if ($member['mb_level'] >= 5) { // 레벨5이상시 전체리스트 출력
		$sql_s = '';
	} else {
		$sql_s = "ca_id = '".$_POST['ca_id']."' and ";
	}
}
$sql = "select * from {$g5['parking_list']} where ".$sql_s."pk_end_chk = '0' order by pk_id desc";
$rs = sql_query($sql);
for ($i=0; $row=sql_fetch_array($rs); $i++) {




?>
	<tr class=" even">						
		<td class="">
			<?php echo $row['car_nem']; ?>									
		</td>
		<td class="td_caname">
			<?php
				$sql2 = "select ca_id, ca_name from {$g5['g5_mem_category_table']} where ca_id = ".$row['ca_id'];
				$row2 = sql_fetch($sql2);
			?>
			<?php echo $row2['ca_name']; ?>	
		</td>
		<td class="td_pkenddate"><span class="sv_member">
			<?php echo (!empty($row['pk_up_time']) && $row['pk_up_time'] !== '0000-00-00 00:00:00') ? getTime_Format($row['pk_up_time']) : '대기'; ?>
		</span></td>
		<td class="td_pkenddate"><span class="sv_member">
			<?php echo (!empty($row['pk_out_time']) && $row['pk_out_time'] !== '0000-00-00 00:00:00') ? getTime_Format($row['pk_out_time']) : '대기'; ?>
		</span></td>
		<td class="td_pkchk">
			<?php if ($row['pk_out_chk'] == 1) {?>
			<span class="d-none d-sm-inline-block btn btn-sm btn-gray shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 출차완료</span>
			<?php } else { ?>
			<span class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 출차대기</span>
			<?php  } ?>
		</td>
		<td class="td_pkchk">
			<?php if ($row['pk_end_chk'] == 1) {?>
			<span class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 퇴장</span>
			<?php } else { ?>
			<span class="d-none d-sm-inline-block btn btn-sm btn-info shadow-sm"><i class="fas fa-download fa-sm text-white"></i> 퇴장대기</span>
			<?php } ?>
		</td>
	</tr>
<?php } ?>