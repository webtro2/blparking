<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.G5_THEME_CSS_URL.'/style.css">', 0);
add_javascript('<script src="'.G5_THEME_JS_URL.'/jquery.bxslider.js"></script>', 10);
add_javascript('<script src="'.G5_THEME_JS_URL.'/jquery.fitvids.js"></script>', 15);
?>

<?php
$max_width = $max_height = 0;
$bn_first_class = ' class="bn_first"';
$bn_slide_btn = '';
$bn_sl = ' class="bn_sl"';

$main_banners = array();

for ($i=0; $row=sql_fetch_array($result); $i++)
{
    $main_banners[] = $row;

    if ($i==0) echo '<div id="main_bn">'.PHP_EOL.'<ul class="slide-wrap">'.PHP_EOL;
    //print_r2($row);
    // 테두리 있는지
    $bn_border  = ($row['bn_border']) ? ' class="sbn_border"' : '';;
    // 새창 띄우기인지
    $bn_new_win = ($row['bn_new_win']) ? ' target="_blank"' : '';

    $bimg = G5_DATA_PATH.'/banner/'.$row['bn_id'];
    if (file_exists($bimg))
    {
        $banner = '';
        $size = getimagesize($bimg);

        if($size[2] < 1 || $size[2] > 16)
            continue;

        if($max_width < $size[0])
            $max_width = $size[0];

        if($max_height < $size[1])
            $max_height = $size[1];

        echo '<li'.$bn_first_class.'>'.PHP_EOL;
        if ($row['bn_url'][0] == '#')
            $banner .= '<a href="'.$row['bn_url'].'">';
        else if ($row['bn_url'] && $row['bn_url'] != 'http://') {
            $banner .= '<a href="'.G5_SHOP_URL.'/bannerhit.php?bn_id='.$row['bn_id'].'"'.$bn_new_win.'>';
        }
		if ($row['bn_videos']) {
			echo '<iframe style="width:900px;height:1300px;" src="'.$row['bn_videos'].'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
		} else {
			echo $banner.'<img src="'.G5_DATA_URL.'/banner/'.$row['bn_id'].'" width="'.$size[0].'" alt="'.get_text($row['bn_alt']).'"'.$bn_border.'>';
		}
        if($banner)
            echo '</a>'.PHP_EOL;
        echo '</li>'.PHP_EOL;

       
    }
}
?>

<?php 
if ($i > 0) {
    echo '</ul>'.PHP_EOL;
echo '</div>'.PHP_EOL;
?>

<script>
jQuery(function($){
    var slider = $('.slide-wrap11').show().bxSlider({
        speed:800,
        pager:false,
		controls:false,
        auto: true,
        useCSS : false,
		video:true,
        onSlideAfter : function(){
            slider.startAuto();
        }
    });
});

var slider = $('.slide-wrap1').bxSlider({
		speed:800,
        pager:false,
		controls:false,
        auto: true,
        useCSS : false,
		video:true,
     onSlideAfter: function(slide, oldindex, currentSlide){
       oldSlide = $( '.slide-wrap1 > li:nth-child(' + (oldindex+1) + ')');
         youtubeVideo = oldSlide.find('iframe[src*=youtube]');
         if ( youtubeVideo.length ) {
           youtubeVideo.get(0).contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}','*');
         }
     }
});

var slider = $(".slide-wrap").bxSlider({
       speed:1000,
	   adaptiveHeight:true,   
       pager:false,
	   controls:false,
       auto:true, 
       autoStart:true, 
       video:true,
       onSlideAfter: function(slide){
          if (slide.find("iframe:first").length) {
              slider.stopAuto();
          }
       }
});

 $(document).ready(function(){
	// Target your .container, .wrapper, .post, etc.
	$("#thing-with-videos").fitVids();
});
</script>

<?php
}
?>