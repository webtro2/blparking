<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// common.php에서 필터링/SQL 이스케이프한 요청 변수를 사용합니다.
// 체크하지 않은 서비스 항목과 생략된 선택 입력은 빈 문자열로 저장합니다.
foreach (array('ext3_0', 'ext3_1', 'ext3_2', 'ext3_3', 'ext4_0', 'ext4_1', 'ext4_2', 'wr_12', 'wr_15', 'wr_16', 'wr_17') as $map_field) {
    if (!isset($$map_field) || !is_scalar($$map_field)) $$map_field = '';
}
$wr_id = (int)$wr_id;

// 필드가 존재하지 않을 경우, wr_11 ~ wr_17 필드 생성
$fields_to_check = ['wr_11', 'wr_12', 'wr_13', 'wr_14', 'wr_15', 'wr_16', 'wr_17'];

foreach ($fields_to_check as $field) {
    $sql_check_column = "SHOW COLUMNS FROM $write_table LIKE '$field'";
    $result = sql_query($sql_check_column);
    if (sql_num_rows($result) == 0) {
        $sql_add_column = "ALTER TABLE $write_table ADD $field VARCHAR(255) DEFAULT NULL";
        sql_query($sql_add_column);
    }
}

//time
$wr_3 = "$ext3_0|$ext3_1|$ext3_2|$ext3_3";
$sql3 = " update $write_table set wr_3 = '$wr_3' where wr_id = '$wr_id' ";
sql_query($sql3);

$wr_4 = "$ext4_0|$ext4_1|$ext4_2";
$sql4 = " update $write_table set wr_4 = '$wr_4' where wr_id = '$wr_id' ";
sql_query($sql4);


$sql12 = " update $write_table set wr_12 = '$wr_12' where wr_id = '$wr_id' ";
sql_query($sql12);

$sql15 = " update $write_table set wr_15 = '$wr_15' where wr_id = '$wr_id' ";
sql_query($sql15);

$sql16 = " update $write_table set wr_16 = '$wr_16' where wr_id = '$wr_id' ";
sql_query($sql16);

$sql17 = " update $write_table set wr_17 = '$wr_17' where wr_id = '$wr_id' ";
sql_query($sql17);

//$sqld = " update $write_table set wr_datetime = '$wr_datetime' where wr_id = '$wr_id' ";
//sql_query($sqld);

/*if($w != "u"){
	alert("온라인상담이 정상적으로 신청되었습니다","./write.php?bo_table=$bo_table"); 
}*/
//if (!$board['bo_use_tag']) return;
//include_once(G5_TAG_PATH."/view.tag.update.skin.php");
?>