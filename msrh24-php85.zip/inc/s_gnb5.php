<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('review1')" class="menu1">온라인상담</a></li>
	<li class="submenu2"><a href="javascript:GoPage('review2')" class="menu2">수술후기</a></li>
	<li class="submenu3"><a href="javascript:GoPage('review3')" class="menu3">고객불편상담</a></li>
</ul>
