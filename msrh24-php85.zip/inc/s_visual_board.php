<div class="s_visual">
	<div class="s_visual_in">
		<div class="sv_tit">
			<h3 data-aos="fade-up" data-aos-delay="300"><span class="vis_dep01"></span></h3>
			<p data-aos="fade-up" data-aos-delay="400" class="t1">환자들의 건강을 재건하여 <br>
환자와 가족, 직장의 행복을 재건, 희망찬 미래를 재건합니다.</p>
		</div>
	</div>
</div>


<!-- Sub Content -->
<div id="subContent">

	<div class="sub_menu_wrap">
		<div class="in">
			<div class="m_home"><a href="/"></a></div>
			<div class="m_1dep_box m_dep_box">
				<div class="m_dep_tit"><span class="vis_dep01"></span></div>
				<?php  include "../../inc/s_gnb0.php" ?>
			</div>
			<div class="m_2dep_box m_dep_box">
				<div class="m_dep_tit"><span class="vis_dep02"></span></div>
				<?php  include "../../inc/s_gnb$s_num.php" ?>
			</div>
		</div>
	</div><!-- sub_menu_wrap -->
