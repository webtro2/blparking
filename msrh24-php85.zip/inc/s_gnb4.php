<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('clinic1')" class="menu1">수부미세접합</a></li>
	<li class="submenu2"><a href="javascript:GoPage('clinic2')" class="menu2">족부·족관절</a></li>
	<li class="submenu3"><a href="javascript:GoPage('clinic3')" class="menu3">관절경(무릎·어깨)</a></li>
	<li class="submenu4"><a href="javascript:GoPage('clinic4')" class="menu4">인공관절</a></li>
	<li class="submenu5"><a href="javascript:GoPage('clinic5')" class="menu5">팔꿈치</a></li>
	<li class="submenu6"><a href="javascript:GoPage('clinic6')" class="menu6">손목</a></li>
	<li class="submenu7"><a href="javascript:GoPage('clinic7')" class="menu7">척추</a></li>
	<li class="submenu8"><a href="javascript:GoPage('clinic8')" class="menu8">구연 및 발표논문</a></li>
</ul>
