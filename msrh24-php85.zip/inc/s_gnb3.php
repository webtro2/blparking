<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('depart1')" class="menu1">정형외과</a></li>
	<!-- <li class="submenu2"><a href="javascript:GoPage('depart2')" class="menu2">수부외과</a></li> -->
	<li class="submenu3"><a href="javascript:GoPage('depart3')" class="menu3">내과·가정의학과</a></li>
	<li class="submenu4"><a href="javascript:GoPage('depart4')" class="menu4">영상의학과</a></li>
	<li class="submenu5"><a href="javascript:GoPage('depart5')" class="menu5">마취통증의학과</a></li>
	<li class="submenu6"><a href="javascript:GoPage('depart6')" class="menu6">성형외과</a></li>
</ul>
