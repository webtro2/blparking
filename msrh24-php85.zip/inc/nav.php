
<ul class="gnb_dp1_wrap">

	<li class="gnb_dp1">
		<div>
			<a href="javascript:GoPage('intro1')">병원소개</a>
		</div>
		<?php  include "s_gnb1.php" ?>
	</li>

	
	<li class="gnb_dp1">
		<div>
			<a  href="javascript:GoPage('guide1')">병원이용안내</a>
		</div>
		<?php  include "s_gnb2.php" ?>
	</li>


	<li class="gnb_dp1">
		<div>
			<a   href="javascript:GoPage('depart1')">진료과목</a>
		</div>
		<?php  include "s_gnb3.php" ?>
	</li>

	
	<li class="gnb_dp1">
		<div>
			<a  href="javascript:GoPage('clinic1')">진료분야</a>
		</div>
		<?php  include "s_gnb4.php" ?>
	</li>


	<li class="gnb_dp1">
		<div>
			<a   href="javascript:GoPage('review1')">상담 및 후기</a>
		</div>
		<?php  include "s_gnb5.php" ?>
	</li>


	<li class="gnb_dp1">
		<div>
			<a  href="javascript:GoPage('comm1')">정보마당</a>
		</div>
		<?php  include "s_gnb6.php" ?>
	</li>

</ul>
