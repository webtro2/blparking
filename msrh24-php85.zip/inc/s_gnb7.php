<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('login')" class="menu1">로그인</a></li>
	<li class="submenu2"><a href="javascript:GoPage('join')" class="menu2">회원가입</a></li>
	<li class="submenu3"><a href="javascript:GoPage('provision')" class="menu3">이용약관</a></li>
	<li class="submenu4"><a href="javascript:GoPage('privacy')" class="menu4">개인정보처리방침</a></li>
</ul>
