<div id="wrap">

<!-- header -->
<div id="header">
	<div id="hd_logo" class="h_height">
		<a href="/index.php">
			<img class="off" src="/images/common/logo_w.png"  alt="" />
			<img class="on" src="/images/common/logo.png"  alt="" />
		</a>
	</div>

	<div id="gnb_pc" class="hd_menu">
		<?php  include "nav.php" ?>
	</div>

	<div id="hd_mem" class="h_height">
        <a href="http://pf.kakao.com/_Zxlexen" target="_blank"><img src="/images/common/icon_kakao.png" alt=""></a>
        <ul class="">
            <?php if (!empty($member['mb_id'])){?>
                <li><a href="javascript:GoPage('logout')">로그아웃</a></li>
            <?php if (!empty($is_admin)){?>
                <li><a href="/pg/adm/">관리자</a></li>
            <?php }else{?>
                <li><a href="javascript:GoPage('mypage')">정보수정</a></li>
            <?php  } ?>
            <?php }else{?>
                <li><a href="javascript:GoPage('login')">로그인</a></li>
                <li><a href="javascript:GoPage('join')">회원가입</a></li>
            <?php }?>
        </ul> 
	</div>

	<div id="menuToggle" class="hd_full hd_mbx">
		<span class="t"></span>
		<span class="m"></span>
		<span class="b"></span>
	</div>

	<div id="gnb_mo">
		<?php  include "nav.php" ?>
		<div id="mem_mo">
			 <ul class="">
				<?php if (!empty($member['mb_id'])){?>
					<li><a href="javascript:GoPage('logout')">로그아웃</a></li>
				<?php if (!empty($is_admin)){?>
					<li><a href="/pg/adm/">관리자</a></li>
				<?php }else{?>
					<li><a href="javascript:GoPage('mypage')">정보수정</a></li>
				<?php  } ?>
				 <?php }else{?>
					<li><a href="javascript:GoPage('login')">로그인</a></li>
					<li><a href="javascript:GoPage('join')">회원가입</a></li>
				 <?php }?>
			</ul> 
		</div>
	</div>

</div>

<!-- //header -->
