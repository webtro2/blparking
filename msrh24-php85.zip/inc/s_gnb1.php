<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('intro1')" class="menu1">병원장 인사말</a></li>
	<li class="submenu2"><a href="javascript:GoPage('intro2')" class="menu2">MS재건병원 정신</a></li>
	<li class="submenu3"><a href="javascript:GoPage('intro3')" class="menu3">의료진 소개</a></li>
	<li class="submenu4"><a href="javascript:GoPage('intro4')" class="menu4">보도자료</a></li>
	<li class="submenu5"><a href="javascript:GoPage('intro5')" class="menu5">대외 및 학회활동</a></li>
	<li class="submenu6"><a href="javascript:GoPage('intro6')" class="menu6">의료장비안내</a></li>
	<li class="submenu7"><a href="javascript:GoPage('intro7')" class="menu7">층별안내</a></li>
	<li class="submenu8"><a href="javascript:GoPage('intro8')" class="menu8">찾아오시는 길</a></li>
</ul>