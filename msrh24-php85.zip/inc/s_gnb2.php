<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('guide1')" class="menu1">진료시간</a></li>
	<li class="submenu2"><a href="javascript:GoPage('guide2')" class="menu2">입퇴원 안내</a></li>
	<li class="submenu3"><a href="javascript:GoPage('guide3')" class="menu3">병원생활 안내</a></li>
	<li class="submenu4"><a href="javascript:GoPage('guide4')" class="menu4">응급실 안내</a></li>
	<li class="submenu5"><a href="javascript:GoPage('guide5')" class="menu5">증명서발급 안내</a></li>
</ul>
