


	<footer id="footer">
		<div class="inner">
			<h1><img src="/images/common/f_logo.png"></h1>
			<ul id="f-link">
				<li><a href="javascript:GoPage('provision')">이용약관</a></li>
				<li><a href="javascript:GoPage('privacy')">개인정보처리방침</a></li>
				<li><a href="javascript:GoPage('review1')">온라인상담</a></li>				
				<li><a href="javascript:GoPage('intro7')">찾아오시는 길</a></li>
			</ul>
			<ul id="f-info">
				<li><span>MS재건병원</span></li>
				<li><span>대표자명</span>유선오 외 3명</li>
				<li><span>주소</span>대구광역시 중구 동덕로 194</li>
				<li><span>TEL</span>053-653-0119</li>
				<li><span>FAX</span>053-653-0771</li>
				<li><span>사업자등록번호</span>734-97-00078</li>
				<li class="copy">COPYRIGHT ⓒ MSRHOSPITAL.ALL RIGHT RESERVED</li>
			</ul>
		</div>
	</footer>

	</div>





	<script>
		AOS.init({
			duration: 600,
			offset: 0,
			delay: 100,
			easing: 'ease-out-quad',
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function() {
			subFunc.snb("<?= $s_num ?? '' ?>", "<?= $p_num ?? '' ?>");
		});
	</script>


	</body>

	</html>