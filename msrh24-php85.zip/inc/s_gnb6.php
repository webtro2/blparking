<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('comm1')" class="menu1">병원소식</a></li>
	<li class="submenu2"><a href="javascript:GoPage('comm2')" class="menu2">공지사항</a></li>
	<li class="submenu3"><a href="javascript:GoPage('comm3')" class="menu3">병원자료실</a></li>
	<li class="submenu4"><a href="javascript:GoPage('comm4')" class="menu4">비급여공지</a></li>
	<li class="submenu5"><a href="javascript:GoPage('comm5')" class="menu5">건강상식</a></li>
	<li class="submenu6"><a href="javascript:GoPage('comm6')" class="menu6">직원공간</a></li>
	<li class="submenu7"><a href="javascript:GoPage('comm7')" class="menu7">채용정보</a></li>
</ul>
