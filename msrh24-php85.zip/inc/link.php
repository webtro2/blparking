<script language="javascript">
function GoPage(code) {
	if ( !code )						{	window.location = "/";	}

	else if ( code == "main" )			{	window.location = "/index.php";		}

	///////
	else if ( code == "intro1" )		{	window.location = "/doc/intro1.php"; }
	else if ( code == "intro2" )		{	window.location = "/doc/intro2.php"; }
	else if ( code == "intro3" )		{	window.location = "/doc/intro3.php"; }
	else if ( code == "intro4" )		{	window.location = "/pg/bbs/board.php?bo_table=intro4"; }
	else if ( code == "intro5" )		{	window.location = "/pg/bbs/board.php?bo_table=intro5"; }
	else if ( code == "intro6" )		{	window.location = "/doc/intro6.php"; }
	else if ( code == "intro7" )		{	window.location = "/doc/intro7.php"; }
		else if ( code == "intro7_1" )		{	window.location = "/doc/intro7.php#pageCont"; }
		else if ( code == "intro7_2" )		{	window.location = "/doc/intro7_2.php#pageCont"; }
		else if ( code == "intro7_3" )		{	window.location = "/doc/intro7_3.php#pageCont"; }
		else if ( code == "intro7_4" )		{	window.location = "/doc/intro7_4.php#pageCont"; }
		else if ( code == "intro7_5" )		{	window.location = "/doc/intro7_5.php#pageCont"; }
		else if ( code == "intro7_6" )		{	window.location = "/doc/intro7_6.php#pageCont"; }
		else if ( code == "intro7_7" )		{	window.location = "/doc/intro7_7.php#pageCont"; }
		else if ( code == "intro7_8" )		{	window.location = "/doc/intro7_8.php#pageCont"; }
		else if ( code == "intro7_9" )		{	window.location = "/doc/intro7_9.php#pageCont"; }
		else if ( code == "intro7_10" )		{	window.location = "/doc/intro7_10.php#pageCont"; }
	else if ( code == "intro8" )		{	window.location = "/doc/intro8.php"; }

	else if ( code == "guide1" )		{	window.location = "/doc/guide1.php"; }
	else if ( code == "guide2" )		{	window.location = "/doc/guide2.php"; }
	else if ( code == "guide3" )		{	window.location = "/doc/guide3.php"; }
	else if ( code == "guide4" )		{	window.location = "/doc/guide4.php"; }
	else if ( code == "guide5" )		{	window.location = "/doc/guide5.php"; }

	else if ( code == "depart1" )		{	window.location = "/doc/depart1.php"; }
	else if ( code == "depart2" )		{	window.location = "/doc/depart2.php"; }
	else if ( code == "depart3" )		{	window.location = "/doc/depart3.php"; }
	else if ( code == "depart4" )		{	window.location = "/doc/depart4.php"; }
	else if ( code == "depart5" )		{	window.location = "/doc/depart5.php"; }
	else if ( code == "depart6" )		{	window.location = "/doc/depart6.php"; }


	else if ( code == "clinic1" )		{	window.location = "/doc/clinic1.php"; }
	else if ( code == "clinic2" )		{	window.location = "/doc/clinic2.php"; }
	else if ( code == "clinic3" )		{	window.location = "/doc/clinic3.php"; }
	else if ( code == "clinic4" )		{	window.location = "/doc/clinic4.php"; }
	else if ( code == "clinic5" )		{	window.location = "/doc/clinic5.php"; }
	else if ( code == "clinic6" )		{	window.location = "/doc/clinic6.php"; }
	else if ( code == "clinic7" )		{	window.location = "/doc/clinic7.php"; }
	else if ( code == "clinic8" )		{	window.location = "/doc/clinic8.php"; }


	else if ( code == "review1" )		{	window.location = "/pg/bbs/board.php?bo_table=review1"; }
	else if ( code == "review2" )		{	window.location = "/pg/bbs/board.php?bo_table=review2"; }
	// else if ( code == "review3" )		{	window.location = "/pg/bbs/board.php?bo_table=review3"; }
	else if ( code == "review3" )		{	window.location = "/doc/review1.php"; }


	else if ( code == "comm1" )		{	window.location = "/pg/bbs/board.php?bo_table=comm1"; }
	else if ( code == "comm2" )		{	window.location = "/pg/bbs/board.php?bo_table=comm2"; }
	else if ( code == "comm3" )		{	window.location = "/pg/bbs/board.php?bo_table=comm3"; }
	else if ( code == "comm4" )		{	window.location = "/pg/bbs/board.php?bo_table=comm4"; }
	else if ( code == "comm5" )		{	window.location = "/pg/bbs/board.php?bo_table=comm5"; }
	else if ( code == "comm6" )		{	window.location = "/pg/bbs/board.php?bo_table=comm6"; }
	else if ( code == "comm7" )		{	window.location = "/pg/bbs/board.php?bo_table=comm7"; }



	else if ( code == "login" )		{	window.location = "/pg/bbs/login.php"; }	
	else if ( code == "join" )		{	window.location = "/pg/bbs/register.php"; }	
	else if ( code == "logout" )		{	window.location = "/pg/bbs/logout.php"; }
	else if ( code == "provision" )		{	window.location = "/doc/provision.php"; }	
	else if ( code == "privacy" )		{	window.location = "/doc/privacy.php"; }	
	else if ( code == "mypage" )		{	window.location = "/pg/bbs/member_confirm.php?url=register_form.php"; }


	else if ( code == "kakao" )    { window.open('https://kko.kakao.com/V2MdqFTG3L', '_blank'); }
	else if ( code == "naver" )    { window.open('https://map.naver.com/p/directions/-/14316230.7347415,4283004.9131255,MS%EC%9E%AC%EA%B1%B4%EB%B3%91%EC%9B%90,1124632952,PLACE_POI/-/transit?c=16.00,0,0,0,dh', '_blank'); }
}
</script>
