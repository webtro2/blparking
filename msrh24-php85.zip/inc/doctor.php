<div class="overlay" id="doctor1"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img1.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>유선오 <span>병원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>족부 및 족관절 클리닉</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>경북 대학교 의과대학</p></li>
				<li><p>한림대학교 강남 성심병원 정형외과 전문의</p></li>
				<li><p>한림대학교 강남 성심병원 정형외과 족부 족관절 전임의</p></li>
				<li><p>미국 볼티모어 기념병원 족부 클리닉 연수</p></li>
				<li><p>인천 기독 병원 족부 클리닉 과장</p></li>
				<li><p>대구 현대 병원 족부 클리닉 과장</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한 족부 족관절 학회 정회원</p></li>
				<li><p>대한 족부 족관절 학회 이사 및 논문 심사위원</p></li>
				<li><p>대한 족부 질환 연구회 회원</p></li>
				<li><p>미국 족부 정형외과 국제 회원</p></li>
				<li><p>한림대학교 의과대학 정형외과 외래 부교수</p></li>
			</ul>		
	   </div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg3">연구업적</h3>
			<ul id="dotList">
				<li><p>2002, 2003 2004 2005 2006 대한 족부 족관절 학회 연수강좌 강의</p></li>
				<li><p>2001, 2004년 아시아 족부학회 연제 발표</p></li>
				<li><p>2002, 2003, 2004, 2005 대한 족부 족관절 추계 학회 연제 발표</p></li>
				<li><p>2002 2003 대한 족부 족관절 춘계 학회 연제 발표</p></li>
				<li><p>2003 2004 2005 대한 정형외과 추계 학회 연제 발표</p></li>
				<li><p>2005년 세계 족부학회 연제 발표</p></li>
				<li><p>2006년 건국대학교 족부 족관절 심포지엄 강의</p></li>
				<li><p>2006년 대구시 의사회 학술대회, 족부 질환의 최신지견 강의</p></li>
				<li><p>2007년 제2회 강릉 족부 족관절 심포지엄 강의</p></li>
				<li><p>2007년 연세대학교 족부 족관절 심포지엄 강의</p></li>
				<li><p>그 외 대한정형외과학회 및 족부 족관절 학회 및 학회지에 다수의 논문 발표</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>





<div class="overlay" id="doctor2"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img2.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>하성한 <span>병원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>수부외과 세부 전문의</p></li>
				<li><p>견주관절 클리닉</p></li>
				<li><p>슬관절클리닉</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>영남대학교 의과대학</p></li>
				<li><p>성균관대학교 삼성서울병원 정형외과 임상교수</p></li>
				<li><p>대구 현대 병원 수부외과센터 정형외과 과장, 관절경센터 소장</p></li>
				<li><p>수부외과 세부 전문의</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한견주관절외과학회 정회원</p></li>
				<li><p>대한수부외과학회 정회원</p></li>
				<li><p>대한미세수술학회 정회원</p></li>
				<li><p>한림대학교 의과대학 정형외과 외래교수</p></li>
				<li><p>성균관대학교 삼성서울병원 정형외과 외래교수</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor3"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img3.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>김효곤 <span>병원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>수부 관절클리닉</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>연세대학교 의과대학졸업</p></li>
				<li><p>성균관대학교 삼성서울병원 인턴</p></li>
				<li><p>성균관대학교 삼성서울병원 정형외과 전문의</p></li>
				<li><p>공군강릉비행장 병원장(항의전대장) 역임</p></li>
				<li><p>성균관대학교 삼성서울병원 정형외과 임상교수</p></li>
				<li><p>성균관대학교 삼성서울병원 정형외과 외래교수</p></li>
				<li><p>수부외과 세부 전문의</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한수부외과학회 정회원</p></li>
				<li><p>대한미세수술학회 정회원</p></li>
				<li><p>대한말초신경수술학회 정회원</p></li>
				<li><p>대한 수부외과학회 이사</p></li>
				<li><p>대한미세수술학회 이사</p></li>
				<li><p>대한말초신경수술학회 정보통신위원회 위원</p></li>
				<li><p>대구고등법원 전문감정(장애 판정) 촉탁의</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor4"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img4.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>김정래 <span>병원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>족부 및 족관절 클리닉</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>영남대학교의료원 의과대학</p></li>
				<li><p>영남대학교의료원 인턴</p></li>
				<li><p>영남대학교의료원 정형외과 전문의</p></li>
				<li><p>포항해군병원 정형외과 과장 역임</p></li>
				<li><p>인제대학교 서울백병원 정형외과 족부 족관절 임상교수</p></li>
				<li><p>영남대학교의료원 정형외과 족부 족관절 임상교수</p></li>
				<li><p>일본 NARA university 족부 족관절 센터 연수</p></li>
				<li><p>미국 족부 정형외과 국제 회원</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한 족부족관절 학회 정회원</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor5"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img5.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>김동영 <span>원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>무릎 및 어깨관절 클리닉</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>경북대학교 의과대학</p></li>
				<li><p>대구파티마병원 정형외과 전문의</p></li>
				<li><p>대구통합병원 정형외과 과장 역임</p></li>
				<li><p>대구한미병원 원장 역임</p></li>
				<li><p>Chulalong cong Uni. 슬관절 인공관절 연수</p></li>
				<li><p>Asan Medical center 슬관절 인공관절 수료</p></li>
				<li><p>연세대 슬관절 인공관절 workshop 연수</p></li>
				<li><p>고려대 슬관절 견관절 관절경 workshop연수</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한슬관절학회 정회원</p></li>
				<li><p>대한견주관절학회 정회원</p></li>
				<li><p>대한관절경학회 정회원</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor6"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img6.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>이원제 <span>원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>척추센터</p></li>
				<li><p>수부 및 상하지 외상 골절</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>영남대학교 의과대학</p></li>
				<li><p>영남대학교 의과대학 인턴 수료</p></li>
				<li><p>영남대학교 의과대학 전공의</p></li>
				<li><p>영남대학교 의료원 척추센터 전임의</p></li>
				<li><p>국군원주병원 정형외과장</p></li>
				<li><p>울산 굿모닝병원 척추센터 진료부장</p></li>
				<li><p>울산 세민병원 척추관절센터</p></li>
				<li><p>국민건강보험공단 자문의</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한척추외과학회 정회원</p></li>
				<li><p>대한수부외과학회 정회원</p></li>
				<li><p>인공디스크 치환술(FRANCE-LDR COURSE)콴 연수</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>




<div class="overlay" id="doctor7"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img7.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>나호동 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>족부 및 족관절 클리닉</p></li>
				<li><p>척추 및 견주관절</p></li>
				<li><p>수부</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>영남대학교 의과대학</p></li>
				<li><p>영남대학교의료원 정형외과 전문의</p></li>
				<li><p>영남대학교의료원 전임의(척추, 견주관절, 수부)</p></li>
				<li><p>영남대학교의료원 정형외과 족부, 족관절 임상교수</p></li>
				<li><p>육군군의관</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한족부족관절학회 정회원</p></li>
				<li><p>대한수부외과학회 정회원</p></li>
				<li><p>대한스포츠의학회 정회원</p></li>
				<li><p>대한골절학회 정회원</p></li>
				<li><p>대한척추외과학회 척추술기워크샵 수료</p></li>
				<li><p>척추인증의 (대한척추외과학회)</p></li>
				<li><p>TPI 교육이수 (한국통증의학회)</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<!-- <div class="overlay" id="doctor8"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img8.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>박진식 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>수부외과 클리닉</p></li>
				<li><p>견주관절 클리닉</p></li>
				<li><p>수부 및 상하지 외상 골절</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>한양대학교 의과대학</p></li>
				<li><p>한양대학교병원 교육연구부 인턴</p></li>
				<li><p>한양대학교병원 정형외과 전공의</p></li>
				<li><p>국제축구연맹 FIFA 인증 스포츠 전문의</p></li>
				<li><p>육군 6사단, 1군지사 군의관</p></li>
				<li><p>한양대학교병원 정형외과(견주관절 및 수부) 전임의</p></li>
				<li><p>세종스포츠정형외과 수부 및 견주관절 진료원장</p></li>
				<li><p>대한정형외과학회 정회원</p></li>
				<li><p>대한수부외과학회 정회원</p></li>
				<li><p>대한견주관절학회 준회원</p></li>
				<li><p>대한미세수술학회 정회원</p></li>
				<li><p>대한스포츠의학회 정회원</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div> -->



<div class="overlay" id="doctor9"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img9.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>정종성 <span>원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>마취통증의학과 전문의</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>경북대학교 의과대학 및 동대학원</p></li>
				<li><p>경북대학교 병원 마취통증의학과 전공의</p></li>
				<li><p>대한 마취과 학회 정회원</p></li>
				<li><p>대한 통증학회 정회원</p></li>
				<li><p>대한 IMS 정회원</p></li>
				<li><p>통증학회 TPI 연수</p></li>
				<li><p>전 현대병원 마취통증의학 과장</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>




<div class="overlay" id="doctor10"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img10.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>하인호 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>마취통증의학과 전문의</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>경북대학교 의과대학 및 동대학원</p></li>
				<li><p>경북대학교병원 마취통증의학과 전문의</p></li>
				<li><p>대한마취통증의학회 정회원</p></li>
				<li><p>대한통증학회 정회원</p></li>
				<li><p>대한IMS 정회원</p></li>
				<li><p>통증학회 TPI 연수</p></li>
				<li><p>전 곽병원 마취통증의학 과장</p></li>
				<li><p>전 참튼튼병원 마취통증의학 과장</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor11"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img11.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>황병윤 <span>원장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>가정의학과 전문의</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>계명대학교 의과대학</p></li>
				<li><p>계명대학교 동산의료원 전공의</p></li>
				<li><p>가정의학과 전문의</p></li>
				<li><p>대한 가정의학과 정회원</p></li>
				<li><p>대한 노인학회 정회원</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>




<div class="overlay" id="doctor12"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img12.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>강민석 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>영상의학과 전문의</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>부산대학교 의과대학</p></li>
				<li><p>부산대학병원 전공의</p></li>
				<li><p>영상의학과 전문의</p></li>
				<li><p>한국건강관리협회 울산지부 진료과장</p></li>
				<li><p>대구기독병원 진료과장</p></li>
				<li><p>대구세강병원 진료과장</p></li>
				<li><p>대한영상의학회 정회원</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor13"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img13.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>김철수 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>응급의학과 전공의</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				<li><p>차의과대학교 인턴</p></li>
				<li><p>분당차병원 응급의학과 전공의</p></li>
				<li><p>문경제일병원 응급의학과 과장</p></li>
				<li><p>아산충무병원 응급의학과 과장</p></li>
				<li><p>성남 정병원 응급의학과 과장</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>



<div class="overlay" id="doctor14"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img14.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>이현록 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>성형외과 전문의</p></li>
				<li><p>수부외과 세부 전문의</p></li>
				<li><p>수부외과 클리닉</p></li>
				<li><p>수부 및 상지 외상 골절</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				 <li><p>동국대학교 의과대학 인턴</p></li>
                 <li><p>동국대학교병원 성형외과 전문의</p></li>
                 <li><p>수부외과 세부전문의</p></li>
                 <li><p>수부외과 전임의 수료</p></li>
                 <li><p>전. 새손병원 수부외과 진료 과장</p></li>
                 <li><p>대한 성형외과학회 정회원</p></li>
                 <li><p>대한 수부외과학회 정회원</p></li>
                 <li><p>대한 미세수술학회 정회원</p></li>
                 <li><p>대한 두개안면성형외과학회 정회원</p></li>
                 <li><p>Chang Gung Memorial Hospital 연수</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>





<div class="overlay" id="doctor15"></div>
<div class="popup">
<div class="in-box">
    <section class="img-box">      
       <img src="/images/main/mdoctor-img15.png">
	    <dl>
			<dd>MS재건병원</dd>
			<dt>송원호 <span>과장</span></dt>
	   </dl>	  
    </section>
    <section class="profile-box"> 
	   <div>
			<h3 class="bg1">진료분야</h3>
			<ul id="dotList" class="w50">
				<li><p>정형외과 전문의</p></li>
				<li><p>수부 및 상하지 외상 골절</p></li>
			</ul>
		</div>
	   <p class="line"></p>
	    <div>
			<h3 class="bg2">주요약력</h3>
			<ul id="dotList">
				 <li><p>경북대학교 의학전문대학원</p></li>
                 <li><p>한림대학교 강동성심병원 정형외과 전공의</p></li>
                 <li><p>서울아산병원 소아 전임의</p></li>
                 <li><p>서울아산병원 외상 & 고관절 전임의</p></li>
                 <li><p>AO trauma Basic & Advanced course</p></li>
                 <li><p>대한정형외과학회 정회원</p></li>
			</ul>		
	   </div>
    </section>
    <a class="close" href="#close"></a>
</div>
</div>
