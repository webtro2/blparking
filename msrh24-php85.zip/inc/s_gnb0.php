<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('intro1')" class="menu1">병원소개</a></li>
	<li class="submenu2"><a href="javascript:GoPage('guide1')" class="menu2">병원이용안내</a></li>
	<li class="submenu3"><a href="javascript:GoPage('depart1')" class="menu3">진료과목</a></li>
	<li class="submenu4"><a href="javascript:GoPage('clinic1')" class="menu4">진료분야</a></li>
	<li class="submenu5"><a href="javascript:GoPage('review1')" class="menu5">상담 및 후기</a></li>
	<li class="submenu6"><a href="javascript:GoPage('comm1')" class="menu6">정보마당</a></li>
	<li class="submenu7"><a href="javascript:GoPage('provision')" class="menu7">멤버쉽</a></li>
</ul>
