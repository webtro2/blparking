<?php include_once "_common.php"; ?>

<?php include "inc/head.php"; ?>
<?php include "inc/link.php"; ?>
<?php include "inc/top.php"; ?>

<?php include_once(G5_BBS_PATH.'/newwin.inc.php');?>
<?php include_once(G5_LIB_PATH.'/latest.lib.php');?>


<!-- mVisual -->
<div id="mVisual"> 
	<section class="mvWrap">
		<div class="mv_slider mv1">
		  <div class="mv-txt">
			 <div>
				<p class="t1" data-aos="fade-up" data-aos-delay="200"><span class="fw-EB">건강</span>재건<span class="dot">·</span><span class="fw-EB">행복</span>재건<span class="dot">·</span><span class="fw-EB">미래</span>재건</p>
				<p class="t2" data-aos="fade-up" data-aos-delay="300">환자들의 건강을 재건하여 <br>환자와 가족, 직장의 행복을 재건, 희망찬 미래를 재건합니다.</p>
			 </div>
		  </div>
	   </div>
	   <div class="mv_slider mv2">
		  <div class="mv-txt">
			 <div>
				<p class="t1" data-aos="fade-up" data-aos-delay="200"><span class="fw-EB">건강</span>재건<span class="dot">·</span><span class="fw-EB">행복</span>재건<span class="dot">·</span><span class="fw-EB">미래</span>재건</p>
				<p class="t2" data-aos="fade-up" data-aos-delay="300">환자들의 건강을 재건하여 <br>환자와 가족, 직장의 행복을 재건, 희망찬 미래를 재건합니다.</p>
			 </div>
		  </div>
	   </div>
	</section>
	<section id="mvTel">
		<ul>
			<li class="icon1">
				<dl>					
					<dd>원무과</dd>
					<dt>053) 650-0131~2</dt>
				</dl>
			</li>
			<li class="icon2">
				<dl>					
					<dd>외래진료</dd>
					<dt>053) 650-0114</dt>
				</dl>
			</li>
			<li class="icon3">
				<dl>					
					<dd>진료예약</dd>
					<dt>053) 650-0198</dt>
				</dl>
			</li>
			<li class="icon4">
				<dl>					
					<dd>365일 24시간 응급실</dd>
					<dt>053) 650-0118</dt>
				</dl>
			</li>
		</ul>
	</section>
</div>
<!-- //mVisual -->







<section id="mInfo">
<div class="inner mp-Part">
		<div id="mTitle">
			<p class="eng">microsurgical · muscukiskeletal</p>
			<h3 class="fw-EB">다시 뛰는 내일, <br class="br680"><span class="fc-M1">MS</span><span class="fc-M2">재건병원</span>과 함께</h3>
		</div>
		<div class="imgWrap">
			<img src="/images/main/minfo-img.png">
		</div>
		<div class="contWrap">
			<h3>상·하지에 발생할 수 있는 <br class="br580">모든 외상 및 질환을 <br>
치료하는 24시간 수술이 가능한 MS재건</h3>
			<p class="t1">축적된 의학 지식과 풍부한 수술 경험을 보유한 <br>
정형외과 및 수부외과 전문의가 미세수술, 상하지 재건, 족부 및 족관절, <br>
수부상지 재건, 관절경 등 각자 특화된 영역에서 협진 체계를 구축하여 <br>
최상의 치료 결과를 보여드립니다.</p>
			<ul class="btn">
				<a href="javascript:GoPage('intro1')"><p>병원장 인사말</p></a>
				<a href="javascript:GoPage('intro5')"><p>대외 및 학회활동</p></a>
				<a href="javascript:GoPage('clinic8')"><p>구연 및 발표논문</p></a>
				<a href="javascript:GoPage('intro7')"><p>찾아오시는 길</p></a>
			</ul>
		</div>
</div>
</section>





<section id="mClinic">
<div class="inner mp-Part">
		<div id="mTitle" class="center">
			<p class="eng">microsurgical · muscukiskeletal</p>
			<h3>정확한 <span class="fc-M1 fw-EB">원인진단</span>을 통한 <br class="br680"><span class="fc-M2 fw-EB">1:1 맞춤치료</span> 시행</h3>
			<p class="t1">정확한 원인 진단을 통해 환자 개개인에 맞춘 1:1 치료 계획을 제공하여 <br>환자의 빠른 회복과 불편 최소화를 목표로, 체계적이고 세심한 진료로 건강한 일상 복귀를 지원합니다.</p>
		</div>
		<div class="mClinicWrap">
			<a href="javascript:GoPage('clinic1')">
			<div class="in-box bg1">
				<h3>수부미세 접합</h3>
				<div class="hover-box">
					<dl>
						<dt>수부미세 접합</dt>
						<p class="line"></p>
						<dd>손과 팔에 생기는 다양한 외상과 질환에 대해서 전문적으로 진료하는 분야</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
			<a href="javascript:GoPage('clinic2')">
			<div class="in-box bg2">
				<h3>족부·족관절</h3>
				<div class="hover-box">
					<dl>
						<dt>족부·족관절</dt>
						<p class="line"></p>
						<dd>족부 및 족관절에서 발생하는 모든 질환의 예방, 치료 및 재활을 담당하는 분야</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
			<a href="javascript:GoPage('clinic3')">
			<div class="in-box bg3">
				<h3>관절경</h3>
				<div class="hover-box">
					<dl>
						<dt>관절경</dt>
						<p class="line"></p>
						<dd>관절의 질환이나 손상을 관절내시경을 이용하여 최소 절개 시술</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
			<a href="javascript:GoPage('clinic4')">
			<div class="in-box bg4">
				<h3>인공관절</h3>
				<div class="hover-box">
					<dl>
						<dt>인공관절</dt>
						<p class="line"></p>
						<dd>인체에 무해하고 튼튼한 인공관절로 대체해 수술하는 방법</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
			<a href="javascript:GoPage('clinic5')">
			<div class="in-box bg5">
				<h3>팔꿈치</h3>
				<div class="hover-box">
					<dl>
						<dt>팔꿈치</dt>
						<p class="line"></p>
						<dd>팔꿈치의 과도한 사용으로 인한 손상과 통증을 치료하는 분야</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
			<a href="javascript:GoPage('clinic6')">
			<div class="in-box bg6">
				<h3>손목</h3>
				<div class="hover-box">
					<dl>
						<dt>손목</dt>
						<p class="line"></p>
						<dd>손목의 과도한 사용으로 인한 손상과 통증을 치료하는 분야</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
			<a href="javascript:GoPage('clinic7')">
			<div class="in-box bg7">
				<h3>척추</h3>
				<div class="hover-box">
					<dl>
						<dt>척추</dt>
						<p class="line"></p>
						<dd>경추에서부터 요추까지 신경계통에 발생하는 여러 질환을 치료</dd>
						<p class="btn"><span>자세히보기</span></p>
					</dl>
				</div>
			</div>
			</a>
		</div>
</div>
</section>















<section id="mDoctor">
<div class="inner mp-Part">
		<div id="mTitle">
			<p class="eng">microsurgical · muscukiskeletal</p>
			<h3>축적된 <span class="fc-M1 fw-EB">의학 지식</span>과 <br class="br680">풍부한 <span class="fc-M2 fw-EB">수술 경험</span></h3>
			<p class="t1">MS재건병원은 실력을 인정받은 의료진들이 많은 임상 경험을 바탕으로 <br>환자의 빠른 회복과 치료를 위해 노력합니다.  </p>
		</div>
		<div class="mDoctorWrap">
			<a href="#doctor1">
                    <div class="img">
                        <img src="/images/main/mdoctor-img1.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>유선오 <span>병원장</span></h3>
                    </div>
			</a>
			<a href="#doctor2">
                    <div class="img">
                        <img src="/images/main/mdoctor-img2.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>하성한 <span>병원장</span></h3>
                    </div>
			</a>
			<a href="#doctor3">
                    <div class="img">
                        <img src="/images/main/mdoctor-img3.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>김효곤 <span>병원장</span></h3>
                    </div>
			</a>
			<a href="#doctor4">
                    <div class="img">
                        <img src="/images/main/mdoctor-img4.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>김정래 <span>병원장</span></h3>
                    </div>
			</a>
			<a href="#doctor5">
                    <div class="img">
                        <img src="/images/main/mdoctor-img5.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>김동영 <span>원장</span></h3>
                    </div>
			</a>
			<a href="#doctor6">
                    <div class="img">
                        <img src="/images/main/mdoctor-img6.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>이원제 <span>원장</span></h3>
                    </div>
			</a>
			<a href="#doctor7">
                    <div class="img">
                        <img src="/images/main/mdoctor-img7.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>나호동 <span>과장</span></h3>
                    </div>
			</a>
			<!-- <a href="#doctor8">
                    <div class="img">
                        <img src="/images/main/mdoctor-img8.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>박진식 <span>과장</span></h3>
                    </div>
			</a> -->
          
            <a href="#doctor14">
                    <div class="img">
                        <img src="/images/main/mdoctor-img14.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>성형외과 전문의</h4>
                        <h3>이현록 <span>과장</span></h3>
                    </div>
			</a>
              <a href="#doctor15">
                    <div class="img">
                        <img src="/images/main/mdoctor-img15.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>정형외과 전문의</h4>
                        <h3>송원호 <span>과장</span></h3>
                    </div>
			</a>
			<a href="#doctor9">
                    <div class="img">
                        <img src="/images/main/mdoctor-img9.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>마취통증의학과 전문의</h4>
                        <h3>정종성 <span>원장</span></h3>
                    </div>
			</a>
			<a href="#doctor10">
                    <div class="img">
                        <img src="/images/main/mdoctor-img10.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>마취통증의학과 전문의</h4>
                        <h3>하인호 <span>과장</span></h3>
                    </div>
			</a>
			<a href="#doctor11">
                    <div class="img">
                        <img src="/images/main/mdoctor-img11.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>가정의학과 전문의</h4>
                        <h3>황병윤 <span>원장</span></h3>
                    </div>
			</a>
			<a href="#doctor12">
                    <div class="img">
                        <img src="/images/main/mdoctor-img12.png" alt="">
                    </div>
                    <div class="txt">
                        <h4>영상의학과 전문의</h4>
                        <h3>강민석 <span>과장</span></h3>
                    </div>
			</a>
		</div>
</div>
</section>

<?php include "inc/doctor.php"; ?>










<section id="mGuide" class="mp-Part pb0">
		<div id="mTitle" class="center">
			<p class="fc-wh eng">microsurgical · muscukiskeletal</p>
			<h3 class="fc-wh">늘 언제나 <br class="br680"><span class="fw-EB">환자 곁</span>에서, <span class="fw-EB">환자 편</span>에 서서</h3>
			<h3 class="fc-wh">생각하고 행동하는 <br class="br680"><span class="fw-EB">MS재건병원</span></h3>
		</div>
		<div class="contWrap">
			<div class="in-box bg1">
				<dl>
					<dt>병원 이용안내</dt>
					<dd>MS재건병원의 진료 절차와 이용 방법을 <br>쉽고 편리하게 안내합니다.</dd>
				</dl>
				<a href="javascript:GoPage('guide1')">진료 안내</a>
				<a href="javascript:GoPage('intro6')">병원층별 안내</a>
				<a href="javascript:GoPage('guide4')">응급실 안내</a>
				<a href="javascript:GoPage('guide5')">증명서발급 안내</a>
			</div>
			<div class="in-box bg2">
				<dl>
					<dt>상담 및 후기</dt>
					<dd>온라인상담을 통해 진료에 대한 궁금증을 해결하고, <br>다양한 수술 후기를 통해 치료 경험을 공유합니다.</dd>
				</dl>
				<a href="javascript:GoPage('review1')">온라인상담</a>
				<a href="javascript:GoPage('review2')">수술후기</a>
			</div>
			<div class="in-box bg3">
				<dl>
					<dt>진료시간 안내</dt>
				</dl>
				<ul id="mDotList">
					<li><p><span>월-금요일</span>오전 9시 ~ 오후 6시</p></li>
					<li><p><span>토요일</span>오전 9시 ~ 오후 1시</p></li>
					<li><p><span>점심시간</span>오전 1시 ~ 오후 2시</p></li>
					<li><p><span>일·공휴일</span>휴진</p></li>
				</ul>
				<p class="st1">단, 응급환자는 365일 24시간 응급 진료</p>
			</div>
		</div>
</section>






<section id="mComm">
<div class="inner mp-Part">
		<div id="mTitle">
			<p class="eng">microsurgical · muscukiskeletal</p>
			<h3>다양한 <span class="fc-M1 fw-EB">소식</span>과 <span class="fc-M2 fw-EB">정보</span>를 <br class="br680">알려드립니다.</h3>
		</div>
		<div class="contWrap">
			<div class="in-box">
				<div class="tit">
					<h3>병원소식</h3>
					<a href="javascript:GoPage('comm1')">+</a>
				</div>
				
				<?php echo latest('basic', 'comm1', 3, 99); ?>
<!--
				<ul class="cont">
					<li>
						<a href="#">
							<div class="date"><b>11</b><span>24.09</span></div>
							<div class="con">
								<div class="t">2024 추석맞이 사랑나눔 실천</div>
								<div class="c">2024년 추석을 맞이하여 관내 어려운 이웃들에게 사랑나눔 실천의 일환으로 일환으로</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="date"><b>11</b><span>24.09</span></div>
							<div class="con">
								<div class="t">2024 추석맞이 사랑나눔 실천</div>
								<div class="c">2024년 추석을 맞이하여 관내 어려운 이웃들에게 사랑나눔 실천의 일환으로 일환으로</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="date"><b>11</b><span>24.09</span></div>
							<div class="con">
								<div class="t">2024 추석맞이 사랑나눔 실천</div>
								<div class="c">2024년 추석을 맞이하여 관내 어려운 이웃들에게 사랑나눔 실천의 일환으로 일환으로</div>
							</div>
						</a>
					</li>
				</ul>
-->
			</div>
			<div class="in-box">
				<div class="tit">
					<h3>보도자료</h3>
					<a href="javascript:GoPage('intro4')">+</a>
				</div>
				<?php echo latest('pic_block', 'intro4', 2, 99); ?>
<!--
				<ul class="cont">
					<li class="imgcont">
						<a href="#">
							<div class="img"><img src="/images/main/mcomm-img1.png"></div>
							<div class="con">
								<div class="t">2024 추석맞이 사랑나눔 실천 2024 추석맞이 사랑나눔 실천2024 추석맞이 사랑나눔 실천</div>
								<div class="c">2024년 추석을 맞이하여 관내 어려운 이웃들에게 사랑나눔 실천의 일환으로 2024년 추석을 맞이하여 관내 어려운 이웃들에게 사랑나눔 실천의 일환으로</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="date"><b>11</b><span>24.09</span></div>
							<div class="con">
								<div class="t">2024 추석맞이 사랑나눔 실천</div>
								<div class="c">2024년 추석을 맞이하여 관내 어려운 이웃들에게 사랑나눔 실천의 일환으로</div>
							</div>
						</a>
					</li>
				</ul>
-->
			</div>
		</div>
</div>
</section>




<section id="mMap">
	<div id="mapWrap">
	<!-- * 카카오맵 - 지도퍼가기 -->
	<!-- 1. 지도 노드 -->
	<div id="daumRoughmapContainer1734423297769" class="root_daum_roughmap root_daum_roughmap_landing"
		style="width:100%"></div>

	<!--
		2. 설치 스크립트
		* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
	-->
	<script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

	<!-- 3. 실행 스크립트 -->
	<script charset="UTF-8">
		new daum.roughmap.Lander({
			"timestamp" : "1734423297769",
			"key" : "2miuy"
		}).render();
	</script>
	</div>
	<div id="contWrap">
		<div class="in-cont">
		<div class="in-box">
			<h3>오시는 길</h3>
			<p class="add">대구광역시 중구 동덕로 194 (동인동 1가)</p>
			<p class="t1">동인네거리에서 종각네거리 방면 45m</p>
			<ul>
				<li class="tit">주차장 안내</li>
				<li class="cont"><p class="t1 pt0">건물 뒷편 지하주차장 (발렛파킹)</p></li>
			</ul>
			<ul class="mt0 pb0">
				<li class="tit">버스 이용시</li>
				<li class="cont">
					<p class="t1 pt0">동인찜갈비골목[앞]</p>
					<span>156</span><span>306</span><span>403</span><span>425</span><span>650</span>
					<p class="t1">동인찜갈비골목[건너]</p>
					<span>156</span><span>306</span><span>403</span><span>425</span><span>650</span><span>980</span><span>가창2</span>
					<p class="t1">동인네거리1</p>
					<span>425</span><span>651</span>
				</li>
			</ul>
		</div>
		</div>
		<div class="btn">
		<a href="javascript:GoPage('kakao')" class="bg1"><p>카카오맵 길찾기</p><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
		<a href="javascript:GoPage('naver')" class="bg2"><p>네이버지도 길찾기</p><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
		</div>
	</div>
</section>



<script type="text/javascript" src="/js/main.js"></script>

<?php include "inc/bottom.php"; ?>