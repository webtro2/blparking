<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "6";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>




	<div id="infoTop">
		<div class="img"><img src="/images/sub/infotop-clinic6.png" alt="" /></div>
		<div class="cont">
			<div class="in-box">
					<p class="eng">MS R.HOSPITAL</p>
					<h3>손목</h3>
					<dl>
						<dt>손목의 건강을 되찾아 자유로운 움직임을 선물</dt>
						<dd>손목 터널 증후군부터 관절염까지, <BR>손목의 건강을 회복시키는 정밀한 치료를 제공합니다.</dd>
					</dl>
			</div>
		</div>
	</div>


	<div id="clinicWrap">
		<h3 id="depart1-h3">손목 클리닉</h3>
		<dl>
			<dt>전문적인 진단과 치료를 통해 건강하고 자유로운 움직임을 되찾으세요.</dt>
			<dd>손목은 일상생활에서 반복적으로 사용되어 손상과 통증이 발생하기 쉬운 부위입니다. <BR>손목 클리닉에서는 손목 터널 증후군, 건초염, 인대 손상, 골절, 관절염 등 다양한 손목 질환을 전문적으로 진단하고 치료합니다.</dd>
			<dd>대학병원급 의료장비를 통해 정밀한 진단을 제공하며, 비수술적 치료(약물치료, 주사요법, 물리치료)부터 <BR>수술적 치료까지 환자 개개인의 상태에 맞춘 최적의 솔루션을 제시합니다.</dd>
			<dd>특히, 최소침습 수술을 통해 회복 시간을 단축하고 합병증을 최소화하며, <BR>수술 후에는 전문적인 재활 치료로 손목의 기능을 완벽히 회복할 수 있도록 돕습니다. </dd>
		</dl>
	</div>


<h3 id="depart1-h3" >손목 질환</h3>


<div id="clinicTab">
	<section id="tabWrap">
		<ul class="w3">
		   <li class="ON"><a href="#tab1">손목건초염</a></li>
		   <li><a href="#tab2">원위 요척골 관절의 불안정</a></li>
		   <li><a href="#tab3">척골 충돌 증후군</a></li>
		</ul>
	</section>


	<section id="contWrap">
		  <article id="tab1" class="tabCont ON">
				<h3 id="tabTitle"><span class="lt1">손목건초염이란?</span></h3>
				<div id="tabcont">
					<p class="t1">근육과 뼈를 연결해주는 건(힘줄)을 둘러싸고 있는 것을 '건초'라 합니다.</p>
					<p class="t1">이 건초에 염증이 발생하여 부종 및 통증이 발생하는 질병을 건초염이라고 합니다.</p>
					<p class="t1">건초염은 어디든 나타날 수 있지만 주록 '손목'에 나타나며, 손을 많이 쓰는 사람에게 잘 발생합니다.</p>
					<ul id="circleList" class="w4">
						<li><p>반복적인 동작</p></li>
						<li><p>과도한 사용</p></li>
						<li><p>충격 또는 손상</p></li>
						<li><p>호르몬 변화</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic6">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">손목건초염 증상</h3>
							<li><p>손목 바깥쪽과 엄지손가락 부위에 통증이 느껴지며, 움직일 때 악화됩니다.</p></li>
							<li><p>손목 바깥쪽에 부종이 생기며 만지면 민감할 수 있습니다.</p></li>
							<li><p>엄지손가락과 손목의 움직임이 제한되고 힘이 약해질 수 있습니다.</p></li>
							<li><p>손목을 움직일 때 힘줄 부위에서 마찰음이나 딸깍 소리가 날 수 있습니다.</p></li>
						</ul>
					</div>
				<h3 id="tabTitle">손목건초염 치료</h3>
				<div id="tabcont" class="pb0">
					<div id="dl-cont" class="w50">						
						<dl>
							<dt>보존적 치료</dt><dd>비수술적 치료는 통증 완화와 염증 감소를 목표로 합니다. 우선 손목을 사용하지 않고 충분히 휴식하며, 손목 보호대를 착용하여 움직임을 제한합니다. 비스테로이드성 소염제(NSAIDs)로 통증과 염증을 줄이고, 물리치료로 손목의 기능 회복을 돕습니다. 필요시 스테로이드 주사를 건초에 주입하여 염증을 빠르게 완화할 수 있습니다. 초기 단계에서는 휴식과 적절한 관리만으로도 증상이 호전될 수 있습니다.</dd>
						</dl>
						<dl>
							<dt>신경 감압술</dt><dd>비수술적 치료로 증상이 개선되지 않을 경우 수술적 치료를 고려할 수 있습니다. 수술은 힘줄을 감싸고 있는 건초를 절개하여 힘줄이 더 자유롭게 움직일 수 있도록 하는 방식으로 진행됩니다. 이는 힘줄의 압력을 줄이고 염증을 완화시키는 데 효과적입니다. 수술 후에는 물리치료를 통해 손목의 운동성과 힘을 회복하며, 완전한 기능 회복까지 몇 주에서 몇 달이 소요될 수 있습니다.</dd>
						</dl>
					</div>
				</div>				
		  </article>
		  <article id="tab2" class="tabCont">		
			<h3 id="tabTitle"><span class="lt1">원위 요척골 관절의 불안정이란?</span></h3>
				<div id="tabcont">
					<p class="t1">원위 요척골 관절 불안정은 손목의 요골과 척골이 연결된 관절 부위가 손상되거나 불안정해져 통증, 부기, 운동 장애 등을 초래하는 상태입니다. </p>
					<p class="t1">손목 외상 후에 흔히 발생하며, 안정성을 유지하는 인대의 손상이 주요 원인입니다.</p>
					<ul id="circleList" class="w4">
						<li><p>외상</p></li>
						<li><p>반복적인 사용</p></li>
						<li><p>관절염</p></li>
						<li><p>선천적 요인</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic6">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">원위 요척골 관절의 불안정 증상</h3>
							<li><p>손목을 움직일 때 특히 강하게 느껴지는 통증이 나타납니다.</p></li>
							<li><p>손목의 가동 범위가 줄어들며, 일상적인 움직임이 어려울 수 있습니다.</p></li>
							<li><p>손목을 움직일 때 관절이 어긋나는 듯한 소리가 들리거나 느껴질 수 있습니다.</p></li>
							<li><p>손목이 불안정하게 느껴지고 물건을 잡을 때 힘이 약해질 수 있습니다.</p></li>
						</ul>
					</div>
				<h3 id="tabTitle">원위 요척골 관절의 불안정 치료</h3>
				<div id="tabcont" class="pb0">
					<div id="dl-cont" class="w50">						
						<dl>
							<dt>보존적 치료</dt><dd>비수술적 치료는 관절의 안정성을 강화하고 통증을 줄이는 데 초점을 맞춥니다. 손목 보호대를 착용해 관절의 움직임을 제한하고 안정성을 제공하며, 비스테로이드성 소염제(NSAIDs)로 염증과 통증을 완화합니다. 물리치료를 통해 주변 근육을 강화하고 관절의 안정성을 회복하며, 반복적인 손목 사용을 줄이는 것이 중요합니다. 심한 경우, 스테로이드 주사로 염증을 감소시킬 수 있습니다. 경미한 불안정성은 적절한 치료와 휴식으로 호전될 수 있습니다.</dd>
						</dl>
						<dl>
							<dt>수술적 치료</dt><dd>수술적 치료는 인대 복원과 관절 안정성을 회복하기 위해 필요할 수 있습니다. 손상된 인대를 재건하거나 봉합하고, 관절의 정렬을 바로잡아 안정성을 강화하는 수술이 주로 시행됩니다. 심한 경우에는 관절 고정술이나 관절경을 이용한 치료가 이루어질 수 있습니다. 수술 후에는 손목의 기능과 운동 범위를 회복하기 위해 재활 치료가 필수적이며, 완전한 회복까지 몇 개월이 걸릴 수 있습니다.</dd>
						</dl>
					</div>
				</div>				
			</article>
		  <article id="tab3" class="tabCont">		
			<h3 id="tabTitle"><span class="lt1">척골 충돌 증후군이란?</span></h3>
				<div id="tabcont">
					<p class="t1">척골 충돌 증후군은 손목의 척골이 요골보다 길거나 구조적으로 부조화를 이루어 손목의 관절과 삼각섬유연골 복합체(TFCC)에 과도한 압박을 가해 통증과 염증을 유발하는 상태입니다. </p>
					<p class="t1">반복적인 손목 사용이나 외상이 원인이 될 수 있습니다.</p>					 
					<ul id="circleList" class="w4">
						<li><p>척골 길이 이상</p></li>
						<li><p>반복적 사용</p></li>
						<li><p>손목 골절·충격</p></li>
						<li><p>퇴행성 변화</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic6">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">척골 충돌 증후군 증상</h3>
							<li><p>손목의 새끼손가락 쪽에서 지속적이고 심한 통증이 발생합니다.</p></li>
							<li><p>손목의 가동 범위가 줄어들고 힘이 약해질 수 있습니다.</p></li>
							<li><p>손목 관절 부위가 붓고 염증 증상이 나타날 수 있습니다.</p></li>
							<li><p>손목을 움직일 때 관절에서 소리가 날 수 있습니다.</p></li>
						</ul>
					</div>
				<h3 id="tabTitle">척골 충돌 증후군 치료</h3>
				<div id="tabcont" class="pb0">
					<div id="dl-cont" class="w50">						
						<dl>
							<dt>보존적 치료</dt><dd>척골 충돌 증후군의 비수술적 치료는 통증 완화와 염증 감소를 목표로 합니다. 손목 보호대를 착용해 관절의 부담을 줄이고, 비스테로이드성 소염제(NSAIDs)로 염증과 통증을 완화합니다. 물리치료로 손목의 근력을 강화하고 관절의 안정성을 회복시킬 수 있습니다. 스테로이드 주사를 통해 삼각섬유연골 복합체의 염증을 줄이며, 반복적인 손목 사용을 피하거나 줄이는 것이 중요합니다. 증상이 경미한 경우, 이러한 치료로 개선될 수 있습니다.</dd>
						</dl>
						<dl>
							<dt>수술적 치료</dt><dd>비수술적 치료로 증상이 개선되지 않을 경우 수술적 치료를 고려할 수 있습니다. 대표적으로 척골 단축술이 시행되며, 척골의 길이를 줄여 관절의 압박을 해소합니다. 삼각섬유연골 복합체(TFCC)가 손상된 경우, 복원 또는 봉합 수술을 병행할 수 있습니다. 관절경을 사용한 최소 침습적 수술도 효과적입니다. 수술 후에는 손목의 기능과 안정성을 회복하기 위해 재활 치료가 필수적이며, 완전한 회복까지 몇 개월이 소요될 수 있습니다.</dd>
						</dl>
					</div>
				</div>				
			</article>

	</section>
</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
