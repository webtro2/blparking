<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

		<div id="guide1">
			<div id="titWrap">
				<h3>입원절차</h3>
			</div>
			<div id="contWrap">
				<ul id="boxNum">
					<li>
						<p class="tit">진료접수</p>
						<ul id="dotList">
							<li><p>1층 원무과에 오시면 접수를 도와드리겠습니다.</p></li>
						</ul>
					</li>
					<li>
						<p class="tit">해당과 진료</p>
						<ul id="dotList">
							<li><p>담당 의사와의 상담 후 환자의 상태를 평가하여 입원이 필요하다고 판단되면 입원을 결정합니다.</p></li>
							<li><p>진료를 받으시고 검사 받으러 가실때도 담당과 간호사가 환자분이 편안하게 검사를 받을 수 있도록 안내해 드립니다.</p></li>
						</ul>
					</li>
					<li>
						<p class="tit">입원수속</p>
						<ul id="dotList">
							<li><p>원무과 접수창구에서 입원 신청서를 작성하고 필요한 서류를 제출합니다.</p></li>
							<li><p>건강보험증, 신분증, 입원 동의서, 보호자 정보 등을 준비해 주시면 신속히 진행할 수 있습니다.</p></li>
						</ul>
					</li>
					<li>
						<p class="tit">병실이동</p>
						<ul id="dotList">
							<li><p>배정받은 병실로 이동하며, 입원 생활에 필요한 물품과 병실 이용 안내를 받습니다.</p></li>
							<li><p>입원 초기 병실 생활 및 병원 규칙(면회 시간, 식사 시간 등)에 대해 설명드립니다.</p></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>

		<div id="guide1" class="p-Part">
			<div id="titWrap">
				<h3>입원시 필요한 <br>서류 및 물품</h3>
			</div>
			<div id="contWrap">
				<ul id="dotList">
					<li><p>건강보험증, 신분증, 입원동의서</p></li>
					<li><p>약정인 및 연대보증인 1인의 서명</p></li>
					<li><p>입원 생활 준비물 : 수저, 휴지, 슬리퍼, 치약, 칫솔, 타올, 세면도구, 물컵 등</p></li>
				</ul>
			</div>
		</div>

		<div id="guide1">
			<div id="titWrap">
				<h3>구급차 이용안내</h3>
			</div>
			<div id="contWrap">
				<ul id="dotList">
					<li><p>입.퇴원 시 구급차 사용을 원하실 경우 원무과 또는 입원병동간호사실에 문의 하시기 바랍니다.</p></li>
				</ul>
			</div>
		</div>


		<div id="guide1">
			<div id="titWrap">
				<h3>퇴원절차</h3>
			</div>
			<div id="contWrap">
				<ul id="boxNum">
					<li>
						<p class="tit">입원 만료 전</p>
						<ul id="dotList">
							<li><p>산재 환자의 경우, 입원 만료 예정일로부터 늦어도 일주일전에는 퇴원 또는 입원 연장 여부가 결정되어야 하므로 미리 주치의와 상의하셔야 합니다.</p></li>
							<li><p>제증명서류가 필요하신분은 퇴원결정 전에 미리 병동간호사실에 신청하십시오.</p></li>
						</ul>
					</li>
					<li>
						<p class="tit">퇴원 결정</p>
						<ul id="dotList">
							<li><p>담당 의사가 환자의 상태를 확인한 후 퇴원이 가능하다고 판단되면 퇴원을 결정합니다.</p></li>
							<li><p>퇴원 결정되면 입원 기록을 확인한 후 담당 간호사의 정리가 끝나면 원무과 퇴원 창구에서 계산서가 발행됩니다 .</p></li>
						</ul>
					</li>
					<li>
						<p class="tit">퇴원 수속</p>
						<ul id="dotList">
							<li><p>퇴원 후 주의사항, 복용해야 할 약물, 생활 관리 방법 등을 의료진에게 상세히 안내받습니다.</p></li>
							<li><p>병동 간호사실에서 연락을 받은 후 보험카드와 진료비를 준비하여 1층 원무과 퇴원 수속 창구에서 진료비 계산서를 받아서 진료비를 수납하시면 됩니다 .</p></li>
							<li><p>진료비 수납이 완료되면 퇴원 수속 창구에서 퇴원 완료증과 예약증을 확인 후 퇴원 완료증을 병동 간호사실에 내시고 퇴원약을 받아야 합니다.</p></li>
						</ul>
					</li>
					<li>
						<p class="tit">귀가 및 관리</p>
						<ul id="dotList">
							<li><p>예약증과 퇴원약을 수령하신 후 귀가하시면 됩니다 .</p></li>
							<li><p>퇴원 후 외래 진료 예약은 간호사실에서 다음 예약을 해드리며 진료비 수납시 함께 납부하시면 됩니다.</p></li>
							<li><p>퇴원 후 불편한 증상이나 궁금한 점이 생길 경우 병원에 연락하여 상담받으실 수 있습니다.</p></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
