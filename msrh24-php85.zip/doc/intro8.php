<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "8";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont"  class="pb0">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="sMap" class="inner">
		<!-- * 카카오맵 - 지도퍼가기 -->
		<!-- 1. 지도 노드 -->
		<div id="daumRoughmapContainer1734668164375" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%"></div>

		<!--
			2. 설치 스크립트
			* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
		-->
		<script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

		<!-- 3. 실행 스크립트 -->
		<script charset="UTF-8">
			new daum.roughmap.Lander({
				"timestamp" : "1734668164375",
				"key" : "2mjya"
			}).render();
		</script>
	</div>
	<div id="sMapInfo">
		<div id="img"><img src="/images/common/logo_w.png"></div>
		<div id="cont">
			<h3><i class="fa-solid fa-location-dot"></i> 대구광역시 중구 동덕로 194 (동인동 1가)</h3>
			<div class="tel">
				<dl>
					<dt><i class="fa-solid fa-phone"></i> Tel</dt>
					<dd>053) 653-0119</dd>
				</dl>
				<dl>
					<dt><i class="fa-solid fa-fax"></i> Fax</dt>
					<dd>053) 653-0770</dd>
				</dl>
			</div>
		</div>
		<div class="btn">
			<a href="javascript:GoPage('kakao')" class="bg1"><p>카카오맵 길찾기</p></a>
			<a href="javascript:GoPage('naver')" class="bg2"><p>네이버지도 길찾기</p></a>
		</div>
	</div>

	
	<div id="sMapLoca">
	<div class="inner">
		<h3 class="center">주차장 및 대중교통 이용안내</h3>
		<ul class="in-box">
			<li class="tit">
				<img src="/images/sub/intro8-icon1.png">
				<p class="t2">주자창 안내</p>	
			</li>
			<li class="cont">
				<p class="t2">일반 차량은 지하1층 주차장 이용</p>	
				<p class="t1">건물 뒷편으로 진입하여 본 건물 우측 지하주차장을 이용하시기 바랍니다.</p>
				<p class="t2">화물차, 승합차는 외부주차장 이용</p>
				<p class="t1">중앙유료주차장(대구시 중구 국채보상로 139길 39-5)을 이용하시기 바랍니다.</p>
			</li>
		</ul>
		<ul class="in-box">
			<li class="tit">
				<img src="/images/sub/intro8-icon2.png">
				<p class="t2">버스이용시</p>	
			</li>
			<li class="cont">
				<p class="t2">동인찜갈비골목[앞]</p>	
				<p class="t1"><span>156</span><span>306</span><span>403</span><span>425</span><span>650</span></p>
				<p class="t2">동인찜갈비골목[건너]</p>	
				<p class="t1"><span>156</span><span>306</span><span>403</span><span>425</span><span>650</span><span>980</span><span>가창2</span></p>
				<p class="t2">동인네거리1</p>	
				<p class="t1"><span>425</span><span>651</span></p>
			
			</li>
		</ul>


        <div class="park_img">
            <img src="/images/sub/park_img1.jpg" alt="주차장 안내">
            <img src="/images/sub/park_img2.jpg" alt="주차장 안내">
        </div>
	</div>
	</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
