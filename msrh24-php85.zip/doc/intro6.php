<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "6";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="intro6">
		<section class="in-box">
			<div class="imgWrap">
				<img src="/images/sub/intro6-img1.png">
			</div>
			<div class="contWrap">
				<dl>
					<dt>All 전산화에 의한 NO Chart System</dt>
					<dd>본원에서는 ICM 사의 full PACS OCS EMR system을 전면 도입하여, 의료 기록(medical recording)마저도 tablet PC monitor 상에 전자 펜을 이용하여 직접 필기하여 챠트를 작성함으로써 방사선 영상(PACS)과 처방 전달(OCS)뿐만 아니라 의료 기록(EMR)까지도 완전 전산화하여 진정한 No chart system에 의한 완전 전산화를 대구 최초로 실현하여 신속하고 정확한 환자 진료를 보장합니다.</dd>
				</dl>
			</div>
		</section>
		<section class="in-box">
			<div class="imgWrap">
				<img src="/images/sub/intro6-img2.png">
			</div>
			<div class="contWrap">
				<dl>
					<dt>CT 스캐너 </dt>
					<dd>경제성과 효율성을 겸비한 고성능 CT 촬영기로, 우수한 영상 품질과 저선량 기술을 통해 환자의 방사선 노출을 최소화하며 진단의 정확성을 높입니다. 직관적인 사용자 인터페이스와 간소화된 워크플로우는 의료진의 작업 효율성을 극대화하고, 유지비가 낮아 운영 비용을 절감할 수 있습니다. 컴팩트한 설계로 공간 활용도가 뛰어나며, 다양한 의료 환경에 최적화된 솔루션을 제공합니다.</dd>
				</dl>
			</div>
		</section>
		
		<section class="in-box">
			<div class="imgWrap">
				<img src="/images/sub/intro6-img3.png">
			</div>
			<div class="contWrap">
				<dl>
					<dt>자기공명영상장비 (MRI)</dt>
					<dd>고해상도 영상과 신뢰성을 겸비한 1.5T MRI 장비로,혁신적인 기술로 빠른 검사 속도와 우수한 영상 품질을 제공하며, Tim을 장착하여 기존의 MRI로는 불가능하였던 전신 척추 스캔을 환자 이동 없이 한번에 촬영이 가능하며 다양한 진단 요구를 충족합니다. 환자 중심의 설계로 편안한 검사 경험을 제공하고, 의료진의 효율성을 극대화할 수 있도록 직관적인 인터페이스와 최적화된 워크플로우를 지원합니다.</dd>
				</dl>
			</div>
		</section>

		<section class="in-box">
			<div class="imgWrap">
				<img src="/images/sub/intro6-img4.png">
			</div>
			<div class="contWrap">
				<dl>
					<dt>골밀도 검사기</dt>
					<dd>골밀도 측정에서 오차를 일으키는 피질골과 골극을 제외하고 골절의 위험성을 정확하게 반영하는 망상골 (cancellous bone)만 측정하여 정확한 골밀도 측정을 보장하는 최신형 골밀도 검사기를 도입하였습니다.</dd>
				</dl>
			</div>
		</section>
	
		<section class="in-box">
			<div class="imgWrap">
				<img src="/images/sub/intro6-img5.png">
			</div>
			<div class="contWrap">
				<dl>
					<dt>방사선 촬영기</dt>
					<dd>고성능 방사선 촬영 시스템으로, 탁월한 영상 품질과 빠른 촬영 속도를 제공합니다. 저선량 기술을 통해 환자의 방사선 노출을 최소화하고, 직관적인 인터페이스로 사용자가 쉽게 조작할 수 있습니다. 효율적인 워크플로우와 다양한 자동화 기능을 지원하여 진단의 정확성을 높이며, 유연한 설치 옵션과 유지보수가 용이해 다양한 의료 환경에 적합합니다.</dd>
				</dl>
			</div>
		</section>
		<section class="in-box">
			<div class="imgWrap">
				<img src="/images/sub/intro6-img6.png">
			</div>
			<div class="contWrap">
				<dl>
					<dt>C자형 이동식 방사선 영상 투시기</dt>
					<dd>고해상도의 듀얼 23인치 모니터 시스템과 직관적인 터치스크린 인터페이스를 통해 수술 중 실시간으로 선명하고 정확한 영상을 분석할 수 있습니다.  빠른 처리 속도로 안정적인 방사선 영상을 지원합니다. 또한, 대용량 메모리를 탑재해 4,000장 이상의 이미지를 저장하고, USB를 통한 소프트웨어 업그레이드 기능도 제공합니다.</dd>
				</dl>
			</div>
		</section>	
	</div>

	
	
		<section id="intro6-2">
			<dl>
				<dt>미세 현미경 및 수술기구</dt>
				<dd>골밀도 측정에서 오차를 일으키는 피질골과 골극을 제외하고 골절의 위험성을 정확하게 반영하는 망상골 (cancellous bone)만 측정하여 정확한 골밀도 측정을 보장하는 최신형 골밀도 검사기를 도입하였습니다.</dd>
			</dl>
			<dl>
				<dt>관절경 시스템</dt>
				<dd>흔히 시행하는 무릎, 어깨 관절과 같은 큰 관절의 관절경 뿐만 아니라 팔꿈치, 발목, 손목, 중수지 관절까지 시행할 수 있는 초소형 관절경까지 모두 완비되어 상, 하지 모든 관절의 정확한 진단과 치료를 가능케 하는 최신형 관절경 시스템을 도입하여 다양한 관절 질환의 치료에 최선의 결과를 보장합니다.</dd>
			</dl>
			<dl>
				<dt>무균 수술실</dt>
				<dd>수술 중 감염 방지와 청결을 보장하는 넓고 깨끗한 6개의 무균 수술실을 확보하여 쾌적한 수술 환경을 유지하여 최상의 수술 결과를 보장합니다.</dd>
			</dl>
			<dl>
				<dt>물리·재활치료실</dt>
				<dd>환자의 재활을 도와주는 다양한 최고급 장비와 함께, 수많은 임상 경험으로 숙련된 물리치료사와 재활치료사가 정성 어린 손길로 치료하여 수술 후 환자의 회복과 재활에서 최고의 결과를 보장합니다. 또한 건물의 2층에 있으면서 3면이 창문으로 구성되어 밝고 쾌적하며 넓은 공간을 확보하여 힘든 재활 치료 기간 동안 환자분들에게 편안한 치료 공간을 제공하고 있습니다.</dd>
			</dl>
			<dl>
				<dt>체외 충격파 치료기</dt>
				<dd>근골격계 통증질환에 혁신적인 최첨단 치료기로 체외 충격파 치료의 우수한 효과는 이미 해외에서 입증이 되었습니다.
체외충격파치료의 장점은 기본 보존적 치료의 단점인 일시적 통증 완화 보다 평소에 근본적인 치료를 효과적으로 시행할 수 있습니다.
비수술적 방법으로 수술에 거부감이 있는 환자에게 효과적인 치료를 가능케 합니다. 1회 10분 내외의 짧은 시간 동안 치료가 가능합니다. 4~5회의 반복치료로 기존 다른 치료보다 월등한 치료 효과를 보입니다. 부작용이 전혀 없는 치료법으로서, 기타 약물의 부작용이 있는 환자에게도 적용할 수 있습니다. 짧은 치료 시간 및 입원이 불필요하므로 일상생활에 지장을 주지 않습니다.
체외충격파치료의 적응증은 어깨(오십견, 석회화 건염), 목(견갑부근막통증후군), 팔꿈치(테니스 엘보, 골프 엘보), 골반(윤활낭염, 장경대인대마찰증후군), 무릎(만성 슬개인대염), 정강이(전경골근막통증후군), 아킬레스(만성 아킬레스건염), 발바닥(만성 족저근막염), 만성 근육 통증, 골저의 지연 유합 및 골연골염이 있습니다.</dd>
			</dl>
			<dl>
				<dt>소독시스템 및 중앙공급실</dt>
				<dd>주) 한신의 대용량의 EO gas 소독 시스템과 2대의 대용량 고압 멸균 시스템으로 모든 진료 물품 및 수술 기구에서 완벽한 청결성 및 멸균성을 보장하여 수술 중 감염 방지에 최선을 다하고 있습니다.</dd>
			</dl>
			<dl>
				<dt>초음파 진단기</dt>
				<dd>보이지 않는 몸 속 내부를 고통 없이 편안하고 간단하게 검사할 수 있는 최신 초음파 진단기를 도입하였습니다.</dd>
			</dl>
		</section>	

</div>
</div>
<?php include "../inc/bottom.php"; ?>
