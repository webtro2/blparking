<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


		
		<div id="guide1">
			<div id="titWrap">
				<h3>응급실</h3>
			</div>
			<div id="contWrap" class="guide1-4">
				<img src="/images/sub/guide1-4-icon.png">
				<dl>
					<dt><span class="fc-M2">문의전화</span> 053) 650-0118</dt>					
					<dd>365일 24시간 응급실</dd>
				</dl>
			</div>
		</div>

		
		<div id="guide1">
			<div id="titWrap">
				<h3>절단 부위의 처치</h3>
			</div>
			<div id="contWrap">
				<ul id="dotList">
					<li><p>환자를 안정시키고 절단부 상태를 살펴봅니다.</p></li>
					<li><p>절단 부위를 직접 압박하고 올려준다. 불완전 절단 시에는 절단 부위와 연결 부위를 같이 드레싱하고 올려줍니다.</p></li>
					<li><p>출혈의 정도를 확인하고 지혈이 안 되면 지혈점을 찾아 압박합니다.</p></li>
					<li><p>계속 출혈이 되면 마지막 방법으로 절단 부위 5㎝ 이내에서 고무줄 등으로 묶어 압박을 시행하며 이 때 압박을 시작한 시각을 기록합니다.</p></li>
				</ul>
			</div>
		</div>



		<div id="guide1">
			<div id="titWrap">
				<h3>절단 환자 발생시 <br>환자 이송 방법</h3>
			</div>
			<div id="contWrap">
				<ul id="dotList">
					<li><p>전화로 구조 요청을 할 때 반드시 절단 환자임을 밝히도록 합니다.</p></li>
					<li><p>절단된 부위는 묻은 흙을 털어내는 정도로 생리 식염수 또는 흐르는 물로 가볍게 씻습니다.</p></li>
					<li><p>절단된 부위를 축축한 소독 거즈에 싸고 다시 소독 거즈에 싼 다음 비닐 봉지에 넣고 고무줄로 밀봉한 후 얼음 상자에 보관하여 이송하는 것이 좋습니다. 이 때 절단 부위가 얼음에 직접 닿아서 얼지 않도록 세심한 주의가 필요합니다. (얼어버리면 재접합이 절대로 불가능함)</p></li>
					<li><p>손가락이나 발가락처럼 근육이 거의 없는 부위는 8시간 이내에는 재접합이 가능하며, 4°C 에서 차갑게 보관된 경우에는 24-48시간까지도 재접합이 가능합니다.</p></li>
					<li><p>손목이나 발목관절보다 더 위쪽에서 절단된 경우에는 근육이 많이 포함되어 있어 6시간 이내에 재접합을 해야 하며, 4°C 에서 차갑게 보관된 경우에도 가능한 한 12시간 이내에는 재접합을 해야 하므로 신속한 진료를 요합니다.</p></li>
					<li><p>대부분의 경우 재접합은 신속한 수술을 요하므로, 다치면 물도 먹지 말고 절대 금식을한 상태로 병원에 오시고, 절단부는 가능하면 4°C 에서 차갑게 보관하면서 이송하는 것이 좋습니다.</p></li>
				</ul>
			</div>
		</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
