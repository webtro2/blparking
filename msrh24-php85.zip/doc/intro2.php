<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" >
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

		
		<div id="intro2">
			<div id="titWrap">
				<h3>MS재건병원 명칭</h3>
			</div>
			<div id="contWrap" class="intro2-1">
				<p class="t1">미세수술적 방법을 포함한 다양한 방법으로 팔, 다리의 근골격계에서 손상된 부분을 다시 만들어
정상적인 기능을 회복시키고자 최선의 노력을 하나는 병원  </p>
				<div class="img"><img src="/images/sub/intro2-img1.png"></div>
				<dl>
					<dt class="bg1">MS</dt>
					<dd>Microsurgical (미세수술)·Musculoskeletal (근골격계)</dd>
				</dl>
				<dl>
					<dt class="bg2">재건</dt>
					<dd>허물어진 건물이나조직 따위를 다시 일으켜 세움</dd>
				</dl>
				
			</div>
		</div>


		<div id="intro2">
			<div id="titWrap">
				<h3>MS재건병원 로고</h3>
			</div>
			<div id="contWrap" class="intro2-2">
				<div class="img"><img src="/images/sub/intro2-img2.png"></div>
				<dl>
					<dt class="bg1">MS</dt>
					<dd>Musculoskeletal & Microsurgical Reconstructive</dd>
				</dl>
				<dl>
					<dt class="bg1">빨간색</dt>
					<dd>동맥과 근육을 상징</dd>
				</dl>	
				<dl>
					<dt class="bg2">파란색</dt>
					<dd>정맥과 뼈를 상징</dd>
				</dl>	
				<dl>
					<dt class="bg2">가로줄</dt>
					<dd>미세하고 정확하게 재배열한다는 의미</dd>
				</dl>					
				<dl>
					<dt class="bg3">전체모양</dt>
					<dd>방패 : 질병을 막는다  - 십자가 : 병원을 상징</dd>
				</dl>
			</div>
		</div>



		<div id="intro2" class="pb0">
			<div id="titWrap">
				<h3>MS재건병원 정신</h3>
			</div>
			<div id="contWrap" class="intro2-3">
				<p class="t1"><span>환자들의 건강을 재건하여 <br class="bg1024">환자와 가족, 직장의 행복을 재건하여, 희망찬 미래를 재건한다.</span></p>
				<div class="circleWrap">
				<dl class="bg1">
					<dt>건강재건</dt>
					<dd>Health</dd>
				</dl>
				<dl class="bg2">
					<dt>행복재건</dt>
					<dd>Happiness</dd>
				</dl>
				<dl class="bg3">
					<dt>미래재건</dt>
					<dd>Future</dd>
				</dl>
				</div>
			</div>
		</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
