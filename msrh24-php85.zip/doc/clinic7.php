<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "7";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="infoTop">
		<div class="img"><img src="/images/sub/infotop-clinic7.png" alt="" /></div>
		<div class="cont">
			<div class="in-box">
					<p class="eng">MS R.HOSPITAL</p>
					<h3>척추</h3>
					<dl>
						<dt>척추의 건강, 당신의 삶을 바로 세웁니다</dt>
						<dd>디스크, 협착증 등 척추 질환을 정밀 진단하고 <BR>최적의 치료로 건강을 되찾아 드립니다.</dd>
					</dl>
			</div>
		</div>
	</div>


	<div id="clinicWrap">
		<h3 id="depart1-h3">척추 클리닉</h3>
		<dl>
			<dt>경추에서 요추까지, 신경계통에 발생하는 여러 질환의 정확한 진단과 치료 시행</dt>
			<dd>척추는 몸의 중심을 이루는 중요한 구조로, 디스크 탈출증(허리디스크), 척추관 협착증, 척추 측만증, 골다공증성 압박골절 등 <BR>다양한 질환으로 인해 통증과 움직임 제한이 발생할 수 있습니다. </dd>
			<dd>척추 클리닉에서는 최신 진단 장비를 활용해 정밀한 검사를 진행하고, 비수술적 치료(약물치료, 신경 차단술, 물리치료)와 <BR>수술적 치료를 포함한 맞춤형 치료 계획을 제공합니다. </dd>
			<dd>특히, 최소침습 척추 수술을 통해 회복 시간을 단축하고 환자의 부담을 줄이며, <BR>수술 후 전문 재활 프로그램으로 빠른 회복과 기능 회복을 지원합니다. </dd>
		</dl>
	</div>




<h3 id="depart1-h3" >척추클리닉 진료</h3>

	<ul id="boxNum" class="guide3">
		<li>
			<p class="tit">신경차단술(경추간공. 후관절 내측분지)</p>
			<ul id="dotList">
				<li><p>국소마취하에 요추나 경추부위 선택적 신경 차단술을 시행하고 있습니다. </p></li>
				<li><p>일반적으로 추간판 탈출증이나 협착증에서 선택적으로 시술 가능하며합니다. </p></li>
				<li><p>일시적인 효과가 아니라 오래동안 유지될 수도 있으며, 환자의 상태에 따라 시행해 볼수 있습니다.</p></li>
			</ul>
		</li>
		<li>
			<p class="tit">신경 성형술(풍선 신경 성형술)</p>
			<ul id="dotList">
				<li><p>꼬리뼈 공간을 이용한 특수 카테터를 삽입 병변 지역에 신경 완화를 목적으로 시행합니다. </p></li>
				<li><p>일반적으로 외래에서도 가능은 하나 대개의 경우 2-3일정도 입원 가료가 필요로 합니다. </p></li>
				<li><p>협착증이나 추간판 탈출증 그리고 추간판 내장증 및 섬유륜의 손상에서 시행해 볼 수 있으며, 수술전 1-2회정도 시행할수 있는 방법입니다.</p></li>
			</ul>
		</li>
		<li>
			<p class="tit">수핵제거술 및 후방 감압술</p>
			<ul id="dotList">
				<li><p><b class="fc-bl">미세현미경을 이용</b> : 최근 고해상도의 미세현미경을 이용하여 추간판 탈출증이나 협착증의 수술을 시행하고 있으며 신경의 손상이나 주변 조직의 손상을 최소화 하여 회복을 좀더 용이 하게 하고 있습니다.</p></li>
				<li><p><b class="fc-bl">내시경을 이용</b> : 내시경을 통하여 추간판 탈출증이나 협착증의 수술이 가능할 정도로 발달 되었으며, 신경의 손상이나 주변 조직의 손상을 최소화 하여 회복을 좀더 용이 하게 하고 있습니다.</p></li>
			</ul>
		</li>
		<li>
			<p class="tit">기기 유합술</p>
			<ul id="dotList">
				<li><p>목이나 척추의 퇴행성 변화가 심한경우나 과거 수술이후 재발의 경우등과 같이 광범위한 척추의 절제나 교정등이 필요로 할 때 시행할수 있는 방법입니다. </p></li>
				<li><p>상처가 크고 회복에도 시일이 많이 걸리는 만큼 정확한 진단이 필수라 할수 있습니다.</p></li>
			</ul>
		</li>
		<li>
			<p class="tit">인공디스크 치환술</p>
			<ul id="dotList">
				<li><p>경추부 요추부의 경우 디스크 내장증이나 추간판의 탈출이 심해 절제가 많이 이루어질 경우 유합술 대신 인공 디스크를 이용하여 움직임을 살릴수 있는 수술법입니다.</p></li>
				<li><p>비용이나 여러 가지 환자의 상태를 고려해야 하므로 전문의와 상의가 필요 합니다.</p></li>
			</ul>
		</li>
	</ul>


<h3 id="depart1-h3" >척추 질환</h3>


<div id="clinicTab">
	<section id="tabWrap">
		<ul class="w4">
		   <li class="ON"><a href="#tab1">추간판탈출증</a></li>
		   <li><a href="#tab2">척추관협착증</a></li>
		   <li><a href="#tab3">골다공증성 척추 압박골절</a></li>
		   <li><a href="#tab4">척추측만증</a></li>
		</ul>
	</section>


	<section id="contWrap">
		  <article id="tab1" class="tabCont ON">
				<h3 id="tabTitle"><span class="lt1">추간판탈출증이란?</span></h3>
				<div id="tabcont">
					<p class="t1">목이나 허리부위에 추체 사이에 충격을 흡수하는 기능을 가진 디스크가 여러 원인으로 인해 돌출이 되어 신경증상을 유발하는 질환으로 흔히 디스크라고 불리우는 질환입니다. </p>
					<p class="t1">대체로 허리부위의 통증을 동반하며, 엉치 허벅지 다리 종아리 발등으로 당기거나 쥐가 나는등의 증상이 발생을 하게됩니다.</p>
					<p class="t1">증상이 심해지면 가만히 있기도 어려울정도로 다리가 당기게 되며 심할 경우 마비등의 증상이 나타 날수 있습니다</p>
					<ul id="circleList" class="w4">
						<li><p>노화</p></li>
						<li><p>과도한 하중</p></li>
						<li><p>외상</p></li>
						<li><p>가족력</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic7">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">추간판탈출증  증상</h3>
							<li><p>허리를 굽히거나 회전할 때 심해지며, 지속적으로 통증이 발생할 수 있습니다.</p></li>
							<li><p>탈출된 디스크가 신경을 압박해 다리나 발에 방사통을 유발할 수 있습니다.</p></li>
							<li><p>다리나 발에 저림, 찌릿한 느낌이 들거나 마비 증상이 나타날 수 있습니다.</p></li>
							<li><p>통증으로 인해 허리의 움직임이 제한되고, 일상적인 활동이 어려워질 수 있습니다.</p></li>
						</ul>
					</div>	
		  </article>
		  <article id="tab2" class="tabCont">
				<h3 id="tabTitle"><span class="lt1">척추관협착증이란?</span></h3>
				<div id="tabcont">
					<p class="t1">시간이 지나 퇴행성 변화가 진행하면서 척추내관이 좁아지는 현상을 척추관 협착증이라고 합니다. </p>
					<p class="t1">일반적으로 나이가 들면서 발생을 하기 때문에 다양한 증상을 동반을 합니다 요통을 동반하면서 흔히 오래 걷기 어렵다고 하는 신경학적 파행의 증상을 보입니다.</p>
					<p class="t1">증상이 심하게 되면 5-10분 정도도 걷기가 어려워 지게 됩니다.</p>
					<ul id="circleList" class="w4">
						<li><p>노화</p></li>
						<li><p>디스크 탈출</p></li>
						<li><p>척추 퇴행성 질환</p></li>
						<li><p>가족력</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic7">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">척추관협착증  증상</h3>
							<li><p>오래 서 있거나 걸을 때 통증이 심해지며, 앉으면 증상이 완화될 수 있습니다.</p></li>
							<li><p>신경 압박으로 다리와 발에 저림 증상이 나타날 수 있습니다.</p></li>
							<li><p>오래 걸을 때 다리에 힘이 빠지거나 통증으로 인해 보행이 어려워질 수 있습니다.</p></li>
							<li><p>다리의 근육이 약해지며, 걸을 때 다리가 저려 힘이 빠지거나 비틀거릴 수 있습니다.</p></li>
						</ul>
					</div>
		  </article>
		  <article id="tab3" class="tabCont">
				<h3 id="tabTitle"><span class="lt1">골다공증성 척추 압박골절이란?</span></h3>
				<div id="tabcont">
					<p class="t1">고령인 경우나 뼈가 약할 경우 비교적 가벼운 외상에서도 척추 골절이 발생할 가능성이 있습니다. </p>
					<p class="t1">주저 앉았다던지. 가볍게 넘어지고 난뒤, 허리나 등부위에 통증이 발생하고 지속된다면 골다공증성 압박골절을 생각 해볼수 있습니다.</p>
					<p class="t1">이러한 경우 정확한 상태 파악이 중요 하며 보존적 치료나 추체성형술등의 시술로 호전될 수 있습니다.</p>
					<ul id="circleList" class="w4">
						<li><p>골다공증</p></li>
						<li><p>노화</p></li>
						<li><p>여성 호르몬 부족</p></li>
						<li><p>낙상이나 부상</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic7">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">골다공증성 척추 압박골절  증상</h3>
							<li><p>갑작스럽고 심한 허리 통증이 발생하며, 움직일 때 더 악화될 수 있습니다.</p></li>
							<li><p>등과 허리의 압박감: 무거운 물건을 들거나 갑자기 몸을 돌릴 때 통증이 발생합니다.</p></li>
							<li><p>골절로 인해 척추가 압박되어 키가 줄어들 수 있습니다.</p></li>
							<li><p>척추가 압박되면서 자세가 불안정해지고, 구부정한 자세를 취하게 될 수 있습니다.</p></li>
						</ul>
					</div>	
		  </article>
		  <article id="tab4" class="tabCont">
				<h3 id="tabTitle"><span class="lt1">척추측만증이란?</span></h3>
				<div id="tabcont">
					<p class="t1">청소년기 학생들의 경우 허리가 휘어 보인다는 이유로 병원을 많이 찾게 되는데, 단순히 휘어 보인다고 해서 다 측만증은 아닙니다. </p>
					<p class="t1">단순한 자세성 측만증에서부터 특발성 측만증까지 다양한 측만증이 존재하며 대부분의 경우 정확한 상태 파악과 진단이 중요하다고 할 수 있습니다. </p>
					<p class="t1">의심이 되거나 걱정이 되시는 경우 전문의의 진단과 치료가 필요 합니다.</p>
					<ul id="circleList" class="w4">
						<li><p>유전적 요인</p></li>
						<li><p>근육 불균형</p></li>
						<li><p>척추 발육 이상</p></li>
						<li><p>척추 외상</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic7">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">척추측만증  증상</h3>
							<li><p>한쪽 어깨가 다른 쪽보다 높거나 골반이 기울어져 보입니다.</p></li>
							<li><p>척추의 변형으로 인해 통증이 발생할 수 있습니다.</p></li>
							<li><p>측만증으로 인해 허리의 비정상적인 압력이 가해져 불편감을 느낄 수 있습니다.</p></li>
							<li><p>척추의 변형이 심해지면 걸을 때 균형을 잡기 어렵고 비틀거리거나 피로감을 느낄 수 있습니다.</p></li>
						</ul>
					</div>
		  </article>
	</section>
</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
