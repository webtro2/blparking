<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

<div id="clinicBg">	
	<div id="clinicTop" class="depart3 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png">
			<dl>
				<dt>내과·가정의학과</dt>
				<dd>주요 성인병의 진단 및 치료를 담당하며 위장관질환, 호흡기, 비뇨기, 두통 및 어지럼증 등의 각종 일차 의료를 제공하여 환자들의 건강 증진을 도모합니다.</dd>
			</dl>
		</div>
	</div>
	<div id="clinicCont">
		<h3 class="fc-M2">내과적 질환의 예방과 관리부터 만성질환, 급성질환 치료까지 포괄적인 의료서비스를 제공합니다.</h3>
		<p class="t1">내과·가정의학과는 만성질환 관리, 급성질환 치료, 건강검진 등을 통해 전반적인 건강을 종합적으로 관리합니다.</p> <p class="t1">환자 개개인의 생활습관과 병력에 맞춘 맞춤형 진료를 제공하며, 질환 예방부터 치료까지 포괄적인 의료서비스를 제공합니다.</p>
	</div>
</div>

		<h3 id="depart1-h3">내과·가정의학과 클리닉</h3>
	<div id="imgList" class="w3 inner">
		<div class="in-box">
			<img src="/images/sub/depart3-img1.png">
			<dl>
				<dt>생활습관병 클리닉</dt>
				<dd>생활습관병이란 과거 “성인병”으로 불려졌으며 고혈압, 당뇨, 비만, 고지혈증, 동맥경화, 심장병, 뇌졸중, 암, 알콜성 간질환, 만성 위장염 등이 해당됩니다. 이는 잘못된 생활습관(식사, 운동, 술, 담배, 스트레스, 과로, 수면부족)이 원인이며, 또한 생활습관의 개선이 병의 예방과 치료에 중요한 역할을 합니다.</dd>
			</dl>
		</div>
		<div class="in-box">
			<img src="/images/sub/depart3-img2.png">
			<dl>
				<dt>일반 질환 클리닉</dt>
				<dd>소화기 질환, 상기도 감염 및 천식 등의 홉흡기 질환, 골다공증 등의 폐경기 질환, 요로감염 등의 비뇨기과적 질환, 피부과적 질환, 비염, 축농증 등의 이비인후과적 질환, 어지럼증 치료등의 다양한 진료 서비스를 제공합니다.</dd>
			</dl>
		</div>
		<div class="in-box">
			<img src="/images/sub/depart3-img3.png">
			<dl>
				<dt>소아·청소년 클리닉</dt>
				<dd>출생 직후부터 자라나는 성장기 청소년들의 알레르기 질환의 진단 및 치료(천식, 두드러기, 식품 알레르기, 아토피성 피부염), 소화기 계통 질환의 진단 및 치료(만성복통, 변비, 설사 등), 소아 감염성 질환(상기도 감염, 중이염, 부비동염, 호흡기질환), 소아 신장계 질환의 진단 및 치료(요로감염, 혈뇨 등)</dd>
			</dl>
		</div>
	</div>



	<h3 id="depart1-h3">종합건강검진안내</h3>
	<div class="inner">
		<ul id="boxNum" class="depart3">
			<li>
				<p class="tit">초음파 검사</p>
				<ul id="dotList" class="w50">
					<li><p>간</p></li>
					<li><p>담낭</p></li>
					<li><p>췌장</p></li>
					<li><p>신장</p></li>
					<li><p>갑상선</p></li>
				</ul>
			</li>
			<li>
				<p class="tit">X-선 검사</p>
				<ul id="dotList" class="w50">
					<li><p>폐</p></li>
					<li><p>심장</p></li>
				</ul>
			</li>
			<li>
				<p class="tit">혈액종합검사</p>
				<ul id="dotList" class="w50">
					<li><p>당뇨</p></li>
					<li><p>고지혈증</p></li>
					<li><p>간염</p></li>
					<li><p>빈혈</p></li>
					<li><p>간 기능</p></li>
					<li><p>신장 기능</p></li>
					<li><p>갑상선 기능</p></li>
					<li><p>췌장 기능</p></li>
				</ul>
			</li>
			<li>
				<p class="tit">골밀도검사</p>
				<ul id="dotList" class="w50">
					<li><p>골다공증</p></li>
					<li><p>골감소증</p></li>
				</ul>
			</li>
			<li>
				<p class="tit">심전도검사</p>
				<ul id="dotList" class="w50">
					<li><p>협심증</p></li>
					<li><p>심근경색</p></li>
					<li><p>부정맥 진단</p></li>
				</ul>
			</li>
			<li>
				<p class="tit">소변검사</p>
				<ul id="dotList" class="w50">
					<li><p>혈노</p></li>
					<li><p>단백뇨</p></li>
					<li><p>당뇨</p></li>
					<li><p>방관염 진단</p></li>
				</ul>
			</li>
		</ul>
	</div>




	<h3 id="depart1-h3">의료진소개</h3>

			<div id="intro3" class="inner depart">
			<a href="#doctor11">
                    <div class="img">
                        <img src="/images/main/mdoctor-img11.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>황병윤 <span>원장</span></dt>
							<dd>가정의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>가정의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
		</div>

<?php include "../inc/doctor.php"; ?>
</div>
</div>
<?php include "../inc/bottom.php"; ?>
