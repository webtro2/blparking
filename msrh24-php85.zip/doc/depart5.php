<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "5";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



<div id="clinicBg">	
	<div id="clinicTop" class="depart5 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png">
			<dl>
				<dt>마취통증의학과</dt>
				<dd>수술, 마취에 대한 두려움과 불안을 덜어드리기 위해, 환자분께 편안함을 전하고자 항상 웃는 얼굴과 친절한 말 한마디로 다가가고 있습니다.</dd>
			</dl>
		</div>
	</div>
		<div id="clinicCont">
		<h3 class="fc-M2">수술 전후의 안전한 마취와 통증 관리를 통해 환자분께 최적의 편안함을 제공하도록 노력합니다.</h3>
		<p class="t1">수술 전후의 안전한 마취 관리와 다양한 급·만성 통증 치료를 전문으로 합니다. 환자 개개인의 상태를 세심히 평가하여 적절한 마취 방법을 선택하고, 수술 중 안전을 최우선으로 보장합니다. </p>
		<p class="t1">또한, 비수술적 방법과 최신 기술을 활용해 통증을 효과적으로 완화하며, 삶의 질 향상을 목표로 하고 있습니다.</p>
	</div>
</div>







	<h3 id="depart1-h3">마취통증의학과 클리닉</h3>
	<div id="imgList" class="w3 inner">
		<div class="in-box">
			<img src="/images/sub/depart5-img1.png">
			<dl>
				<dt>전신마취클리닉</dt>
				<dd>환자는 수술 중 의식과 통증, 근수축이 없으며 나쁜 반응이 없도록 해줘야 합니다. 전신마취 방법에는 흡입마취와 정맥마취가 주로 사용됩니다. 수술전에는 빈혈이 있는지, 간기능, 신장기능은 정상인지, 당뇨나 고혈압이 있는지 등을 검사한 후 전신마취를 시행합니다.</dd>
			</dl>
		</div>
		<div class="in-box">
			<img src="/images/sub/depart5-img2.png">
			<dl>
				<dt>부위마취클리닉</dt>
				<dd>특정부위에 국소마취제를 투입시켜 한정된 부위만 통증이 없게하는 마취로 척추마취, 경막외마취, 상완신경총차단 등이 있습니다. 이런 부위마취를 시행한 경우 환자는 의식이 평상시와 같이 깨어 있으며, 전신마취의 위험이 큰 환자나 전신마취의 부작용이 우려되는 환자에게 비교적 안전하게 사용될 수 있습니다.</dd>
			</dl>
		</div>
		<div class="in-box">
			<img src="/images/sub/depart5-img3.png">
			<dl>
				<dt>통증클리닉</dt>
				<dd>여러 원인에 의한 통증 질환을 진단하고 예방, 치료하는 임상과 입니다. 급성·만성통증환자에서 여러가지 검사와 약물치료 및 물리적 방법으로 치료하며 또한 신경블록의 이용이 특징입니다. 신경치료는 통증 전달 경로를 차단하거나 혈액순환을 개선하여 포진 후 신경통 등 신경블록으로 효과를 볼 수 있는 질환도 치료 합니다.</dd>
			</dl>
		</div>
	</div>


	<h3 id="depart1-h3">의료진소개</h3>

			<div id="intro3" class="inner depart">
			<a href="#doctor9">
                   <div class="img">
                        <img src="/images/main/mdoctor-img9.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>정종성 <span>원장</span></dt>
							<dd>마취통증의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>마취통증의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor10">
                    <div class="img">
                        <img src="/images/main/mdoctor-img10.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>하인호 <span>과장</span></dt>
							<dd>마취통증의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>마취통증의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			</div>

<?php include "../inc/doctor.php"; ?>
</div>
</div>
<?php include "../inc/bottom.php"; ?>
