<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "8";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<!-- <h3 id="subTitle"><span class="vis_dep02"></span></h3>-->


	<h3 id="depart1-h3" class="pt0">구연 및 발표논문
		<p class="st1 center c1">수술자료가 다소 선정적일 수 있사오니 열람 여부를 고려해 주세요.</p>
	</h3>
	
<div id="clinic8">
<div class="accWrap">
    <button class="accBtn">이전재접합술을 이용한 다발성 수지절단의 치료</button>
	<div class="accCont"><h3>2009년 미세이전재접합술발표</h3><img src="/images/sub/clinic8-img1.jpg"></div>
	
	<button class="accBtn">무지화 수술 및 기타 방법을 이용한 엄지의 재건</button>
	<div class="accCont"><h3>2009년 미세이전재접합술발표</h3><p class="t1">이 슬라이드는 엄지가 결손되고 없을 때 제2수지를 엄지의 위치로 이전하는 무지화 수술과 더불어 기타의 여러 가지 방법을 이용해서 엄지를 재건하는 수술 방법들에 대해서 총 정리한 것으로, 2009년 대한 수부-미세학회 춘계 합동 심포지엄에서 초청 연자로 초빙되어 강의한 것이며, 강의 내용은 단행본 책자로 발간되었습니다.</p><img src="/images/sub/clinic8-img2.jpg"></div>
	
	<button class="accBtn">이전재접합술을 이용한 다발성 수지 절단의 치료</button>
	<div class="accCont"><h3>2009년 미세이전재접합술발표</h3><p class="t1">이 논문은 여러 손가락의 절단상이 발생하였고 손상이 심해서 원래 위치에 재접합이 어려울 때 재접합이 가능한 일부의 손가락을 기능적으로 더 좋은 위치로 이전하여 재접합한 후의 치료 결과를 보고한 것으로 2009년 대한 미세수술학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img3.jpg"></div>
	
	<button class="accBtn">다양한 피판술을 이용한 수부 탈장갑성 손상의 치료</button><div class="accCont"><h3>2009년 센텀병원강의</h3><p class="t1">이 슬라이드는 수부의 광번위한 탈장갑성 손상이 발생하였을 때 여러 가지의 다양한 피판술을 이용해서 치료하는  총괄적인 내용에 대해서 정리한 것으로 2009년 서부산 센텀병원에 초청 연자로 초빙되어 강연하였습니다.</p><img src="/images/sub/clinic8-img4.jpg"></div>
	
	<button class="accBtn">역혈류성 수지 동맥 피판술을 이용한 수지 연부 조직 결손의 재건</button>
	<div class="accCont"><h3>2009년 대정추계RDIF</h3><p class="t1">이 슬라이드는 수지의 연부 조직 결손이 있을 때 동측 또는 옆에 있는 손가락에서 역혈류성수지 동맥 피판술을 시행하여 연부 조직 결손을 재건한 후의 치료 결과를 보고한 것으로, 2009년 대한 정형외과학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img5.jpg"></div>
	
	<button class="accBtn">일차골 이식술을 이용한 수부의 개방성 골절의 골 결손의 치료</button>
	<div class="accCont"><h3>2009년 수부일차골이식</h3><p class="t1">이 슬라이드는 손의 개방성 골절이 발생하면서 골 결손이 있을 때 최초 수술시에 바로 뼈이식 수술을 즉시 시행하여 골 유합을 얻은 치료 결과를 보고한 것으로, 2009년 대한 수부외과학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img6.jpg"></div>
	
	<button class="accBtn">족지의 유리 수질부 이전술을 이용한 수지 수실부 결손의 재건</button>
	<div class="accCont"><h3>2008년 APFSSH-PULP</h3><p class="t1">이 논문은 대퇴부의 전외측 천공지 피판술을 이용해서 손에 발생한 탈장갑성 손상에 의한 광범위한 연부 조직 결손을 치료한 결과를 보고한 것으로, 2008년 홍콩에서 개최된 아시아-태평양 수부외과학회에서 구연 발표되었습니다.</p>
	<img src="/images/sub/clinic8-img7.jpg"></div>
	
	<button class="accBtn">ALT flap(대퇴부 전외측 천공지 피판술)을 이용한 수부 탈장갑성 손상의 치료</button>
	<div class="accCont"><h3>2008년 APFSSH-ALT</h3><p class="t1">이 논문은 대퇴부의 전외측 천공지 피판술을 이용해서 손에 발생한 탈장갑성 손상에 의한 광범위한 연부 조직 결손을 치료한 결과를 보고한 것으로, 2008년 홍콩에서 개최된 아시아-태평양 수부외과학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img8.jpg"></div>
	
	<button class="accBtn">수지 관절의 재건에 이용된 족지의 유리 혈관화 관절 이식술</button>
	<div class="accCont"><h3>2008년 수부관절이식술</h3><p class="t1">이 슬라이드는 손의 개방성 골절이 발생하면서 골 결손이 있을 때 최초 수술시에 바로 뼈이식 수술을 즉시 시행하여 골 유합을 얻은 치료 결과를 보고한 것으로, 2009년 대한 수부외과학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img9.jpg"></div>
	
	<button class="accBtn">유리 정맥 피판술을 이용한 수지 연부 조직 결손의 재건</button>
	<div class="accCont"><h3>2008년 미세정맥피판술</h3><p class="t1">이 논문은 손에 발생한 연부 조직의 결손을 정맥 피판술을 이용하여 치료한 결과를 보고한 것으로, 2008년 대한미세수술학회 추계학술대회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img10.jpg"></div>
	
	<button class="accBtn">후 골간 동맥 피판술을 이용한 수부 및 수근 관절부 결손의 재건</button>
	<div class="accCont"><h3>2008년 PIA</h3><p class="t1">이 논문은 손과 손목 부위에 연부 조직 결손이 발생하였을 때 아래 팔의 후측면에서 후 골간동맥 피판술을 시행하여 연부 조직 결손을 피복한 후의 치료 결과를 보고한 것으로, 2008년 대한 수부외과학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img11.jpg"></div>
	
	<button class="accBtn">복합 부위 통증 증후군(CRPS)</button>
	<div class="accCont"><h3>2007년 수부연수강좌 CRPS</h3><p class="t1">이 슬라이드는 복합 부위 통증 증후군 (complex regional pain syndrome)에 대해서 총 정리를 한 것으로, 정형외과 및 성형외과 전문의와 전공의를 대상으로 2007년 대한수부외과학회 추계 연수강좌에서 초청 연자로 초빙되어 강의하였던 자료입니다.</p><img src="/images/sub/clinic8-img12.jpg"></div>
	
	<button class="accBtn">미세조갑피판술발표본</button>
	<div class="accCont"><h3>미세조갑피판술발표본</h3><img src="/images/sub/clinic8-img13.jpg"></div>

 </div>


<div class="accWrap">
    <button class="accBtn">손목 관절 주위 절단의 재접합술</button>
	<div class="accCont"><h3>2007년 수부추계손목절단</h3><p class="t1">이 논문은 손목 관절 주위에서 절단된 증례의 재접합술 후의 치료 결과에 대해서 보고한 것으로, 2007년 대한 수부외과학회 추계학술대회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img21_01.jpg"><img src="/images/sub/clinic8-img21_02.jpg"></div>
	
	<button class="accBtn">정맥 이식술(vein graft)</button>
	<div class="accCont"><h3>2006년 수부춘계VEIN GRAFT</h3><p class="t1">이 슬라이드는 미세 수술시에 혈관이 결손되고 없을 때 혈관을 재건하는 방법으로 사용되는 정맥 이식술(vein graft)에 대해서 총 정리를 한 것으로, 2006년 대한 수부-미세학회 춘계 합동 심포지엄에서 초청 연자로 초빙되어 강의한 것이며, 강의 내용은 단행본 책자로 발간되었습니다.</p><img src="/images/sub/clinic8-img22_01.jpg"><img src="/images/sub/clinic8-img22_02.jpg"></div>
	
	<button class="accBtn">손목 관절의 해부학과 생역학</button>
	<div class="accCont"><h3>2006년 수부연수강좌-손목</h3><p class="t1">이 슬라이드는 손목 관절의 해부학과 생역학에 대해서 정형외과 및 성형외과 전문의와 전공의를 대상으로 2006년 대한수부외과학회 추계 연수강좌에서 초청 연자로 초빙되어 강의하였던 자료입니다.</p><img src="/images/sub/clinic8-img23_01.jpg"><img src="/images/sub/clinic8-img23_02.jpg"></div>
	
	<button class="accBtn">수지 첨부 절단의 재접합술</button>
	<div class="accCont"><h3>2006년 경북대 FINGERTIP REPLANTATION</h3><p class="t1">이 슬라이드는 손가락의 끝부위가 절단 되었을 때 재접합술의 방법에 대해서 총 정리를 한 것으로, 2006년 경북대 손의 외과 국제 심포지엄에서 초청 연자로 초빙되어 강의한 것입니다.</p><img src="/images/sub/clinic8-img24_01.jpg"><img src="/images/sub/clinic8-img24_02.jpg"><img src="/images/sub/clinic8-img24_03.jpg"></div>
	
	<button class="accBtn">사지 연부 조직 결손에 이용된 얇은 대퇴부 천공지 피판술</button>
	<div class="accCont"><h3>2005년 ALTFLAP-LOUISVILLE</h3><p class="t1">이 슬라이드는 사지의 연부 조직 결손이 있을 때 유리 대퇴부 천공지 피판술을 얇게 만들어서 결손을 피복하는 수술 방법에 대해서 강의한 것으로, 2009년 미국 Louisville의 Kleiner Hand Institute에서 강연하였습니다.</p><img src="/images/sub/clinic8-img25_01.jpg"><img src="/images/sub/clinic8-img25_02.jpg"></div>
	
	<button class="accBtn">손과 사지의 재접합술</button>
	<div class="accCont"><h3>2005년 연세대성형외과REPLANTATION</h3><p class="t1">이 슬라이드는 재접합술의 전반적인 치료 방법에 대한 전체적인 내용을 총 정리한 것으로 연세대학교 병원 성형외과 학술 집담회에 초청 연자로 강연하였던 자료입니다.</p><img src="/images/sub/clinic8-img26.jpg"></div>
	
	<button class="accBtn">유리 대퇴부 전외측 천공지 피판술을 이용한 수부 탈장겁성 손상의 치료</button>
	<div class="accCont"><h3>2005년 ALT탈장갑손상</h3><p class="t1">이 논문은 손에 탈장갑성 손상에 의해서 광범위한 연부 조직 결손이 발생하였을 때 이를 치료하기 위해서 허벅지에서 천공지 피판술을 시행하여 치료한 결과를 보고한 것으로, 2005년 대한 미세수술학회 추계학술대회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img27.jpg"></div>
	
	<button class="accBtn">다양한 피판술을 이용한 수부 탈장갑성 손상의 치료</button>
	<div class="accCont"><h3>2005년 탈장갑절단-여러피판</h3><p class="t1">이 논문은 손에 탈장갑성 손상에 의해서 광범위한 연부 조직 결손이 발생하였을 때 이를 치료하기 위해서 여러 가지의 피판술을 이용하여 수술적 치료를 시행한 결과를 보고한 것으로, 2005년 대한수부외과학회 추계학술대회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img28.jpg"></div>
	
	<button class="accBtn">무지 견열성 절단의 재접합술</button>
	<div class="accCont"><h3>2004년 견열성 무지절단의 재접합술</h3><p class="t1">이 논문은 흔히 재접합이 어렵다고 여겨지는 엄지 손가락이 길게 뽑혀 나오면서 절단되었을 때의 재접합술의 방법과 치료 결과에 대해서 보고한 것으로, 2003년 대한 정형외과학회 추계학술대회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img29_01.jpg"><img src="/images/sub/clinic8-img29_02.jpg"></div>
	
	<button class="accBtn">주상골 골절 : 최신 치료 방법 </button>
	<div class="accCont"><h3>2003년 주상골 골절</h3><p class="t1">이 슬라이드는 손목의 주상골이 골절 되었을 때의 최신의 치료 방법에 대해서 강의한 것으로, 2003년 정형외과 개원의 협의회 강좌에서 강연하였습니다.</p><img src="/images/sub/clinic8-img30_01.jpg"><img src="/images/sub/clinic8-img30_02.jpg"></div>
	
	<button class="accBtn">다발성 수지 연부 조직 결손의 피복을 위한 유리 동맥화 정맥 피판술</button>
	<div class="accCont"><h3>2003년 다발성수지정맥피판술</h3><p class="t1">이 논문은 여러 손가락에서 동시에 연부 조직 결손이 발생하였을 때 치료 방법 중의 하나로 이용 가능한 유리 동맥화 정맥 피판술에 대한 치료 결과를 보고한 것으로, 2003년 대한정형외과학회 추계학술대회와 2003년 일본 미세재건학회에서 구연 발표되었습니다.</p><img src="/images/sub/clinic8-img31_01.jpg"><img src="/images/sub/clinic8-img31_02.jpg"></div>
	
	<button class="accBtn">포스트</button>
	<div class="accCont"><img src="/images/sub/clinic8-img32_01.jpg"><img src="/images/sub/clinic8-img32_02.jpg"><img src="/images/sub/clinic8-img32_03.jpg"><img src="/images/sub/clinic8-img32_04.jpg"><img src="/images/sub/clinic8-img32_05.jpg"><img src="/images/sub/clinic8-img32_06.jpg"><img src="/images/sub/clinic8-img32_07.jpg"><img src="/images/sub/clinic8-img32_08.jpg"><img src="/images/sub/clinic8-img32_09.jpg"><img src="/images/sub/clinic8-img32_10.jpg"><img src="/images/sub/clinic8-img32_11.jpg"></div>

 </div>
</div>



<script>
document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelectorAll(".accBtn");
  const contents = document.querySelectorAll(".accCont");

  buttons.forEach((button, index) => {
    button.addEventListener("click", () => {
      const content = contents[index];

      // 다른 아코디언이 열려 있으면 닫기
      contents.forEach((otherContent, i) => {
        if (i !== index) {
          otherContent.style.display = "none";  // 다른 콘텐츠는 닫기
          buttons[i].classList.remove("active");  // 다른 버튼은 비활성화
        }
      });

      // 클릭한 아코디언이 열리거나 닫히도록 처리
      if (content.style.display === "none" || content.style.display === "") {
        content.style.display = "block";  // 열기
        button.classList.add("active");  // 버튼 활성화
      } else {
        content.style.display = "none";  // 닫기
        button.classList.remove("active");  // 버튼 비활성화
      }
    });
  });

  // accCont 클릭 시 해당 콘텐츠 닫기
  contents.forEach((content, index) => {
    content.addEventListener("click", (event) => {
      event.stopPropagation();  // 이벤트 전파를 막아서 버튼 클릭이 아닌 콘텐츠 클릭만 처리
      content.style.display = "none";  // 해당 콘텐츠 닫기
      buttons[index].classList.remove("active");  // 버튼 비활성화
    });
  });
});
</script>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
