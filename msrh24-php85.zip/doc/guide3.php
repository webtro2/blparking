<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<ul id="boxNum" class="guide3">
		<li>
			<p class="tit">회진시간</p>
			<ul id="dotList">
				<li><p>오전 8시30분 ~ 9시</p></li>
			</ul>
			<p class="st1">환자 및 보호자분은 병실에 대기하여 주시기 바랍니다.</p>
		</li>
		<li>
			<p class="tit">식사시간</p>
			<ul id="dotList" class="w50">
				<li><p><b class="fc-bl">조식</b> : 7시 30분</p></li>
				<li><p><b class="fc-bl">중식</b> : 12시</p></li>
				<li><p><b class="fc-bl">석식</b> : 5시 30분</p></li>
			</ul>
			<p class="st1">수저는 개인위생을 위하여 개별 준비하시기 바랍니다.</p>
		</li>
		<li>
			<p class="tit">면회시간</p>
			<ul id="dotList">
				<li><p>오전 10시 ~ 오후 9시</p></li>
			</ul>
			<p class="st1">환자의 안정과 빠른 쾌유를 위하여 짧은 시간에 면회하여 주시면 감사하겠습니다.</p>
		</li>		
		<li>
			<p class="tit">도난사고 예방</p>
			<ul id="dotList">
				<li><p>귀중품이나 많은 현금은 병실에 두는 일이 없도록 해주세요.</p></li>
			</ul>
		</li>
		<li>
			<p class="tit">안전사고 예방</p>
			<ul id="dotList">
				<li><p>낙상 예방을 위해 침대에 누워서는 반드시 침대 난간을 올려 주시기 바랍니다.</p></li>
				<li><p>화재 예방을 위해 병실 내에서는 개인 전열 기구 사용을 금합니다.</p></li>
				<li><p>음식을 데우실 때에는 각층에 배치된 탕비실의 전자 레인지를 이용하시기 바랍니다.</p></li>
			</ul>
		</li>
		<li>
			<p class="tit">기타 안내</p>
			<ul id="dotList">
				<li><p>병원은 건물 전체가 금연 건물로 지정되어 있으므로 원내에서는 금연입니다.</p></li>
				<li><p>환자에 대한 모든 처치 및 치료는 환자의 건강을 회복하고 고통 경감을 위한 것이 오니 담당 의사와 간호사의 지시에 적극 협조하여 주시기 바랍니다.</p></li>
			</ul>
		</li>
	</ul>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
