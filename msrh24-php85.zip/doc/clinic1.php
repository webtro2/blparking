<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>




	<div id="infoTop" class="clinic1">
		<div class="img"><img src="/images/sub/infotop-clinic1.png" alt="" /></div>
		<div class="cont">
			<div class="in-box">
					<p class="eng">MS R.HOSPITAL</p>
					<h3>수부미세접합</h3>
					<dl>
						<dt>정교한 기술로 손의 미래를 설계하다</dt>
						<dd>미세접합술을 통해 손의 신경, 혈관, 힘줄을 복원하여 <br>정상 기능을 회복시키는 전문 클리닉입니다.</dd>
					</dl>
			</div>
		</div>
	</div>



<div id="clinicWrap">
	<h3 id="depart1-h3" >수부외과 및 미세재건수술 클리닉이란?</h3>
	<dl>
		<dt>손과 팔에 생기는 다양한 외상과 질환에 대해서 전문적으로 진료하는 분야</dt>
		<dd>미세재건수술은 여러 수술 방법 중에서 특히 미세현미경을 이용하여 치료하는 방법으로, <br>다른 방법으로 치료가 불가능한 것을 성공적으로 치료할 수 있게 하는 고난도의 수술 방법입니다.</dd>
		<dd>손과 팔은 구조와 기능이 아주 복잡하여 외상이나 질환이 발생시 정확한 치료를 위해서는 많은 지식과 경험이 필요합니다. <br>본원에서는 정형외과 전문의이면서 수부외과 세부 전문의를 함께 취득하고 수많은 임상 경험을 가진 전문의들이 정성껏 진료에 임하고 있어서 최상의 치료 결과를 보장합니다.</dd>
		<dd>수부 및 미세재건수술 클리닉에서는 아래와 같은 다양한 질환에 대해서 특화된 진료를 하고 있습니다.</dd>
	</dl>
</div>






	<h3 id="depart1-h3" >
		수부미세접합 치료 사례 
		<p class="st1 center c1">수술자료가 다소 선정적일 수 있사오니 열람 여부를 고려해 주세요.</p>
	</h3>
	
	<div id="clinicTab">
	<section id="tabWrap">
		<ul class="w7">
		   <li class="ON"><a href="#tab1">손과 팔의 골절과 외상</a></li>
		   <li><a href="#tab2">미세재건수술</a></li>
		   <li><a href="#tab3">수지 절단의 재접합술</a></li>
		   <li><a href="#tab4">손저림증 치료</a></li>
		   <li><a href="#tab5">종양</a></li>
		   <li><a href="#tab6">선천성 기형</a></li>
		   <li><a href="#tab7">손의 구축과 손톱 변형</a></li>
		</ul>
	</section>
	<section id="contWrap">
		  <article id="tab1" class="tabCont ON">
				<div class="info">
					<h4><p class="eng">CASE 01</p>손과 팔의 골절과 외상</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>상지에 발생한 골절이나 외상(힘줄, 신경, 혈관의 손상)은 적절한 치료가 되지 않으면 심각한 후유증을 남기게 됩니다.</p></li>
						<li><p>섬세하고 정확한 수술과 더불어 정성을 다하는 적극적인 물리 치료로 합병증을 최소화하면서 다치기 전의 상태로 회복시킵니다.</p></li>
					</ul>
				</div>
				<ul class="case">
					<li>						
						<p class="tit">손목뼈의 개방성 골절을 내고정술로 치료</p>				
						<img src="/images/sub/clinic1-1-img1.png">		
					</li>
					<li>						
						<p class="tit">양 손의 여덟 손가락의 골절을 내고정술로 치료</p>				
						<img src="/images/sub/clinic1-1-img2.png">
					</li>
				</ul>
		  </article>					  
		  <article id="tab2" class="tabCont">
				<div class="info">
					<h4><p class="eng">CASE 02</p>미세제건수술</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>수지 재건술과 다양한 피판술</p></li>
						<li><p>손가락이 절단되고 없다면 발가락을 떼어서 손가락에 붙이는 방법으로 없는 손가락을 재건하여 기능이 회복시킬 수 있습니다.</p></li>
					</ul>
				</div>
				<ul class="case">
					<li>						
						<p class="tit">양쪽 엄지손가락 절단상을 발가락 이식술로 재건</p>				
						<img src="/images/sub/clinic1-2-img1.png">		
					</li>
					<li>						
						<p class="tit">손목 부위의 연부조직 결손을 유리피판술로 재건</p>				
						<img src="/images/sub/clinic1-2-img2.png">
					</li>
				</ul>
		  </article>
		  <article id="tab3" class="tabCont">
				<div class="info">
					<h4><p class="eng">CASE 03</p>수지 절단의 재접합술</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>현대 병원에서부터 본원이 이르기까지 1,300례 이상의 수많은 손가락 및 팔, 다리 절단의 재접합술을 시행한 풍부한 경험을 바탕으로 합니다.</p></li>
						<li><p>전 세계 어디에 내놓아도 뒤지지 않는 재접합 성공률과 함께 수술 후의 최상의 기능 회복을 보장합니다.</p></li>
					</ul>
				</div>
				<ul class="case">
					<li>						
						<p class="tit">세손가락이 절단된 환자의 재접합술 후의 결과</p>				
						<img src="/images/sub/clinic1-3-img1.png">		
					</li>
					<li>						
						<p class="tit">손목의 견열성 절단의 재접합술의 수술 결과</p>				
						<img src="/images/sub/clinic1-3-img2.png">
					</li>
				</ul>	
		  </article>
		  <article id="tab4" class="tabCont">
				<div class="info">
					<h4><p class="eng">CASE 04</p>손저림증 치료</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>팔목 터널 증후군과 같이 손목이나 팔꿈치 등에서 신경이 눌려서 손이나 팔이 저리는 신경 압박 질환으로 고통 받는 환자분들을 비수술적인 방법이나 최소한의 피부 절개를 이용한 수술로 통증에서 해방시켜 드립니다.</p></li>
					</ul>
				</div>
				<ul class="case">					
					<li>						
						<p class="tit">일반적으로 시행하는 광범위한 절개 수술</p>				
						<img src="/images/sub/clinic1-4-img2.png"  class="img1-4-2">
					</li>
					<li>						
						<p class="tit">본원에서 시행하는 최초 절개술을 이용한 수술법</p>				
						<img src="/images/sub/clinic1-4-img3.png">
						<p class="st1">흉터와 통증을 최소화시킬수 있습니다.</p>
					</li>
					<li>						
						<p class="tit">팔목 터널 증후군에서 정중 신경 압박 도해</p>				
						<img src="/images/sub/clinic1-4-img1.png">		
					</li>
				</ul>
		  </article>
		  <article id="tab5" class="tabCont">
				<div class="info">
					<h4><p class="eng">CASE 05</p>종양</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>손과 팔에는 결절종(자갈풍), 지방종, 혈관종, 섬유종, 사구종 등 많은 종류의 다양한 종양이 생길 수 있습니다. </p></li>
						<li><p>본원에서는 병변에 맞는 정확한 수술로 흉터와 재발을 최소화하면서 치료합니다.</p></li>
					</ul>
				</div>
				<ul class="case">
					<li>						
						<p class="tit">손목에 발생한 결절종 제거술</p>				
						<img src="/images/sub/clinic1-5-img1.png"  class="img1-5-1">		
					</li>					
					<li>						
						<p class="tit">극심한 손가락 통증을 일으키는 손톱 아래 사구종 제거</p>				
						<img src="/images/sub/clinic1-5-img3.png"  class="img1-5-1">
					</li>
					<li>						
						<p class="tit">2수지에 발생한 혈관종을 완전히 제거</p>				
						<img src="/images/sub/clinic1-5-img2.png">
					</li>
				</ul>
		  </article>
		  <article id="tab6" class="tabCont">
				<div class="info">
					<h4><p class="eng">CASE 06</p>선천성 기형</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>미세 수술로 쌓인 정밀한 수술 기법을 바탕으로 하여 합지증, 다지증(육손), 거대지 등 다양한 선천성 기형을 적절한 시기에 섬세하고도 정확한 수술로 치료합니다.</p></li>
					</ul>
				</div>
				<ul class="case">
					<li>						
						<p class="tit">엄지에 발생한 다지증의 치료 결과</p>				
						<img src="/images/sub/clinic1-6-img1.png" class="img1-6-1">		
					</li>
					<li>						
						<p class="tit">엄지의 다지증을 뼈와 인대를 재건하면서 절제수술 시행</p>				
						<img src="/images/sub/clinic1-6-img2.png" class="img1-6-2">
					</li>
				</ul>
		  </article>
		  <article id="tab7" class="tabCont">
				<div class="info">
					<h4><p class="eng">CASE 07</p>손의 구축과 손톱 변형</h4>
					<p class="line"></p>
					<ul id="dotList">
						<li><p>화상이나 사고, 질환의 후유증으로 손가락이 굽거나 펴지지 않는 손의 구축과 손톱 손상으로 인한 변형을 구축 유리술이나 피판술, 손톱 연장술과 손톱 이식술 등으로 치료할 수 있습니다.</p></li>
					</ul>
				</div>
				<ul class="case">
					<li>						
						<p class="tit">Dupuytren씨 구축에 의한 손가락 굴곡변형을 교정</p>				
						<img src="/images/sub/clinic1-7-img1.png">		
					</li>
					<li>						
						<p class="tit">갈고리 모양의 손톱 변경을 발가락 수질부 이식술로 교정</p>				
						<img src="/images/sub/clinic1-7-img2.png" class="img1-7-2">
					</li>
					<li>						
						<p class="tit">외상에 의한 손톱 기형을 바가락 조갑상 이식술로 교정</p>				
						<img src="/images/sub/clinic1-7-img3.png">
					</li>
				</ul>
		  </article> 
	</section>
	</div>

	



</div>
</div>
<?php include "../inc/bottom.php"; ?>
