<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


		<div id="guide1">
			<div id="titWrap">
				<h3>진료시간 안내</h3>
			</div>
			<div id="contWrap" class="guide1-1">
				<div class="in-box">
					<dl>
						<dt>월~금요일</dt><dd>오전 9시 ~ 오후 6시</dd>
					</dl>
					<dl>
						<dt>점심시간</dt><dd>오후 1시 ~ 2시</dd>
					</dl>
					<dl>
						<dt>토요일</dt><dd>오전 9시 ~ 오후 1시</dd>
					</dl>
					<dl>
						<dt>일요일</dt><dd>외래 진료 휴진</dd>
					</dl>
					<dl>
						<dt>공휴. 일</dt><dd>오전 9시 ~ 오후 1시</dd>
					</dl>
					<dl>
						<dt>공휴. 절</dt><dd>외래 진료 휴진</dd>
					</dl>
				</div>
				<ul id="sDotList" class="guide1">
					<li><p>단, 응급환자는 24시간 응급 진료함</p></li>
				</ul>
			</div>
		</div>



		<div id="guide1">
			<div id="titWrap">
				<h3>진료예약</h3>
			</div>
			<div id="contWrap" class="guide1-4">
				<img src="/images/sub/guide1-4-icon.png">
				<dl>
					<dt><span class="fc-M2">전화예약</span> 053) 650-0198</dt>					
					<dd>진료예약 또는 궁금한 사항은 언제든 전화주세요.</dd>
				</dl>
			</div>
		</div>




		<div id="guide1">
			<div id="titWrap">
				<h3>외래진료 시간표</h3>
			</div>
			<div id="contWrap">
				       <div class="scroll">
							<table class="tb-style1">
								<colgroup>
									<col width="10%">
									<col width="">
									<col width="">
									<col width="">
									<col width="">
									<col width="">
									<col width="10%">
								</colgroup>
								<thead>
									<tr>
										<th></th>
										<th>월</th>
										<th>화</th>
										<th>수</th>
										<th>목</th>
										<th>금</th>
										<th>토</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<th>오전</th>
										<td>하성한<br>김정래<br>이원제<br>송원호</td>
										<td>김정래<br>김동영<br>나호동<br>이현록</td>
										<td>유선오<br>김효곤<br>김동영<br>나호동</td>
										<td>유선오<br>김효곤<br>이원제<br>송원호</td>
										<td>김정래<br>김효곤<br>김동영<br>이현록</td>
										<td>교대</td>
									</tr>
									<tr>
										<th>오후</th>
										<td>유선오<br>김효곤<br>김동영<br>이현록</td>
										<td>하성한<br>김정래<br>이원제<br>송원호</td>
										<td>김정래<br>김동영<br>이현록<br>나호동</td>
										<td>하성한<br>이원제<br>나호동<br>송원호</td>
										<td>이원제<br>나호동<br>송원호</td>
										<td>교대</td>
									</tr>
								</tbody>
							</table>
						</div>
						<ul id="sDotList" class="guide1">
							<li><p>오전 : 09:00 ~ 13:00 / 오후 : 14:00 ~ 18:00</p></li>
							<li><p>외래 진료 시간 외에는 수술 일정이 진행됩니다.</p></li>
							<li><p>진료 일정은 사정에 따라 변경될 수 있습니다.</p></li>
						</ul>
			</div>
		</div>




		<div id="guide1">
			<div id="titWrap">
				<h3>외래진료 절차</h3>
				<p class="t1">진료 접수 시 신분증 지참 필수</p>
			</div>
			<div id="contWrap" class="guide1-3">
				
				<dl>
					<p class="num">01</p>
					<dt>진료접수</dt>
					<dd>병원에 방문하여 접수창구에서 진료를 신청하거나 예약을 확인합니다.</dd>
				</dl>
				<dl>
					<p class="num">02</p>
					<dt>해당과 진료</dt>
					<dd>진료과로 이동하여 담당 의사와 상담 및 진료를 받습니다.</dd>
				</dl>
				<dl>
					<p class="num">03</p>
					<dt>검사 및 결과 확인</dt>
					<dd>필요한 검사를 진행한 후 결과를 확인하고 추가 상담을 받습니다.</dd>
				</dl>
				<dl>
					<p class="num">04</p>
					<dt>진료비 수납</dt>
					<dd>원무과에서 진료비를 정산하고 결제 절차를 완료합니다.</dd>
				</dl>
				<dl>
					<p class="num">05</p>
					<dt>처방전 수령</dt>
					<dd>진료 후 처방전을 발급받아 약국에서 약을 조제받습니다.</dd>
				</dl>
			</div>
		</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
