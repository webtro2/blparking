<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

<div id="clinicBg">	
	<div id="clinicTop" class="depart2 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png">
			<dl>
				<dt>수부외과</dt>
				<dd>환자의 상태를 안전하게 체크하고 빠른 치료를 도와주는 MS재건병원은 지역을 대표하는 수부외과 병원입니다.</dd>
			</dl>
		</div>
	</div>
	<div id="clinicCont">
		<h3 class="fc-M2">손과 팔의 다양한 질환과 외상을 전문적으로 치료하며, 기능과 삶의 질을 회복시켜 드립니다.</h3>
		<p class="t1">손과 팔에 생길 수 있는 급성 손상을 포함한 다양한 질환을 치료하는 분야입니다. </p>
		<p class="t1">골절이나 외상 뿐만 아니라 합지증, 다지증 등의 선천성 기형과 수근관 증후군 등의 신경이 눌리는 질환, 종양, 손톱기형, 손목 연골 손상, 팔꿈치에 생기는 다양한 질환 등을 보존적 방법이나 수술로 치료하여 기능을 재건하는 치료 영역입니다.</p>
	</div>
</div>


		<h3 id="depart1-h3">의료진 소개</h3>
	
		
		<div id="intro3" class="inner">
			<a href="#doctor1">
                    <div class="img">
                        <img src="/images/main/mdoctor-img1.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>유선오 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor2">
                    <div class="img">
                        <img src="/images/main/mdoctor-img2.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>하성한 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
							<li><p>수부외과 세부 전문의</p></li>
							<li><p>견주관절 클리닉</p></li>
							<li><p>슬관절클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor3">
                    <div class="img">
                        <img src="/images/main/mdoctor-img3.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김효곤 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부 관절클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor4">
                    <div class="img">
                        <img src="/images/main/mdoctor-img4.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김정래 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor5">
                    <div class="img">
                        <img src="/images/main/mdoctor-img5.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김동영 <span>원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>무릎 및 어깨관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor6">
                    <div class="img">
                        <img src="/images/main/mdoctor-img6.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>이원제 <span>소장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>척추센터 소장</p></li>
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor7">
                    <div class="img">
                        <img src="/images/main/mdoctor-img7.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>나호동 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
							<li><p>척추 및 견주관절</p></li>
							<li><p>수부</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor8">
                    <div class="img">
                        <img src="/images/main/mdoctor-img8.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>박진식 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부외과 클리닉</p></li>
							<li><p>견주관절 클리닉</p></li>
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
		</div>



<?php include "../inc/doctor.php"; ?>
</div>
</div>
<?php include "../inc/bottom.php"; ?>
