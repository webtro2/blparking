$(document).ready(function(){

	$("#gnb > ul > li").hover(function(){
		$("#header").addClass("on")
	},function(){
		$("#header").removeClass("on")
	})
	
	$("#menuToggle").click(function(){
		$("#header").toggleClass("menu")
	})


})




$(document).ready(function () {

	$('#gnb_pc').hover(function(){
		$('#header').addClass('menu_on');
		$('#header').addClass('on');
		$('#gnb_pc .smenu').stop().slideDown(300);
	},function(){
		$('#gnb_pc .smenu').stop().slideUp(300);
		$('#header').removeClass('menu_on');
		$('#header').removeClass('on');
	});


	$('#gnb_mo li.gnb_dp1>div').click(function(){
		if($(this).hasClass('on')){
			$(this).removeClass('on');
			$(this).siblings('.smenu').stop().slideUp(300);
		}else{
			$('#gnb_mo .gnb_dp1>div').removeClass('on');
			$('#gnb_mo .smenu').stop().slideUp(300);
			$(this).addClass('on');
			$(this).siblings('.smenu').stop().slideDown(300);
		}
	});

	$('#header .hd_full').click(function(){
		if($(this).hasClass('m_on')){
			$(this).removeClass('m_on');
			$('#gnb_mo').removeClass('m_menuOn');
			$('#header').removeClass('on');
		}else{
			$(this).addClass('m_on');
			$('#gnb_mo').addClass('m_menuOn');
			$('#header').addClass('on');
		}
	});

	//scrolltop
	var jbOffset = $( '#header' ).offset();
	$( window ).scroll( function() {
		if ( $( document ).scrollTop() > (jbOffset.top+100) ) {
			$( '#header' ).addClass( 'scroll' );
		}
		else {
			$( '#header' ).removeClass( 'scroll' );
		}
	});


	$(window).resize(function() {
			if($(window).width() <1330) {
				$(".gnb_dp1 > div > a").removeAttr("href")
			}
		});

	$("#gnb_mo > ul > li > div > a").removeAttr("href");

});
