var subFunc = (function($){
	var _snb = function(level1, level2){

		var sub_dep1=$('.sub_menu_wrap .m_1dep_box .menu'+level1);
		var sub_dep2=$('.sub_menu_wrap .m_2dep_box .menu'+level2);
		var sub_dep3=$('.sv_tit_en .menu'+level1);
		var sub_dep1_t = $(sub_dep1).text();
		var sub_dep2_t = $(sub_dep2).text();
		var sub_dep3_t = $(sub_dep3).text();

		$('.s_visual').css({"background-image":"url(/images/sub/s_visual"+level1+".jpg)"});

		$('span.vis_dep01').text(sub_dep1_t);
		$('span.vis_dep02').text(sub_dep2_t);
		$('span.vis_dep03').text(sub_dep3_t);

		sub_dep1.addClass('on');
		sub_dep2.addClass('on');
		sub_dep2.parent().addClass('s_on');

		$('.sub_menu_wrap .m_dep_tit').click(function(){
			if($(this).hasClass('m_on')){
				$(this).removeClass('m_on');
				$(this).siblings("ul.smenu").slideUp();
			} else {
				$(this).addClass('m_on');
				$(this).siblings("ul.smenu").slideDown();
			}
		});

		$(".sub_menu_wrap .m_dep_box").on("mouseleave", function(){
			if($(this).children(".m_dep_tit").hasClass("m_on")){
				$(this).children(".m_dep_tit").removeClass("m_on");
				$(this).children("ul.smenu").slideUp(300);
			}
		});

		$(window).resize(function(){
			var width = parseInt($(this).width()); //parseint�� �뺤닔濡� �섍린 �꾪븿
			if(width <= 10000){
				$('.sub_menu_wrap .m_2dep_box .smenu').css({'display':'none'});
			}else{
				$('.sub_menu_wrap .m_2dep_box .smenu').css({'display':'block'});
			}
		}).resize();


	};
	return{
		snb:_snb
	}
})(jQuery);






$(document).ready(function() {
	$(".tabCont").hide(); //Hide all content
	$("#tabWrap ul li.ON").addClass("active").show(); //Activate first tab
	$(".tabCont.ON").show(); //Show first tab content

	//On Click Event
	$("#tabWrap ul li").click(function() {
		$("#tabWrap ul li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tabCont").hide(); //Hide all tab content
		var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active content
		return false;
	});
});