$(document).ready(function() {


  //메인비주얼
  $('.mvWrap').slick({
     dots: true,
     arrows:false,
     infinite: true,
     speed:1000,
     fade: true,
     cssEase: 'linear',
     autoplay: true,
     autoplaySpeed:6000,
	 pauseOnHover : false
  });







		$('.mClinicWrap').slick({
			infinite:true, 
			speed:500, 
			arrows:true,
			dots:false, 
			slidesToShow:4, 
			slidesToScroll:1, 
			autoplay:true, 
			autoplaySpeed:3000, 
			pauseOnHover : false,
			responsive: [{
				breakpoint:1025,
				settings: {
					slidesToShow: 3,
					}
				},{
				breakpoint:769,
				settings: {
					slidesToShow: 2,
					}
				},{
				breakpoint:481,
				settings: {
					slidesToShow: 1,
					}
				}
			]
				
		});




$('.mDoctorWrap').slick({
			infinite:true, 
			speed:500, 
			arrows:true,
			dots:false, 
			slidesToShow:5, 
			slidesToScroll:1, 
			autoplay:true, 
			autoplaySpeed:3000, 
			pauseOnHover : false,
			responsive: [{
				breakpoint:1025,
				settings: {
					slidesToShow: 4,
					}
				},{
				breakpoint:769,
				settings: {
					slidesToShow: 3,
					}
				},{
				breakpoint:641,
				settings: {
					slidesToShow: 2,
					}
				}
			]
				
		});






  //Default Action

	$(".tabCont").hide(); //Hide all content
	$("#tabWrap ul li.ON").addClass("active").show(); //Activate first tab
	$(".tabCont.ON").show(); //Show first tab content

	//On Click Event
	$("#tabWrap ul li").click(function() {
		$("#tabWrap ul li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tabCont").hide(); //Hide all tab content
		var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active content
		return false;
	});



});
