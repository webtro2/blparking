
$(document).ready(function(e) {

	

	// hash scroll
	var hashScroll = (function() {		
		var naviWrap = null;
		var navi = null;
		var naviPosition = 0;
		var naviPositionTp = 0;
		

		function init() {
			naviWrap = $(".hash_wrap");
			navi = $(".hash_wrap .hash_bx");

			// check
			if(naviWrap.length < 1) return false;


			// click event
			navi.on("click", ".btn a", function(evt) {
				evt.preventDefault();

				var hashId = $(this).attr("href").substring(1);

				goToHash(hashId);
				return false;
			});

			// scroll event
			$(window).scroll(onScrollEvent);
			$(window).resize(onScrollEvent);
			$(window).load(function() {
				onScrollEvent();

				// hash parsing
				var hashId = location.hash.substring(1, location.hash.length).replace(/ /gi, '%20');
				if(hashId.length > 1) goToHash(hashId);
			});
		}

		// scroll event
		function onScrollEvent(evt) {
			//if($(".navigator.hashList").css("display") == "none") return;
			
			var scrollTop = $(window).scrollTop();
			var docuTop = $(document).scrollTop();
			var scrollLeft = $(window).scrollLeft();

			naviPosition = $(".hash_wrap").offset().top;
			
			if (docuTop > naviPosition ) {
				navi.addClass("fixed");
			}else {
				navi.removeClass("fixed");
			}

			//if(docuTop > naviPosition){
			//	naviWrap.addClass("fixed");
			//	
			//}else{
			//	naviWrap.removeClass("fixed");
			//}


			// hscroll
			if($(naviWrap).hasClass("fixed")) $(navi).css("left", -1 * scrollLeft);

			var idx = checkVerticalScroll(scrollTop);
			onIndexCheck(idx);

			


		}
		

		// positon check
		function checkVerticalScroll(scrollTop) {
			var windowHeight = (window.innerHeight) ? window.innerHeight : $(window).height();
			var documentHeight = $(document).height() - windowHeight;

			var topHeight = 100 // $(naviWrap).height();
			var idx = 0;

			$(".sectionList .subCection").each(function(i) {
				var top = $(this).offset().top - topHeight;
				var height = $(this).outerHeight() ;
				
				if(scrollTop >= documentHeight) {
					idx = navi.find(".btn a").length - 2;
					return false;
				}
				
				if(top > scrollTop - height) {
					idx = i;
					return false;
				}
			});

			return idx;
		}

		// index check
		function onIndexCheck(idx) {
			navi.find(".btn a").removeClass("on");
			navi.find(".btn:eq(" + idx + ") a").addClass("on");
			
			var sub_hash = $(".btn:eq(" + idx + ") a.on");
			var sub_hash_t = $(sub_hash).text();
			$('span.vis_hashtxt').text(sub_hash_t);
		}
		


		// move hash position
		function goToHash(hashId) {
			var topHeight = 0 // $(naviWrap).height();
			var target = $("#" + hashId);
			var position = (target.length > 0) ? ($(target).offset().top - topHeight) : 0;

			// scroll
			$("html, body").dequeue().delay(10).animate({scrollTop: position}, 250, function() {
				location.hash = "#" + hashId;
				$(window).scrollTop(position);
			});
		}

		return {
			init : init,
			goToHash : goToHash
		}
	}());

	hashScroll.init();



	
});


