<?php require_once(__DIR__ . '/../pg/common.php'); ?>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="language" content="ko" />
<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<meta name="format-detection" content="telephone=no" />
<meta property="og:image" content="/og.png">


<title>MS재건병원</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"/>
<link rel="stylesheet" type="text/css" href="/css/default.css" />
<link rel="stylesheet" type="text/css" href="/css/layout.css?v=1" />
<link rel="stylesheet" type="text/css" href="/css/scont.css?v=3" />


<link rel="shortcut icon" href="favicon.ico">

<!-- gnb -->
<script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="/js/common.js"></script>
<script type="text/javascript" src="/js/sub.js"></script>

<!-- js -->
<script type="text/javascript" src="/js/aos.js"></script>
<script src="/js/allmenu.js"></script>

<!-- slick -->
<script src="/js/slick/slick.min.js"></script>
<link rel="stylesheet" href="/js/slick/slick-theme.css">
<link rel="stylesheet" href="/js/slick/slick.css">

<!-- swiper -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<script type="text/javascript" src="/js/s-hash/fixgnb.js"></script>
<link media="all" href="/js/s-hash/fixgnb.css" type="text/css" rel="stylesheet"/>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Hospital",
  "name": "MS재건병원",
  "alternateName": [
    "MSRHOSPITAL",
    "엠에스재건병원",
    "대구MS재건병원",
    "대구 정형외과 병원",
    "수부미세접합 병원"
  ],
  "url": "https://msrhospital.kr/",
  "telephone": "053-653-0119",
  "faxNumber": "053-653-0771",
  "priceRange": "건강보험 적용",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "대구광역시 중구 동덕로 194",
    "addressLocality": "중구",
    "addressRegion": "대구광역시",
    "addressCountry": "KR"
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "09:00",
      "closes": "18:00"
    },
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": "Saturday",
      "opens": "09:00",
      "closes": "13:00"
    }
  ],
  "contactPoint": [
    {
      "@type": "ContactPoint",
      "contactType": "원무과",
      "telephone": "053-650-0131"
    },
    {
      "@type": "ContactPoint",
      "contactType": "원무과",
      "telephone": "053-650-0132"
    },
    {
      "@type": "ContactPoint",
      "contactType": "외래진료",
      "telephone": "053-650-0114"
    },
    {
      "@type": "ContactPoint",
      "contactType": "진료예약",
      "telephone": "053-650-0198"
    },
    {
      "@type": "ContactPoint",
      "contactType": "응급실",
      "telephone": "053-650-0118",
      "availableLanguage": "ko",
      "hoursAvailable": {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        "opens": "00:00",
        "closes": "23:59"
      }
    }
  ],
  "medicalSpecialty": [
    "정형외과",
    "수부외과",
    "내과",
    "가정의학과",
    "영상의학과",
    "마취통증의학과",
    "응급의학",
    "성형외과",
    "미세수술",
    "재건수술"
  ],
  "description": "MS재건병원은 대구광역시 중구 동덕로에 위치한 정형외과 중심 병원으로 수부미세접합, 상하지 재건, 족부·족관절, 관절경, 인공관절, 척추, 팔꿈치, 손목 질환을 진료하며 365일 24시간 응급 진료를 운영합니다.",
  "availableService": [
    {
      "@type": "MedicalProcedure",
      "name": "수부미세접합",
      "description": "손과 팔에 발생하는 다양한 외상과 질환을 전문적으로 진료하고 미세접합 및 재건 치료를 시행합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "족부·족관절 진료",
      "description": "족부 및 족관절에서 발생하는 질환의 예방, 치료, 수술 및 재활을 제공합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "관절경 수술",
      "description": "관절의 질환이나 손상을 관절내시경을 이용해 최소 절개로 진단하고 치료합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "인공관절 수술",
      "description": "손상된 관절을 인체에 적합한 인공관절로 대체하는 수술 치료를 시행합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "척추 진료",
      "description": "경추부터 요추까지 척추와 신경계통에 발생하는 다양한 질환을 진료합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "팔꿈치 진료",
      "description": "팔꿈치의 과사용, 외상, 통증 및 기능 이상에 대한 진료를 시행합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "손목 진료",
      "description": "손목 손상과 통증, 수부 질환에 대한 정밀 진료를 제공합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "마취통증의학 진료",
      "description": "수술 및 통증 관리를 위한 마취통증의학과 진료를 제공합니다."
    },
    {
      "@type": "MedicalProcedure",
      "name": "영상의학 진료",
      "description": "정밀 영상검사를 바탕으로 정확한 진단을 지원합니다."
    },
    {
      "@type": "EmergencyService",
      "name": "365일 24시간 응급실",
      "description": "응급환자를 위해 365일 24시간 응급 진료를 운영합니다."
    }
  ],
  "knowsAbout": [
    "수부미세접합",
    "손가락 재접합",
    "상하지 재건",
    "수부외과",
    "족부질환",
    "족관절질환",
    "무지외반증",
    "관절경",
    "무릎관절",
    "어깨관절",
    "인공관절",
    "척추질환",
    "팔꿈치질환",
    "손목질환",
    "수부 및 상하지 외상",
    "골절",
    "미세수술",
    "재건수술",
    "응급외상",
    "마취통증의학"
  ],
  "amenityFeature": [
    {
      "@type": "LocationFeatureSpecification",
      "name": "365일 24시간 응급실 운영",
      "value": true
    },
    {
      "@type": "LocationFeatureSpecification",
      "name": "정형외과 전문의 진료",
      "value": true
    },
    {
      "@type": "LocationFeatureSpecification",
      "name": "수부미세접합 진료",
      "value": true
    },
    {
      "@type": "LocationFeatureSpecification",
      "name": "상하지 외상 및 재건 진료",
      "value": true
    },
    {
      "@type": "LocationFeatureSpecification",
      "name": "발렛파킹 가능한 지하주차장",
      "value": true
    }
  ],
  "employee": [
    {
      "@type": "Physician",
      "name": "유선오",
      "jobTitle": "병원장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["족부 및 족관절 클리닉", "정형외과", "족부질환"]
    },
    {
      "@type": "Physician",
      "name": "하성한",
      "jobTitle": "병원장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["수부외과", "견주관절", "슬관절", "미세수술"]
    },
    {
      "@type": "Physician",
      "name": "김효곤",
      "jobTitle": "병원장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["수부 관절클리닉", "수부외과", "미세수술", "말초신경수술"]
    },
    {
      "@type": "Physician",
      "name": "김정래",
      "jobTitle": "병원장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["족부 및 족관절 클리닉", "정형외과"]
    },
    {
      "@type": "Physician",
      "name": "김동영",
      "jobTitle": "원장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["무릎관절", "어깨관절", "인공관절", "관절경"]
    },
    {
      "@type": "Physician",
      "name": "이원제",
      "jobTitle": "원장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["척추센터", "수부 및 상하지 외상 골절", "척추질환"]
    },
    {
      "@type": "Physician",
      "name": "나호동",
      "jobTitle": "과장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["족부 및 족관절", "척추", "견주관절", "수부"]
    },
    {
      "@type": "Physician",
      "name": "이현록",
      "jobTitle": "과장",
      "medicalSpecialty": "성형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["수부외과", "수부 및 상지 외상 골절", "미세수술"]
    },
    {
      "@type": "Physician",
      "name": "송원호",
      "jobTitle": "과장",
      "medicalSpecialty": "정형외과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["수부 및 상하지 외상 골절", "소아 정형", "외상", "고관절"]
    },
    {
      "@type": "Physician",
      "name": "정종성",
      "jobTitle": "원장",
      "medicalSpecialty": "마취통증의학과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["마취통증의학", "통증치료", "TPI"]
    },
    {
      "@type": "Physician",
      "name": "하인호",
      "jobTitle": "과장",
      "medicalSpecialty": "마취통증의학과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["마취통증의학", "통증치료", "TPI"]
    },
    {
      "@type": "Physician",
      "name": "황병윤",
      "jobTitle": "원장",
      "medicalSpecialty": "가정의학과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["가정의학", "노인의학"]
    },
    {
      "@type": "Physician",
      "name": "강민석",
      "jobTitle": "과장",
      "medicalSpecialty": "영상의학과 전문의",
      "affiliation": "MS재건병원",
      "knowsAbout": ["영상의학", "진단영상"]
    }
  ],
  "sameAs": [
    "https://msrhospital.kr/",
    "http://pf.kakao.com/_Zxlexen",
    "https://kko.kakao.com/V2MdqFTG3L"
  ],
  "identifier": {
    "@type": "PropertyValue",
    "name": "사업자등록번호",
    "value": "734-97-00078"
  }
}
</script>
</head>

<body>

