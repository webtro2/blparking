<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "7";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


<div id="intro7">
  <div id="intro7Tab">
    <ul>
		<li><a href="javascript:GoPage('intro7_10')"><p class="num">지하1층</p><p class="t1">주차장 · 약국 · 편의점</p></a></li>
		<li><a href="javascript:GoPage('intro7_1')"><p class="num">1층</p><p class="t1">접수 및 수납 · 원무과 · 야간처치실 · 영상의학실 · 진단검사실</p></a></li>
		<li><a href="javascript:GoPage('intro7_2')"><p class="num">2층</p><p class="t1">외래 · 초음파실 · 석고실 · 주사실 · 커피숍</p></a></li>
		<li><a href="javascript:GoPage('intro7_3')"><p class="num">3층</p><p class="t1">MRI실 · 골밀도 검사실 · 물리(재활)치료실 · 운동치료실</p></a></li>
		<li><a href="javascript:GoPage('intro7_4')"><p class="num">4층</p><p class="t1"> 사무국 · 보험 심사과 · 부설 연구소</p></a></li>
		<li class="ON"><a href="javascript:GoPage('intro7_5')"><p class="num">5층</p><p class="t1">수술실 · 회복실 · 마취통증의학과</p></a></li>
		<li><a href="javascript:GoPage('intro7_6')"><p class="num">6~10층</p><p class="t1">6병동 ~ 10병동 (9층-샴푸실 · 10층-약제과)</p></a></li>
		<li><a href="javascript:GoPage('intro7_7')"><p class="num">11층</p><p class="t1">도서관 · 북카폐 · MS아트홀</p></a></li>
		<li><a href="javascript:GoPage('intro7_8')"><p class="num">12층</p><p class="t1">강당 · 직원식당 · 영양과</p></a></li>
	    <li><a href="javascript:GoPage('intro7_9')"><p class="num">13층</p><p class="t1">하늘정원</p></a></li>
    </ul>
  </div>

  <div id="contWrap">
    <article class="intro7Cont">
		<ul class="cont">
			<li><span class="t1">수술실</span><span class="t1">회복실</span><span class="t1">마취통증의학과</span></li>
		</ul>
      <div class="swiper storeimg">
			<div class="swiper-wrapper">
				<div class="swiper-slide"><img src="/images/sub/view/5-01.jpg"></div>
				<div class="swiper-slide"><img src="/images/sub/view/5-02.jpg"></div>
			</div>
			<div class="swiper-pagination"></div>
		</div>
    </article>
  </div>
</div>


<script>
    var swiper = new Swiper(".storeimg", {
      slidesPerView: 1,
	  effect : 'fade',
      loop: true,    
	  autoplay: {
      delay: 2500,
      disableOnInteraction: false,
      },
	  pagination: {
        el: ".swiper-pagination",
        clickable: true
      },
    });


</script>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
