<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="infoTop">
		<div class="img"><img src="/images/sub/infotop-clinic4.png" alt="" /></div>
		<div class="cont">
			<div class="in-box">
					<p class="eng">MS R.HOSPITAL</p>
					<h3>인공관절</h3>
					<dl>
						<dt>새 관절로 다시 걷는 기쁨을</dt>
						<dd>퇴행성 관절염과 같은 심각한 관절 손상을 <br>인공관절로 교체하여 삶의 질을 높여 드립니다.</dd>
					</dl>
			</div>
		</div>
	</div>



	<div id="clinicWrap">
		<h3 id="depart1-h3">인공관절 클리닉</h3>
		<dl>
			<dt>인체에 무해하고 튼튼한 인공관절로 대체해 수술하는 분야</dt>
			<dd>몸 속에서 안전한 금속과 폴리에틸렌으로 만들어진 인공관절을 삽입하는 수술로 손상된 어깨, 무릎, 족부 등으로 관절의 변형이 심해 <br>교정이 필요한 경우 튼튼한 인공관절로 대체하는 수술법입니다.</dd>
			<dd>퇴행성 관절염, 류마티스 관절염, 심각한 관절 손상 등으로 인한 통증과 움직임 제한을 해결합니다. <br>우수한 기술을 활용한 인공관절 수술로 통증 완화와 관절 기능 회복을 극대화합니다.</dd>
			<dd>환자 맞춤형 치료 계획을 통해 수술 후 빠른 회복과 일상 복귀를 돕습니다. 안전하고 정밀한 수술로 삶의 질을 높여 드립니다.</dd>
		</dl>
	</div>


<h3 id="depart1-h3" >인공관절 질환</h3>


<div id="clinicTab">
	<section id="tabWrap">
		<ul class="w1">
		   <li class="ON"><a href="#tab1">퇴행성관절염</a></li>
		</ul>
	</section>


	<section id="contWrap">
		  <article id="tab1" class="tabCont ON">
				<h3 id="tabTitle"><span class="lt1">퇴행성관절염이란?</span></h3>
				<div id="tabcont">
					<p class="t1">관절 사이 뼈와 뼈가 맞닿게 되어 심한 고통이 발생되는 질환입니다. </p>
					<p class="t1">퇴행성 관절염은 지속적인 관절 사용으로 인해 연골이 닳아 없어지면서 관절 사이의 뼈와 뼈가 맞닿아 발생하는 통증, 부종, 변형 등으로 극심한 고통을 받게 되는 질환입니다.</p>
					<ul id="circleList" class="w4">
						<li><p>노화</p></li>
						<li><p>유전적 요인</p></li>
						<li><p>반복적 관절사용</p></li>
						<li><p>부상</p></li>
					</ul>
				</div>				
					<div id="imgHalf" class="clinic4">
						<ul id="numList" class="in-box">						
							<h3 id="tabTitle" class="mt0">퇴행성관절염 증상</h3>
							<li><p>활동 후나 날씨 변화 시 관절에 통증이 발생하며, 장기간 사용 시 더 심해질 수 있습니다.</p></li>
							<li><p>관절이 뻣뻣해지고 움직임이 제한되는 느낌이 발생할 수 있습니다.</p></li>
							<li><p>관절에 염증이 생기면 붓고, 관절 주변에 열감이 있을 수 있습니다.</p></li>
							<li><p>관절의 기능이 저하되어 일상적인 활동이나 운동에 어려움을 겪을 수 있습니다.</p></li>
						</ul>
					</div>
				<h3 id="tabTitle">퇴행성관절염 치료</h3>
				<div id="tabcont" class="pb0">
					<div id="dl-cont" class="w50">						
						<dl>
							<dt>보존적 치료</dt><dd>퇴행성 관절염의 보존적 치료는 통증 완화와 관절 기능 회복을 목표로 합니다. 비스테로이드성 소염제(NSAIDs)로 염증과 통증을 완화하고, 체중 관리와 운동을 통해 관절에 가해지는 부담을 줄일 수 있습니다. 물리치료를 통해 관절을 강화하고 유연성을 높이며, 냉찜질과 온찜질을 통해 통증을 줄일 수 있습니다. 또한, 관절 보호대를 착용하여 관절을 안정시키고, 필요시 스테로이드 주사를 통해 염증을 감소시킬 수 있습니다.</dd>
						</dl>
						<dl>
							<dt>수술적 치료</dt><dd>보존적 치료로 효과를 보기 어려운 경우, 수술적 치료를 고려할 수 있습니다. 초기 단계에서는 관절경을 통한 치료가 이루어지며, 관절 내부의 연골 손상 부위를 정리하고 염증을 제거하는 방법이 사용됩니다. 퇴행성 관절염이 심해지면, 인공관절 치환술이 필요할 수 있습니다. 이 수술은 손상된 관절을 인공 관절로 대체하여, 관절의 운동성을 회복시킵니다. 수술 후에는 재활 치료를 통해 관절 기능을 회복하고, 활동 범위를 넓힐 수 있습니다.</dd>
						</dl>
					</div>
				</div>				
		  </article>
	</section>
</div>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
