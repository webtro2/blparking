<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="intro1" class="inner">
		<h3>MS재건병원은 뛰어난 수준의 의술을 갖춘 정형외과 전문의가 <br>
함께 하여 <span class="fc-M1">상·하지에 발생할 수 있는 모든 외상 및 질환</span>을 전문적으로 치료하는 <br>
<span class="fc-M2">24시간 수술 병원</span>으로 설립되었습니다.</h3>
		<img src="/images/sub/intro1-sb.png">
	</div>

	<div id="intro1-2">
		<div class="introImg"><img src="/images/sub/intro1-bg.png"></div>
		<div class="introWrap">
			<p class="t1">전문의가 모두 풍부한 정형외과 및 수부외과 수술 경험을 보유하고 있으면서, 이에 더하여 각각 
미세수술 및 상하지 재건(김효곤), 족부 및 족관절(유선오,김정래), 수부상지재건 및 관절경(하성한)이라는 
더욱 특화된 진료 영역을 구축, 협진 체계를 이룸으로써 시너지 효과를 이루어, 팔 다리에 생길 수 있는 모든 질환과 
외상에 대해서 가장 신속하고 편리한 진료환경에서 최고의 특화된 의료 서비스를 제공하여 최상의 치료 결과를 
보장하고자 합니다.</p>
			<p class="t1">저희 MS재건병원의 원장과 직원 모두는 그 동안 대구 현대 병원 등 다른 병원에 재직하면서 환자 · 보호자 분들에게 받은 사랑에 보답하고 더 나은 진료를 베풀기 위해서 그 동안 축적된 의학 지식과 기술을 바탕으로 우수한 병원시설과 장비, 쾌적한 병원 환경, 환자 · 보호자 분들을 감동시킬 수 있는 친절한 의료 서비스를 더하여 치료의 효과를 더욱 더 
높임으로서 찾아오시는 모든 환자분들이 최대한 빠른 시일 내에  건강을 되찾을 수 있도록 한 차원 높은 의료서비스를 
제공하여 지역 사회와 국민 보건에 공헌하는 MS 재건병원이 될 것을 약속 드립니다. </p>
		</div>
	</div>

	<div id="intro1-3" class="inner">
		<div class="introImg"><img src="/images/sub/intro1-img.png"></div>
		<div class="introWrap">
			<p class="t1">또한 이용하고 계신 홈페이지는 가정과 직장에서 환자와 보호자들께서 궁금해 하시는 
의학정보와 건강 상담 등을 보다 쉽게 이해할 수 있도록 운영하고 있습니다. 
앞으로도 지속적으로 수정하고 보완하여 보다 더 유익한 정보를 신속하게 제공하도록 
최선을 다하겠습니다.</p>
			<p class="t1">MS재건병원을 이용하시면서 불편한 점이나 건의하시는 부분에 대해 항상 귀 기울여
			<h4>언제나 "<span class="fc-M1">환자곁에서</span> <span class="fc-M2">환자편에서</span>" 생각하고 행동하는 
MS재건병원이 될 것을 거듭 약속드리며, </h4>
			<p class="t1">여러분 가정에 건강한 웃음이 넘치는 하루하루가 되시길 기원합니다.</p>
			<dl>
				<dd>MS재건병원장</dd>
				<dt>유선오 · 하성한 · 김효곤 · 김정래</dt>
			</dl>
		</div>
		
	</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
