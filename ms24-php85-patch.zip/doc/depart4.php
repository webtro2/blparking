<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


<div id="clinicBg">	
	<div id="clinicTop" class="depart4 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png">
			<dl>
				<dt>영상의학과</dt>
				<dd>정확한 진단은 환자분의 건강을 지키는 첫걸음입니다. 최선을 다해 믿을 수 있는 결과를 제공하겠습니다.</dd>
			</dl>
		</div>
	</div>
	<div id="clinicCont">
		<h3 class="fc-M2">대학병원급 우수한 영상 장비를 활용해 정밀한 진단을 제공하며, 환자 상태를 정확히 파악합니다.</h3>
		<p class="t1">디지털 방사선영상(DR), 초음파영상(US), 전산화단층촬영(CT), 자기공명영상(MRI) 등 각종 영상의 촬영, 판독, 진단 및 의료영상저장전달체계(PACS)를 기반으로 한 각종 영상정보의 처리, 보관 및 전송 등의 영상정보지원을 담당하고 있습니다.</p>
		<p class="t1">본원의 주요진료과목인 근골격 및 척추영상의학과 더불어 신경두경부, 흉부와 복부영상의학 등 신체 다양한 부위의 영상진단을 통해 진료의 질을 높이는데 최선을 다하겠습니다.</p>
	</div>
</div>





	<h3 id="depart1-h3">영상의학과 대표 의료기기</h3>
	<div id="imgList" class="w3 inner">
		<div class="in-box">
			<img src="/images/sub/intro6-img2.png">
			<dl>
				<dt>전산화단층촬영(CT)</dt>
				<dd>X선을 이용한 단층 촬영 기술로 인체의 단면을 정밀하게 확인하며, 장기, 혈관, 뼈 구조 등을 상세히 파악해 질환 진단에 널리 사용됩니다.</dd>
			</dl>
		</div>
		<div class="in-box">
			<img src="/images/sub/intro6-img3.png">
			<dl>
				<dt>자기공명영상(MRI)</dt>
				<dd>자기장을 활용한 고해상도 영상 촬영 기기로, 뇌, 척수, 연부 조직, 관절 등 세밀한 구조를 진단하는 데 적합합니다. 방사선 노출 없이 안전하게 검사할 수 있습니다.</dd>
			</dl>
		</div>
		<div class="in-box">
			<img src="/images/sub/intro6-img5.png">
			<dl>
				<dt>디지털 방사선영상(DR)</dt>
				<dd>X선을 사용해 뼈, 폐, 관절 등의 이상 유무를 빠르고 간단하게 확인할 수 있는 기본 영상 진단 장비입니다.</dd>
			</dl>
		</div>
	</div>


	<h3 id="depart1-h3">의료진소개</h3>

			<div id="intro3" class="inner depart">
			<a href="#doctor12">
                    <div class="img">
                        <img src="/images/main/mdoctor-img12.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>강민석 <span>과장</span></dt>
							<dd>영상의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>영상의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
		</div>


<?php include "../inc/doctor.php"; ?>
</div>
</div>
<?php include "../inc/bottom.php"; ?>
