<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "5";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="guide1">
			<div id="titWrap">
				<h3>신청안내</h3>
			</div>
			<div id="contWrap">
				<ul id="dotList">
					<li><p><b class="fc-bl">입원 환자</b> : 퇴원 2~3일전 간호사실에 신청하시기 바랍니다.</p></li>
					<li><p><b class="fc-bl">퇴원 · 외래 환자</b> : 외래 진료과 간호사에게 신청하시기 바랍니다.</p></li>
				</ul>
				<p class="guide5-st1">외래 진료 시간 동안에만 증명서 발급이 가능하며 병원 사정에 따라 당일 발급이 어려운 경우도 있으니 미리 신청하시기 바랍니다.</p>
			</div>
		</div>



	<div id="guide1">
			<div id="titWrap">
				<h3>신청시 구비서류</h3>
			</div>
			<div id="contWrap">
				<ul id="boxNum" class="guide5">
					<li>
						<p class="tit fs-2">환자본인 요청 시</p>
						<ul id="dotList">
							<li><p>본인임을 확인 할 수 있는 신분증 (주민등록증, 운전면허증 등)</p></li>
						</ul>
					</li>
					<li>
						<p class="tit fs-2">환자의 가족 요청 시 <br>(환자의 배우자, 부모, 자녀)</p>
						<ul id="dotList">
							<li><p>신청인의 신분증</p></li>
							<li><p>환자의 신분증 및 사본</p></li>
							<li><p>가족임을 확인 할 수 있는 서류 (가족관계증명서, 주민등록등본 등)</p></li>
							<li><p>환자가 자필서명한 동의서</p></li>
						</ul>
						<p class="st1">단, 17세미만환자의 부모가 요청 시(부모신분증, 가족확인서류 지참)</p>
					</li>
					<li>
						<p class="tit fs-2">환자가 지정하는 <br>대리인이 요청 시</p>
						<ul id="dotList">
							<li><p>신청인의 신분증</p></li>
							<li><p>환자의 신분증 및 사본</p></li>
							<li><p>환자가 자필 서명한 위임장</p></li>
							<li><p>환자가 자필 서명한 동의서</p></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>




	<div id="guide1">
			<div id="titWrap">
				<h3>발급 요청시 확인사항</h3>
			</div>
			<div id="contWrap">
				<ul id="dotList">
					<li><p>신분증 또는 신분증 사본은 반드시 사진이 있는 것이어야 함</p></li>
					<li><p>친족관계증명서는 환자 본인과의 관계가 명시된 것이어야 함</p></li>
					<li><p>동의서 및 위임장은 자필서명이 있어야 하며 도장 및 지장은 인정되지 않음</p></li>
					<li><p>동의서에는 사본발급 받는 범위(날짜, 기록지 범위 등)를 구체적으로 명기하도록 하여야 함</p></li>
					<li><p>사망, 의식불명인자, 미성년자 등의 경우에는 법정 대리인이 대신할 수 있음</p></li>
				</ul>
			</div>
		</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
