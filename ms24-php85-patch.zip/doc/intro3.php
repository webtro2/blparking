<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


		<div id="intro3">
			<a href="#doctor1">
                    <div class="img">
                        <img src="/images/main/mdoctor-img1.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>유선오 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor2">
                    <div class="img">
                        <img src="/images/main/mdoctor-img2.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>하성한 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
							<li><p>수부외과 세부 전문의</p></li>
							<li><p>견주관절 클리닉</p></li>
							<li><p>슬관절클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor3">
                    <div class="img">
                        <img src="/images/main/mdoctor-img3.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김효곤 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부 관절클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor4">
                    <div class="img">
                        <img src="/images/main/mdoctor-img4.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김정래 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor5">
                    <div class="img">
                        <img src="/images/main/mdoctor-img5.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김동영 <span>원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>무릎 및 어깨관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor6">
                    <div class="img">
                        <img src="/images/main/mdoctor-img6.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>이원제 <span>원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>척추센터 소장</p></li>
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor7">
                    <div class="img">
                        <img src="/images/main/mdoctor-img7.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>나호동 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
							<li><p>척추 및 견주관절</p></li>
							<li><p>수부</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<!-- <a href="#doctor8">
                    <div class="img">
                        <img src="/images/main/mdoctor-img8.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>박진식 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부외과 클리닉</p></li>
							<li><p>견주관절 클리닉</p></li>
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a> -->
            <a href="#doctor14">
                    <div class="img">
                        <img src="/images/main/mdoctor-img14.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>이현록 <span>과장</span></dt>
							<dd>성형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부외과 세부 전문의</p></li>
							<li><p>수부외과 클리닉</p></li>
							<li><p>수부 및 상지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
				<p class="go">약력보기</p>
			</a>
             <a href="#doctor15">
                    <div class="img">
                        <img src="/images/main/mdoctor-img15.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>송원호 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
				<p class="go">약력보기</p>
			</a>
			<a href="#doctor9">
                   <div class="img">
                        <img src="/images/main/mdoctor-img9.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>정종성 <span>원장</span></dt>
							<dd>마취통증의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>마취통증의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor10">
                    <div class="img">
                        <img src="/images/main/mdoctor-img10.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>하인호 <span>과장</span></dt>
							<dd>마취통증의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>마취통증의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor11">
                    <div class="img">
                        <img src="/images/main/mdoctor-img11.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>황병윤 <span>원장</span></dt>
							<dd>가정의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>가정의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor12">
                    <div class="img">
                        <img src="/images/main/mdoctor-img12.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>강민석 <span>과장</span></dt>
							<dd>영상의학과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>영상의학과</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
	</div>



<?php include "../inc/doctor.php"; ?>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
