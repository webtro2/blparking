<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "5";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


<div id="clinicBg">
	<div id="clinicTop" class="review1 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png">
			<dl>
				<dt>고객불편상담 안내</dt>
			</dl>
		</div>
	</div>
	<div id="clinicCont">
		<h3 class="fc-bl">보다 신속하고 정확한 확인 및 <br class="mo">원활한 처리를 위해 <br>고객님의 불편사항과 민원은 <br class="mo"><b>이메일</b>로 접수해 주시기 바랍니다.</h3>
		<p class="t1">접수해 주신 내용은 담당 부서에서 확인 후<br class="mo"> 성실하고 신속하게 답변드리겠습니다.</p>
        <div class="bgp"><p>※ 불편사항 접수 이메일 : msr0119@naver.com</p></div>
	</div>
</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
