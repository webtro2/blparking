<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "6";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



<div id="clinicBg">	
	<div id="clinicTop" class="depart6 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png" alt="성형외과">
			<dl>
				<dt>성형외과</dt>
				<dd>외상이나 질환으로 손상된 신체 부위의 기능과 형태를 회복하여 환자분이 건강한 일상으로 돌아갈 수 있도록 세심한 진료를 제공합니다.</dd>
			</dl>
		</div>
	</div>

	<div id="clinicCont">
		<h3 class="fc-M2">손상된 조직의 기능과 형태를 회복하고 환자분의 편안한 일상 복귀를 돕겠습니다.</h3>
		<p class="t1">성형외과는 외상, 화상, 피부 및 연부조직 손상, 상처, 흉터와 신체 조직의 결손이나 변형을 진단하고 치료합니다.<br> 환자 개개인의 손상 정도와 회복 상태를 세심하게 확인하여 적절한 치료 및 재건 계획을 수립합니다.</p>
		<p class="t1">상처 치료와 흉터 관리부터 조직 재건과 기능 회복까지 체계적인 진료를 시행하며, <br>손상 부위의 형태적인 회복뿐 아니라 신체 기능과 삶의 질을 높이는 것을 목표로 합니다.</p>
	</div>
</div>








	<h3 id="depart1-h3">의료진소개</h3>

			<div id="intro3" class="inner depart">
			<a href="#doctor14">
                    <div class="img">
                        <img src="/images/main/mdoctor-img14.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>이현록 <span>과장</span></dt>
							<dd>성형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부외과 세부 전문의</p></li>
							<li><p>수부외과 클리닉</p></li>
							<li><p>수부 및 상지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
				<p class="go">약력보기</p>
			</a>
			
			</div>

<?php include "../inc/doctor.php"; ?>
</div>
</div>
<?php include "../inc/bottom.php"; ?>
