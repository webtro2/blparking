<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


<div id="clinicBg">
	<div id="clinicTop" class="depart1 inner">
		<div id="in-box">
			<img src="/images/common/logo_w.png">
			<dl>
				<dt>정형외과</dt>
				<dd>MS재건병원은 지역 내 구. 현대병원에서 인정받은 실력있는 의료진들이 많은 임상 경험을 바탕으로 환자의 빠른 회복과 치료를 위해 노력합니다.</dd>
			</dl>
		</div>
	</div>
	<div id="clinicCont">
		<h3 class="fc-M2">뼈, 관절, 근육, 인대 등 근골격계 질환 및 외상을 전문으로 진단하고 치료합니다.</h3>
		<p class="t1">사지와 척추에 있는 뼈와 관절 및 근육, 인대, 신경, 혈관 등 주위 조직에 대해서 연구하고, 질환과 외상을 진단하고 치료하는 분야입니다. </p>
		<p class="t1">주로 하는 치료에는 약물 치료, 주사, 물리 치료, 운동 치료 등이 있으며, 이런 치료에도 증상이 계속되는 경우에는 수술적인 치료를 하게 됩니다.</p>
	</div>
</div>


		<h3 id="depart1-h3">의료진 소개</h3>
	
		
		<div id="intro3" class="inner">
			<a href="#doctor1">
                    <div class="img">
                        <img src="/images/main/mdoctor-img1.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>유선오 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor2">
                    <div class="img">
                        <img src="/images/main/mdoctor-img2.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>하성한 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
							<li><p>수부외과 세부 전문의</p></li>
							<li><p>견주관절 클리닉</p></li>
							<li><p>슬관절클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor3">
                    <div class="img">
                        <img src="/images/main/mdoctor-img3.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김효곤 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부 관절클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor4">
                    <div class="img">
                        <img src="/images/main/mdoctor-img4.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김정래 <span>병원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor5">
                    <div class="img">
                        <img src="/images/main/mdoctor-img5.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>김동영 <span>원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>무릎 및 어깨관절 클리닉</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor6">
                    <div class="img">
                        <img src="/images/main/mdoctor-img6.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>이원제 <span>원장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>척추센터 소장</p></li>
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<a href="#doctor7">
                    <div class="img">
                        <img src="/images/main/mdoctor-img7.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>나호동 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>족부 및 족관절 클리닉</p></li>
							<li><p>척추 및 견주관절</p></li>
							<li><p>수부</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a>
			<!-- <a href="#doctor8">
                    <div class="img">
                        <img src="/images/main/mdoctor-img8.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>박진식 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부외과 클리닉</p></li>
							<li><p>견주관절 클리닉</p></li>
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
					<p class="go">약력보기</p>
			</a> -->

             <a href="#doctor15">
                    <div class="img">
                        <img src="/images/main/mdoctor-img15.png" alt="">
                    </div>
					<div class="cont">
						<dl class="txt">
							<dt>송원호 <span>과장</span></dt>
							<dd>정형외과 전문의</dd>
						</dl>
						<h3>진료분야</h3>
						<ul id="dotList" class="intro3">
							<li><p>수부 및 상하지 외상 골절</p></li>
						</ul>
					</div>
					<div class="c-table">
					<table class="tb-style1 intro3">
						<colgroup>
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
							<col width="">
						</colgroup>
						<thead>
							<tr>
								<th></th>
								<th>월</th>
								<th>화</th>
								<th>수</th>
								<th>목</th>
								<th>금</th>
								<th>토</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>오전</th>
								<td>○</td>
								<td></td>
								<td></td>
								<td>○</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<th>오후</th>
								<td></td>
								<td>○</td>
								<td></td>
								<td>○</td>
								<td>○</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>
				<p class="go">약력보기</p>
			</a>
            
		</div>



<?php include "../inc/doctor.php"; ?>
</div>
</div>
<?php include "../inc/bottom.php"; ?>
