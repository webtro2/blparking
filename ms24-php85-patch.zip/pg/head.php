<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH.'/head.sub.boa.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');


$login = "/pg/bbs/login.php";		// 로그인
$logout = "/pg/bbs/logout.php";		// 로그아웃
$join = "/pg/bbs/register.php";		// 회원가입
$join1 = "/pg/bbs/register_form.php";		// 회원가입
$join2 = "/pg/bbs/register_result.php";		// 회원가입
$mypage = "/pg/bbs/member_mypage.php";		// 마이페이지
$modify = "/pg/bbs/member_confirm.php?url=register_form.php";		// 정보수정
$idpw = "/pg/bbs/password_lost.php";		// 아이디/비밀번호찾기
$leave = "/pg/bbs/member_confirm.php?url=member_leave.php";		// 회원탈퇴


$mstr = strtok($_SERVER['REQUEST_URI'], '?');

$s_num = "";
$p_num = "";

if($bo_table == "intro4"){
	$s_num = "1";
	$p_num = "4";
}elseif($bo_table == "intro5"){
	$s_num = "1";
	$p_num = "5";
}elseif($bo_table == "review1"){
	$s_num = "5";
	$p_num = "1";
}elseif($bo_table == "review2"){
	$s_num = "5";
	$p_num = "2";
}elseif($bo_table == "review3"){
	$s_num = "5";
	$p_num = "3";
}elseif($bo_table == "comm1"){
	$s_num = "6";
	$p_num = "1";
}elseif($bo_table == "comm2"){
	$s_num = "6";
	$p_num = "2";
}elseif($bo_table == "comm3"){
	$s_num = "6";
	$p_num = "3";
}elseif($bo_table == "comm4"){
	$s_num = "6";
	$p_num = "4";
}elseif($bo_table == "comm5"){
	$s_num = "6";
	$p_num = "5";
}elseif($bo_table == "comm6"){
	$s_num = "6";
	$p_num = "6";
}elseif($bo_table == "comm7"){
	$s_num = "6";
	$p_num = "7";
}else if($mstr == $join || $mstr == $join1 || $mstr == $join2) {
	$s_num = "7";
	$p_num = "2";
}
?>



<?php include __DIR__ . "/../inc/head.php"; ?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>
<?php include __DIR__ . "/../inc/s_visual_board.php"; ?>




<div id="pageCont" class="inner" >
<h3 id="subTitle"><span class="vis_dep02"></span></h3>