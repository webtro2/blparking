<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 2);
		});
	</script>


	<div id="pageCont" class="s-inner">

    

	<div id="subTitle">
		<h3>경쟁력</h3>
	</div>
    

        <div class="center"><img src="/images/sub/intro2-img1.png" style="max-width:100%" /></div>

		
	</div>
</div>


<?php include "../inc/bottom.php"; ?>