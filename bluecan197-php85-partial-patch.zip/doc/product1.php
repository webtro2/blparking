<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual2.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb2.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(2, 1);
		});
	</script>

	<div id="subTitle" class="pg01 inner mb0">
		<h3>제품소개</h3>

		<div class="ss_gnb">
			<ul class="col3">
				<li class="submenu1"><a class="menu1" href="javascript:GoPage('product1')">장난감멀티자판기</a></li>
				<li class="submenu2"><a class="menu2" href="javascript:GoPage('product1-2')">미니카자판기</a></li>
				<li class="submenu3"><a class="menu3" href="javascript:GoPage('product1-3')">토이고매장</a></li>
			</ul>
		</div>

	</div>



	<div id="pageCont" class="s-inner sub0201 pt0">
		<div class="sub02_tit_wrap ">
			<div class="tit half">
				<b>토이고 장난감 멀티자판기</b>
				토이고 장난감 멀티자판기는 토이고에서 직수입하여 저렴한 금액에 <br class="pc">
				언제 어디서든 장남감을 구입하고 즐길 수 있는 자판기입니다. <br class="pc">
				어린이들이 있는 장소라면 어디든 설치가 가능하며, <br class="pc">
				현재 캠핑장 등에 설치되어 많은 인기를 얻고있습니다.
			</div>
			<div class="img half right"><img src="/images/sub/sub0201_img_01.png" /></div>
		</div>
		<h5 class="sub02_bo_tit">제품소개</h5>

	</div>

</div>


<?php include "../inc/bottom.php"; ?>