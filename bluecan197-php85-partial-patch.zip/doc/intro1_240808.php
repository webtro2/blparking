<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 1);
		});
	</script>


	<div id="subTitle">
		<h3>보나팩토리 소개</h3>
	</div>

	<div id="pageCont" class="s-inner sub0101 over">
		<div class="half sub0101_box1">
			<img class="sub0101_img" src="/images/sub/sub0101_img_01_240412.png" />
		</div>
		
		<div class="half sub0101_box2">
			<div class="tit">
				<span>
				전자담배 액상 자동판매기 전문업체<br class="pc">
				보나팩토리 입니다.
				</span>
			</div>

			<div class="con">
				안녕하세요.<br>
				전자담배 액상 자동판매기 전문업체 보나팩토리입니다.<br class="pc">
				보나팩토리는 무인 자동판매기 제작 및 유통 전문기업인 토이고에서 <br class="pc">
				전자담배 액상 무인판매를 위해 새롭게 런칭한 브랜드로<br>
				타 전자담배 브랜드와의 압도적인 맛 차이를 보장하며<br class="pc">
				소비자에게 좋은 제품을, 사업주에게는 좋은 수익을 제공해드릴 것입니다.<br class="pc">


			</div>
			<div class="sign"><small>대표</small> 석진호</div>
		</div>
	</div>

</div>


<?php include "../inc/bottom.php"; ?>