<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual2.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb2.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(2, 1);
		});
	</script>

	<div id="subTitle" class="pg03 inner mb0">
		<h3>제품소개</h3>

		<div class="ss_gnb">
			<ul class="col3">
				<li class="submenu1"><a class="menu1" href="javascript:GoPage('product1')">장난감멀티자판기</a></li>
				<li class="submenu2"><a class="menu2" href="javascript:GoPage('product1-2')">미니카자판기</a></li>
				<li class="submenu3"><a class="menu3" href="javascript:GoPage('product1-3')">토이고매장</a></li>
			</ul>
		</div>

	</div>



	<div id="pageCont" class="s-inner sub0203 pt0">
		<div class="sub02_tit_wrap ">
			<div class="tit half">
				<b>토이고 매장</b>
				토이고 매장은 오프라인 매장으로 직수입 브릭제품 매장이며 본사 직수입으로 <br class="pc">
				유통과정을 단축하여 보다 높은 마진율을 드리고 있으며  <br class="pc">
				소비자에게는 저렴한 금액으로 단골 고객확보에 노력하고 있습니다. <br class="pc">
				브릭제품 외에도 인기좋은 장난감 제품, 지속적인 신상품 발주를 통하여  <br class="pc">
				신규고객 유입에도 많은 도움을 드리고자 최선을 다해 노력하고 있습니다.
			</div>
			<div class="img half right"><img src="/images/sub/sub0203_img_01.png" /></div>
		</div>
		<h5 class="sub02_bo_tit">제품소개</h5>

	</div>

</div>


<?php include "../inc/bottom.php"; ?>