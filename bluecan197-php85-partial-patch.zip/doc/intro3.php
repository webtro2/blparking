<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 3);
		});
	</script>


	<div id="subTitle">
		<h3>찾아오시는 길</h3>
	</div>
	
	<div id="pageCont" class="s-inner sub0103_map_box">
		<div class="map_box">
			<div id="daumRoughmapContainer1538124950753" class="root_daum_roughmap root_daum_roughmap_landing"></div>

			<script charset="UTF-8" class="daum_roughmap_loader_script" src="http://dmaps.daum.net/map_js_init/roughmapLoader.js"></script>

			<script charset="UTF-8">
				new daum.roughmap.Lander({
					"timestamp" : "1538124950753",
					"key" : "q7o8",
					"mapWidth" : "1200",
					"mapHeight" : "450"
				}).render();
			</script>
		</div>

		<div class="clear"></div>

		<div class="sub0103_box1">
			<div class="sub0103_box1_t">대전광역시 중구 대둔산로 275 규현빌딩 3층</div>
			<div class="sub0103_box1_c">T 1600.9652&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;F 042.581.8078</div>
		</div>

		<div class="sub0103_box2">
			<div class="sub0103_box2_t">오시는길</div>
			<ul class="sub0103_box2_ul">
				<li>
					<div class="sub0103_box2_c">
						<div class="sub0103_box2_c_t"><span class=""></span> 버스 이용시</div>
						<div class="sub0103_box2_c_c">· 우남스타원아파트 - 312, 313, 316, 513, 34</div>
						<div class="sub0103_box2_c_c">· 사정교 - 312, 314, 316</div>
					</div>					
				</li>
				<li>
					<div class="sub0103_box2_c">
						<div class="sub0103_box2_c_t"><span class=""></span> 주차장 안내</div>
						<div class="sub0103_box2_c_c">· 본사 건물(규현빌딩) 내 주차장 이용</div>
					</div>
				</li>
			</ul>
		</div>

	</div>

</div>


<?php include "../inc/bottom.php"; ?>