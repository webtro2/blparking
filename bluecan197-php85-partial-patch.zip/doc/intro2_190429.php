<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 2);
		});
	</script>


	<div id="subTitle">
		<h3>경쟁력</h3>
	</div>

	<div id="pageCont" class="s-inner">

		<div class="sub0102_box_wrap">
			<div class="img">
				<img src="/images/sub/sub0102_img_01.png" />
			</div>
			<div class="txt txt1">
				<img src="/images/sub/sub0102_img_05.png" />
				<b>높은 마진율</b>
				<span>
					타 악세사리 매장에 비해 <br>
					높은 마진율을 가지고 있습니다.
				</span>
			</div>
			<div class="img img2">
				<img src="/images/sub/sub0102_img_02.png" />
			</div>

			<div class="txt txt2">
				<img src="/images/sub/sub0102_img_06.png" />
				<b>지속적인 신상품 발주</b>
				<span>
					본사의 지속적인 신상품 발주로 <br>
					여러 아이템 지속적 공급됩니다.
				</span>
			</div>
			<div class="center">
				
			</div>
			<div class="txt txt3">
				<img src="/images/sub/sub0102_img_07.png" />
				<b>유통과정 단축</b>
				<span>
					모든 제품은 착한마녀에서 직접 <br>
					직수입하여 유통과정이 단축됩니다.
				</span>
			</div>

			<div class="img">
				<img src="/images/sub/sub0102_img_03.png" />
			</div>
			<div class="txt txt4">
				<img src="/images/sub/sub0102_img_08.png" />
				<b>저렴한 금액</b>
				<span>
					저렴한 금액으로 판매되어 <br>
					단골 고객의 확보가 유리합니다.
				</span>
			</div>
			<div class="img img4">
				<img src="/images/sub/sub0102_img_04.png" />
			</div>
		</div>
		
	</div>
</div>


<?php include "../inc/bottom.php"; ?>