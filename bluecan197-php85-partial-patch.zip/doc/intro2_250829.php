<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 2);
		});
	</script>


	<div id="subTitle">
		<h3>경쟁력</h3>
        <p>3,900만 원으로 시작하는 고수익 무인창업 <br>
보나팩토리는 ‘창업자의 부담은 줄이고 수익은 높이는’ 구조를 지향합니다. <br>
합리적인 초기 비용과 인건비 없는 운영 방식으로 <br>
누구나 쉽게 도전할 수 있는 스마트 창업 모델을 제공합니다.</p>
	</div>
    

	<div id="pageCont" class="s-inner">

        <div class="center"><img src="/images/sub/sub0102_img_12.png" /></div>

        <p class="center" style="margin-bottom:8%;">“보나팩토리는 기계만 파는 게 아닙니다. <br>
        사업의 안정성과 수익성까지 함께 설계합니다.”</p>

		<div class="sub0102_box_wrap">
        
            <div class="txt txt1">
                <img src="/images/sub/sub0102_img_05.png" />
                <b>인건비 ZERO</b>
                <span>
                    적은 유지 비용으로 최대 이익 창출 가능
                </span>
            </div>
           
            <div class="img">
                <img src="/images/sub/sub0102_img_01_240808.jpg?v=1" />
            </div>

			<div class="txt txt2">
				<img src="/images/sub/sub0102_img_10.png" />
				<b>작은 공간으로 이익 창출</b>
				<span>
					오직 자판기 2대 들어갈 공간이면 OK
				</span>
			</div>
			
			<div class="img img2">
				<img src="/images/sub/sub0102_img_02_240808.jpg" />
			</div>
			
			<div class="center">
            
			</div>
           
			<div class="img">
				<img src="/images/sub/sub0102_img_03_240808.jpg?v=1" />
			</div>
           
            <div class="txt txt3">
				<img src="/images/sub/sub0102_img_08.png" />
				<b>24시간 무인시스템</b>
				<span>
					24시간 무인 운영으로<br>
					매장 접근성 극대화
				</span>
			</div>
			
			<div class="img img4">
				<img src="/images/sub/sub0102_img_04_240808.jpg?v=1" />
			</div>
			
			<div class="txt txt4">
				<img src="/images/sub/sub0102_img_11.png" />
				<b>편리한 판매 관리</b>
				<span>
					관제 시스템으로 언제, 어디서든 <br>자판기 판매현황 및 관리 가능
				</span>
			</div>
		</div>
		
	</div>
</div>


<?php include "../inc/bottom.php"; ?>