<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual3.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb3.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(3, 1);
		});
	</script>


	<div id="subTitle" class="pg03 inner">
		<h3>가맹절차</h3>

		<div class="ss_gnb">
			<ul class="col3">
				<li class="submenu1"><a class="menu1" href="javascript:GoPage('franchise1')">장난감멀티자판기</a></li>
				<li class="submenu2"><a class="menu2" href="javascript:GoPage('franchise1-2')">미니카자판기</a></li>
				<li class="submenu3"><a class="menu3" href="javascript:GoPage('franchise1-3')">토이고매장</a></li>
			</ul>
		</div>

	</div>

	<div id="pageCont" class="s-inner sub03_step_box_wrap over">
		
		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_01.png" /></div>
			<div class="num">01</div>
			<div class="con">
				<b>가맹문의 및 상담</b>
				본사방문 상담, <Br class="mo">자금규모 및 수익률<Br>창업환경 및 점포정보
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_02.png" /></div>
			<div class="num">02</div>
			<div class="con">
				<b>상권분석</b>
				상권 및 입지분석 <Br>예상매출 산정, <Br class="mo">점포확정
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_03.png" /></div>
			<div class="num">03</div>
			<div class="con">
				<b>가맹계약</b>
				점포계약 및 가맹계약
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_04.png" /></div>
			<div class="num">04</div>
			<div class="con">
				<b>인테리어 공사</b>
				인테리어 및 시설공사
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_05.png" /></div>
			<div class="num">05</div>
			<div class="con">
				<b>교육실시</b>
				점포운영 교육실시
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_06.png" /></div>
			<div class="num">06</div>
			<div class="con">
				<b>영업준비</b>
				초도물품 입고, <Br class="mo">POS 설치 등 <Br>개점준비 마무리
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_07.png" /></div>
			<div class="num">07</div>
			<div class="con">
				<b>영업시작</b>
				GRAND OPEN
			</div>
		</div>


	</div>

</div>


<?php include "../inc/bottom.php"; ?>