<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual2.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb2.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(2, 1);
		});
	</script>

	<div id="subTitle" class="pg02 inner mb0">
		<h3>제품소개</h3>

		<div class="ss_gnb">
			<ul class="col3">
				<li class="submenu1"><a class="menu1" href="javascript:GoPage('product1')">장난감멀티자판기</a></li>
				<li class="submenu2"><a class="menu2" href="javascript:GoPage('product1-2')">미니카자판기</a></li>
				<li class="submenu3"><a class="menu3" href="javascript:GoPage('product1-3')">토이고매장</a></li>
			</ul>
		</div>

	</div>



	<div id="pageCont" class="s-inner sub0202 pt0">
		<div class="sub02_tit_wrap ">
			<div class="tit half">
				<b>토이고 미니카 자판기</b>
				미니카 자판기세트는 미니카 트랙과 함께 설치되며, <br class="pc">
				어린이 및 아빠들에게 많은 사랑을 얻고 있습니다. <br class="pc">
				토이고 미니카 자판기 세트의 트랙은 토이고에서 직접 수입하며, <br class="pc">
				자판기에 들어가는 미니카 제품은 타이야 정품 제품으로 채워져 있습니다. <br class="pc">
				아이에겐 새로운 즐거움을, 아빠에게는 추억의 즐거움을 선사하는 <br class="pc">
				토이고 미니카 자판기세트는 현재 캠핑장에서 인기 제품입니다.
			</div>
			<div class="img half right"><img src="/images/sub/sub0202_img_01.png" /></div>
		</div>
		<h5 class="sub02_bo_tit">제품소개</h5>

	</div>

</div>


<?php include "../inc/bottom.php"; ?>