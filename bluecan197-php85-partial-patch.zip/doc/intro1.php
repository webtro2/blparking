<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 1);
		});
	</script>


	<div id="subTitle">
		<h3>파란깡통 소개</h3>
	</div>

	<div id="pageCont" class="" style="padding-bottom:0;">

            <div id="intro1new">
                <div class="s-inner">
                    <div id="introPic"><img src="/images/sub/intro1new_img.jpg" alt="파란깡통 대표 김지형"></div>
                    <dl class="dlTop">
                        <dd>세차 입문자도 믿고 쓰는 스마트한 가성비 솔루션</dd>
                        <dt>파란깡통</dt>
                    </dl>
                    <h3>안녕하십니까, <b>파란깡통</b> 대표 김지형입니다.</h3>
                    <p class="t1">
                        매일을 빠짐없이 관리하고, 고객 한 분 한 분의 니즈를 충족시키며, <br>끊임없이 세차장 유지 보수에 힘써오신 사장님 정말 그동안 고생 많으셨습니다.
                        <br><br>
                        저희 <b>파란깡통은</b> <b>2018년 첫발을 내디딘 이래, 수많은 변화 속에서도 오직 세차장 사장님들과의 약속을 지키며  <br>
                        현재까지 유일하게 자리를 지켜오고 있는 세차용품 자판기 전문 기업</b>입니다. <br> 
                        수많은 업체가 생겨나고 사라지는 동안에도 저희가 묵묵히 자리를 지킬 수 있었던 이유는,   <br>현장에서 땀 흘리시는 사장님들의 노고를 누구보다 잘 알고 있기 때문입니다.
                        <br><br>
                        이제는 사장님의 부담을 조금이나마 덜어드리고, 더 큰 결실을 맺으실 수 있도록 파란깡통이 곁에서 든든하게 돕겠습니다.
                    </p>

                    
                <ul class="list">
                    <li>24시간 무인 운영을 통한 확실한 부가 수익</li>
                    <p>별도의 인력 관리나 추가 인건비 부담 없이, 세차장이 운영되는 365일 24시간 내내   사장님의 매장에서 새로운 부가 가치를 창출합니다.</p>
                    <li>멈추지 않는 제품 혁신과 지속적인 리뉴얼</li>
                    <p>단순히 자판기만 설치하고 끝나는 것이 아닙니다. 트렌드와 고객 니즈에 맞춘  고품질 세차용품을 꾸준히 발굴하고 리뉴얼하여, 고객이 계속해서 찾아오는 알찬 제품으로 구성 합니다.</p>
                    <li>끝까지 함께하는 책임감과 신뢰</li>
                    <p>2018년부터 이어온 노하우와 검증된 내구성으로, 단순한 기기 공급을 넘어  사장님의 사업이 더욱 번창할 수 있도록 가장 확실한 비즈니스 파트너가 되어드리겠습니다.</p>
                </ul>


                <p class="t1">
                    세차장의 새로운 부가 수익과 세차 고객의 만족, 두 마리 토끼를 모두 잡고자 하시는
                    사장님들께 파란깡통이 가장 신뢰할 수 있는 답이 되어드리겠습니다. <br>
                    <br>
                    사장님의 노고가 더욱 빛날 수 있도록, 항상 현장의 목소리에 귀 기울이고 함께 발로 뛰겠습니다. <br>
                    감사합니다. <br>
                     <br>
                    <b>파란깡통 대표 김지형 올림</b>
                </p>

                </div>

            </div>
        
	</div>

</div>


<?php include "../inc/bottom.php"; ?>