<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual3.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb3.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(3, 1);
		});
	</script>


	<div id="subTitle" class="pg01 inner">
		<h3>가맹절차</h3>
	</div>

	<div id="pageCont" class="s-inner sub03_step_box_wrap over">
	    <div class="sub03_step_box">
			<div class="mg"><img style="max-width:100%;" src="/images/sub/sub0301_img_01_250708.png" /></div>
			<div class="num">01</div>
			<div class="con">
				<b>창업문의 및 상담</b>
				본사방문 상담 <br>창업환경 및 점포정보
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img style="max-width:100%;" src="/images/sub/sub0301_img_02_250708.png" /></div>
			<div class="num">02</div>
			<div class="con">
				<b>계약체결 </b>
				창업 조건 확인 후 <br>계약 체결
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img style="max-width:100%;" src="/images/sub/sub0301_img_03_250708.png" /></div>
			<div class="num">03</div>
			<div class="con">
				<b>매장위치 상권분석</b>
				상권 및 입지분석, 예상매출 산정
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img style="max-width:100%;" src="/images/sub/sub0301_img_08_250708.png" /></div>
			<div class="num">04</div>
			<div class="con">
				<b>인테리어 및 매장교육</b>
				매장 인테리어 설계 및 매장 교육
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img style="max-width:100%;" src="/images/sub/sub0301_img_09_250708.png" /></div>
			<div class="num">05</div>
			<div class="con">
				<b>영업개시</b>
				자판기 설치 및 영업 개시
			</div>
		</div>

        <div class="sub03_step_box">
			<div class="mg"><img style="max-width:100%;" src="/images/sub/sub0301_img_13.png" /></div>
			<div class="num">06</div>
			<div class="con">
				<b>사후관리</b>
				매장 운영 중 발생하는 문제 해결 및 정기 점검
			</div>
		</div>
		
<!--
		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_01.png" /></div>
			<div class="num">01</div>
			<div class="con">
				<b>가맹문의 및 상담</b>
				본사방문 상담 <Br>자금규모 및 수익률 <br>창업환경 및 점포정보
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_02.png" /></div>
			<div class="num">02</div>
			<div class="con">
				<b>상권분석</b>
				상권 및 입지분석 <Br>예상매출 산정<br>점포확정
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_03.png" /></div>
			<div class="num">03</div>
			<div class="con">
				<b>가맹계약</b>
				점포계약 및 가맹계약
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_04.png" /></div>
			<div class="num">04</div>
			<div class="con">
				<b>인테리어 공사</b>
				인테리어 및 시설공사
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_05.png" /></div>
			<div class="num">05</div>
			<div class="con">
				<b>교육실시</b>
				점포운영 교육실시
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_06.png" /></div>
			<div class="num">06</div>
			<div class="con">
				<b>영업준비</b>
				초도물품 입고, POS 설치 등<br>개점준비 마무리
			</div>
		</div>

		<div class="sub03_step_box">
			<div class="mg"><img src="/images/sub/sub0301_img_07.png" /></div>
			<div class="num">07</div>
			<div class="con">
				<b>영업시작</b>
				GRAND OPEN
			</div>
		</div>
-->


	</div>

</div>

<script>
$(document).ready(function () {
    $('#fConsult .docbtn').addClass('active');
});

</script>

<?php include "../inc/bottom.php"; ?>