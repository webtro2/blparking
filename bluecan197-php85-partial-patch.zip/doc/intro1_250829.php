<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 1);
		});
	</script>


	<div id="subTitle">
		<h3>보나팩토리 소개</h3>
	</div>

	<div id="pageCont" class="s-inner sub0101 over">
		<div class="half sub0101_box1">
			<img class="sub0101_img" src="/images/sub/sub0101_img_01_250708.png" />
		</div>
		
		<div class="half sub0101_box2">
			<div class="tit">
				<span>
				무인매장의 가능성을 현실로. <br class="">
				작은 공간이 큰 수익이 되는 구조를 만듭니다.
				</span>
			</div>

			<div class="con">
            보나팩토리는 자판기 전문 브랜드 ‘토이고’에서 시작해 <br>
            지금은 전국 360여 대의 자판기를 운영 중인 <br>
            검증된 무인매장 시스템 기업입니다. <br>
            <br>
            우리는 단순한 자판기 설치를 넘어 <br>
            전자담배 무인매장이라는 새로운 창업 모델을 제시하고, <br>
            운영자에게 소자본·무인·고수익의 현실적인 창업 솔루션을 제공합니다.

			</div>
			<div class="sign"><small>대표</small> 석진호</div>
		</div>
	</div>

</div>


<?php include "../inc/bottom.php"; ?>