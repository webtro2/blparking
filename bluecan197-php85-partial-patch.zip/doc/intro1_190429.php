<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<!-- visual -->
<?php include "../inc/s_visual1.php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include "../inc/s_gnb1.php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(1, 1);
		});
	</script>


	<div id="subTitle">
		<h3>착한마녀 소개</h3>
	</div>

	<div id="pageCont" class="s-inner sub0101 over">
		<div class="half sub0101_box1">
			<img class="sub0101_img" src="/images/sub/sub0101_img_01.png" />
		</div>
		
		<div class="half sub0101_box2">
			<div class="tit">
				<span>
				여심을 사로잡는 악세사리 <br>
				악세사리 전문 할인 매장<br class="pc">
				착한마녀입니다.
				</span>
			</div>

			<div class="con">
				안녕하세요. 악세사리 전문매장 착한마녀입니다.<br>
				착한마녀는 악세사리 전문 할인 매장으로 <br class="pc">
				착한마녀의 모든 제품은 직접 착한마녀에서 직수입하여 <br class="pc">
				타 악세사리 매장에 비해 마진율이 높습니다. <br>
				착한마녀는 귀걸이, 목걸이를 비롯하여 실내 인테리어 소품, <br class="pc">
				구체관절인형 등을 판매하고 있으며, <br class="pc">
				여심을 사로 잡을 수 있는 여러 아이템을 <br class="pc">
				지속적으로 공급해드리고 있습니다. <br>
				착한마녀와 함께 하실 점주님은 언제든 환영합니다.


			</div>
			<div class="sign"><small>대표</small> 석진호</div>
		</div>
	</div>

</div>


<?php include "../inc/bottom.php"; ?>