<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="language" content="ko" />
<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<meta name="format-detection" content="telephone=no" />



<meta name="title" content="파란깡통"> 
<meta name="author" content="http://bluecan.kr"> 
<meta name="description" content="파란깡통, 세차장 자동 판매기, 멀티자판기"> 
<meta name="subject" content="파란깡통, 세차장 자동 판매기, 멀티자판기"> 
<meta name="keywords" content="파란깡통, 세차장 자동 판매기, 멀티자판기"> 
<meta property="og:type" content="website"> 
<meta property="og:title" content="파란깡통"> 
<meta property="og:subject" content="파란깡통, 세차장 자동 판매기, 멀티자판기"> 
<meta property="og:description" content="파란깡통, 세차장 자동 판매기, 멀티자판기"> 
<meta property="og:image" content="/og_250902.png"> 
<meta property="og:url" content="http://bluecan.kr">
<link rel="canonical" href="http://bluecan.kr"> 
<meta property="al:web:url" content="http://bluecan.kr">
<link rel="shortcut icon" href="/favi_250901.ico">

<meta name="naver-site-verification" content="a59bb171fdea860307c505c80d50f3ef1815197a" />
<title>파란깡통</title>
<!-- css -->
<link media="all" href="/css/default.css?v=2" type="text/css" rel="stylesheet"/>
<link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/notosanskr.css" />
<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700|Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

<script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script>
<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">

<!-- js -->
<script type="text/javascript" src="/js/aos.js"></script>

<!--[if lt IE 9]>
<script type="text/javascript" src="/js/html5shiv.js"></script>
<![endif]-->

<!-- gnb -->
<script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="/js/common_ui.js"></script>

<!-- allmenu -->
<link rel="stylesheet" href="/css/allmenu.css?v=1" />
<link rel="stylesheet" href="/css/layout.css?v=2" />
<link rel="stylesheet" href="/css/main.css?v=7" />
<link rel="stylesheet" href="/css/scont.css?v=7" />
<link rel="stylesheet" href="/css/sub.css?v=5" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="/js/allmenu.js"></script>

<!-- visual -->
<script type="text/javascript" src="/js/velocity.min.js"></script>
<script type="text/javascript" src="/js/main.js"></script>




<script type="text/javascript">
	$(function(){
		gnb.web();
    });
</script>


</head>

<body>

<div id="wrap">