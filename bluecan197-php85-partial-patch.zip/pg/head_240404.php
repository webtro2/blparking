<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
/*if(defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/head.php');
    return;
}*/

include_once(G5_PATH.'/head.sub.boa.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

$title1 = "";
$g_num = "";
$p_num = "";

if($bo_table == "pro01"){
	$title1 = "착한마녀 매장";
	$g_num = "2";
	$p_num = "1";
}else if($bo_table == "store01"){
	$title1 = "가맹점찾기";
	$g_num = "4";
	$p_num = "1";
}else if($bo_table == "comm01"){
	$title1 = "공지&뉴스";
	$g_num = "5";
	$p_num = "1";
}else if($bo_table == "comm02"){
	$title1 = "고객문의";
	$g_num = "5";
	$p_num = "2";
}
?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>

<!-- visual -->
<?php include __DIR__ . "/../inc/s_visual".$g_num.".php"; ?>
<!-- END visual -->


<div id="subContent">

	<!-- sub_top -->
	<div class="sub_top">
		<div class="sub_top_in">
			<div class="snb">
				<div class="home">
					<a href="/">HOME</a>
				</div>
				<div class="depth1_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include __DIR__ . "/../inc/s_gnb0.php"; ?>
				</div>

				<div class="depth2_area">
					<a href="javascript:;" class="open_depth"></a>
					<?php include __DIR__ . "/../inc/s_gnb".$g_num.".php"; ?>
				</div>
			</div>
		</div>
	</div>
	<!-- //sub_top -->
	<script type="text/javascript">
		$(function(){
			gnb.web(0);
			subFunc.snb(<?=$g_num?>, <?=$p_num?>);
		});
	</script>




	<?php if($bo_table == "pro01"){ ?>
		<div id="subTitle" class="pg01 inner mb0">
			<h3>보나팩토리 자동판매기</h3>
		</div><!-- subTitle -->

		<div id="pageCont" class="s-inner sub0201 pt0">
			<div class="sub02_tit_wrap center pt0">
				<div class="tit" >
					무인 자동판매기 전문기업인 토이고에서 전자담배 액상의<br class="pc">
					무인판매를 위해 보나팩토리를 새롭게 론칭하였습니다. <br>
					고품질, 합리적인 가격의 제품을 수입/유통하여 소비자에게는<br class="pc"> 좋은 제품을, 사업주에게는 좋은 수익을 제공해드릴 것입니다.
				</div>
				<div class="img"><img class="img750" src="/images/sub/sub0201_img_01.png" /></div>
				<div class="advantage">
					<ul>
						<li><span class="number">1</span>본사 직수입으로 <b>유통과정 단축</b></li>
						<li><span class="number">2</span>자동판매기는 일종의 무인매장으로 <b>인건비 절감</b></li>
						<li><span class="number">3</span>판매시간 제약없는 <b>24시간 무인판매</b></li>
						<li><span class="number">4</span>카드결제 시스템으로 편리한 <b>매출관리기능</b></li>
						<li><span class="number">5</span>15인치 모니터를 통해 <b>제품소개와 기타홍보영상 송출가능</b></li>
						<li><span class="number">6</span>관제프로그램을 이용하여 <b>재고파악과 로그분석 가능</b></li>
					</ul>
				</div>
			</div>

			<h5 class="sub02_bo_tit">제품소개</h5>

	<?php } else {?>
		<div id="subTitle">
			<h3><?=$title1?></h3>
		</div>

		<div id="pageCont" class="s-inner">
	<?php } ?>
		
	