<?php  include "./_common.php"; ?>
<?php include "inc/head.php"; ?>
<?php include "inc/link.php"; ?>
<?php include "inc/top.php"; ?> 
<?php include_once(G5_LIB_PATH.'/latest.lib.php'); ?>
<?php include_once(G5_BBS_PATH.'/newwin.inc.php'); ?>

<style>
    .slider-block {position: relative;}
    .slider-block video{position:absolute; left:50%; top:50%; transform:translate(-50%, -50%); width: 100%;}
    @media all and (max-width:768px){
    }
</style>
<!-- mVisual -->
<div id="mVisual" class="section"><!-- [D] 메인 비주얼 이미지 -->
	<!-- .slider Start -->
	<div class="slider">
		<div class="jquery-reslider">
			<!-- <div class="slider-block visual_1"> -->
				<!-- <div class="mVisualIn">  
					<dl>
					  <dt>TELECOM &<br/> JEWELRY</dt>
					  <dd class="t1">악세서리부터 핸드폰 개통까지 _ 착한마녀</dd>[D] 영문 20자 / 한글 16자 내외(공백포함)
					</dl>
				</div> -->
			<!-- </div> -->
			<!-- <div class="slider-block visual_2"> -->
				<!-- <div class="mVisualIn">  
					<dl>
					  <dt>TELECOM &<br/> JEWELRY</dt>
					  <dd class="t1">악세서리부터 핸드폰 개통까지 _ 착한마녀</dd>[D] 영문 20자 / 한글 16자 내외(공백포함)
					</dl>
				</div> -->
			<!-- </div> -->
            <div class="slider-block visual_9">
                <video src="/images/intro/intro_250829.mp4" playsinline autoplay loop muted></video>
			</div>
			<!--<div class="slider-block visual_6">
				 <div class="mVisualIn">  
					<dl>
					  <dt>TELECOM &<br/> JEWELRY</dt>
					  <dd class="t1">악세서리부터 핸드폰 개통까지 _ 착한마녀</dd>[D] 영문 20자 / 한글 16자 내외(공백포함)
					</dl>
				</div>
			</div> -->
			<!-- <div class="slider-block visual_7">
			</div>
			<div class="slider-block visual_8">
			</div> -->

			<div class="slider-dots">
			  <ul>
			  </ul>
			</div>
		  </div>
		</div>
		<!-- .slider End -->
		
		<!-- jQuery -->
		<script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
		<!-- Client JavaScript -->
		<script src="/js/jquery.reslider.js"></script>
		<script>
		  $(function(){
			  $('.jquery-reslider').reSlider({
				  speed:1000,  //페이드속도
				  delay:2800,  //자동전환 속도
				  imgCount:4,  //이미지갯수
				  dots:true,   //하단 페이지 버튼
				  autoPlay:true//자동재생
				})
		   })
		 </script>
	<div id="moveSectionDown" class="scroll2"><img src="/images/main/scrollDown.png" alt="scroll" /></div>
</div>
<!-- //mVisual -->


<div id="mSection1New">
    <img src="/images/main/msec1new-img_260813.jpg" style="width:100%;" alt="">
</div>

<!-- <div id="mSection1" class="center">
	<div class="s-inner">
		<img src="/images/main/logo_240404.png" alt="착한마녀"/>
		<p class="t1 mt20">전자담배는 파란깡통</p>
		<p class="t2 mt10">파란깡통는 전자담배 자동판매기 전문 업체입니다. <br>파란깡통만의 다양한 전자담배를 만나보세요.</p>
	</div>
</div> -->

<div id="mSection2">	
	<link rel="stylesheet" href="/css/carouseller.css">

	<div class="carouseller row-fluid for-car"> 
		<div class="carousel-wrapper"> 
			<div class="carousel-items"> 
				<?=latest_group('g_gallery','group2','5','20')?>
				
			</div>
		</div>
		<div class="carousel-control-block">
			<div class="carousel-button-left shadow"><a href="javascript:void(0)">‹</a></div> 
			<div class="carousel-button-right shadow"><a href="javascript:void(0)">›</a></div> 
		</div>
	</div>
</div>
<script src="/js/carouseller.min.js"></script>
<script type="text/javascript">
	$(function() {
		carouseller = new carousel('.carouseller');
	});
</script>

<!-- 
<div id="mSection3">
	<div class="s-inner">
		<p>파란깡통의 더 많은 제품을 만나보고 싶으세요?</p>
		<a href="javascript:GoPage('product1')">제품소개</a>
	</div>
</div> -->

<div id="mSection4">
	<div id="QnA">
		<div class="tit center">
			<h3>파란깡통이 궁금하다면?</h3>
			<p>언택트 시대, 파란깡통과 함께 새로운 창업을 준비해보세요.</p>
		</div>

		<div id="dv_rolling" class="rolling">
			<ul>
				<li class="qa1"><a href="javascript:GoPage('store1')">파란깡통의 오프라인 매장이 궁금해요!</a></li>
				<li class="qa2"><a href="javascript:GoPage('franchise1')">파란깡통 창업 절차를 알려주세요!</a></li>
				<li class="qa3"><a href="javascript:GoPage('product1')">파란깡통의 제품들을 보여주세요!</a></li>
				<li class="qa4"><a href="javascript:GoPage('intro2')">파란깡통만의 경쟁력은 무엇인가요?</a></li>
			</ul>
		</div>

		<script type="text/javascript" src="/js/jquery.vticker-min.js"></script> 
		<script type="text/javascript">
		  $(function(){
			  $('#dv_rolling').vTicker({
				  speed: 500,
				  pause: 3000,
				  animation: 'fade',
				  mousePause: true,
				  showItems: 4,
				  height: 0,
				  direction: 'up'
			});
		});
        </script>

	</div>

	<div id="qnaSlide">
		<div class="autoplay">
			<!-- <div class="bn1"><img src="/images/main/qna_img1_240403.jpg" /></div> -->
			<!-- <div class="bn1"><img src="/images/main/qna_img2_240403.jpg" /></div> -->
			<!-- <div class="bn1"><img src="/images/main/qna_img3_240403.jpg" /></div> -->
			<!-- <div class="bn1"><img src="/images/main/qna_img4_240403.jpg" /></div> -->
            <div class="bn1"><img src="/images/main/qna_img9.jpg" /></div>
			<div class="bn1"><img src="/images/main/qna_img10.jpg" /></div>
			<!-- <div class="bn1"><img src="/images/main/qna_img5_240403.jpg" /></div> -->
			<!-- <div class="bn1"><img src="/images/main/qna_img6_240403.jpg" /></div> -->
		
		</div>

		<script type="text/javascript" src="/js/slick.min.js"></script>
		<link href="/css/slick.css" media="all" rel="stylesheet" type="text/css">
		<link href="/css/slick-theme.css" media="all" rel="stylesheet" type="text/css">

		<script type="text/javascript">
			$(document).ready(function(){
				$('.autoplay').slick({
					infinite: true,
					autoplay: true,
					autoplaySpeed: 4000,
					arrows:false,
					dots: true
				});
			});
		</script>
	</div>

</div>




<?php include "inc/bottom.php"; ?> 