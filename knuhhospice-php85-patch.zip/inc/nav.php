<ul class="gnb">

  <!-- 권역호스피스센터 소개 -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('intro1')">센터소개</a></div>
    <?php  include __DIR__ . "/s_gnb1.php" ?>
  </li>

  <!-- 사업안내 -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('business1')">사업안내</a></div>
    <?php  include __DIR__ . "/s_gnb2.php" ?>
  </li>

  <!-- 호스피스·완화의료 -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('hospice1')">호스피스·완화의료</a></div>
    <?php  include __DIR__ . "/s_gnb6.php" ?>
  </li>

  <!-- 센터소식 -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('news1')">센터소식</a></div>
    <?php  include __DIR__ . "/s_gnb3.php" ?>
  </li>

  <!-- 교육신청 -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('edu1')">교육신청</a></div>
    <?php  include __DIR__ . "/s_gnb4.php" ?>
  </li>

</ul>
