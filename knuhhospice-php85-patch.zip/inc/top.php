<!-- header -->
<div id="header">

  <div id="util">
    <div class="inner">
      <ul class="utilL">
        <li><a href="https://www.knuch.kr:442/index.asp" target="_blank">칠곡경북대학교병원</a></li>
        <li><a href="https://www.knuh.kr/index.asp" target="_blank">경북대학교병원</a></li>
        <li><a href="https://child.knuh.kr/index.asp" target="_blank">경북대학교어린이병원</a></li>
      </ul>
      <ul class="utilR">
        <li><a href="javascript:GoPage('news1')">공지사항</a></li>
        <li><a href="javascript:GoPage('intro4')">오시는길</a></li>
      </ul>
    </div>
  </div>

  <div id="hdMenu" class="inner">
  	<h1 id="logo"><a href="javascript:GoPage('main')"><img src="/images/common/logo.png"  alt=""/></a></h1>

  	<div id="gnb_pc">
  		<?php  include __DIR__ . "/nav.php" ?>
  	</div>

    <div class="menuToggle"><span class="t"></span><span class="m"></span><span class="b"></span></div>
  </div>

  <div id="gnb_mo">
    <div class="gnb_mo_top">
      	<h1><img src="/images/common/logo.png"  alt=""/></h1>
    </div>
   	<?php  include __DIR__ . "/nav.php" ?>
  </div>

</div>
<!-- //header -->


<!--<div id="q_kakao">
  <a href="http://pf.kakao.com/_xnhqxmb" target="_blank">
    <dl>
      <dt>카카오톡 채널</dt>
      <dd>빠르고 간편하게 문의하세요</dd>
    </dl>
    <img src="/images/common/ico_kakao.png" alt="" />
  </a>
</div>-->



<div id="content">
