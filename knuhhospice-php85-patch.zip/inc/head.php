<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="language" content="ko" />
<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<meta name="format-detection" content="telephone=no" />

<title>칠곡경북대학교병원 권역호스피스센터</title>

<meta name="naver-site-verification" content="a21e947d78a22a9556e3cd8ef450c581ba0ecc99" />
<meta name="title" content="칠곡경북대학교병원 권역호스피스센터">
<meta name="description" content="칠곡경북대학교병원 권역호스피스센터, 호스피스완화의료의 활성화를 위해 다양한 사업을 수행합니다.">
<meta name="subject" content="칠곡경북대학교병원 권역호스피스센터">
<meta name="keywords" content="칠곡, 경북대학교, 경북대학교병원, 경대병원, 호스피스, 호스피스센터, 환자, 완화의료, 권역, 권역호스피스센터">
<meta property="og:type" content="website">
<meta property="og:title" content="칠곡경북대학교병원 권역호스피스센터">
<meta property="og:subject" content="칠곡경북대학교병원 권역호스피스센터">
<meta property="og:description" content="칠곡경북대학교병원 권역호스피스센터, 호스피스완화의료의 활성화를 위해 다양한 사업을 수행합니다.">
<meta property="og:image" content="http://knuchhospice.co.kr/images/og_img.png">
<link rel="canonical" href="http://knuchhospice.co.kr/">
<link rel="shortcut icon" href="http://knuchhospice.co.kr/favi.ico">

<link rel="stylesheet" type="text/css" href="/css/default.css" />
<script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script>
<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">

<!-- gnb -->
<script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="/js/common_ui.js"></script>
<script type="text/javascript" src="/js/sub.js"></script>

<!-- js -->
<script type="text/javascript" src="/js/aos.js"></script>

<!-- slick  -->
<script type="text/javascript" src="/js/slick/slick.min.js"></script>
<link media="all" href="/js/slick/slick.css" type="text/css" rel="stylesheet"/>
<link media="all" href="/js/slick/slick-theme.css" type="text/css" rel="stylesheet"/>


<script type="text/javascript">
  $(document).ready(function() {
    $(".tab_content").hide(); //Hide all content
    $("ul.tabs li:first").addClass("active").show(); //Activate first tab
    $(".tab_content:first").show(); //Show first tab content

    //On Click Event
    $("ul.tabs li").click(function() {
      $("ul.tabs li").removeClass("active"); //Remove any "active" class
      $(this).addClass("active"); //Add "active" class to selected tab
      $(".tab_content").hide(); //Hide all tab content
      var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
      $(activeTab).fadeIn(); //Fade in the active content
      return false;
    });
  });
</script>

</head>

<body>

<div id="wrap">
