</div>

<!-- footer -->
<div id="footer">
  <div class="f-link">
    <div class="inner">
      <ul class="btLink">
        <li><a href="javascript:GoPage('intro1')">센터소개</a></li>
        <li><a href="javascript:GoPage('privacy')">개인정보처리방침</a></li>
        <li><a href="javascript:GoPage('provision')">이용약관</a></li>
        <li><a href="javascript:GoPage('intro4')">찾아오시는 길</a></li>
      </ul>
      <div class="btSite">
        <button type="button" class="select_btn">패밀리사이트 바로가기</button>
        <ul class="select_list">
          <li><a href="https://www.knuch.kr:442/index.asp" target="_blank">칠곡경북대학교병원</a></li>
          <li><a href="https://www.knuh.kr/index.asp" target="_blank">경북대학교병원</a></li>
          <li><a href="https://child.knuh.kr/index.asp" target="_blank">경북대학교어린이병원</a></li>
        </ul>
      </div>
    </div>
  </div>

  <div class="f-info">
    <div class="s-inner">
      <h1><img src="/images/common/f_logo.png" alt="" /></h1>
      <div class="txt">
        <p>칠곡경북대학교병원 권역호스피스센터</p>
        <p>주소 : 대구광역시 북구 호국로 807번지 권역호스피스센터</p>
        <!-- p>대표전화 : 053-200-3680</p -->
        <p class="copy">COPYRIGHT ⓒ 2022 REGIONAL HOSPICE CENTER. ALL RIGHT PRESERVED.</p>
      </div>
    </div>
  </div>

</div>
<!-- //footer -->


</div>

<script>
   AOS.init({
     duration: 600,
     offset: 0,
     delay: 100,
     easing: 'ease-out-quad',
   });
</script>

<script type="text/javascript">
	$(document).ready(function() {
		subFunc.snb("<?=($s_num ?? '')?>", "<?=($p_num ?? '')?>");
	});
</script>



</body>
</html>
