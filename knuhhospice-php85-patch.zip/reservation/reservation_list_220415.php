<?php include_once('../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<style>
.subLoca li.on { display: none !important; }
</style>



	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" >

<?php
$sql_common = " from st_event ";

$sql_search = " where (1) ";
if ($stx) {
    $sql_search .= " and ( ";
    switch ($sfl) {
        default :
            $sql_search .= " ({$sfl} like '{$stx}%') ";
            break;
    }
    $sql_search .= " ) ";
}

$sql_search .= " and ev_use = '1' ";


if (!$sst) {
    $sst = "ev_datetime";
    $sod = "desc";
}

$sql_order = " order by {$sst} {$sod} ";

$sql = " select count(*) as cnt {$sql_common} {$sql_search} {$sql_order} ";
$row = sql_fetch($sql);
$total_count = $row['cnt'];

//$rows = $config['cf_page_rows'];
$rows = 15;
$total_page  = ceil($total_count / $rows);  // 전체 페이지 계산
if ($page < 1) $page = 1; // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record = ($page - 1) * $rows; // 시작 열을 구함

$sql = " select * {$sql_common} {$sql_search} {$sql_order} limit {$from_record}, {$rows} ";
$result = sql_query($sql);
?>
	<div id="pageCont" class="event cert cert2">
        <div class="s-inner">

		<table class="tb-style5 green min720">
		<caption>프로그램(목록)</caption>
		<colgroup>
			<col width="">
			<col width="23%">
			<col width="23%">
<!--			<col width="11%">-->
			<col width="16%">
		</colgroup>
		<thead>
			<tr>
				<th scope="col">교육명</th>
				<th scope="col">교육일</th>
				<th scope="col">신청기간</th>
<!--				<th scope="col">참가인원</th>-->
				<th scope="col">마감여부</th>
			</tr>
		</thead>
		<tbody>
<?php
$today = date("Y-m-d");
for ($i=0; $row=sql_fetch_array($result); $i++) {
	$ev_sdate = $row["ev_sdate"];
	$ev_edate = $row["ev_edate"];

	$ev_asdate = $row["ev_asdate"];
	$ev_aedate = $row["ev_aedate"];

	$ev_join_max_cnt = $row["ev_join_max_cnt"];

	$ev_state = $row["ev_state"];

	$state_str = "";
	$day1 = dateDiff($ev_asdate, $today);
	$day2 = dateDiff($ev_aedate, $today);

//	echo $day1;
//	echo $day2;
	if($day1 > 0){
		$state_str = "접수전";
	}
	if ($day2 < 0){
		$state_str = "마감";
	}

	if($day1 <= 0 && $day2 >= 0){
		$state_str = "신청가능";
//		$sql = "select count(*) as cnt from st_event_apply where ev_id = '".$row['ev_id']."' and mb_id = '".$member['mb_id']."' ";
//		$row1 = sql_fetch($sql);
//
//		$cnt1 = $row1['cnt'];
//
//		if ($cnt1 > 0) $state_str = "수정";
//		else $state_str = "참가신청";
	}

	if (trim($ev_state) != ""){
		$state_str = trim($ev_state); //행사종료
	}

	//신청자
	$sql = " select count(ea_id) as cnt from st_event_apply ea where ea.ev_id = '".$row['ev_id']."' ";
	$row1 = sql_fetch($sql);
	$apply_count = $row1['cnt'];

	if ((int)$ev_join_max_cnt > 0){
		if ((int)$ev_join_max_cnt <= $apply_count){
			$state_str = "마감";
		}
	}

	$ev_date = str_replace("-", ".", $ev_sdate);
	if (substr($ev_sdate, 0, 4) == substr($ev_edate, 0, 4)){
		$ev_date;
//            .= " ~ ".substr(str_replace("-", ".", $ev_edate), 5, 5);
	}else{
		$ev_date .= " ~ ".str_replace("-", ".", $ev_edate);
	}

	$ev_adate = str_replace("-", ".", $ev_asdate);
	if (substr($ev_asdate, 0, 4) == substr($ev_aedate, 0, 4)){
		$ev_adate .= " ~ ".substr(str_replace("-", ".", $ev_aedate), 5, 5);
	}else{
		$ev_adate .= " ~ ".str_replace("-", ".", $ev_aedate);
	}

?>
		<tr>
			<td style="border-left:0;">
				<a href="reservation_view.php?ev_id=<?php echo $row['ev_id']; ?>"><?php echo $row['ev_subject']; ?></a>
			</td>
			<td class="center"><?php echo $ev_date; ?></td>
			<td class="center"><?php echo $ev_adate; ?></td>
<!--			<td class="center"><?php echo $apply_count; ?>명</td>-->
			<td class="center">
				<?php if ($state_str == "접수중" || $state_str == "신청" || $state_str == "신청가능"){?>
				<a href="reservation_view.php?ev_id=<?php echo $row['ev_id']; ?>"><span class="on"><?=$state_str?></span></a>
				<?php }else{?>
				<span class="off"><?=$state_str?></span>
				<?php }?>
			</td>
		</tr>
<?php
}

if ($i == 0)
	echo "<tr><td colspan=\"5\" class=\"empty_table\">자료가 없습니다.</td></tr>";
?>
		</tbody>
	</table>

<?php echo get_paging(G5_IS_MOBILE ? $config['cf_mobile_pages'] : $config['cf_write_pages'], $page, $total_page, '?'.$qstr.'&amp;page='); ?>

	</div>

</div>




<?php include "../inc/bottom.php"; ?>
