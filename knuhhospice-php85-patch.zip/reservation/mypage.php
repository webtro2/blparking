<?php include "./_common.php"; ?>
<?php 
if ($is_guest) {
	$msg = "회원으로 로그인 한 후에 신청이 가능합니다.";
	alert($msg);
}

include_once(G5_PATH.'/head.sub.boa.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');
?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>
<?php
$s_num = "4";
$p_num = "1";
?>
<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->
<!-- Sub Content -->
<div id="subContent">
	<div id="subTitle">
		<span class="vis_dep02"></span>
	</div>

	<div id="pageCont" class="cert cert1">
		<div class="s-inner">
			<div class="btn_box right mt0 mb30">
				<input type="button" value="정보수정" onClick="location.href='/pg/bbs/member_confirm.php?url=register_form.php'">
			</div>
			
			<div class="cert_tit">아이디 및 회원등급</div>
			<table class="tb-style5 tb-write">
			<tbody>
			<tr>
			<th>아이디</th>
			<td><?php echo $member['mb_id']; ?></td>
			</tr>
			<tr>
			<th>회원등급</th>
			<td><?php echo $member['mb_1']; ?><?php //php echo getLevelStr($member['mb_level']); //2준회원, 3준회원 ?></td>
			</tr>
			</tbody>
			</table>

			<div class="cert_tit mt40">회원정보</div>
			<table class="tb-style5 tb-write">
			<tbody>
			<tr>
			<th>이름</th>
			<td><?php echo $member['mb_name']; ?></td>
			</tr>
			<tr>
			<th>별명</th>
			<td><?php echo $member['mb_nick']; ?></td>
			</tr>
			<tr>
			<th>E-mail</th>
			<td><?php echo $member['mb_email']; ?></td>
			</tr>
			<tr>
			<th>생년월일</th>
			<td><?php echo $member['mb_birth']; ?></td>
			</tr>
			<tr>
			<th>전화번호</th>
			<td><?php echo $member['mb_tel']; ?></td>
			</tr>
			<tr>
			<th>휴대폰번호</th>
			<td><?php echo $member['mb_hp']; ?></td>
			</tr>
			<tr>
			<th>주소</th>
			<td><?php echo $member['mb_zip1']; ?><?php echo $member['mb_zip2']; ?> <br><?php echo $member['mb_addr1']; ?> <?php echo $member['mb_addr2']; ?></td>
			</tr>
			</tbody>
			</table>


<?php
$sql = "select * from st_event_apply ea left outer join st_event ev ";
$sql .= " on ev.ev_id = ea.ev_id ";
$sql .= " where mb_id = '".$member['mb_id']."' ";
$sql .= " order by ea_id desc ";
$result = sql_query($sql);
?>
			<div class="cert_tit mt40">교육 참가 이력</div>
			<div class="of">
			<table class="tb-style5 min720">
			<col width="5%">
			<col width="">
			<col width="18%">
			<col width="10%">
			<!-- <col width="10%">
			<col width="12%"> -->
			<col width="12%">
			<thead>
			<tr>
			<th>번호</th>
			<th>교육명</th>
			<th>교육일자</th>
			<!-- <th>참가비</th>
			<th>납부일자</th> -->
			<th>신청일자</th>
			<th>참석여부</th>
			</tr>
			</thead>
			<tbody>
<?php
for ($i=0; $row=sql_fetch_array($result); $i++) {
	$ev_sdate = $row["ev_sdate"];
	$ev_edate = $row["ev_edate"];

	if ($row['ea_use'] == "1"){
		$disp_use = "참석";
	}else{
		$disp_use = "불참";
	}

	if ($row['ev_amount'] > 0){
		$disp_amount = number_format($row['ev_amount'])."원";
	}else{
		$disp_amount = "무료";
	}

	$ev_date = str_replace("-", ".", $ev_sdate);
	if (substr($ev_sdate, 0, 4) == substr($ev_edate, 0, 4)){
		$ev_date .= " ~ ".substr(str_replace("-", ".", $ev_edate), 5, 5);
	}else{
		$ev_date .= " ~ ".str_replace("-", ".", $ev_edate);
	}
?>
			<tr class="center">
			<td class="number"><?php echo ($i+1); ?></td>
			<td><?php echo $row['ev_subject']; ?></td>
			<td><?php echo $ev_sdate; ?><?php //php echo $ev_date; ?></td>
			<!-- <td><?php echo $disp_amount; ?></td>
			<td><?php echo $row['ev_amount_date']; ?></td> -->
			<td><?php echo substr($row['ea_datetime'], 0, 10); ?></td>
			<td><?php echo $disp_use; ?></td>

			</tr>
<?php
}

if ($i == 0){
?>
			<tr>
			<td class="center" colspan="5">조회된 자료가 없습니다.</td>
			</tr>
<?php 
}
?>
			<!--<tr class="center">
			<td class="number">2</td>
			<td>홍길동</td>
			<td><a class="check" href="/doc/event2_view.php">2021 한국예술심리교육학회 춘계학술대회</a></td>
			<td>정회원</td>
			<td>무통장입금</td>
			<td>40,000원</td>
			<td>40,000원</td>
			<td>2021-09-24</td>
			</tr>
			<tr class="center">
			<td class="number">1</td>
			<td>홍길동</td>
			<td><a class="check" href="/doc/event2_view.php">2021 한국예술심리교육학회 춘계학술대회</a></td>
			<td>준회원</td>
			<td>무통장입금</td>
			<td>40,000원</td>
			<td>0원</td>
			<td>2021-09-24</td>
			</tr>//-->
			</tbody>
			</table>
			</div>

		</div>
	</div>

</div>

<?php include "../inc/bottom.php"; ?>