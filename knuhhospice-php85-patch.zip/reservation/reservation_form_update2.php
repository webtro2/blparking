<?php
include_once('./_common.php');

$ea_upload_count = 10;
$upload_max_filesize = 1024 * 1024 * 10;
$bo_upload_size = 1024 * 1024 * 10;

$upload_max_filesize = ini_get('upload_max_filesize');

if (empty($_POST)) {
    alert("파일 또는 글내용의 크기가 서버에서 설정한 값을 넘어 오류가 발생하였습니다.\\npost_max_size=".ini_get('post_max_size')." , upload_max_filesize=".$upload_max_filesize."\\n서버관리자에게 문의 바랍니다.");
}


$ev_id = $_POST['ev_id'];
$mb_id = $_POST['mb_id'];
$w = $_POST['w'];

//행사체크
$sql = "select * from st_event where ev_id = '".$ev_id."' and ev_use = '1' ";
$ev = sql_fetch($sql);
if (!$ev['ev_id'])
	alert('정보가 올바르지 않습니다.',"/");

//신청기간 확인
$ev_asdate = $ev["ev_asdate"];
$ev_aedate = $ev["ev_aedate"];

$ev_join_max_cnt = $ev["ev_join_max_cnt"];

$ea_hp = $_POST['ea_hp1']."-".$_POST['ea_hp2']."-".$_POST['ea_hp3'];
$ea_tel = $_POST['ea_tel1']."-".$_POST['ea_tel2']."-".$_POST['ea_tel3'];
$ea_email = $_POST['ea_email_id']."@".$_POST['ea_email_kind'];


if ($w == "" || $w == "u"){//신규 수정시 상태 확인
	$today = date("Y-m-d");

	$day1 = dateDiff($ev_asdate, $today);
	$day2 = dateDiff($ev_aedate, $today);

	//접수전
	if($day1 > 0) alert("신청기간이 아닙니다.","/");

	//접수마감
	if ($day2 < 0) alert("신청기간이 아닙니다.","/");
}


if ($w == ""){//신규
	//참여가능인원 초과
	if ((int)$ev_join_max_cnt > 0){
		$sql = " select count(ea_id) as cnt from st_event_apply ea where ea.ev_id = '".$ev['ev_id']."' ";
		$row1 = sql_fetch($sql);
		$apply_count = $row1['cnt'];		

		if ((int)$ev_join_max_cnt <= $apply_count){
			alert('신청인원제한으로 접수마감되어 더 이상 신청하실 수 없습니다.',"/");
		}		
	}

	//기신청여부 확인
//	if ($w == ""){
//		$sql = " select count(ea_id) as cnt from st_event_apply ea where ea.ev_id = '".$ev['ev_id']."' and mb_id = '".$mb_id."' ";
//		$row1 = sql_fetch($sql);
//		$apply_count = $row1['cnt'];
//		if ($apply_count > 0) alert("이미 신청되어 있습니다.","/");
//	}

	//등록
	$sql = " insert into st_event_apply set
					ev_id = '".$ev['ev_id']."'
					, mb_id = '".$mb_id."'
					, sc_code = '".$_POST['ea_schoolcode']."'
					, ea_name = '".$_POST['ea_name']."'
					, ea_gender = '".$_POST['ea_gender']."'
					, ea_team = '".$_POST['ea_team']."'
					, ea_pos = '".$_POST['ea_pos']."'
					, ea_tel = '".$ea_tel."'
					, ea_hp = '".$ea_hp."'
					, ea_email = '".$ea_email."'
					, ea_stay = '".$_POST['ea_stay']."'
					, ea_comment = '".$_POST['ea_comment']."'
					, ea_ip = '".$_SERVER['REMOTE_ADDR']."'
					, ea_datetime = '".G5_TIME_YMDHIS."' ";
//		echo $sql;
	sql_query($sql);
	?>
<form name="fget" method="get" action="./my_training.php">
</form>

<script>
var f = document.fget;

alert('신청되었습니다.');
f.submit();
location.href="/";
</script>
<?php
	exit;

}else if ($w == "u"){
	$sql = "select * from st_event_apply where ev_id = '".$ev_id."' and mb_id = '".$_POST['mb_id']."'  ";
	$ea = sql_fetch($sql);

	if ($ea['ea_id']){
		//수정
		$sql = " update st_event_apply set
						  sc_code = '".$_POST['ea_schoolcode']."'
						, ea_name = '".$_POST['ea_name']."'
						, ea_gender = '".$_POST['ea_gender']."'
						, ea_team = '".$_POST['ea_team']."'
						, ea_pos = '".$_POST['ea_pos']."'
						, ea_tel = '".$ea_tel."'
						, ea_hp = '".$ea_hp."'
						, ea_email = '".$ea_email."'
						, ea_stay = '".$_POST['ea_stay']."'
						, ea_comment = '".$_POST['ea_comment']."'
					where ea_id = '".$ea['ea_id']."' ";
		//echo $sql;
		sql_query($sql);
?>
<form name="fget" method="get" action="/reservation/mypage.php">
</form>

<script>
var f = document.fget;

alert('정보가 수정되었습니다.');
f.submit();
location.href="/";
</script>
<?php
		exit;
	}
}else if ($w == "d"){
	$sql = " select * from st_event_apply where ev_id = '".$ev_id."' and mb_id = '".$member['mb_id']."'  ";
	$ea = sql_fetch($sql);
	if (!$ea['ea_id'])
		alert('신청정보가 올바르지 않습니다.');

	$sql = " delete from st_event_apply where ea_id = '".$ea['ea_id']."' ";
	sql_query($sql);
?>
	<form name="fget" method="get" action="/reservation/mypage.php">
	</form>

	<script>
	var f = document.fget;

	alert('신청취소 되었습니다.');
	f.submit();
	location.href="/";
	</script>
<?php 
	exit;
}
?>