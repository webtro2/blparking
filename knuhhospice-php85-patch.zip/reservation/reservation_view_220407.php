<?php include_once('../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>
<?php
$s_num = "4";
$p_num = "1";
?>
<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<style>
.subLoca li.on { display: none !important; }
</style>


<!-- Sub Content -->
<div id="subContent">

<?php
$sql = "select * from st_event where ev_id = '$ev_id' and ev_use = '1' ";
$ev = sql_fetch($sql);
if (!$ev['ev_id'])
	alert('존재하지 않는 자료입니다.');

$today = date("Y-m-d");

$ev_sdate = $ev["ev_sdate"];
$ev_edate = $ev["ev_edate"];

$ev_asdate = $ev["ev_asdate"];
$ev_aedate = $ev["ev_aedate"];

$ev_join_max_cnt = $ev["ev_join_max_cnt"];


$ev_state = $ev["ev_state"];

$delcheck = false;
$state_str = "";
$day1 = dateDiff($ev_asdate, $today);
$day2 = dateDiff($ev_aedate, $today);

$apply_list_str = "";
//	echo $day1;
//	echo $day2;
if($day1 > 0){
	$state_str = "<li><a href='javascript:;' title='접수전' class='btn_bot gray'>접수전</a></li>";
}
if ($day2 < 0){
	$state_str = "<li><a href='javascript:;' title='접수마감' class='btn_bot gray'>접수마감</a></li>";
	$state_str = "";
}

if($day1 <= 0 && $day2 >= 0){
	$state_str = '<li><a href="javascript:reservation(\''.$ev['ev_id'].'\');" title="참가신청" class="btn_bot green">참가신청</a></li>';

	$apply_list_str = "<li><a href='./reservation_alist.php?ev_id={$ev['ev_id']}' title='신청자 명단' class='btn_bot darkBlue'>신청자 명단</a></li>";
	$apply_list_str = "";

	$sql = "select count(*) as cnt from st_event_apply where ev_id = '".$ev['ev_id']."' and mb_id = '".$member['mb_id']."' ";
	$row1 = sql_fetch($sql);

	$cnt1 = $row1['cnt'];

	if ($cnt1 > 0){
		//$state_str = '<a href="javascript:reservation(\''.$ev['ev_id'].'\');" class="btnS btnNormal">수정</a>';
		$state_str = '<li><a href="javascript:reservation(\''.$ev['ev_id'].'\');" title="참가신청" class="btn_bot blue">참가신청</a></li>';
		$delcheck = true;
	}
}

//신청자
$sql = " select count(ea_id) as cnt from st_event_apply ea where ea.ev_id = '".$ev['ev_id']."' ";
$row1 = sql_fetch($sql);
$apply_count = $row1['cnt'];

if ((int)$ev_join_max_cnt > 0){
	if ((int)$ev_join_max_cnt <= $apply_count){
		$state_str = "<li><a href='javascript:;' title='접수마감' class='btn_bot gray'>접수마감</a></li>";
		$state_str = "";
		$apply_list_str = "";
	}
}

if (trim($ev_state) != ""){
	$state_str = trim($ev_state); //교육종료
}

if($state_str == "교육종료"){
	$state_str = "<li><a href='javascript:;' title='교육종료' class='btn_bot gray'>교육종료</a></li>";
}
?>
	<div id="subTitle">
		<?php echo $ev['ev_subject'] ?><!-- <span class="vis_dep02"></span> -->
	</div>

	<div id="pageCont" class="event cert cert2">
        <div class="s-inner">

<table class="tb-style5 green">
<col width="15%">
<col width="35%">
<col width="15%">
<col width="35%">
<tbody>
<tr>
<th>교육 담당자</th>
<td><?php echo $ev['ev_manager_name']; ?></td>
<th>담당자 연락처</th>
<td><?php echo $ev['ev_manager_tel']; ?></td>
</tr>
<tr>
<th>교육일시</th>
<td><?php echo $ev['ev_sdate']; ?>
<!-- ~ <?php echo $ev['ev_edate']; ?>-->
 </td>
<th>장소</th>
<td><?php echo $ev['ev_place']; ?></td>
</tr>
<tr>
<th>신청기간</th>
<td><?php echo $ev['ev_asdate']; ?> ~ <?php echo $ev['ev_aedate']; ?></td>
<th>모집인원</th>
<td><?php echo $ev['ev_join_max_cnt']; ?></td>
</tr>
<tr>
<th>대상</th>
<td colspan="3"><?php echo $ev['ev_target']; ?></td>
</tr>
<tr>
<th>세부일정</th>
<td colspan="3"><?php echo $ev['ev_content']; ?></td>
</tr>
<?php
$file = get_file2($ev['ev_id']);

$j = 0;
$cnt=0;
for ($i=0; $i<count($file); $i++) {
	if (isset($file[$i]['source']) && $file[$i]['source'] && !$file[$i]['view']) {
		$cnt++;
?>
			<tr>
				<th>첨부파일 <?php echo $cnt; ?></th>
				<td colspan="3"><a href="<?php echo $file[$i]['href']; ?>"><?php echo $file[$i]['source']; ?></a></td>
			</tr>
<?php
	}
}
?>
<!-- <th>참가비</th>
<td colspan="3"><?php
if ($ev['ev_amount'] == 0){
echo "참가비 무료";
}else{
echo number_format($ev['ev_amount'])."원";
}
?><?php
if ($ev['ev_amount2'] != "" && $ev['ev_amount2'] != "0"){
echo " (비회원 : ".number_format($ev['ev_amount2'])."원)";
}
?>
<?php
if ($ev['ev_amount3'] != "" && $ev['ev_amount3'] != "0"){
echo " (당일회원 접수비 : ".number_format($ev['ev_amount3'])."원)";
}
?>
</td>
</tr>
<tr>
<th>입금계좌</th>
<td><?php echo $ev['ev_bank_account']; ?></td>
<th>예금주</th>
<td><?php echo $ev['ev_account_holder']; ?></td>
</tr>
<tr>
<th>납부마감</th>
<td colspan="3"><?php echo $ev['ev_closing_date']; ?></td>
</tr> -->
</tbody>
</table>

<!-- <div class="mt20">
	<?php echo $ev['ev_content']; ?>
</div> -->

<div class="btn_box mb60">
	<ul>
		<?php echo $state_str; ?>
		<?php //php echo $apply_list_str; ?>
		<li>
			<a href="./reservation_list.php" title="목록 바로가기" class="btn_bot gray">목록</a>
		</li>
	</ul>
</div>

		</div>
	</div>
</div>

<form id="fpost" name="fpost" action="./reservation_form.php" method="post">
<input type="hidden" id="ev_id" name="ev_id" value="" />
</form>

<script>
function reservation(c)
{
	$("#ev_id").val(c);
	$('#fpost')[0].submit();
}
</script>

<?php include "../inc/bottom.php"; ?>
