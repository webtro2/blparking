<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH.'/head.sub.boa.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');


$s_num = "";
$p_num = "";

if($bo_table == "news1"){
	$s_num = "3";
	$p_num = "1";
}elseif($bo_table == "news2"){
	$s_num = "3";
	$p_num = "2";
}elseif($bo_table == "news3"){
	$s_num = "3";
	$p_num = "3";
}elseif($bo_table == "news4"){
	$s_num = "3";
	$p_num = "4";
}
?>

<?php include __DIR__ . "/../inc/head.php"; ?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>

<!-- visual -->
<?php include __DIR__ . "/../inc/s_visual_board.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">


