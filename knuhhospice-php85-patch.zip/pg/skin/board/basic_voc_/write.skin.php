<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$board_skin_url.'/style.css">', 0);
?>

<section id="bo_w">
    <h2 class="sound_only"><?php echo $g5['title'] ?></h2>
	<table width="<?=$width?>" border="0" align="center" cellpadding="1" cellspacing="0">
			<tr>
			  <td  colspan=2 align="center" valign="top">
				<h6 class="tarea_h6">개인정보취급방침</h6>
				<textarea name="textarea" class="input01" style="width:100%; height:200px;">
개인정보란 생존하는 개인에 관한 정보로서 당해 정보에 포함되어 있는 성명 등의 사항에 의하여 당해 개인을 식별할 수 있는 정보(당해 정보만으로는 특정 개인을 식별할 수 없더라도 다른 정보와 용이하게 결합하여 식별할 수 있는 것을 포함합니다)를 말합니다. 서울플란트치과(이하 '병원') 고객의 개인정보보호를 매우 중요시하며, 『정보통신망 이용촉진 및 정보보호 등에 관한 법률』 상의 개인정보보호 규정 및 행정안전부가 제정한 『개인정보 보호지침』을 준수하고 있습니다.

개인정보취급방침의 순서는 다음과 같습니다.

1. 개인정보의 수집 범위
2. 개인정보 수집에 대한 동의
3. 개인정보의 수집목적 및 이용목적
4. 쿠키(cookie)에 의한 개인정보 수집 및 거부
5. 목적 외 사용 및 제 3자에 대한 제공 및 공유
6. 개인정보의 열람, 정정
7. 개인정보 수집, 이용, 제공에 대한 동의철회
8. 개인정보의 보유기간 및 이용기간
9. 링크사이트
10. 개인정보의 위탁처리
11. 이용자의 권리와 의무
12. 의견수렴 및 불만처리
13. 개인정보관리 책임자 및 담당자
14. 아동의 개인정보 보호
15. 광고성 정보 전송
16. 고지의 의무


1. 개인정보의 수집 범위
병원는 다양하고 편리한 인터넷 서비스를 제공하기 위하여 아래와 같은 목적으로 개인정보를 수집 및 이용하고 있습니다. 
병원가 제공하는 서비스 이용과정에서 회원 본인이 자발적으로 공개한 개인정보 및 게시물과 관련한 권리와 책임은 작성자 본인에게 있습니다. 자발적으로 공개된 정보는 보호받기 어려우며 타인에 의해 무단으로 수집되거나 처리될 수 있으며, 이로 인해 발생한 손실이나 문제는 전적으로 본인에게 있음을 유념하시기 바랍니다. 서비스 이용과정에서 개인에 관한 정보는 공개되지 않도록 심혈을 기울여 주시기 바랍니다. 병원는 다음 목적 이외로는 개인정보를 이용하지 않으며, 병원에서 제공하는 서비스의 목적이 변경되는 경우 별도의 동의를 받는 등 필요한 조치를 합니다.

＊ 회원가입, 문의 등의 서비스 이요시 수집되는 정보
- 필수항목 : 이름, 이메일주소 등
- 선택항목 : 이름, 이메일주소 등
2. 개인정보 수집에 대한 동의
고객께서 병원의 개인정보취급방침 또는 이용약관의 내용에 대해 『동의 』버튼 또는 『동의하지 않습니다.』 버튼을 클릭하는 절차를 마련하여, 『동의』버튼을 클릭하는 경우에만 개인정보 수집에 대해 동의한 것으로 봅니다.

3. 개인정보 수집목적 및 이용목적
고객님께 만족스러운 서비스를 제공하기 위해 다음과 같은 목적을 위하여 개인 정보를 수집하고 있습니다.

＊ 성명 : 고객문의(QnA) 의한 절차에 의해 필요
＊ E-mail 주소 등 : 이벤트 정보 등 안내 혹은 상품 접수/반품 등 각종 고지 사항 송부를 위한 정보
단, 이용자의 기본적 인권 침해의 우려가 있는 민감한 개인정보(인종 및 민족, 사상 및 신조, 출신지 및 본적지, 정치적 성향 및 범죄기록, 건강상태 및 성생활 등)는 수집하지 않습니다.
4. 쿠키(cookie)에 의한 개인정보 수집 및 거부
병원의 일부 서비스를 위해서 고객에 대한 정보를 저장하고 수시로 불러오는 쿠키(cookie)를 사용합니다. 쿠키는 웹사이트 서버가 귀하의 컴퓨터 브라우저에게 보내는 소량의 정보입니다. 고객은 웹사이트에 접속한 후 온라인 예약서비스를 이용하기 위해서는 쿠키를 허용하여야 합니다. 귀하는 쿠키에 대하여 선택권을 가지며 사용여부를 선택할 수 있습니다. 모든 쿠키를 허용할 수도 있고, 쿠키가 저장될 때마다 확인을 거치거나, 모든 쿠키의 저장을 거부할 수도 있습니다. 다만, 쿠키의 저장을 거부할 경우에는 일부 서비스를 이용하는데 있어 지장이 있을 수 있습니다. 쿠키는 귀하의 컴퓨터는 식별하지만 귀하의 개인적으로 식별하지는 않으며, 컴퓨터 브라우저의 종료 시 만료 됩니다.

＊ 설정방법 예(인터넷 익스플로어의 경우) : 웹 브라우저 상단의 도구 > 인터넷 옵션 > 개인정보

5. 목적 외 사용 및 제 3자에 대한 제공 및 공유
고객의 개인정보를 『개인정보의 수집목적 및 이용목적』에서 고지한 범위내에서 사용하며, 동 범위를 초과하여 이용하거나 타인 또는 타기업/기관에 제공하지 않습니다. 특히 다음의 경우는 주의를 기울여 개인정보를 이용 및 제공할 것입니다.

＊ 제휴관계 : 보다 나은 서비스 제공을 위하여 고객의 개인정보를 제휴사에게 제공하거나 공유 할 수 있습니다. 단, 사전에 제휴사명, 제휴목적, 제공 서비스, 개인정보의 공유 범위, 이용목적 및 제휴기간 등에 대해 상세하게 고지할 것이며, 전자우편 및 서면을 통하여 동의를 구할 것입니다.
＊ 위탁처리 : 원활한 업무 처리를 위해 이용자의 개인정보를 위탁 처리할 경우 반드시 사전에 위탁처리 업체명과 위탁처리 되는 개인정보의 범위, 위탁 목적, 위탁 처리 과정, 위탁 기간에 대해 상세하게 고지합니다.
<고지 및 동의 방법>
온라인 홈페이지를 통해 최소 10일 이전부터 고지함과 동시에 이메일 등을 이용하여 1회 이상 개별적으로 고지합니다.
<예외 사항>
＊ 관계법령에 의하여 수사상의 목적으로 관계기관으로부터의 요구가 있을 경우
＊ 통계작성 ㆍ학술연구나 시장조사를 위하여 특정 개인을 식별할 수 없는 형태로 광고주ㆍ 협력사나 연구단체 등에 제공하는 경우
＊ 기타 관계법령에서 정한 절차에 따른 요청이 있는 경우
그러나 예외 사항에서도 관계법령에 의하거나 수사기관의 요청에 의해 정보를 제공한 경우에는 이를 당사자에게 고지하는 것을 원칙으로 운영하고 있습니다. 법률상의 근거에 의해 부득이하게 고지를 못할 수도 있습니다. 본래의 수집목적 및 이용목적에 반하여 무분별하게 정보가 제공되지 않도록 최대한 노력하겠습니다.
6. 개인정보의 열람, 정정
고객께서는 언제든지 등록되어 있는 고객의 개인정보를 열람하거나 정정 하실 수 있습니다. 개인정보관리책임자 및 담당자에게 서면, 전화 또는 E-mail로 연락하시면 업무절차에 따라 정해진 최소 시간 내에 조치하겠습니다.
고객이 개인정보의 오류에 대한 정정을 요청한 경우, 정정을 완료하기 전까지 당해 개인 정보를 이용 또는 제공하지 않습니다.
잘못된 개인정보를 제3자에게 이미 제공한 경우에는, 정정 처리결과를 제3자에게 지체없이 통지하여 정정하도록 조치하겠습니다.
7. 개인정보 수집, 이용, 제공에 대한 동의철회
온라인상 예약을 통해 개인정보의 수집, 이용, 제공에 대해 고객께서 동의하신 내용을 고객께서는언제든지 철회하실 수 있습니다. 개인정보관리책임자 및 담당자에게 서면, 전화, E-mail등으로 연락하시면 즉시 개인정보의 삭제 등 필요한 조치를 하겠습니다. 동의철회를 하고 개인정보를 파기하는 조치를 취한 경우에는 그 사실을 고객에게 지체 없이 통지하도록 하겠습니다.

8. 개인정보의 보유기간 및 이용기간
고객의 개인정보는 다음과 같이 개인정보 수집목적 또는 제공 받은 목적이 달성되면 파기됩니다.
단, 상법 등 법령의 규정에 의하여 보존할 필요성이 있는 경우에는 예외로 합니다. 회원 가입 정보의 경우 회원가입을 탈퇴하거나 회원에서 제명된 경우 등 일정한 사전에 보유목적, 기간 및 보유하는 개인정보 항목을 명시하여 동의를 구합니다.
＊ 소송이나 분쟁에 있어 근거자료로 보존할 필요성이 있는 기록 : 5년
＊ 소비자의 불만 또는 분쟁처리에 관한 기록 : 3년
고객의 동의를 받아 보유하고 있는 거래정보 등에 대해 고객이 열람을 요구하는 경우 병원는 지체 없이 그 열람 확인이 가능하도록 조치합니다.
9. 링크사이트
고객께 다른 병원의 웹사이트 또는 자료에 대한 링크를 제공할 수 있습니다. 이 경우 병원의 외부사이트 및 자료에 대한 아무런 통제권이 없으므로 그로부터 제공 받는 서비스나 자료의 유용성에 대해 책임질 수 없습니다. 병원가 포함하고 있는 링크를 클릭(click)하여 타 사이트(site)의 페이지로 옮겨갈 경우 해당 사이트의 개인정보취급방침은 병원와 무관하므로 새로 방문한 사이트의 개인정보취급방침을 검토해 보시기 바랍니다.

10. 개인정보의 위탁처리
현재 회원의 개인정보를 병원가 자체적으로 처리하고 있습니다. 그러나 병원의 서비스 향상을 위해서 고객의 개인정보를 외부에 수집/취급/관리 등을 위탁하여 처리할 수 있습니다. 개인정보의 처리를 위탁하는 경우에는 위탁기간 및 그 사실을 홈페이지를 통해 미리 고객께 고지하겠습니다. 개인정보의 처리를 위탁하는 경우에는 위탁계약 등을 통하여 서비스제공자의 개인정보보호 관련 지시엄수, 개인정보에 관한 비밀유지, 제3자 제공의 금지 및 사고시의 책임부담, 위탁기간, 처리 종료후의 개인정보의 반환 또는 파기 등을 명확히 규정하고 당해 계약내용을 서면 또는 전자적으로 보관하겠습니다.

11. 이용자의 권리와 의무
고객의 개인정보를 최신의 상태로 정확하게 입력하여 불의의 사고를 예방해 주시기 바랍니다. 고객이 입력한 부정확한 정보로 인해 발생하는 사고의 책임은 고객께 있으며, 타인 정보의 도용 등 허위정보를 입력할 경우 회원자격이 상실될 수 있으며 모든 법적인 책임은 도용 또는 허위정보를 입력한 자의 책임으로 됩니다.
고객은 개인정보를 보호 받을 권리와 함께 스스로를 보호하고 타인의 정보를 침해하지 않을 의무도 가지고 있습니다. 비밀번호를 포함한 고객의 개인정보가 유출되지 않도록 조심하시고 게시물을 포함한 타인의 개인정보를 훼손하지 않도록 유의해 주십시오. 만약 이 같은 책임을 다하지 못하고 타인의 정보 및 존엄성을 훼손할 시에는 『정보통신망이용촉진 및 정보보호 등에 관한 법률』에 의해 처벌 받을 수 있습니다.

12. 의견수렴 및 불만처리
고객의 의견을 소중하게 생각하며, 고객은 의문사항에 대해 언제나 성실한 답변을 받을 권리가 있습니다. 당사는 고객과의 원활한 의사소통을 위해 고객상담 전화를 설치해 놓고 있습니다.

[고객상담처리센터]
- 직 책 :
- 전자우편 :
- 전화번호 :
- 주 소 : 
기타 개인정보에 관한 상담이 필요한 경우에는 개인정보침해신고센터, 대검찰청 인터넷 범죄수사센터, 경찰청 사이버범죄수사대 등으로 문의하실 수 있습니다.
* 개인정보침해신고센터
- 전화번호 : 1336
- URL : http://www.cyberprivacy.or.kr
* 대검찰청 인터넷범죄수사센터
- 전화 : 02-3480-3600
- URL : http://icic.sppo.go.kr
* 경찰청 사이버범죄수사대
- URL : http://www.police.go.kr
13. 개인정보 보호관리 책임자 및 담당자
병원는 고객이 홈페이지를 안전하게 이용할 수 있도록 최선을 다하고 있습니다. 개인정보를 보호하는데 있어 고객께 고지한 사항들에 반하는 사고가 발생할 시에 개인정보관리책임자가 모든 책임을 집니다. 그러나 기술적인 보완조치를 했음에도 불구하고, 해킹 등 기본적인 네트워크상의 위험성에 의해 발생하는 예기치 못한 사고로 인한 정보의 훼손 및 방문자가 작성한 게시물에 의한 각종 분쟁에 관해서는 책임이 없습니다. 고객의 개인정보를 취급하는 책임자 및 담당자는 다음과 같으며 개인정보 관련 문의사항에 신속하고 성실하게 답변해리고 있습니다.

[개인정보보호책임자]
- 직 책 :
- 전자우편 :
- 전화번호 :
- 주 소 :
[개인정보관리담당자]
- 직 책 :
- 전자우편 :
- 전화번호 :
- 주 소 :
14. 아동의 개인정보 보호
병원는 만 14세 미만 아동의 개인정보를 보호하는 것을 중요하게 여기고 보호하고자 노력하고 있습니다. 이에 만14세 미만의 미성년자들도 회원으로 가입 및 상품 구매 등을 할 수 없게 하고 있습니다. 즉 만14세 미만의 미성년자들은 병원에서 회원자격의 서비스를 받을 수 없습니다.

15. 광고성 정보 전송
① 고객의 명시적인 수신거부의사에 반하여 영리목적의 광고성 정보를 전송하지 않습니다.
② 고객이 뉴스레터 등 전자우편 전송에 대한 동의를 한 경우 전자우편의 제목란 및 본문란에 다음 사항과 같이 고객이 쉽게 알아 볼 수 있도록 조치합니다.
＊ 전자우편의 제목란 : (광고)라는 문구를 제목란에 표시하지 않을 수 있으며 전자우편 본문란의 주요 내용을 표시합니다.
＊ 전자우편의 본문란 : 고객은 수신 거부의 의사표시를 할 수 있는 전송자의 명칭, 전자우편주소, 전화번호를 명시합니다. 고객이 수신 거부의 의사를 쉽게 표시할 수 있는 방법을 한글 및 영문으로 각각 명시합니다.
③ 상품정보 안내 등 온라인 마케팅을 위해 광고성 정보를 전자우편 등으로 전송하는 경우 전자우편의 제목란 및 본문란에 다음 사항과 같이 고객이 쉽게 알아 볼 수 있도록 조치합니다.
＊ 전자우편의 제목란 : (광고)라는 문구를 제목란의 처음에 빈칸 없이 한글로 표시하고 이어서 전자우편 본문란의 주요 내용을 표시합니다.
＊ 전자우편의 본문란 : 고객이 수신거부의 의사표시를 할 수 있는 전송자의 명칭, 전자우편 주소, 전화번호를 명시합니다. 고객이 수신거부의 의사를 쉽게 표시할 수 있는 방법을 한글 및 영문으로 각각 명시합니다.
＊ 팩스/휴대폰 문자전송 등 전자우편 이외의 문자전송을 통해 영리목적의 광고성 정보를 전송하는 경우에는 전송내용 처음에 (광고) 문구를 표기하고 전송내용 중에 전송자의 연락처를 명시하도록 조치합니다.
16. 고지의 의무
현 개인정보보호정책은 년 월 일에 제정되었으며, 정부의 정책 또는 보안기술의 변경에 따라 내용의 추가/삭제 및 수정이 있을 경우에는 개정 7일 전부터 홈페이지를 통해 고지할 것입니다.
- 개인정보보호정책 시행일자: 
이상의 병원 교육협회 홈페이지 개인정보취급방침은 년 월 일부터 적용됩니다.
				</textarea>
			</td>
			</tr>
			<tr>
				<td colspan="2"  class="chk_agree" height="30" align="left" valign="top" >
					<INPUT type=checkbox value=1 name=agree id=agree> <label for="agree"> 위 이용약관에 동의 합니다.</label>
				</td>
			</tr>
</table>	
    <!-- 게시물 작성/수정 시작 { -->
    <form name="fwrite" id="fwrite" action="<?php echo $action_url ?>" onsubmit="return fwrite_submit(this);" method="post" enctype="multipart/form-data" autocomplete="off" style="width:<?php echo $width; ?>">
    <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
    <input type="hidden" name="w" value="<?php echo $w ?>">
    <input type="hidden" name="bo_table" value="<?php echo $bo_table ?>">
    <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
    <input type="hidden" name="sca" value="<?php echo $sca ?>">
    <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
    <input type="hidden" name="stx" value="<?php echo $stx ?>">
    <input type="hidden" name="spt" value="<?php echo $spt ?>">
    <input type="hidden" name="sst" value="<?php echo $sst ?>">
    <input type="hidden" name="sod" value="<?php echo $sod ?>">
    <input type="hidden" name="page" value="<?php echo $page ?>">
    <?php
    $option = '';
    $option_hidden = '';
    if ($is_notice || $is_html || $is_secret || $is_mail) {
        $option = '';
        if ($is_notice) {
            $option .= "\n".'<input type="checkbox" id="notice" name="notice" value="1" '.$notice_checked.'>'."\n".'<label for="notice">공지</label>';
        }

        if ($is_html) {
            if ($is_dhtml_editor) {
                $option_hidden .= '<input type="hidden" value="html1" name="html">';
            } else {
                $option .= "\n".'<input type="checkbox" id="html" name="html" onclick="html_auto_br(this);" value="'.$html_value.'" '.$html_checked.'>'."\n".'<label for="html">HTML</label>';
            }
        }

        if ($is_secret) {
            if ($is_admin || $is_secret==1) {
                $option .= "\n".'<input type="checkbox" id="secret" name="secret" value="secret" '.$secret_checked.'>'."\n".'<label for="secret">비밀글</label>';
            } else {
                $option_hidden .= '<input type="hidden" name="secret" value="secret">';
            }
        }

        if ($is_mail) {
            $option .= "\n".'<input type="checkbox" id="mail" name="mail" value="mail" '.$recv_email_checked.'>'."\n".'<label for="mail">답변메일받기</label>';
        }
    }

    echo $option_hidden;
    ?>

    <?php if ($is_category) { ?>
    <div class="bo_w_select write_div">
        <label for="ca_name"  class="sound_only">분류<strong>필수</strong></label>
        <select name="ca_name" id="ca_name" required>
            <option value="">분류를 선택하세요</option>
            <?php echo $category_option ?>
        </select>
    </div>
    <?php } ?>
	<?php if ($option) { ?>
		<!-- <div class="write_div">
			<span class="sound_only">옵션</span>
			<?php echo $option ?>
		</div> -->
		<?php } ?>	

	<!--<div class="bo_w_info write_div2">
		<span>상담유형</span>
		<div style="margin-top:11.5px; font-size:0.9em">
		 &nbsp;&nbsp;<input type="radio" name="wr_3" required value="칭찬" id="wr_3" class="frm_input2" <?php if($wr_3 == "칭찬") echo "checked";?>> 칭찬  &nbsp;&nbsp;
		 &nbsp;&nbsp;<input type="radio" name="wr_3" value="불만" id="wr_3" class="frm_input2" <?php if($wr_3 == "불만") echo "checked";?>> 불만  &nbsp;&nbsp;
		 &nbsp;&nbsp;<input type="radio" name="wr_3" value="문의" id="wr_3" class="frm_input2" <?php if($wr_3 == "문의") echo "checked";?>> 문의  &nbsp;&nbsp;
		 &nbsp;&nbsp;<input type="radio" name="wr_3" value="제안" id="wr_3" class="frm_input2" <?php if($wr_3 == "제안") echo "checked";?>> 제안 &nbsp;&nbsp;
		 </div>
	</div>-->

	<?php if ($is_name) { ?>

    <div class="bo_w_info write_div3 half">
        <span>이름</span>
        <input type="text" name="wr_name" value="<?php echo $name ?>" id="wr_name" required class="frm_input required" placeholder="이름">
	</div>
	    <?php } ?>
		<?php if ($is_password) { ?>
	<!-- <div class="bo_w_info write_div3 half">
        <span>비밀번호</span>
        <input type="password" name="wr_password" id="wr_password" <?php echo $password_required ?> class="frm_input <?php echo $password_required ?>" placeholder="비밀번호">
	</div> -->
	    <?php } ?>
	<div class="bo_w_info write_div3 half">
            <span>연락처</span>
            <input type="text" name="wr_1" value="<?=$write["wr_1"]?>" id="wr_1" class="frm_input required" required placeholder="연락처">
    </div>
		<?php if ($is_email) { ?>

	<div class="bo_w_info write_div3 half">
            <span>이메일</span>
            <input type="text" name="wr_email" value="<?php echo $email ?>" id="wr_email" class="frm_input email required" required placeholder="이메일">
    </div>
	    <?php } ?>

	<!--<div class="bo_w_info write_div2 half">
		<span>핸드폰</span><input type="text" name="wr_2" value="<?php echo $wr_2 ?>" id="wr_2" class="frm_input required" required placeholder="핸드폰">
	</div>

    <?php if ($is_homepage) { ?>
    <div class="write_div">
        <label for="wr_homepage" class="sound_only">홈페이지</label>
        <input type="text" name="wr_homepage" value="<?php echo $homepage ?>" id="wr_homepage" class="frm_input full_input" size="50" placeholder="홈페이지">
    </div>
    <?php } ?>-->

    
	<!--<div class="bo_w_info write_div2">
        <span>방문매장</span>
        <input type="text" name="wr_1" value="<?php echo $wr_1 ?>" id="wr_1" class="frm_input required" required placeholder="방문매장">
	</div>-->
	
	<div class="bo_w_info write_div3 half">
            <span>건물유형</span>
			<select name='wr_2' id='wr_2' class="frm_input required" itemname='건물유형' style="width: 150px">
			   <option value='' >::: 선택 :::</option>
			   <option value='주거' <?php  if($write['wr_2'] == "주거") echo "selected"; ?>>주거</option>
			   <option value='상업' <?php  if($write['wr_2'] == "상업") echo "selected"; ?>>상업</option>
			   <option value='의료' <?php  if($write['wr_2'] == "의료") echo "selected"; ?>>의료</option>
			   <option value='교육' <?php  if($write['wr_2'] == "교육") echo "selected"; ?>>교육</option>
			   <option value='사무' <?php  if($write['wr_2'] == "사무") echo "selected"; ?>>사무</option>
			   <option value='etc' <?php  if($write['wr_2'] == "etc") echo "selected"; ?>>기타</option>
			</select>
            <input type="text" name="wr_11" value="<?=$write["wr_11"]?>" id="wr_11" class="frm_input full_input" placeholder="기타를 입력해주세요" style="width: 300px">

	 </div>

	 <div class="bo_w_tit write_div bo_w_info write_div2">
            <span>공사범위</span>
			<select name='wr_3' id='wr_3' class="frm_input required" itemname='공사범위' style="width: 150px">
			   <option value='' >::: 선택 :::</option>
			   <option value='전체시공' <?php  if($write['wr_3'] == "전체시공") echo "selected"; ?>>전체시공</option>
			   <option value='부분시공' <?php  if($write['wr_3'] == "부분시공") echo "selected"; ?>>부분시공</option>
			   <option value='리모텔링' <?php  if($write['wr_3'] == "리모텔링") echo "selected"; ?>>리모텔링</option>
			   <option value='etc' <?php  if($write['wr_3'] == "etc") echo "selected"; ?>>기타</option>
			</select>
            <input type="text" name="wr_12" value="<?=$write["wr_12"]?>" id="wr_12" class="frm_input full_input" placeholder="기타를 입력해주세요" style="width: 300px">
	 </div>
	
	 <div class="bo_w_tit write_div bo_w_info write_div2">
            <span>현장주소</span>
            <input type="text" name="wr_4" value="<?=$write["wr_4"]?>" id="wr_4" required class="frm_input full_input required" size="50" maxlength="255" placeholder="현장주소">
	 </div>

	 <div class="bo_w_tit write_div bo_w_info write_div2">
            <span>현장도면</span>
			<select name='wr_5' id='wr_5' class="frm_input required" itemname='공사범위' style="width: 150px">
			   <option value='' >::: 선택 :::</option>
			   <option value='유' <?php  if($write['wr_5'] == "유") echo "selected"; ?>>유</option>
			   <option value='무' <?php  if($write['wr_5'] == "무") echo "selected"; ?>>무</option>
			   <option value='현장실측' <?php  if($write['wr_5'] == "현장실측") echo "selected"; ?>>현장실측</option>
			</select>

			<div class="clear"></div>

	 <div class="bo_w_tit write_div bo_w_info write_div2">
				 <span class="wr_t">도면첨부</span>
				 <div class="wr_c">
						<?php for ($i=0; $is_file && $i<$file_count; $i++) { ?>
						<div class="bo_w_flie write_div">
						  <div class="file_wr write_div">
							<label for="bf_file_<?php echo $i+1 ?>" class="lb_icon"><i class="fa fa-download" aria-hidden="true"></i><span class="sound_only"> 파일 #<?php echo $i+1 ?></span></label>
							<input type="file" name="bf_file[]" id="bf_file_<?php echo $i+1 ?>" title="파일첨부 <?php echo $i+1 ?> : 용량 <?php echo $upload_max_filesize ?> 이하만 업로드 가능" class="frm_file ">
						  </div>
						  <?php if ($is_file_content) { ?>
						  <input type="text" name="bf_content[]" value="<?php echo ($w == 'u') ? $file[$i]['bf_content'] : ''; ?>" title="파일 설명을 입력해주세요." class="full_input frm_input" size="50" placeholder="파일 설명을 입력해주세요.">
						  <?php } ?>

						  <?php if($w == 'u' && $file[$i]['file']) { ?>
						  <span class="file_del">
							<input type="checkbox" id="bf_file_del<?php echo $i ?>" name="bf_file_del[<?php echo $i;  ?>]" value="1"> <label for="bf_file_del<?php echo $i ?>"><?php echo $file[$i]['source'].'('.$file[$i]['size'].')';  ?> 파일 삭제</label>
						  </span>
						  <?php } ?>
						  
						</div>
						<?php } ?>
				   </div>
			</div>
	 
	 </div>

	<div class="bo_w_info write_div3 half">
            <span>면적</span>
            <input type="text" name="wr_6" value="<?=$write["wr_6"]?>" id="wr_6" class="frm_input required" required placeholder="면적">
	</div>

	<div class="bo_w_info write_div3 half">
            <span>공사예정일</span>
            <input type="text" name="wr_7" value="<?=$write["wr_7"]?>" id="wr_7" class="frm_input required" required placeholder="공사예정일">
	</div>

	<div class="bo_w_info write_div3 half">
            <span>입주예정일</span>
            <input type="text" name="wr_8" value="<?=$write["wr_8"]?>" id="wr_8" class="frm_input required" required placeholder="입주예정일">
	 </div>
	
	<div class="clear"></div>

	<div class="bo_w_info write_div3 half">
            <span>공사예산</span>
            <input type="text" name="wr_9" value="<?=$write["wr_9"]?>" id="wr_9" class="frm_input required" required placeholder="ex)5,000만원~7,000만원">
	 </div>
	<div class="bo_w_info write_div3 half">
            <span>공사수준</span>
			<select name='wr_10' id='wr_10' class="frm_input required" itemname='공사범위' style="width: 150px">
			   <option value='' >::: 선택 :::</option>
			   <option value='고급' <?php  if($write['wr_10'] == "고급") echo "selected"; ?>>고급</option>
			   <option value='중급' <?php  if($write['wr_10'] == "중급") echo "selected"; ?>>중급</option>
			   <option value='실용' <?php  if($write['wr_10'] == "실용") echo "selected"; ?>>실용</option>
			</select>	
	 </div>

	 <div class="bo_w_tit write_div bo_w_info write_div2">
		<span>제목</span>
        
            <input type="text" name="wr_subject" value="<?php echo $subject ?>" id="wr_subject" required class="frm_input full_input required" size="50" maxlength="255" placeholder="제목">
            <?php if ($is_member) { // 임시 저장된 글 기능 ?>
            <script src="<?php echo G5_JS_URL; ?>/autosave.js"></script>
            <?php if($editor_content_js) echo $editor_content_js; ?>
            <button type="button" id="btn_autosave" class="btn_frmline">임시 저장된 글 (<span id="autosave_count"><?php echo $autosave_count; ?></span>)</button>
            <div id="autosave_pop">
                <strong>임시 저장된 글 목록</strong>
                <ul></ul>
                <div><button type="button" class="autosave_close">닫기</button></div>
            </div>
            <?php } ?>
       
        
    </div>

    <div class="write_div  bo_w_info write_div2">
       <!--  <label for="wr_content" class="sound_only">내용<strong>필수</strong></label> -->
	 <span>요청사항</span>
        <div style="" class="wr_content <?php echo $is_dhtml_editor ? $config['cf_editor'] : ''; ?>">
            <?php if($write_min || $write_max) { ?>
            <!-- 최소/최대 글자 수 사용 시 -->
            <p id="char_count_desc">이 게시판은 최소 <strong><?php echo $write_min; ?></strong>글자 이상, 최대 <strong><?php echo $write_max; ?></strong>글자 이하까지 글을 쓰실 수 있습니다.</p>
            <?php } ?>
            <?php echo $editor_html; // 에디터 사용시는 에디터로, 아니면 textarea 로 노출 ?>
            <?php if($write_min || $write_max) { ?>
            <!-- 최소/최대 글자 수 사용 시 -->
            <div id="char_count_wrap"><span id="char_count"></span>글자</div>
            <?php } ?>
        </div>
        
    </div>






<div class="clear"></div>


    <div class="btn_confirm write_div">
        <a href="./board.php?bo_table=<?php echo $bo_table ?>" class="btn_cancel btn">취소</a>
        <input type="submit" value="작성완료" id="btn_submit" accesskey="s" class="btn_submit btn">
    </div>
    </form>

    <script>
    <?php if($write_min || $write_max) { ?>
    // 글자수 제한
    var char_min = parseInt(<?php echo $write_min; ?>); // 최소
    var char_max = parseInt(<?php echo $write_max; ?>); // 최대
    check_byte("wr_content", "char_count");

    $(function() {
        $("#wr_content").on("keyup", function() {
            check_byte("wr_content", "char_count");
        });
    });

    <?php } ?>
    function html_auto_br(obj)
    {
        if (obj.checked) {
            result = confirm("자동 줄바꿈을 하시겠습니까?\n\n자동 줄바꿈은 게시물 내용중 줄바뀐 곳을<br>태그로 변환하는 기능입니다.");
            if (result)
                obj.value = "html2";
            else
                obj.value = "html1";
        }
        else
            obj.value = "";
    }

    function fwrite_submit(f)
    {
        <?php echo $editor_js; // 에디터 사용시 자바스크립트에서 내용을 폼필드로 넣어주며 내용이 입력되었는지 검사함   ?>

        var subject = "";
        var content = "";
        $.ajax({
            url: g5_bbs_url+"/ajax.filter.php",
            type: "POST",
            data: {
                "subject": f.wr_subject.value,
                "content": f.wr_content.value
            },
            dataType: "json",
            async: false,
            cache: false,
            success: function(data, textStatus) {
                subject = data.subject;
                content = data.content;
            }
        });

        if (subject) {
            alert("제목에 금지단어('"+subject+"')가 포함되어있습니다");
            f.wr_subject.focus();
            return false;
        }

        if (content) {
            alert("내용에 금지단어('"+content+"')가 포함되어있습니다");
            if (typeof(ed_wr_content) != "undefined")
                ed_wr_content.returnFalse();
            else
                f.wr_content.focus();
            return false;
        }

        if (document.getElementById("char_count")) {
            if (char_min > 0 || char_max > 0) {
                var cnt = parseInt(check_byte("wr_content", "char_count"));
                if (char_min > 0 && char_min > cnt) {
                    alert("내용은 "+char_min+"글자 이상 쓰셔야 합니다.");
                    return false;
                }
                else if (char_max > 0 && char_max < cnt) {
                    alert("내용은 "+char_max+"글자 이하로 쓰셔야 합니다.");
                    return false;
                }
            }
        }
		if (!f.agree.checked) {
			alert("약관의 내용에 동의해야 신청 하실 수 있습니다.");
			f.agree.focus();
			return false;
		}		
        <?php echo $captcha_js; // 캡챠 사용시 자바스크립트에서 입력된 캡챠를 검사함  ?>

        document.getElementById("btn_submit").disabled = "disabled";

        return true;
    }

			$(function(){
				  //입력박스 숨어있다가
			$("#wr_11").hide();
			$("#wr_2").change(function() {
							//기타를 선택하면 등장
					if($("#wr_2").val() == "etc") {
						$("#wr_11").show();
					}  else {
						$("#wr_11").hide();
					}
				}) 
			});	
	
			$(function(){
				  //입력박스 숨어있다가
			$("#wr_12").hide();
			$("#wr_3").change(function() {
							//기타를 선택하면 등장
					if($("#wr_3").val() == "etc") {
						$("#wr_12").show();
					}  else {
						$("#wr_12").hide();
					}
				}) 
			});

	</script>

</section>
<!-- } 게시물 작성/수정 끝 -->