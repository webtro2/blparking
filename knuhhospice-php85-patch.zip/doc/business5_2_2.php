<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_2_img2_240115.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">김천의료원</h5>
		<p class="stxt2">경상북도 김천의료원은 1921년 개원 이래 100여년의 긴 역사를 가진 공공의료기관으로서 지역민의 건강을 위한 최상의 의료서비스를 제공하고 노인건강증진 및 의료취약계층을 위한 다양한 의료사업을 실시함으로 지역거점 병원으로서 역할에 최선을 다하고 있습니다. 호스피스 완화의료는 완치가 어려운 말기암 환자와 그 가족들의 아픔과 슬픔을 돌보는 진료영역으로 인간으로서 품위를 잃지 않고 남은 생을 의미 있게 정리할 수 있도록 도와주는 돌봄 프로그램으로 우리의료원 호스피스완화의료팀은 2018년 12월 17일 호스피스시범 사업을 시작으로 호스피스 병동을 운영하고 있습니다. 운영병상 10병상(2인실, 1인실, 임종실),  실내정원, 가족실, 상담실, 목욕실, 프로그램실, 자원봉사실 등을 운영하여 내 집처럼 편안한 환경을 제공하고 있으며환자와 가족들의 정서적 안정을 위한 전문적이고 다양한 삶의 질 향상 프로그램, 자원봉사자 지원 서비스, 영적 돌봄, 사회·경제적 지원서비스 제공하고 있습니다.
</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>054-429-8459</td>
			<th>팩스</th>
			<td>054-433-2031</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(39579) 경상북도 김천시 모암길 24 (모암동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.gcmc.or.kr" target="_blank" class="link">http://www.gcmc.or.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">10</td>
				<td>2실</td>
				<td>4실</td>
				<td>0실</td>
				<td>0실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
