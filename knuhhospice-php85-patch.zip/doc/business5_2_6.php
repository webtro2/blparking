<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_2_img6.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">구미강동병원</h5>
		<p class="stxt2">2023년 경북 서북부 지역의 입원형 호스피스를 시작한 구미강동병원은 총체적 돌봄(holistic care) 제공을 위한 접근성 제고 및 충분한 인프라를 구축한 기관으로 2024년 보건복지부 호스피스전문기관으로 지정되어 말기암 환자와 가족의 신체적, 심리·사회적, 영적인 모든 영역을 평가하고 계획하여, 통증 및 증상을 완화하고 편안하고 행복한 돌봄을 제공하고 섬김으로 남은 생애 동안 삶의 질을 향상하고, 마지막 여정이 아름답고 존엄할 수 있도록 진심을 다하고, 최선을 다해 맡은 사명을 이루고자 합니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>1811-8275</td>
			<th>팩스</th>
			<td>054-478-9886</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(39399) 구미시 인동20길 46(진평동 210-2)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.gumigd.com" target="_blank" class="link">http://www.gumigd.com</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">10 병상</td>
				<td>2실</td>
				<td>1실</td>
				<td>2실</td>
				<td>0실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>없음</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
