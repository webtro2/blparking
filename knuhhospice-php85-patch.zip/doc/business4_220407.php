<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="business4" class="cont-top">
			<!-- <h3>지원·연구사업</h3> -->
			<img src="/images/sub/business4_top.png" alt="" />
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">지자체와 협력을 통하여 지방보건의료계획 수립</h4>
			</div>
			<div class="cont">
				<ul class="dotList">
					<li><p>중앙호스피스센터로부터 제공받은 지역별 호스피스·완화의료 현황을 토대로 지자체와 긴밀히 협력하여 지방보건의료계획 수립</p></li>
					<li><p>호스피스·완화의료 이용률 및 자체충족률 향상 방안, 호스피스·완화의료 인식개선을 위한 홍보, 교육 계획 등</p></li>
				</ul>
			</div>
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">호스피스 정책 및 교육 등 위원회 자문 활동</h4>
			</div>
			<div class="cont">
				<p class="stxt1">국내 호스피스 제공체계 모델 구축을 위한 정책, 교육, 평가위원회 참여</p>
			</div>
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">호스피스 전문인력의 소진 예방과 업무 효율성 향상을 위한 소진예방 프로그램 개발 및 운영</h4>
			</div>
			<div class="cont">
				<p class="stxt1">해당 기관 및 권역 내 호스피스 전문기관 필수인력의 업무 동기를 고취하고 업무 활성화를 위한 프로그램 실시</p>
			</div>
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">권역 내 호스피스·완화의료 전문기관 대표자 정례회의</h4>
			</div>
			<div class="cont">
				<p class="stxt1">권역 내 호스피스·완화의료 전문기관 대표자들이 모여 호스피스·완화의료 관련 이슈, 호스피스·완화의료 서비스 질 향상을 위한 의견 수렴 등 다양한 주제를 가지고 소통하는 자리</p>
			</div>
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">권역 내 호스피스·완화의료 전문기관 정보 교류 네트워크 구축</h4>
			</div>
			<div class="cont">
			<p class="stxt1">각 기관 병상현황 공유, 기관별 소식, 권역호스피스센터 행사 알림 등 권역 내 호스피스·완화의료 전문기관 간의 소통 및 정보공유를 목적으로 정보교류방 운영</p>
			</div>
		</div>


	</div>

</div>




<?php include "../inc/bottom.php"; ?>
