<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img9.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 상급종합병원 ]</p>
		<h5 class="stit2 mt5">칠곡경북대학교병원</h5>
		<p class="stxt2">2010년 1월 보건복지부 “ 말기암환자 완화의료사업 지정기관”을 필두로, 2018년 연명의료법에 따른
			보건복지부 호스피스전문병원으로 재지정되었습니다. 다양한 요법과 이벤트를 진행하여 말기암환자와 가족의 심리적
			안정감과 정서적 지지를 하고 있으며 생애말기의 아름다운 동행을 함께 하고 있습니다. 입원형, 자문형, 가정형 3가지 모든
			유형의 호스피스 서비스를 제공하여 환자의 다양한 요구에 부응하며 (소아·청소년 호스피스·완화의료도 시행중) 권역호스피스센터 또한
			우리지역의 호스피스전문기관을 리더하고 있어 지역 내 5가지 형태의 모든 호스피스 사업을 하고 있는 유일한 기관이며
			매년 우리병원 자체에서 호스피스 기금을 1억씩 희사하고 있습니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-200-2539</td>
			<th>팩스</th>
			<td>053-200-2549</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(41404) 대구광역시 북구 호국로 807 칠곡경북대학교병원 (학정동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.knuch.kr/" target="_blank" class="link">http://www.knuch.kr/</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li><p>가정형</p></li>
					<li><p>자문형</p></li>
					<li><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">26</td>
				<td>2실</td>
				<td>-</td>
				<td>-</td>
				<td>6실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>2실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
