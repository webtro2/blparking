<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_2_img5_240115.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">포항의료원</h5>
		<p class="stxt2">경상북도 포항의료원은 지역주민의 보건향상을 위한 지역거점 공공의료기관으로서, 공공사업의 일환으로
			2012년 12월 호스피스병동을 개소하였습니다. 밝고 쾌적한 시설과 완화의료팀의 심리사회적 접근으로 말기암 환자 및
			가족들이 편안하게 생활할 수 있도록 돕고 있습니다. 본원에서는 진행하고 있는 프로그램으로는 원예치료, 미술치료,
			음악치료가 있으며, 영적돌봄, 이미용서비스, 발마사지, 차 및 다과서비스 등을 제공하고 있습니다. 특히 영정사진 뿐만 아니라
			영상편지(마음전하기, 유언남기기)를 촬영하여 그 제작물을 가족들에게 제공함으로써 가족 간 관계완화 및 화합을 도모하고
			있습니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>054-245-0271</td>
			<th>팩스</th>
			<td>054-245-0270</td>
		</tr>
		<tr>
			<th>주소</th>
			<!-- <td colspan="3">(37688) 경상북도 포항시 북구 용흥로 36 (용흥동)</td> -->
			<td colspan="3">(37688) 경상북도 포항시 북구 용흥로 36 경상북도포항의료원 (용흥동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.pmc.or.kr" target="_blank" class="link">http://www.pmc.or.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">25</td>
				<td>1실</td>
				<td>0실</td>
				<td>0실</td>
				<td>6실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
