<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img6.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">대구파티마병원</h5>
		<!-- <p class="stxt2">대구파티마병원은 성 베네딕도 수녀회가 가톨릭교회의 전통인 예수그리스도의 치유사도직을 수행하기
			위하여 설립되었으며, 특히 호스피스완화의료병동은 2005년부터 보건복지부에서 완화의료전문기관으로 지정되어 운영되고
			있습니다. 13개병상(1인실:1, 4인실: 3)의 호스피스 전용 병상에 기도실, 상담실, 임종실, 가족실 등 시설 및 주 1회
			자원봉사자들에 의해 병원에서 국수,떡국등 집밥을 제공하며, 여러가지 요법치료등 프로그램을 갖추어 의사, 간호사,
			사회복지사, 성직자, 자원봉사자 등의 여러분야의 전문가들이 함께 팀을 이루어 활동하여 환자와 그 가족들을 대상으로
			신체적, 정서적, 사회적, 영적으로 도우며, 지지와 격려를 제공하는 총체적인 돌봄을 하고 있습니다.</p> -->
            <p class="stxt2">대구파티마병원은 성 베네딕토 수녀회가 가톨릭 교회의 전통인 예수그리스도의 치유사도직을 수행하기 위해 설립되었으며, 2000년 3월부터 호스피스병동을 운영하여 2005년부터는 보건복지부 완화의료전문기관으로 지정되어 현재까지 운영되고 있습니다. 
 환자와 가족들을 대상으로 의사, 간호사, 사회복지사, 성직자, 영양사, 전문치료사, 자원봉사자 등이 팀을 이루어 통증을 포함한 신체적 심리적 사회적 영적 고통을 완화하여 삶의 질을 향상시키는 전인적이고 전문적인 의료서비스를 제공하고 있습니다. </p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-940-7515-6</td>
			<th>팩스</th>
			<td>053-940-7507</td>
		</tr>
		<tr>
			<th>주소</th>
			<!-- <td colspan="3">(41199) 대구광역시 동구 아양로 99 대구파티마병원 5층 (신암동)</td> -->
			<td colspan="3"> (41199) 대구광역시 동구 아양로99 대구파티마병원 (신암동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.fatima.or.kr" target="_blank" class="link">http://www.fatima.or.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">12</td>
				<td>1실</td>
				<td>0실</td>
				<td>1실</td>
				<td>2실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
