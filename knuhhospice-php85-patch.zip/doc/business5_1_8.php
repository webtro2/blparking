<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img8.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 상급종합병원 ]</p>
		<h5 class="stit2 mt5">영남대학교병원</h5>
		<!-- <p class="stxt2">1983년 5월 28일 7만여 평의 대지위에 친절, 봉사, 협동의 원훈을 바탕으로 진료를 시작, 인간의 건강과
			생명을 소중히 하고 고객만족으로 신뢰받는 영남 최고의 의료원으로서의 강한 책임 의식을 통해 21세기 국민보건 향상을 지향하는
			고객 중심 병원으로서의 발돋움하고 있습니다.</p> -->
		<p class="stxt2">영남대학교병원은 2022년 1월 보건복지부로부터 자문형 호스피스전문기관으로 지정받아 일반 병동과 외래에서 진료를 받는 말기 환자와 가족에게 호스피스완화의료 서비스를 제공하고 있습니다. 입원형 호스피스 병동은 운용하지 않고 있지만 자문형 호스피스팀이 매일 환자와 가족에게 방문하여 그들의 따뜻한 이웃이 되어주며 함께하고 있습니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-620-4673</td>
			<th>팩스</th>
			<td>053-620-3874</td>
		</tr>
		<tr>
			<th>주소</th>
			<!-- <td colspan="3">(705-802) 대구광역시 남구 현충로 170 본관 10층 1059호 호스피스실</td> -->
			<td colspan="3">(42415) 대구광역시 남구 현충로 170 영남대학교병원 (대명동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="https://yumc.ac.kr:8443/" target="_blank" class="link">https://yumc.ac.kr:8443/</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li class="off"><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">0</td>
				<td>0실</td>
				<td>0실</td>
				<td>0실</td>
				<td>0실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">0실</td>
				<td>1실</td>
				<td>0실</td>
				<td>무</td>
				<td>0실</td>
				<td>1실</td>
				<td>0실</td>
			</tr>
		</tbody>
	</table>
</div>
