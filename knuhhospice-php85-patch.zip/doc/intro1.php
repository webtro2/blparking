<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" >

		<div id="greeting" class="s-inner">

				<div class="img">
					<img src="/images/sub/intro1_220530.png" alt="" />
				</div>
				<div class="cont">
					<p class="typo">안녕하십니까 칠곡경북대학교병원 <br><span class="fw-M">권역호스피스센터장 김아솔</span>입니다.</p>
					<p class="stxt2">칠곡경북대학교병원 권역호스피스센터는 「호스피스·완화의료 및 임종과정에 있는 환자의 연명의료결정에 관한 법률」에 기반을 둔 국가 호스피스 관련 정책을 선도하기 위해 2017년 12월 보건복지부로부터 지정받아 운영되고 있습니다.</p>
					<p class="stxt2">호스피스·완화의료는 말기환자의 통증 및 증상을 적극적으로 조절하고 환자와 가족의 심리적·사회적·영적 고통을 경감시켜 삶의 질을 향상 시키는 것을 목표로 하는 전인적인 돌봄으로 행복한 삶을 살며 존엄한 삶의 마지막을 가질 수 있도록 하는 것입니다.</p>
					<p class="stxt2">이에 본 센터에서는 호스피스완화의료의 활성화를 위해 권역 내 호스피스전문기관 관리와 지원, 호스피스전문인력 교육 및 훈련, 완화의료분야 연구활동, 그리고 호스피스완화의료 홍보 사업을 수행하는 역할을 감당하고 있습니다.</p>
					<p class="stxt2">탄생은 삶의 시작이며, 죽음은 삶의 마지막이기에 삶과 죽음은 떨어진 것이 아닙니다. 모든 사람의 삶은 존엄하고 귀합니다. 그 삶의 마지막은 죽음 역시 존엄하게, 행복하게, 아름답게 이루어져야 합니다. 칠곡경북대학교병원 권역호스피스센터는 이 가치를 지키기 위해 최선을 다하겠습니다. 감사합니다.</p>
					<p class="stxt2 sign">칠곡경북대학교병원 권역호스피스센터 센터장 <span>김아솔</span></p>
				</div>

		</div>

	</div>

</div>




<?php include "../inc/bottom.php"; ?>
