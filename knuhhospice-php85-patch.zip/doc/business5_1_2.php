<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img2.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 상급종합병원 ]</p>
		<h5 class="stit2 mt5">계명대학교 동산병원</h5>
		<p class="stxt2">1987년 시작된 계명대학교 동산병원 호스피스는 기독교적인 사랑을 바탕으로 말기암환자와 가족을 위해
			일합니다. 호스피스 개념이 미미하던 시기부터 호스피스완화의료 체계를 도입하여 말기암으로 고통 받는 환자와 가족에게
			전인적 돌봄을 제공하고 있습니다. 또한 생의 마지막순간까지 존엄성과 품위를 유지할 수 있도록 호스피스완화의료전문팀이
			생명사랑을 실천하고 있습니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-258-6369</td>
			<th>팩스</th>
			<td>053-258-6370</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(42601) 대구광역시 달서구 달구벌대로 1035 (신당동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://dongsan.dsmc.or.kr" target="_blank" class="link">http://dongsan.dsmc.or.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li class="off"><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">0</td>
				<td>0실</td>
				<td>0실</td>
				<td>0실</td>
				<td>0실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">0실</td>
				<td>1실</td>
				<td>0실</td>
				<td>무</td>
				<td>0실</td>
				<td>1실</td>
				<td>0실</td>
			</tr>
		</tbody>
	</table>
</div>
