<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "6";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="hospice1" class="cont-top">
			<img src="/images/sub/hospice1_top.png" alt="" />
		</div>

		<div class="s-section pt0">
			<h4 class="stit1">호스피스·완화의료 정의</h4>
			<p class="stxt1 lh2">생명을 위협하는 질환을 가진 환자의 신체적 증상을 적극적으로 조절하고 환자와 가족의 심리 사회적,
				영적 어려움을 돕기 위해 의사, 간호사, 사회복지사 등으로 이루어진 호스피스· 완화의료 전문가가 팀을 이루어 환자와
				가족의 고통을 경감시켜 삶의 질을 향상시키는 것을 목표로 하는 의료 서비스입니다.</p>
		</div>


		<h4 class="stit1">호스피스·완화의료 서비스유형</h4>
		<div class="titCont pds">
			<div class="tit">
				<h4 class="stit2 fc-r">입원형 호스피스</h4>
			</div>
			<div class="cont">
				<dl class="dl-style2 pt0">
					<dt>입원형 호스피스란?</dt>
					<dd>보건복지부 지정 호스피스전문기관 병동에 입원한 말기암 환자와 가족들에게 호스피스·완화의료 서비스를
					제공합니다. 이러한 서비스로 환자와 가족들의 신체적, 심리·사회적, 영적 고통을 완화하여 삶의 질 향상에 기여합니다.</dd>
				</dl>
				<dl class="dl-style2">
					<dt>대상질환</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>말기 암</p></li>
						</ul>
					</dd>
				</dl>
				<dl class="dl-style2">
					<dt>서비스</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>포괄적인 초기 평가 및 돌봄 계획 수립과 상담</p></li>
							<li><p>음악/미술 요법 등 프로그램</p></li>
							<li><p>환자 및 가족의 심리/사회/영적 문제 상담</p></li>
							<li><p>24시간 전화상담 및 응급 입원 서비스</p></li>
							<li><p>호스피스·완화의료 자원봉사자의 돌봄 봉사</p></li>
							<li><p>통증 및 신체증상 완화</p></li>
							<li><p>사별가족 돌봄 서비스</p></li>
							<li><p>임종 관리</p></li>
							<li><p>자원 연계 및 이벤트 프로그램 운영</p></li>
							<li><p>환자와 가족 교육 (환자를 돌보는 방법, 증상 조절 등)</p></li>
						</ul>
					</dd>
				</dl>
			</div>
		</div>

		<div></div>

		<div class="titCont pds">
			<div class="tit">
				<h4 class="stit2 fc-r">가정형 호스피스</h4>
			</div>
			<div class="cont">
				<dl class="dl-style2 pt0">
					<dt>가정형 호스피스란?</dt>
					<dd>가정에서 지내기를 원하는 말기 환자와 가족에게 보건복지부 지정 전문 기관의 호스피스 팀이 가정으로 방문하여
						호스피스·완화의료 서비스를 제공합니다. 이러한 서비스로 환자와 가족들의 신체적, 심리·사회적, 영적 고통을 완화하여
						삶의 질 향상에 기여합니다.</dd>
				</dl>
				<dl class="dl-style2">
					<dt>대상질환</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>말기 암</p></li>
							<li><p>말기 후천성 면역 결핍증</p></li>
							<li><p>말기 만성 폐쇄성 호흡기 질환</p></li>
							<li><p>말기 만성 간경화</p></li>
						</ul>
					</dd>
				</dl>
				<dl class="dl-style2">
					<dt>서비스</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>포괄적인 초기 평가 및 돌봄 계획 수립과 상담</p></li>
							<li><p>환자 및 돌봄 제공자 교육</p></li>
							<li><p>주·야간 상담전화</p></li>
							<li><p>사별가족 돌봄 서비스</p></li>
							<li><p>심리적/사회적/영적 지지</p></li>
							<li><p>장비 대여/연계 및 의뢰 서비스</p></li>
							<li><p>임종 준비교육 및 돌봄 지원</p></li>
						</ul>
					</dd>
				</dl>
			</div>
		</div>

		<div></div>

		<div class="titCont pds">
			<div class="tit">
				<h4 class="stit2 fc-r">자문형 호스피스</h4>
			</div>
			<div class="cont">
				<dl class="dl-style2 pt0">
					<dt>자문형 호스피스란?</dt>
					<dd>일반 병동과 외래에서 진료를 받는 말기 환자와 가족에게 호스피스 팀이 담당 의사와 함께 호스피스·완화의료 서비스를
						제공합니다. 이러한 서비스로 환자와 가족들의 신체적, 심리·사회적, 영적 고통을 완화하여 삶의 질 향상에 기여합니다.</dd>
				</dl>
				<dl class="dl-style2">
					<dt>대상질환</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>말기 암</p></li>
							<li><p>말기 후천성 면역 결핍증</p></li>
							<li><p>말기 만성 폐쇄성 호흡기 질환</p></li>
							<li><p>말기 만성 간경화</p></li>
						</ul>
					</dd>
				</dl>
				<dl class="dl-style2">
					<dt>서비스</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>신체증상관리 자문</p></li>
							<li><p>생애말기 돌봄 계획 및 상담 지원</p></li>
							<li><p>임종 준비 교육 및 돌봄 지원</p></li>
							<li><p>재가서비스 연계</p></li>
							<li><p>심리적/사회적/영적 지지</p></li>
							<li><p>자원 연계/경제적 지원</p></li>
							<li><p>호스피스 입원 연계 (말기 암인 경우)</p></li>
						</ul>
					</dd>
				</dl>
			</div>
		</div>

		<div></div>


		<div class="titCont pds">
			<div class="tit">
				<h4 class="stit2 fc-r">소아청소년 완화의료</h4>
			</div>
			<div class="cont">
				<dl class="dl-style2 pt0">
					<dt>소아청소년 완화의료란?</dt>
					<dd>생명을 위협하는 질환으로 치료받는 소아청소년 환자와 가족이 치료 과정에서 겪는 여러 가지 증상, 불편, 스트레스 등
						신체적, 심리적, 사회적 어려움을 완화시키고 삶의 질 향상에 기여하는 통합적 의료 서비스입니다.</dd>
				</dl>
				<dl class="dl-style2">
					<dt>대상질환</dt>
					<dd>생명을 위협하는 질환에 걸린 소아청소년 환자와 그 가족 중에서 완화의료가 필요하다고 판단되는 경우로
						성인 호스피스와 달리 진단 병명이나 질병 단계에 제한이 없습니다. (현재는 만 24세 이하인 환자에 한해 시범 운영하고
						있습니다.)</dd>
				</dl>
				<dl class="dl-style2">
					<dt>서비스</dt>
					<dd>
						<ul class="dotList col2">
							<li><p>포괄적인 초기 평가 및 돌봄 계획 수립과 상담</p></li>
							<li><p>심리적·영적 돌봄</p></li>
							<li><p>사회적 돌봄</p></li>
							<li><p>퇴원 지원</p></li>
							<li><p>사별가족 돌봄</p></li>
							<li><p>신체적 돌봄</p></li>
							<li><p>의사소통 지원</p></li>
							<li><p>환자 및 가족, 돌봄 제공자 교육</p></li>
							<li><p>임종 돌봄</p></li>
							<li><p>자원봉사자 교육 및 프로그램 운영</p></li>
						</ul>
					</dd>
				</dl>
			</div>
		</div>


	</div>

</div>




<?php include "../inc/bottom.php"; ?>
