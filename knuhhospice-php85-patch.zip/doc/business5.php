<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "5";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="tab" class="tab01">
			<?php  include "../inc/tab_business5.php" ?>
		</div>



		<h4 class="stit1">대구 호스피스 전문기관</h4>
		<ul class="tabs">
			 <li><a href="#tab1">계명대학교 대구동산병원</a></li>
			 <li><a href="#tab2">계명대학교 동산병원</a></li>
			 <li><a href="#tab3">대구가톨릭대학교병원</a></li>
			 <li><a href="#tab4">대구보훈병원</a></li>
			 <li><a href="#tab5">대구의료원</a></li>
			 <li><a href="#tab6">대구파티마병원</a></li>
			 <!-- <li><a href="#tab7">사랑나무의원</a></li> -->
			 <li><a href="#tab8">영남대학교병원</a></li>
			 <li><a href="#tab9">칠곡경북대학교병원</a></li>
			 <li><a href="#tab10">대구기독병원</a></li>

		</ul>

		<div class="tab_container1 tabCont">
      <div id="tab1" class="tab_content">
				<?php  include "business5_1_1.php" ?>
			</div>

			<div id="tab2" class="tab_content" style="display:none;">
				<?php  include "business5_1_2.php" ?>
			</div>

			<div id="tab3" class="tab_content" style="display:none;">
				<?php  include "business5_1_3.php" ?>
			</div>

			<div id="tab4" class="tab_content" style="display:none;">
				<?php  include "business5_1_4.php" ?>
			</div>

			<div id="tab5" class="tab_content" style="display:none;">
				<?php  include "business5_1_5.php" ?>
			</div>

			<div id="tab6" class="tab_content" style="display:none;">
				<?php  include "business5_1_6.php" ?>
			</div>

			<!-- <div id="tab7" class="tab_content" style="display:none;">
				<?php // include "business5_1_7.php" ?>
			</div> -->

			<div id="tab8" class="tab_content" style="display:none;">
				<?php  include "business5_1_8.php" ?>
			</div>

			<div id="tab9" class="tab_content" style="display:none;">
				<?php  include "business5_1_9.php" ?>
			</div>

            <div id="tab10" class="tab_content" style="display:none;">
				<?php  include "business5_1_10.php" ?>
			</div>
		</div>





	</div>

</div>




<?php include "../inc/bottom.php"; ?>
