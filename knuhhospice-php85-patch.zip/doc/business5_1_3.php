<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img3.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 상급종합병원 ]</p>
		<h5 class="stit2 mt5">대구가톨릭대학교병원</h5>
		<p class="stxt2">대구가톨릭대학교병원은 예수그리스도의 사랑과 복음정신을 바탕으로 “전인적치유와 선진의료”의 미션을
			가지고 설립되었다. 본원 호스피스완화의료팀은 1994년부터 말기 암환자와 가족을 위해 입원기간 중 안락함을 제공하고자
			노력해왔으며, 2010년 8월 완화의료병동 오픈을 계기로 보건복지부로부터 말기암환자를 위한 완화의료전문기관으로
			지정받아 지금까지 말기암환자들의 총체적인 안녕과 서비스 질 향상을 위해 노력하고 있다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-650-3431</td>
			<th>팩스</th>
			<td>053-650-3434</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(42472) 대구광역시 남구 두류공원로17길 33 대구가톨릭대학교병원 (대명동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.dcmc.co.kr" target="_blank" class="link">http://www.dcmc.co.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">16</td>
				<td>2실</td>
				<td>1실</td>
				<td>0실</td>
				<td>3실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
