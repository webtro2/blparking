<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="history_top">
			<h3>History</h3>
			<p>호스피스완화의료와 행복한 생에 말기를<br/> 권역호스피스센터가 걸어온 길을 소개합니다.</p>
		</div>

		<ul id="history">
			<li data-aos="fade-left" data-aos-delay="300">
				<div class="txt">
					<h4>2021</h4>
					<dl><dt>03.29</dt><dd>홍보물 제작 및 배포 1차</dd></dl>
					<dl><dt>04.16</dt><dd>7권역 호스피스전문기관 협의체 대표단 1차 간담회</dd></dl>
					<dl><dt>05.01</dt><dd>호스피스·완화의료 인식개선 홍보캠페인</dd></dl>
					<dl><dt>05.27</dt><dd>7권역 호스피스전문기관 협의체 통증캠페인</dd></dl>
					<dl><dt>06.11</dt><dd>비대면 소진예방 힐링프로그램</dd></dl>
					<dl><dt>06.24</dt><dd>지역사회연계교육</dd></dl>
					<dl><dt>07.07</dt><dd>호스피스·완화의료 자원봉사자 교육교재 및 홍보물 배포</dd></dl>
					<dl><dt>07.16</dt><dd>7권역 호스피스전문기관 협의체 직종별 간담회</dd></dl>
					<dl><dt>09.27</dt><dd>호스피스·완화의료 보조활동인력 책자 배포</dd></dl>
					<dl><dt>09.30</dt><dd>호스피스·완화의료 돌봄 제공자 양성과정</dd></dl>
					<dl><dt>10.01</dt><dd>호스피스·완화의료 인식개선 캠페인 라디오 송출</dd></dl>
					<dl><dt>11.08</dt><dd>소식지 발간 및 배포 </dd></dl>
					<dl><dt>11.12</dt><dd>호스피스·완화의료 종사자 보수교육</dd></dl>
					<dl><dt>11.26</dt><dd>홍보물 제작 및 배포 2차</dd></dl>
					<dl><dt>12.01</dt><dd>홍보물 제작 및 배포 3차</dd></dl>
				</div>
			</li>


			<li data-aos="fade-left" data-aos-delay="300">
				<div class="txt">
					<h4>2020</h4>
					<dl><dt>06.17</dt><dd>가정형 호스피스 운영(대구시)</dd></dl>
					<dl><dt>06.20</dt><dd>호스피스·완화의료 전문인력 표준교육과정</dd></dl>
					<dl><dt>06.23</dt><dd>원내 통증캠페인</dd></dl>
					<dl><dt>07.02</dt><dd>7권역 호스피스전문기관 협의체 통증캠페인</dd></dl>
					<dl><dt>07.07</dt><dd>7권역 호스피스전문기관 협의체 대표단 간담회</dd></dl>
					<dl><dt>07.28</dt><dd>홍보물 제작 및 배포 1,2차</dd></dl>
					<dl><dt>08.01</dt><dd>가정형 호스피스 홍보 영상물 방영</dd></dl>
					<dl><dt>08.10</dt><dd>지역사회 암 말기 환자 보호자 교육에 대한 교재 제작 및 배포</dd></dl>
					<dl><dt>09.19</dt><dd>소진예방 힐링 프로그램</dd></dl>
					<dl><dt>09.21</dt><dd>호스피스·완화의료 자원봉사자 교육 교재와 홍보물 배포</dd></dl>
					<dl><dt>10.08</dt><dd>사별가족 돌봄 제공자 양성 과정</dd></dl>
					<dl><dt>10.15</dt><dd>호스피스·완화의료 보조활동인력 책자 배포</dd></dl>
					<dl><dt>11.14</dt><dd>호스피스·완화의료 종사자 보수교육</dd></dl>
					<dl><dt>11.16</dt><dd>소식지 발간 및 배포</dd></dl>
					<dl><dt>11.19</dt><dd>7권역 호스피스전문기관 협의체 직종별 간담회</dd></dl>
					<dl><dt>11.20</dt><dd>호스피스·완화의료 인식개선 홍보캠페인</dd></dl>
					<dl><dt>12.08</dt><dd>호스피스전문기관 리플렛 배포</dd></dl>
				</div>
			</li>

			<li data-aos="fade-left" data-aos-delay="300">
				<div class="txt">
					<h4>2019</h4>
					<dl><dt>04.01</dt><dd>호스피스·완화의료 가정·자문형 추가교육</dd></dl>
					<dl><dt>04.01</dt><dd>가정형 호스피스 운영 (대구시)</dd></dl>
					<dl><dt>04.05</dt><dd>홍보물 제작 및 배포 1차 - 제47회 보건의 날 기념</dd></dl>
					<dl><dt>04.13</dt><dd>상반기 호스피스·완화의료 전문인력 표준교육</dd></dl>
					<dl><dt>05.23</dt><dd>원내 통증캠페인</dd></dl>
					<dl><dt>05.28</dt><dd>지역사회연계교육 1차~10차</dd></dl>
					<dl><dt>05.30</dt><dd>7권역 호스피스전문기관 협의체 대표단 1차 간담회</dd></dl>
					<dl><dt>06.01</dt><dd>호스피스·완화의료 인식개선 캠페인 영상물 방영</dd></dl>
					<dl><dt>06.10</dt><dd>7권역 호스피스센터 소식지 창간 및 배포</dd></dl>
					<dl><dt>06.21</dt><dd>7권역 호스피스전문기관 협의체 통증캠페인</dd></dl>
					<dl><dt>07.26</dt><dd>호스피스·완화의료 보조활동인력 심화교육</dd></dl>
					<dl><dt>08.29</dt><dd>소진예방 힐링프로그램</dd></dl>
					<dl><dt>09.05</dt><dd>가정형 호스피스 질 향상 방안 워크숍</dd></dl>
					<dl><dt>09.26</dt><dd>호스피스·완화의료 자원봉사자 보수교육 및 위안의 날 행사</dd></dl>
					<dl><dt>09.28</dt><dd>하반기 호스피스·완화의료 전문인력 표준교육</dd></dl>
					<dl><dt>10.17</dt><dd>''호스피스의 날' 기념식(연극공연 및 스토리툰)</dd></dl>
					<dl><dt>10.22</dt><dd>홍보물 제작 및 배포 2차</dd></dl>
					<dl><dt>11.01</dt><dd>소식지 발간 및 배포 2차</dd></dl>
					<dl><dt>11.07</dt><dd>대구광역시 호스피스·완화의료 및 웰다잉 문화조성 조례안 제정 협조</dd></dl>
					<dl><dt>11.13</dt><dd>호스피스·완화의료 인식개선 홍보캠페인</dd></dl>
					<dl><dt>11.29</dt><dd>7권역 호스피스전문기관 협의체 대표단 2차 간담회</dd></dl>
					<dl><dt>12.11</dt><dd>홍보물 제작 및 배포 3차</dd></dl>
				</div>
			</li>


			<li data-aos="fade-left" data-aos-delay="300">
				<div class="txt">
					<h4>2018</h4>
					<dl><dt>01.22</dt><dd>권역별호스피스센터 운영 및 정부정책방향 관련 회의 참석</dd></dl>
					<dl><dt>04.28</dt><dd>호스피스·완화의료 전문인력 표준교육과정 실시</dd></dl>
					<dl><dt>05.09</dt><dd>권역별 호스피스센터 사업운영을 위한 지자체 예산 지원 요청</dd></dl>
					<dl><dt>05.11</dt><dd>7권역 호스피스전문기관 협의체 대표단 1차 간담회</dd></dl>
					<dl><dt>05.15</dt><dd>암 극복 캠페인</dd></dl>
					<dl><dt>06.12</dt><dd>7권역 호스피스전문기관 협의체 통증캠페인</dd></dl>
					<dl><dt>08.25</dt><dd>호스피스·완화의료 종사자 보수교육 실시</dd></dl>
					<dl><dt>09.18</dt><dd>7권역 호스피스전문기관 협의체 대표단 2차 간담회</dd></dl>
					<dl><dt>09.29</dt><dd>호스피스·완화의료 전문인력 표준교육 실시</dd></dl>
					<dl><dt>10.12</dt><dd>제 6회 '호스피스의 날' 기념식 참석</dd></dl>
					<dl><dt>10.23</dt><dd>소아·청소년 완화의료 출간기념 북콘서트 개최</dd></dl>
					<dl><dt>11.01</dt><dd>생애말기돌봄 선호도와 호스피스·완화의료 인식에 대한 설문조사 진행</dd></dl>
					<dl><dt>11.13</dt><dd>호스피스·완화의료 인식개선 홍보캠페인 1차</dd></dl>
					<dl><dt>11.15</dt><dd>대구광역시 호스피스전문기관 협의체 홍보물 제작 및 배포</dd></dl>
					<dl><dt>11.19</dt><dd>호스피스·완화의료 완화도우미 심화교육 2차</dd></dl>
					<dl><dt>11.20</dt><dd>호스피스·완화의료 인식개선을 위한 영상물 제작 및 방영</dd></dl>
					<dl><dt>11.21</dt><dd>호스피스·완화의료 자원봉사자 보수교육 & 위안의 밤 개최</dd></dl>
					<dl><dt>11.26</dt><dd>호스피스·완화의료 인식개선 홍보캠페인 2차</dd></dl>
					<dl><dt>12.06</dt><dd>7권역 호스피스전문기관 협의체 대표단 3차 간담회</dd></dl>
					<dl><dt>12.12</dt><dd>권역호스피스센터 개소기념 심포지움 개최</dd></dl>
				</div>
			</li>


			<li data-aos="fade-left" data-aos-delay="300">
				<div class="txt">
					<h4>2017</h4>
					<dl><dt>12.31</dt><dd>권역호스피스센터 지정</dd></dl>
				</div>
			</li>
		</ul>

	</div>

</div>




<?php include "../inc/bottom.php"; ?>
