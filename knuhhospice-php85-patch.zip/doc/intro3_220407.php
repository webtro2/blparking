<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div class="center">
			<ul id="organization">
				<li class="depth1">
					<div><p>칠곡경북대학교병원장</p></div>
				</li>
				<li class="depth2">
					<div><p>임상시험심사위원회 IRB</p></div>
					<div class="depth2_2"><p>지역암센터</p><p>노인보건의료센터</p></div>
				</li>
				<li class="depth3">
					<div>
						<dl>
							<dt>진료처</dt>
							<dd>
								<p>진료각과</p>
								<p>암진료부</p>
								<p>간호부</p>
								<p>약제부</p>
								<p>진료지원실</p>
								<p>의료질관리실</p>
								<p>감염관리실</p>
								<p>공공보건의료사업실</p>
								<dl class="point">
									<dt>호스피스완화의료사업실</dt>
									<dd>
										<p class="point1">권역호스피스센터</p>
										<p class="point2">호스피스완화의료센터</p>
									</dd>
								</dl>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>어린이병원</dt>
							<dd>
								<p>진료부</p>
								<p>관리지원팀</p>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>사무국</dt>
							<dd>
								<p>총무과</p>
								<p>원무과</p>
								<p>시설과</p>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>기획조정실</dt>
							<dd>
								<p>정보통신실</p>
								<p>기획과</p>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>교육연구실</dt>
							<dd>
								<p>교육연구과</p>
								<p>임상시험센터</p>
							</dd>
						</dl>
					</div>
				</li>
			</ul>
		</div>

		<div class="s-section center line">
			<h4 class="stit1 left">세부 조직도</h4>
			<ul id="organization" class="ver2">
				<li class="depth1">
					<div><p>권역호스피스센터</p></div>
				</li>
				<li class="depth3">
					<div>
						<dl>
							<dt>의사(1명)</dt>
							<dd>
								<p>센터장</p>
								<ol class="dotList">
									<li><p>사업총괄</p></li>
									<li class="nbsp"><p>&nbsp;</p></li>
								</ol>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>간호사(1명)</dt>
							<dd>
								<p>팀장</p>
								<ol class="dotList">
									<li><p>업무총괄</p></li>
									<li><p>대외협력업무 담당</p></li>
								</ol>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>사회복지사(1명)</dt>
							<dd>
								<p>교육,홍보</p>
								<ol class="dotList">
									<li><p>코디네이터 업무</p></li>
									<li><p>교육 및 홍보사업 담당</p></li>
								</ol>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>사무직(1명)</dt>
							<dd>
								<p>예산, 행정</p>
								<ol class="dotList">
									<li><p>행정 및 예산업무 담당</p></li>
									<li class="nbsp"><p>&nbsp;</p></li>
								</ol>
							</dd>
						</dl>
					</div>
				</li>
			</ul>
		</div>


	</div>

</div>




<?php include "../inc/bottom.php"; ?>
