<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div class="center">
			<ul id="organization2">
				<li class="depth1">
					<div><p><img src="/images/sub/org_logo1.png" alt="보건복지부" /></p></div>
				</li>
				<li class="depth2">
					<div><p>국가호스피스연명의료위원회</p></div>
					<div class="nbsp"><p></p></div>
				</li>
				<li class="depth3">
					<div><p><img src="/images/sub/org_logo2.png" alt="국립암센터/중앙호스피스센터" /></p></div>
				</li>
				<li class="depth4">
					<div><p>권역호스피스센터</p></div>
					<div>
						<dl>
							<dt>유관기관</dt>
							<dd>
								<p>건강보험심사평가원</p>
								<p>국민건강보험공단</p>
								<p>관련 학회 및 협회</p>
							</dd>
						</dl>
					</div>
				</li>
				<li class="depth5">
					<div>
						<dl>
							<dt>호스피스전문기관</dt>
							<dd>
								<p>입원형 호스피스</p>
								<p>가정형 호스피스</p>
								<p>자문형 호스피스</p>
								<p>소아청소년 완화의료</p>
							</dd>
						</dl>
					</div>
				</li>
			</ul>
		</div>


		<div class="s-section center line">
			<h4 class="stit1 left">세부 조직도</h4>
			<ul id="organization" class="ver2">
				<li class="depth1">
					<div><p>권역호스피스센터</p></div>
				</li>
				<li class="depth3">
					<div>
						<dl>
							<dt>의사(1명)</dt>
							<dd>
								<p>센터장</p>
								<ol class="dotList">
									<li><p>사업총괄</p></li>
									<li class="nbsp"><p>&nbsp;</p></li>
								</ol>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>간호사(1명)</dt>
							<dd>
								<p>팀장</p>
								<ol class="dotList">
									<li><p>업무총괄</p></li>
									<li><p>대외협력업무 담당</p></li>
								</ol>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>사회복지사(1명)</dt>
							<dd>
								<p>교육, 홍보</p>
								<ol class="dotList">
									<li><p>교육 및 홍보사업 담당</p></li>
									<li class="nbsp"><p>&nbsp;</p></li>
								</ol>
							</dd>
						</dl>
					</div>
					<div>
						<dl>
							<dt>사무직(1명)</dt>
							<dd>
								<p>예산, 행정</p>
								<ol class="dotList">
									<li><p>행정 및 예산업무 담당</p></li>
									<li class="nbsp"><p>&nbsp;</p></li>
								</ol>
							</dd>
						</dl>
					</div>
				</li>
			</ul>
		</div>


	</div>

</div>




<?php include "../inc/bottom.php"; ?>
