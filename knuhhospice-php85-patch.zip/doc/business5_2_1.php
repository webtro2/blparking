<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_2_img1.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">계명대학교 경주동산병원</h5>
		<p class="stxt2">계명대학교 경주동산병원은 기독교 정신에 입각한 경주 최초의 종합병원으로 설립되어 지역보건향상과 사회봉사를 위한 선도적인 연구와 진료활동에 전력을 기울이고 있습니다. 2016년 10월부터는 경주 최초의 호스피스 완화의료병동을 운영하여 지역사회 내 말기암환자와 그 가족의 삶의 질을 향상시키고 그들이 겪는 심리적 영적 사회적 고통을 경감시키기 위해 적극적이고 전문적인 호스피스 돌봄서비스를 제공하고 있습니다. </p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>054-770-9576</td>
			<th>팩스</th>
			<td>054-773-9492</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(38144) 경상북도 경주시 봉황로 65 계명대학교 경주동산병원 (서부동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<!-- <td colspan="3"><a href="https://www.kjds@or.kr" target="_blank" class="link">	https://www.kjds@or.kr</a> <span class="lnr lnr-select"></span></td> -->
			<td colspan="3"><a href="https://gyeongju.dsmc.or.kr:49890/" target="_blank" class="link">	https://gyeongju.dsmc.or.kr:49890/</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">10</td>
				<td>2실</td>
				<td>0실</td>
				<td>0실</td>
				<td>2실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
