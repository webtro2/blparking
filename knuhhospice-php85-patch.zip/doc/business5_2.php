<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "5";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="tab" class="tab02">
			<?php  include "../inc/tab_business5.php" ?>
		</div>



		<h4 class="stit1">경북 호스피스 전문기관</h4>
		<ul class="tabs">
			 <li><a href="#tab1">계명대학교 경주동산병원</a></li>
			 <li><a href="#tab2">김천의료원</a></li>
			 <li><a href="#tab3">안동의료원</a></li>
			 <li><a href="#tab4">포항성모병원</a></li>
			 <li><a href="#tab5">포항의료원</a></li>
			 <li><a href="#tab6">구미강동병원</a></li>
		</ul>

		<div class="tab_container1 tabCont">
      <div id="tab1" class="tab_content">
				<?php  include "business5_2_1.php" ?>
			</div>

			<div id="tab2" class="tab_content" style="display:none;">
				<?php  include "business5_2_2.php" ?>
			</div>

			<div id="tab3" class="tab_content" style="display:none;">
				<?php  include "business5_2_3.php" ?>
			</div>

			<div id="tab4" class="tab_content" style="display:none;">
				<?php  include "business5_2_4.php" ?>
			</div>

			<div id="tab5" class="tab_content" style="display:none;">
				<?php  include "business5_2_5.php" ?>
			</div>

            <div id="tab6" class="tab_content" style="display:none;">
				<?php  include "business5_2_6.php" ?>
			</div>
		</div>





	</div>

</div>




<?php include "../inc/bottom.php"; ?>
