<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="business2" class="cont-top">
			<!-- <h3>교육사업</h3> -->
			<img src="/images/sub/business2_top.png" alt="" />
		</div>


		<dl class="dl-style1">
			<dt>호스피스·완화의료 전문인력 표준교육</dt>
			<dd class="stxt1">호스피스 필수인력의 기본교육인 60시간 표준교육</dd>
		</dl>

		<dl class="dl-style1">
			<dt>서비스유형의 다양화에 따른 가정형·자문형 호스피스 추가교육 운영</dt>
			<dd class="stxt1">각 서비스 유형별 16시간 (이론 8시간, 실습 8시간) 추가 교육 운영</dd>
		</dl>

		<dl class="dl-style1">
			<dt>호스피스 필수인력에 대한 법정 필수교육인 보수교육 개발 및 운영</dt>
			<dd>
				<ul class="dotList">
					<li><p>의사협회, 간호사협회, 사회복지사협회에서 보수교육으로 인정받는 교육 개발</p></li>
					<li><p>권역 내 전문인력의 실무에 도움이 되는 호스피스·완화의료 관련 내용</p></li>
				</ul>
			</dd>
		</dl>

		<dl class="dl-style1">
			<dt>권역 내 호스피스 돌봄제공자 양성과정 프로그램 운영</dt>
			<dd class="stxt1">호스피스·완화의료 분야별 돌봄 담당자의 역량강화를 위하여 희망하는 권역별센터 중심으로 과정 개발 및 운영</dd>
		</dl>

		<dl class="dl-style1">
			<dt>권역 내 호스피스 자원봉사자 교육프로그램 개발 및 운영</dt>
			<dd class="stxt1">호스피스전문기관별로 이루어지는 자원봉사자 교육프로그램을 권역차원에서 통합하여 개발 및 운영</dd>
		</dl>

		<dl class="dl-style1">
			<dt>지역사회 중심 호스피스 교육 프로그램 개발</dt>
			<dd class="stxt1">지역사회 의료진 등을 대상으로 호스피스 홍보 및 인식개선을 위한 다양한 교육 프로그램 개발 운영</dd>
		</dl>


	</div>

</div>




<?php include "../inc/bottom.php"; ?>
