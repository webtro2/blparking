<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img5.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">대구의료원</h5>
		<!-- <p class="stxt2">통증 등 환자를 힘들게 하는 신체적 증상을 적극적으로 조절하고 환자와 가족의 심리사회적, 영적 어려움을
			돕고 이를 위해 의사, 간호사, 사회복지사, 성직자, 자원봉사자가 팀을 이루어 환자와 가족의 고통을 경감시켜 삶의 질을
			향상시키는 것을 목표로 하는 대구의료원 호스피스센터(평온관)입니다!</p> -->
            <p class="stxt2">통증 등 환자를 힘들게 하는 신체적 증상을 적극적으로 조절하고 환자와 가족의 심리사회적, 영적 어려움을 돕고 이를 위해 의사, 간호사, 사회복지사, 성직자, 자원봉사자가 팀을 이루어 환자와 가족의 고통을 경감시켜 삶의 질을 향상시키는 것을 목표로 하는 대구의료원 호스피스센터입니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-560-9300</td>
			<th>팩스</th>
			<td>053-560-9312</td>
		</tr>
		<tr>
			<th>주소</th>
			<!-- <td colspan="3">(41845) 대구광역시 서구 평리로 157 대구의료원 호스피스센터 (중리동)</td> -->
			<td colspan="3">(41845) 대구광역시 서구 평리로 157 대구의료원 (중리동)</td>

		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://www.daegumc.co.kr" target="_blank" class="link">http://www.daegumc.co.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">17</td>
				<td>1실</td>
				<td>0실</td>
				<td>0실</td>
				<td>4실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
