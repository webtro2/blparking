<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">


		<div class="s-section pt0">
			<img src="/images/sub/intro4_img1.png" alt="" style="max-width: 100%;"/>
		</div>

		<div id="sLocation">
			<!-- * 카카오맵 - 지도퍼가기 -->
			<!-- 1. 지도 노드 -->
			<div id="daumRoughmapContainer1647939788662" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%; "></div>

			<!--
				2. 설치 스크립트
				* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
			-->
			<script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

			<!-- 3. 실행 스크립트 -->
			<script charset="UTF-8">
				new daum.roughmap.Lander({
					"timestamp" : "1647939788662",
					"key" : "29jqq",
					"mapWidth" : "100%",
					"mapHeight" : "100%"
				}).render();
			</script>
		</div>
		<div id="sLoca-info">
			<div class="txt">
				<h4>권역호스피스센터</h4>
				<dl><dt><i class="add"></i>주소</dt><dd>대구광역시 북구 호국로 807번지 칠곡경북대학교병원 1동 2층 권역호스피스센터</dd></dl>
				<!-- <dl><dt><i class="tel"></i>연락처</dt><dd>Tel. 053-200-3680 / FAX. 053-200-3689</dd></dl> -->
			</div>
			<a href="http://kko.to/WeBrhiN9i" target="_blank"><div class="in"><img src="/images/sub/ico_route.png" alt="" /><p>길찾기</p></div></a>
		</div>

		<div class="s-section">
			<h4 class="stit1">지하철</h4>
			<div class="transport">
				<dl>
					<dt>1호선</dt><dd>명덕역에서 3호선(칠곡경대병원 방면)으로 환승</dd>
				</dl>
				<dl>
					<dt>2호선</dt><dd>신남역에서 3호선(칠곡경대병원 방면)으로 환승</dd>
				</dl>
				<dl>
					<dt>3호선</dt><dd>칠곡경대병원역</dd>
				</dl>
			</div>
		</div>


		<div class="s-section pt0">
			<h4 class="stit1">버스</h4>
			<div class="transWrap">
				<div class="transport">
					<h5 class="stit3">시내버스 노선 안내</h5>
					<dl>
						<dt>칠곡경북대학교병원 정문</dt><dd>칠곡3번</dd>
					</dl>
					<dl>
						<dt>칠곡경북대학교병원 장례식장 뒷편(50사단 정문 및 건너), 칠곡경대병원역</dt><dd>730번, 칠곡3번</dd>
					</dl>
					<dl>
						<dt>칠곡경북대학교병원 후문</dt><dd>급행2번</dd>
					</dl>
					<dl>
						<dt>학정청아람 아파트 앞 후문</dt><dd>706번</dd>
					</dl>
				</div>

				<div class="transport">
					<h5 class="stit3">시내버스 이용 안내</h5>
					<dl>
						<dt>급행2번</dt><dd>가창 → 수성못 → 대구은행본점 → 경북대학교치과병원 → 반월당역 → 경북도청 → 북구구민운동장 → 칠곡그린빌2차앞 → 칠곡경북대학교병원(도착)</dd>
					</dl>
					<dl>
						<dt>730번</dt><dd>대덕맨션 → 봉덕시장 → 경상감영공원 건너 → 북구청 → 북부시외버스터미널 → 팔달역 → 두성파크아파트 → 태전역 → 칠곡지하도 → 팔거역 → 칠곡경북대학교병원(도착)</dd>
					</dl>
					<dl>
						<dt>527, 708, 719, 724, 726, 750, 칠곡4번</dt><dd>칠곡1지구에 위치한 [두성파크아파트] 또는 [태전교정류장]에서 하차 후 730번으로 환승</dd>
					</dl>
					<dl>
						<dt>937, 칠곡1-1, 칠곡2번</dt><dd>(칠곡3지구)칠곡그린파크정류장(하차) → (건너편)706번 환승 → 50사단에서 하차 도보로 5분</dd>
					</dl>
				</div>
			</div>

			<div class="transWrap">
				<div class="transport">
					<h5 class="stit3">고속버스 이용 안내</h5>
					<dl>
						<dt>동대구고속버스터미널 건너편(동대구역방면)</dt><dd>708번 탑승 → 태전역 하차 → 730 환승 / 937번 탑승 → 무태네거리 하차 → 급행2, 706환승</dd>
					</dl>
					<dl>
						<dt>서대구고속버스터미널 앞</dt><dd>730번 병원행</dd>
					</dl>
				</div>

				<div class="transport">
					<h5 class="stit3">시외버스 이용 안내</h5>
					<dl>
						<dt>북부정류장 앞</dt><dd>730번 병원행</dd>
					</dl>
					<dl>
						<dt>남부정류장 앞</dt><dd>309번 탑승 → 대구은행역 하차 → 급행2번 환승<br/>
						724번 탑승 → 태전역 하차 → 730번 환승<br/>
						937번 탑승 → 무태네거리 하차 → 급행2, 706번 환승</dd>
					</dl>
					<dl>
						<dt>동부정류장 앞</dt><dd>708번 탑승 → 태전역 하차 → 730번 환승<br/>
							937번 탑승 → 무태네거리 하차 → 급행2, 706번 환승</dd>
					</dl>
					<dl>
						<dt>서부정류장 앞</dt><dd>706번 탑승 → 무태네거리 하차 → 급행2, 706번 환승<br/>
								726, 750번 탑승 → 태전역 하차 → 730번 환승</dd>
					</dl>
				</div>
			</div>
		</div>

	</div>

</div>




<?php include "../inc/bottom.php"; ?>
