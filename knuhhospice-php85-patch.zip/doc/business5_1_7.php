<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img7_240313.jpg" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 의원 ]</p>
		<h5 class="stit2 mt5">사랑나무의원</h5>
		<!-- <p class="stxt2">사랑나무의원은 독립시설형 호스피스완화의료기관으로 대구 수성구에 위치하고 있습니다.
			의사, 간호사, 복지사,자원봉사자 및 성직자로 이루어진 호스피스완화의료팀으로 이루어져
			환자와 가족의 정신적, 신체적,영적, 사회적 고통을 덜어드리기위해 최선을 다하고 있습니다.
			사랑나무의원은 영남대학교병원 공용윤리위원회 위탁 등록기관으로 연명의료결정법에 따른
			업무를 수행합니다.</p> -->
		<p class="stxt2">사랑나무의원은 대구 경북 최초의 독립시설형 호스피스완화의료 전문기관으로, 전국 최초 공용윤리위원회 업무 협약(영남대 윤리위원회)을 통한 연명의료결정법에 따른 업무 수행을 통해 생애 말기암 환자의 자기 결정권 존중과 환자 및 가족의 돌봄과 삶의 질 향상에 기여하고 있으며, 간병 비용 부담 완화를 위해 무료 간병 서비스를 제공하고 있습니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-217-9500</td>
			<th>팩스</th>
			<td>053-217-9600</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(42037) 대구광역시 수성구 화랑로 112-1 사랑나무의원 (만촌동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://lovetree2015.modoo.at/" target="_blank" class="link">http://lovetree2015.modoo.at/</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">19</td>
				<td>1실</td>
				<td>0실</td>
				<td>6실</td>
				<td>0실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>2실</td>
				<td>유</td>
				<td>2실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
