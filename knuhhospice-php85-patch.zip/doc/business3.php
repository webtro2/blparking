<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

		<div id="business3" class="cont-top">
			<!-- <h3>홍보사업</h3> -->
			<img src="/images/sub/business3_top.png" alt="" />
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">호스피스 통증캠페인 실시</h4>
			</div>
			<div class="cont">
				<ul class="dotList">
					<li><p>매년 5월 중 의료진의 통증조절에 대한 적극적인 참여와 환자의 통증치료에 대한 인지도 향상을 목적으로 캠페인을 개최함</p></li>
					<li><p>권역별센터에서는 지자체, 권역 내 호스피스전문기관 및 센터 자체 의료진 등과 연계하여 통증캠페인을 실시하며 경우에 따라 지역주민 대상 캠페인 실시</p></li>
				</ul>
			</div>
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">일반인 대상 호스피스의 달 캠페인 실시</h4>
			</div>
			<div class="cont">
				<ul class="dotList">
					<li><p>권역 내 지역주민의 호스피스에 대한 필요성 인지를 향상시킴으로써 대국민적 공감대 형성</p></li>
					<li><p>10월 호스피스의 날을 맞이하여 권역별로 전문기관들과의 연계를 통해 지역주민의 참여를 독려하는 호스피스 캠페인 행사를 주관</p></li>
				</ul>
			</div>
		</div>

		<div class="titCont ver2">
			<div class="tit">
				<h4 class="stit1">일반인 대상 홍보사업 운영</h4>
			</div>
			<div class="cont">
				<ul class="dotList">
					<li><p>권역 내 호스피스·완화의료 전문기관 홍보 물품 제작</p></li>
					<li><p>권역 내 호스피스·완화의료 전문기관 라디오 캠페인</p></li>
					<li><p>권역호스피스센터 소식지 ‘큰나무’ 제작 및 배포</p></li>
				</ul>
			</div>
		</div>

	</div>

</div>




<?php include "../inc/bottom.php"; ?>
