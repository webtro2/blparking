<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_2_img4_240115.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">포항성모병원</h5>
		<p class="stxt2">2018년 2월 연명의료결정법 시행 이후 죽음을 삶의 일부로 여기는 웰다잉(well-dying)dp 대한 사회적 관심이 높아진 가운데 2019년 2월 보건복지부로부터 호스피스 전문기관으로 지정받았습니다. 다양한 요법 프로그램과 이벤트를 진행하여 말기 암환자와 가족의 심리적 안정감과 정서적 지지를 하고 있으며 생애 말기의 아름다운 동행을 함께 하고 있습니다. 입원형 호스피스 서비스를 제공하여 환자의 다양한 요구에 부응하고 있습니다. </p>
		<!-- <p class="stxt2">6.25 전후로 수많은 고아들, 양로자들 그리고 장애인들을 돌보던 재단법인 예수성심시녀회는 수도회
			수도자들이 봉사할 수 있는 다른 일을 찾기 시작하였으며, 건강증진, 질병예방 및 진료를 행함으로써 지역사회의 균형있는
			발전에 기여하기 위해 1977년 6월 3일 포항에 지역 최초의 종합병원인 포항성모입니다.</p> -->
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>054-260-8420</td>
			<th>팩스</th>
			<td>054-260-8115</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(37661) 경상북도 포항시 남구 대잠동길 17 포항성모병원 (대잠동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="https://www.pohangsmh.co.kr/" target="_blank" class="link">www.pohangsmh.co.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">10</td>
				<td>2실</td>
				<td>0실</td>
				<td>0실</td>
				<td>2실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
