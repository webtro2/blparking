<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_2_img3.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">안동의료원</h5>
		<!-- <p class="stxt2">호스피스완화의료의 필요에 대한 사회적 인식이 늘고 있으나, 수익성이 낮아 대형병원에서는 호스피스
			병동운영을 기피하고 있습니다. 이에 안동의료원에서는 지난 9월 26일 호스피스 완화의료센터를 오픈하고 10월 4일
			'평안관' 개소식을 개최하였으며, 2016년 12월 27일 경북북부지역에서는 최초로 호스피스 완화의료 전문기관으로
			지정되었습니다. 처음 병상수 11병상(3인실 3병실, 1인실 2병실)으로 시작했으나 현재 10병상(1인실 2개, 2인실 1개,
			3인실 2개)으로 실내정원, 가족실, 상담실, 목욕실, 프로그램실 등을 갖추고 있으며 요일별 영적돌봄, 원예치료, 다도, 발마사지,
			영화상영, 음악감상 등을 통해 의사, 간호사, 사회복지사, 성직자, 자원봉사자 등으로 구성된 호스피스팀이 통증 환자를 힘들게
			하는 신체적 증상을 조절하고 환자와 가족의 심리사회적, 영적 어려움을 도와 말기암환자와 그 가족의 고통을 경감시켜
			삶의 질을 향상시키는 것을 목표로 하고 있습니다.</p> -->
            <p class="stxt2">경상북도 안동의료원은 1912년 11월 1일에 자혜의원으로 처음 개원한 이래 지역민의 보건향상에 기여하고 지역의료발전을 도모함을 목적으로 경상북도가 전액 출자해 설립한 공공의료기관입니다. 
2016년 12월 27일 경북북부지역 최초로 호스피스전문기관으로 지정되어 지금까지 따뜻한 분위기 속에서 가족 같은 마음으로 말기암환자와 가족의 삶의 질 향상에 기여하고자 노력하고 있습니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>054-850-6550</td>
			<th>팩스</th>
			<td>054-858-8960</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(36694) 경상북도 안동시 태사2길 55 (북문동470번지) 경상북도안동의료원 (북문동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://amc.or.kr" target="_blank" class="link">http://amc.or.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">10</td>
				<td>2실</td>
				<td>1실</td>
				<td>2실</td>
				<td>0실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
