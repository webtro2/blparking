<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img4.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 종합병원 ]</p>
		<h5 class="stit2 mt5">대구보훈병원</h5>
		<!-- <p class="stxt2">대구보훈병원 호스피스는 2001년 산재형호스피스를 시작으로 2008년 11월 완화의료전문병동을
			오픈하였고 2009년부터 보건복지부 말기암환자 완화의료사업 지원사업 기관으로 지정되어 현재까지 국가유공자와
			유가족, 지역주민 중 말기암환자를 대상으로 신체적, 정신적, 사회적, 영적서비스를 제공하여 여생을 편안하게 보낼 수 있도록
			지원하고 있습니다. 대구보훈병원 호스피스 완화의료팀은 말기암환자와 가족들의 고통을 사랑으로 돌봅니다.</p> -->
            <p class="stxt2">1998년부터 시작된 대구보훈병원 호스피스는 2015년 보건복지부 호스피스전문기관으로 지정되었으며 현재 입원형과 가정형 호스피스를 운영하고 있습니다. 국가유공자는 물론 일반인도 이용할 수 있습니다. 전문강사를 통한 요법 치료 및 30개 이상의 다양한 프로그램이 진행되고 있으며, 호스피스완화의료병동 환자 및 보호자 만을 위한 옥외정원이 있어 거동이 어려운 환자도 산책이나 소풍, 국화축제 등에 참여할 수 있습니다. 
호스피스완화의료전문기관 평가에서 꾸준히 최고등급을 유지하고 있으며 호스피스완화의료 공적 국무총리상을 두 번이나 수상한 전국에서 유일한 기관입니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>053-630-7843</td>
			<th>팩스</th>
			<td>053-630-7345</td>
		</tr>
		<tr>
			<th>주소</th>
			<!-- <td colspan="3">(42835) 대구광역시 달서구 월곡로 60 대구보훈병원 3층 31병동 (도원동)</td> -->
			<td colspan="3">(4235) 대구광역시 달서구 월곡로60 대구보훈병원 (도원동)</td>

		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://daegu.bohun.or.kr" target="_blank" class="link">http://daegu.bohun.or.kr</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li><p>가정형</p></li>
					<li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">18</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>3실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>유</td>
				<td>1실</td>
				<td>2실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
