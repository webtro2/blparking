<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<div class="imgCont">
	<div class="img"><img src="/images/sub/business5_img10.png" alt="" /></div>
	<div class="cont">
		<p class="fc-b fw-M">[ 병원 ]</p>
		<h5 class="stit2 mt5">대구기독병원</h5>
		<p class="stxt2">대구지하철 2호선 두류역에 위치한 대구기독병원은 경천애인(敬天愛人) 정신으로 예수님의 사랑을 실천하는 선교병원으로써 헌신하고자 설립되었습니다. 의사, 간호사, 사회복지사, 자원봉사자, 성직자, 요법프로그램 전문강사로 구성된 호스피스·완화의료팀은 환자와 가족의 신체적, 심리·사회적, 영적인 고통을 완화하고자 종합적인 평가를 기반으로 전인적이고 총체적인 돌봄을 제공하고 있습니다. 본원에서는 환자와 가족의 아름다운 마무리에 동행하고 좋은 기억으로 채워서 ‘그래도 살만한 인생이었다.’라고 말할 수 있도록 존엄하고 질 높은 생애 말기를 보장합니다.</p>
	</div>
</div>

<div class="tb-scroll">
	<table class="tb-style1" style="min-width:600px;">
		<tr>
			<th>문의전화</th>
			<td>1688-7477</td>
			<th>팩스</th>
			<td>053-606-1653</td>
		</tr>
		<tr>
			<th>주소</th>
			<td colspan="3">(42647) 대구광역시 달서구 달구벌대로 1750 (두류동)</td>
		</tr>
		<tr>
			<th>홈페이지</th>
			<td colspan="3"><a href="http://kidokh.com/" target="_blank" class="link">http://kidokh.com/</a> <span class="lnr lnr-select"></span></td>
		</tr>
		<tr>
			<th>서비스 유형</th>
			<td colspan="3">
				<ul class="checkList inl">
					<li><p>입원형</p></li>
					<li class="off"><p>가정형</p></li>
                    <li class="off"><p>자문형</p></li>
					<li class="off"><p>소아청소년 완화의료</p></li>
				</ul>
			</td>
		</tr>
	</table>
</div>


<h5 class="stit3 mt50">병상현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">총 병상 수</th>
				<th>1인실</th>
				<th>2인실</th>
				<th>3인실</th>
				<th>4인실</th>
				<!-- <th>5인실</th> -->
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">10</td>
				<td>2실</td>
				<td>2실</td>
				<td>0실</td>
				<td>1실</td>
				<!-- <td>0실</td> -->
			</tr>
		</tbody>
	</table>
</div>

<h5 class="stit3 mt50">시설현황</h5>
<div class="tb-scroll">
	<table class="tb-style2" style="min-width:600px;">
		<thead>
			<tr>
				<th class="first">가족실</th>
				<th>임종실</th>
				<th>간호사실</th>
				<th>실내/외 정원</th>
				<th>목욕실</th>
				<th>상담실</th>
				<th>처치실</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td class="first">1실</td>
				<td>1실</td>
				<td>1실</td>
				<td>무</td>
				<td>1실</td>
				<td>1실</td>
				<td>1실</td>
			</tr>
		</tbody>
	</table>
</div>
