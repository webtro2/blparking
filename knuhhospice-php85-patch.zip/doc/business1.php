<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


	<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="pageCont" class="s-inner">

			<div id="business1" class="cont-top">
				<!-- <h3>추진배경 · 추진목표<br/> 사업 목적 · 필요성</h3> -->
				<img src="/images/sub/business1_top.png" alt="" />
			</div>

			<div class="titCont">
				<div class="tit">
					<h4 class="stit1">추진배경</h4>
				</div>
				<div class="cont">
					<ul class="dotList">
						<li><p>생애말기 고통과 부담의 증가</p></li>
						<li><p>국민과 의료인 등의 호스피스·완화의료에 대한 인식 부족</p></li>
						<li><p>권역 내 호스피스 전문인력의 전문성 강화 및 지역주민대상 홍보 필요</p></li>
					</ul>
				</div>
			</div>

			<div class="titCont">
				<div class="tit">
					<h4 class="stit1">추진목표</h4>
				</div>
				<div class="cont">
					<ul class="dotList">
						<li><p>지역 거점기관으로서 권역 내 의료기관의 호스피스 사업에 대한 이해도를 높이고 호스피스전문기관 진입 촉진</p></li>
						<li><p>호스피스전문기관에 관한 호스피스·완화의료 사업 지원을 통해 권역 내 호스피스 서비스의 체계적인 제공 및 질 향상 도모</p></li>
						<li><p>호스피스 전문인력 양성을 통해 해당 권역의 수준 높은 호스피스서비스 제공 기반 구축</p></li>
						<li><p>호스피스 홍보 및 지역사회 교육을 통해 지역주민 및 의료진의 호스피스에 대한 인식 제고 및 긍정적 태도 함양 유도</p></li>
					</ul>
				</div>
			</div>

			<div class="titCont">
				<div class="tit">
					<h4 class="stit1">사업목적</h4>
				</div>
				<div class="cont">
					<ul class="dotList">
						<li><p>호스피스대상 환자와 가족의 삶의 질 향상</p></li>
					</ul>
				</div>
			</div>

			<!--<div class="titCont">
				<div class="tit">
					<h4 class="stit1">필요성</h4>
				</div>
				<div class="cont">
					<ul class="dotList">
						<li><p>호스피스전문기관 종사자들을 위한 호스피스 교육·홍보사업 수행이 필요</p></li>
						<li><p>말기환자의 현황 및 진단, 치료, 관리 등에 대한 연구</p></li>
						<li><p>권역 호스피스사업의 지원 및 전문기관들에 관한 의료지원 및 질 향상 도모</p></li>
						<li><p>호스피스 제공, 통계자료의 수집, 분석을 제공</p></li>
						<li><p>정부의 정책수행 역할</p></li>
					</ul>
				</div>
			</div>-->

	</div>

</div>




<?php include "../inc/bottom.php"; ?>
