<?php include "./_common.php"; ?>
<?php include "inc/head.php"; ?>
<?php include "inc/link.php"; ?>
<?php include "inc/top.php"; ?>
<?php include_once(G5_LIB_PATH.'/latest.lib.php'); ?>
<?php include_once(G5_BBS_PATH.'/newwin.inc.php'); ?>

<!-- mVisual -->
<div id="mVisual" class="mvWrap">
   <div class="mv_slider mv1">
      <div class="mv-txt">
         <div>
            <p class="t1" data-aos="fade-left" data-aos-delay="200">
              <span class="fs-s">환자와 환자의 가족을</span><br/> <span class="fc-r">사랑</span>으로 돌봅니다.</p>
            <p class="t2" data-aos="fade-left" data-aos-delay="300">생의 마지막 순간을 편안하게 맞이할 수 있도록<br/>
              신체적·정신적·영적 요구를 돌보아드립니다.</p>
         </div>
      </div>
   </div>
   <div class="mv_slider mv2">
      <div class="mv-txt">
        <div>
          <p class="t1" data-aos="fade-left" data-aos-delay="200">
            <span class="fs-s">환자와 환자의 가족을</span><br/> <span class="fc-r">사랑</span>으로 돌봅니다.</p>
          <p class="t2" data-aos="fade-left" data-aos-delay="300">생의 마지막 순간을 편안하게 맞이할 수 있도록<br/>
            신체적·정신적·영적 요구를 돌보아드립니다.</p>
        </div>
      </div>
   </div>
</div>
<!-- //mVisual -->


<div id="quickMenu" class="s-inner">
  <a id="kakao" href="http://pf.kakao.com/_xnhqxmb" target="_blank">
    <dl>
      <dt>카카오톡 채널</dt>
      <dd>빠르고 간편하게 문의하세요</dd>
    </dl>
    <img src="/images/common/ico_kakao.png" alt="" />
  </a>
  <div class="boxWrap">
    <div class="box1">
      <a href="javascript:GoPage('intro1')">
        <p class="t1">대구·경북<br/> 권역호스피스센터 소개</p>
        <p class="t2">자세히보기 +</p>
      </a>
    </div>
    <div class="box2">
      <a href="javascript:GoPage('business5')">
        <p class="t1">대구·경북권역호스피스<br/> 전문기관 안내</p>
        <p class="t2">자세히보기 +</p>
      </a>
    </div>
    <!-- <div class="box3">
      <a href="tel:0532003680">
        <p class="t1 fs-s">문의전화</p>
        <p class="tel">053.200.3680</p>
        <p class="t2">09:00 ~ 17:00 (점심시간 12:00~13:00)</p>
      </a>
    </div> -->
  </div>
</div>



<div id="mNews">
  <div class="s-inner">
    <div id="notice">
      <div class="mtit">
        <h3><span class="fc-r">센터소식</span>을 알려드립니다.</h3>
        <a href="javascript:GoPage('news1')" class="more"><span class="x"></span><span class="y"></span></a>
      </div>
      <ul class="bdList">
	  <?php echo latest('notice', 'news1', 3, 40); ?>
        <!-- <li><a href="#">
          <p class="label">교육안내</p>
          <p class="tit">권역호스피스센터 소식을 알려드립니다.</p>
          <p class="txt">권역호스피스센터 새로운 소식을 알려드리는 게시판입니다. 공지사항을 확인해보세요.</p>
          <p class="date">2022-01-26</p>
        </a></li>
        <li><a href="#">
          <p class="label">교육안내</p>
          <p class="tit">권역호스피스센터 소식을 알려드립니다.</p>
          <p class="txt">권역호스피스센터 새로운 소식을 알려드리는 게시판입니다. 공지사항을 확인해보세요.</p>
          <p class="date">2022-01-26</p>
        </a></li>
        <li><a href="#">
          <p class="label">교육안내</p>
          <p class="tit">권역호스피스센터 소식을 알려드립니다.</p>
          <p class="txt">권역호스피스센터 새로운 소식을 알려드리는 게시판입니다. 공지사항을 확인해보세요.</p>
          <p class="date">2022-01-26</p>
        </a></li> -->
      </ul>
    </div>

    <div id="newsletter">
      <div class="mtit">
        <h3><span class="fc-b">소식지</span>를 만나보세요.</h3>
      </div>
      <div class="newsSlide">
	  <?php echo latest('pic_main', 'news4', 6, 40); ?>
        <!-- <div class="item"><img src="/images/main/newsletter1.png" alt="" /></div>
        <div class="item"><img src="/images/main/newsletter2.png" alt="" /></div>
        <div class="item"><img src="/images/main/newsletter1.png" alt="" /></div>
        <div class="item"><img src="/images/main/newsletter2.png" alt="" /></div>
        <div class="item"><img src="/images/main/newsletter1.png" alt="" /></div>
        <div class="item"><img src="/images/main/newsletter2.png" alt="" /></div> -->
      </div>
    </div>
  </div>
</div>


<div id="mEdu">
  <div class="s-inner">
    <div class="mtit">
      <h3><span class="fc-r">교육신청</span>을 안내드립니다.</h3>
    </div>
    <div class="eduSlide">
		<?php
		$list_cnt = 6;//갯수

		$sql = "select * from st_event where ev_use = '1' order by ev_date desc, ev_sdate limit $list_cnt ";
		$result = sql_query($sql);

		for ($i=0; $row=sql_fetch_array($result); $i++) {
		$ev_id = $row['ev_id'];
		?>
		<?php
		$today = date("Y-m-d");
			$ev_sdate = $row["ev_sdate"];
			$ev_edate = $row["ev_edate"];

			$ev_asdate = $row["ev_asdate"];
			$ev_aedate = $row["ev_aedate"];

			$ev_join_max_cnt = $row["ev_join_max_cnt"];

			$ev_state = $row["ev_state"];

			$state_str = "";
			$day1 = dateDiff($ev_asdate, $today);
			$day2 = dateDiff($ev_aedate, $today);

		//	echo $day1;
		//	echo $day2;
			if($day1 > 0){
				$state_str = "접수전";
			}
			if ($day2 < 0){
				$state_str = "마감";
			}

			if($day1 <= 0 && $day2 >= 0){
				$state_str = "신청가능";
		//		$sql = "select count(*) as cnt from st_event_apply where ev_id = '".$row['ev_id']."' and mb_id = '".$member['mb_id']."' ";
		//		$row1 = sql_fetch($sql);
		//
		//		$cnt1 = $row1['cnt'];
		//
		//		if ($cnt1 > 0) $state_str = "수정";
		//		else $state_str = "참가신청";
			}

			if (trim($ev_state) != ""){
				$state_str = trim($ev_state); //행사종료
			}

			//신청자
			$sql = " select count(ea_id) as cnt from st_event_apply ea where ea.ev_id = '".$row['ev_id']."' ";
			$row1 = sql_fetch($sql);
			$apply_count = $row1['cnt'];

			if ((int)$ev_join_max_cnt > 0){
				if ((int)$ev_join_max_cnt <= $apply_count){
					$state_str = "마감";
				}
			}

			$ev_date = str_replace("-", ".", $ev_sdate);
			if (substr($ev_sdate, 0, 4) == substr($ev_edate, 0, 4)){
				$ev_date;
		//            .= " ~ ".substr(str_replace("-", ".", $ev_edate), 5, 5);
			}else{
				$ev_date .= " ~ ".str_replace("-", ".", $ev_edate);
			}

			$ev_adate = str_replace("-", ".", $ev_asdate);
			if (substr($ev_asdate, 0, 4) == substr($ev_aedate, 0, 4)){
				$ev_adate .= " ~ ".substr(str_replace("-", ".", $ev_aedate), 5, 5);
			}else{
				$ev_adate .= " ~ ".str_replace("-", ".", $ev_aedate);
			}



		?>
      <div class="item <?php if ($state_str == "접수중" || $state_str == "신청" || $state_str == "신청가능"){?>on<?php }else{?>off<?php }?>">
        <p class="label"><?=$state_str?></p>
        <p class="tit"><?php echo $row['ev_subject'] ?></p>
        <p class="txt"><?php echo $row['ev_target'] ?></p>
        <dl class="date">
          <dt>신청기간</dt>
          <dd><?php echo $row['ev_asdate']; ?> ~ <?php echo $row['ev_aedate']; ?></dd>
        </dl>
        <a href="/reservation/reservation_view.php?ev_id=<?php echo $row['ev_id']; ?>" class="btn_app"><?=$state_str?></a>
      </div>
    <?php
}
?>

	  <!-- <div class="item on">
        <p class="label">접수중</p>
        <p class="tit">호스피스·완화의료 전문인력 표준교육</p>
        <p class="txt">호스피스 필수인력의 기본교육인 60시간 표준교육 시행</p>
        <dl class="date">
          <dt>신청기간</dt>
          <dd>22.01.26 ~ 22.02.26</dd>
        </dl>
        <a href="#" class="btn_app">접수신청</a>
      </div>
      <div class="item off">
        <p class="label">접수마감</p>
        <p class="tit">호스피스·완화의료 전문인력 표준교육</p>
        <p class="txt">호스피스 필수인력의 기본교육인 60시간 표준교육 시행</p>
        <dl class="date">
          <dt>신청기간</dt>
          <dd>22.01.26 ~ 22.02.26</dd>
        </dl>
        <a href="#" class="btn_app">접수마감</a>
      </div>
      <div class="item on">
        <p class="label">접수중</p>
        <p class="tit">호스피스·완화의료 전문인력 표준교육</p>
        <p class="txt">호스피스 필수인력의 기본교육인 60시간 표준교육 시행</p>
        <dl class="date">
          <dt>신청기간</dt>
          <dd>22.01.26 ~ 22.02.26</dd>
        </dl>
        <a href="#" class="btn_app">접수신청</a>
      </div>
      <div class="item off">
        <p class="label">접수마감</p>
        <p class="tit">호스피스·완화의료 전문인력 표준교육</p>
        <p class="txt">호스피스 필수인력의 기본교육인 60시간 표준교육 시행</p>
        <dl class="date">
          <dt>신청기간</dt>
          <dd>22.01.26 ~ 22.02.26</dd>
        </dl>
        <a href="#" class="btn_app">접수마감</a>
      </div> -->

    </div>
  </div>
</div>


<div id="mBusiness">
  <div class="s-inner">
    <div class="mBusi">
      <dl class="tit">
        <dt>사업안내</dt>
        <dd>생의 마지막을 편안하게<br/> 맞이할 수 있도록</dd>
      </dl>
      <ul>
        <li><a href="javascript:GoPage('business1')"><i><img src="/images/main/ico_business1.png"></i><p>사업소개</p></a></li>
        <li><a href="javascript:GoPage('business2')"><i><img src="/images/main/ico_business2.png"></i><p>교육사업</p></a></li>
        <li><a href="javascript:GoPage('business3')"><i><img src="/images/main/ico_business3.png"></i><p>홍보사업</p></a></li>
        <li><a href="javascript:GoPage('business4')"><i><img src="/images/main/ico_business4.png"></i><p>지원연구사업</p></a></li>
      </ul>
    </div>

    <div class="mCenter">
      <a href="javascript:GoPage('news3')">
        <dl class="tit">
          <dt>센터 자료실</dt>
          <dd>환자와 그 가족의 삶의 질 향상을<br/> 위해 최선을 다하겠습니다.</dd>
        </dl>
        <!-- <div class="img"><img src="/images/main/center_intro.png" alt="" /></div> -->
      </a>
    </div>
  </div>
</div>


<script type="text/javascript" src="/js/main.js"></script>
<?php include "inc/bottom.php"; ?>
