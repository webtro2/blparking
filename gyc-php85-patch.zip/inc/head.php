<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="ko" />
    <meta name="viewport" content="initial-scale=1.0, width=device-width" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">

    <?php
    $site_name = "지와이 참미 하이텍스";
    $site_title = isset($page_title) && $page_title ? $page_title : (isset($g5['title']) && $g5['title'] ? $g5['title'] : $site_name);
    $site_description = isset($page_description) && $page_description ? $page_description : "공간의 가치를 더하는 프리미엄 윈도우 커버링 솔루션, 지와이 참미 하이텍스입니다.";
    $site_keywords = "지와이 참미 하이텍스, 지와이참미, 윈도우커버링, 블라인드, 롤스크린, 원단, 커튼, GY CHAMMI";

    // URL 및 도메인 동적 처리
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') ? "https://" : "http://";
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'gycm.co.kr';
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $current_url = $protocol . $host . $request_uri;
    $canonical_url = isset($canonical_url) && $canonical_url ? $canonical_url : $current_url;
    $base_url = $protocol . $host;
    $og_image_url = $base_url . "/og_img.png";
    ?>

    <title><?php echo htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8'); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($site_description, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta name="keywords" content="<?php echo htmlspecialchars($site_keywords, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="<?php echo htmlspecialchars($canonical_url, ENT_QUOTES, 'UTF-8'); ?>" />

    <!-- Open Graph -->
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="<?php echo htmlspecialchars($site_name, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta property="og:title" content="<?php echo htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta property="og:description" content="<?php echo htmlspecialchars($site_description, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta property="og:url" content="<?php echo htmlspecialchars($canonical_url, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta property="og:image" content="<?php echo htmlspecialchars($og_image_url, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:locale" content="ko_KR" />

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta name="twitter:description" content="<?php echo htmlspecialchars($site_description, ENT_QUOTES, 'UTF-8'); ?>" />
    <meta name="twitter:image" content="<?php echo htmlspecialchars($og_image_url, ENT_QUOTES, 'UTF-8'); ?>" />

    <!-- Schema.org JSON-LD Structured Data -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@graph": [{
                    "@type": "Organization",
                    "@id": "https://gycm.co.kr/#organization",
                    "name": "지와이 참미 하이텍스",
                    "url": "https://gycm.co.kr",
                    "logo": "https://gycm.co.kr/images/common/f_logo.webp",
                    "contactPoint": {
                        "@type": "ContactPoint",
                        "telephone": "+82-53-262-1106",
                        "contactType": "customer service",
                        "areaServed": "KR",
                        "availableLanguage": "Korean"
                    },
                    "address": {
                        "@type": "PostalAddress",
                        "streetAddress": "대구광역시 달서구 와룡로28길 101, 2층(감삼동)",
                        "addressLocality": "대구광역시 달서구",
                        "addressCountry": "KR"
                    }
                },
                {
                    "@type": "WebSite",
                    "@id": "https://gycm.co.kr/#website",
                    "url": "https://gycm.co.kr",
                    "name": "지와이 참미 하이텍스",
                    "description": "공간의 가치를 더하는 프리미엄 윈도우 커버링 솔루션, 지와이 참미 하이텍스입니다.",
                    "publisher": {
                        "@id": "https://gycm.co.kr/#organization"
                    }
                }
            ]
        }
    </script>

    <!-- Speakable JSON-LD Structured Data (AI / Voice Search) -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebPage",
            "speakable": {
                "@type": "SpeakableSpecification",
                "cssSelector": [
                    "h1",
                    ".page-description",
                    ".faq-answer"
                ]
            }
        }
    </script>
    <script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="/js/common.js"></script>
    <script type="text/javascript" src="/js/sub.js"></script>

    <link rel="stylesheet" type="text/css" href="/css/default.css?v=2" />
    <link rel="stylesheet" type="text/css" href="/css/layout.css?v=2" />
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=2" />
    <link rel="stylesheet" type="text/css" href="/css/sub.css?v=2" />
    <link rel="stylesheet" type="text/css" href="/css/scont.css?v=2" />
    <link rel="stylesheet" type="text/css" href="/css/aos.css?v=2" />
    <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
    <link href="https://cdn.jsdelivr.net/gh/sun-typeface/SUIT@2/fonts/static/woff2/SUIT.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200..900&display=swap" rel="stylesheet">

    <!-- slick -->
    <script src="/js/slick/slick.min.js"></script>
    <link rel="stylesheet" href="/js/slick/slick-theme.css">
    <link rel="stylesheet" href="/js/slick/slick.css">

</head>

<body>

    <div id="wrap">