<!-- header -->
<div id="header">
    <div class="w-inner">
        <h1 id="logo">
            <a href="/" aria-label="지와이 참미 하이텍스 메인으로 이동"></a>
        </h1>

        <div class="pcGnb">
            <?php include __DIR__ . "/nav.php"; ?>
        </div>

        <div class="r_btn">
            <div class="lang">
                <div class="current">KOR</div>
                <ul class="list">
                    <li><a href="javascript:GoPage('eng')">ENG</a></li>
                    <li><a href="javascript:GoPage('esp')">ESP</a></li>
                </ul>
            </div>

            <a href="javascript:GoPage('comm2')" class="cta">문의하기</a>

            <button type="button" class="menuToggle" id="menuToggle" aria-label="메뉴 열기">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>

    <div id="mGnb">
        <div class="m_inner">
            <div class="m_nav">
                <?php include __DIR__ . "/nav.php"; ?>
            </div>
            <div class="m_footer">
                <a href="javascript:GoPage('comm2')" class="m_cta">문의하기</a>
                <a href="https://wa.me/821087846808" target="_blank" rel="noopener" class="m_cta m_whatsapp">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M12.04 2c-5.52 0-10 4.48-10 10 0 1.77.46 3.45 1.26 4.9L2 22l5.25-1.26A9.96 9.96 0 0 0 12.04 22c5.52 0 10-4.48 10-10s-4.48-10-10-10zm5.84 14.3c-.25.7-1.24 1.28-2.03 1.45-.54.11-1.24.2-3.6-.77-2.95-1.22-4.85-4.2-5-4.4-.14-.2-1.2-1.6-1.2-3.05s.75-2.17 1.03-2.46c.25-.26.56-.33.75-.33h.54c.17 0 .4-.03.62.47.25.6.85 2.05.92 2.2.07.15.12.33.02.52-.1.2-.15.33-.3.5-.15.17-.3.37-.44.5-.14.14-.3.3-.13.6.17.3.76 1.24 1.62 2 1.12 1 2.05 1.3 2.36 1.45.3.15.48.12.65-.08.17-.2.74-.85.94-1.15.2-.3.4-.25.66-.15.27.1 1.7.8 2 .95.3.15.5.22.57.35.07.13.07.76-.18 1.46z" />
                    </svg>
                    WhatsApp
                </a>
            </div>
        </div>
    </div>
</div>
<!-- //header -->