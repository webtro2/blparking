<div class="f_bn">
    <div class="inner">
        <div class="m_txt" data-aos="fade-up">
            <h3>지와이참미는 <br>여러분을 기다립니다</h3>
            <p>궁금하신 부분에 대해 언제든지 문의주세요.</p>
        </div>

        <div class="btn_box">
            <a href="javascript:GoPage('comm2')" class="btn" data-aos="fade-up">
                <h4>문의하기</h4>
                <div class="icon"><img src="/images/common/f_bn_icon1.webp" alt=""></div>
            </a>
            <a href="javascript:GoPage('e_catalog')" class="btn" data-aos="fade-up">
                <h4>E-카달로그</h4>
                <div class="icon"><img src="/images/common/f_bn_icon2.webp" alt=""></div>
            </a>
        </div>
    </div>
</div>

<!-- footer -->
<div id="footer">
    <div class="w-inner">
        <div class="top_cont">
            <div class="l_cont">
                <div class="f_logo"><img src="/images/common/f_logo.webp" alt=""></div>
                <div class="info">
                    <span>지와이 참미 하이텍스</span>
                    <span>대표 : 이진호</span>
                    <span>사업자등록번호 : 660-01-02113</span> <br>
                    <span>사무실 주소 : 대구광역시 달서구 와룡로28길 101, 2층(감삼동)</span><br>
                    <span>공장 주소 : 대구시 달성군 옥포읍 이팝나무길 114</span><br>
                    <span>대표전화 : +82-10-8784-6808 / +82-53-262-1106</span>
                    <span>팩스번호 : 070-4790-1102</span> <br>
                    <span>이메일 : gychammi.jin@gmail.com / gychammi21@naver.com</span>
                </div>
            </div>

            <ul class="r_cont">
                <li><a href="javascript:GoPage('intro3')">오시는 길</a></li>
                <li><a href="javascript:GoPage('terms')">이용약관</a></li>
                <li><a href="javascript:GoPage('privacy')"><b>개인정보처리방침</b></a></li>
            </ul>
        </div>

        <div class="bottom_cont">
            <p class="copy">Copyright &copy; 2026 GY CHAMMI HIGH TEX. All Rights Reserved.</p>
            <p class="copy"><a href="https://webtro.co.kr" target="_blank">Designed By 웹트로</a></p>
        </div>
    </div>
</div>
<!-- //footer -->

<!-- quick menu -->
<div id="quick">
    <a href="javascript:GoPage('e_catalog')" class="q_btn q_catalog" aria-label="E-카달로그 보기">
        <span class="icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
            </svg>
        </span>
        <span class="txt">카달로그</span>
    </a>
    <a href="https://wa.me/821087846808" target="_blank" rel="noopener" class="q_btn q_whatsapp" aria-label="WhatsApp으로 문의하기">
        <span class="icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12.04 2c-5.52 0-10 4.48-10 10 0 1.77.46 3.45 1.26 4.9L2 22l5.25-1.26A9.96 9.96 0 0 0 12.04 22c5.52 0 10-4.48 10-10s-4.48-10-10-10zm5.84 14.3c-.25.7-1.24 1.28-2.03 1.45-.54.11-1.24.2-3.6-.77-2.95-1.22-4.85-4.2-5-4.4-.14-.2-1.2-1.6-1.2-3.05s.75-2.17 1.03-2.46c.25-.26.56-.33.75-.33h.54c.17 0 .4-.03.62.47.25.6.85 2.05.92 2.2.07.15.12.33.02.52-.1.2-.15.33-.3.5-.15.17-.3.37-.44.5-.14.14-.3.3-.13.6.17.3.76 1.24 1.62 2 1.12 1 2.05 1.3 2.36 1.45.3.15.48.12.65-.08.17-.2.74-.85.94-1.15.2-.3.4-.25.66-.15.27.1 1.7.8 2 .95.3.15.5.22.57.35.07.13.07.76-.18 1.46z" />
            </svg>
        </span>
        <span class="txt">WhatsApp</span>
    </a>
    <a href="javascript:GoPage('comm2')" class="q_btn q_inquiry" aria-label="온라인 문의하기">
        <span class="icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
        </span>
        <span class="txt">문의하기</span>
    </a>
    <button type="button" class="q_btn q_top" id="quickTop" aria-label="페이지 맨 위로 이동">
        <span class="icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 15l-6-6-6 6" />
            </svg>
        </span>
    </button>
</div>
<!-- //quick menu -->

</div>

<script type="text/javascript">
    $(function() {
        subFunc.snb("<?php  echo ($s_num ?? ''); ?>", "<?php  echo ($p_num ?? ''); ?>");

        $("#quickTop").on("click", function() {
            $("html, body").animate({
                scrollTop: 0
            }, 400);
        });
    });
</script>
<script src="/js//aos/aos.js"></script>
<script>
    AOS.init({
        duration: 600,
        offset: 0,
        delay: 100,
        easing: 'ease-out-quad',
    });
</script>
<script src="/js/sub.js"></script>

</body>

</html>