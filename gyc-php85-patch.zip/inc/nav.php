<ul class="gnb">
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('intro1')">회사소개</a></div>
        <?php include __DIR__ . "/s_gnb1.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('product1')">제품소개</a></div>
        <?php include __DIR__ . "/s_gnb2.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('comm1')">고객지원</a></div>
        <?php include __DIR__ . "/s_gnb3.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('project1')">프로젝트</a></div>
        <?php include __DIR__ . "/s_gnb6.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('e_catalog')">E-카달로그</a></div>
    </li>
</ul>