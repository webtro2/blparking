<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "인증서 | 지와이 참미 하이텍스";
include "../inc/head.php";
include "../inc/link.php";
include "../inc/top.php";
?>
<?php 
$s_num = "1";
$p_num = "3";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<?php
include_once "../inc/cert_data.php";
$cert_list = $cert_data_list;
?>

<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro3">
        <div id="subTitle">
            <span class="vis_dep02">인증서</span>
        </div>

        <div class="inner">
            <section class="sec sec_cert_top">
                <div class="s_txt" data-aos="fade-up">
                    <h3>인증서</h3>
                    <p>지와이 참미 하이텍스의 특허 및 인증 현황입니다.</p>
                </div>

                <!-- 카테고리 탭 -->
                <div class="cert_tab" data-aos="fade-up">
                    <ul class="tab_list">
                        <li class="on" data-target="cert"><button type="button">인증서</button></li>
                        <li data-target="patent"><button type="button">특허증</button></li>
                        <li data-target="report"><button type="button">시험성적서</button></li>
                    </ul>
                </div>

                <!-- 인증서 그리드 (타이틀과 이미지만 심플하게 구성) -->
                <div class="cert_grid">
                    <?php foreach ($cert_list as $item): ?>
                        <?php
                        $page_count = count($item['images']);
                        $thumb_img = $item['images'][0];
                        $json_images = htmlspecialchars(json_encode($item['images']), ENT_QUOTES, 'UTF-8');
                        $cert_category = isset($item['category']) ? $item['category'] : 'cert';
                        ?>
                        <div class="cert_card<?= $cert_category === 'cert' ? '' : ' is-hidden' ?>"
                            data-category="<?= htmlspecialchars($cert_category) ?>"
                            data-title="<?= htmlspecialchars($item['title']) ?>"
                            data-images='<?= $json_images ?>' data-aos="fade-up">

                            <!-- 대표 이미지 영역 -->
                            <div class="thumb_wrap">
                                <div class="img_box">
                                    <img src="<?= $thumb_img ?>" alt="<?= htmlspecialchars($item['title']) ?>" loading="lazy">
                                </div>
                            </div>

                            <!-- 타이틀 영역 -->
                            <div class="info_wrap">
                                <h4><?= $item['title'] ?></h4>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- 원본 레이어 팝업 (라이트박스) -->
<div id="certLightbox" class="cert_lightbox" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="modal_container">
        <!-- 팝업 상단 헤더 -->
        <div class="modal_header">
            <div class="title_area">
                <span class="modal_title" id="certModalTitle"></span>
            </div>
            <button type="button" class="btn_close" id="certModalClose" aria-label="팝업 닫기">&times;</button>
        </div>

        <!-- 팝업 본문 (이미지 뷰어) -->
        <div class="modal_body">
            <button type="button" class="nav_btn btn_prev" id="certBtnPrev" aria-label="이전 페이지">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>

            <img src="" alt="" class="main_image" id="certMainImage">

            <button type="button" class="nav_btn btn_next" id="certBtnNext" aria-label="다음 페이지">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>
        </div>

        <!-- 팝업 하단 (여러 장일 때 넘겨볼 수 있는 썸네일 스트립) -->
        <div class="modal_footer" id="certModalFooter">
            <div class="thumb_strip" id="certThumbStrip"></div>
        </div>
    </div>
</div>

<script>
    (function($) {
        $(function() {
            var $cards = $('.cert_card');
            var $lightbox = $('#certLightbox');
            var $modalTitle = $('#certModalTitle');
            var $pageIndicator = $('#certPageIndicator');
            var $mainImage = $('#certMainImage');
            var $btnPrev = $('#certBtnPrev');
            var $btnNext = $('#certBtnNext');
            var $btnClose = $('#certModalClose');
            var $modalFooter = $('#certModalFooter');
            var $thumbStrip = $('#certThumbStrip');

            // 카테고리 탭 필터
            $('.cert_tab .tab_list li').on('click', function() {
                var target = $(this).data('target');

                $('.cert_tab .tab_list li').removeClass('on');
                $(this).addClass('on');

                $cards.each(function() {
                    $(this).toggleClass('is-hidden', $(this).data('category') !== target);
                });
            });

            var currentImages = [];
            var currentIndex = 0;
            var currentTitle = '';

            function updateModalView() {
                if (!currentImages.length) return;

                var total = currentImages.length;
                var currentSrc = currentImages[currentIndex];

                $mainImage.attr('src', currentSrc);
                $modalTitle.text(currentTitle);

                if (total > 1) {
                    $btnPrev.show();
                    $btnNext.show();
                    $modalFooter.show();

                    $thumbStrip.find('.thumb_strip_item').removeClass('is-active')
                        .eq(currentIndex).addClass('is-active');
                } else {
                    $btnPrev.hide();
                    $btnNext.hide();
                    $modalFooter.hide();
                }
            }

            function openModal(title, images) {
                currentTitle = title;
                currentImages = images || [];
                currentIndex = 0;

                $thumbStrip.empty();
                if (currentImages.length > 1) {
                    currentImages.forEach(function(src, i) {
                        var $thumbItem = $('<div class="thumb_strip_item"><img src="' + src + '" alt="페이지 ' + (i + 1) + '"></div>');
                        $thumbItem.on('click', function() {
                            currentIndex = i;
                            updateModalView();
                        });
                        $thumbStrip.append($thumbItem);
                    });
                }

                updateModalView();
                $lightbox.addClass('is-open').attr('aria-hidden', 'false');
                $('body').css('overflow', 'hidden');
            }

            function closeModal() {
                $lightbox.removeClass('is-open').attr('aria-hidden', 'true');
                $mainImage.attr('src', '');
                currentImages = [];
                currentIndex = 0;
                $('body').css('overflow', '');
            }

            function goPrev() {
                if (currentImages.length <= 1) return;
                currentIndex = (currentIndex - 1 + currentImages.length) % currentImages.length;
                updateModalView();
            }

            function goNext() {
                if (currentImages.length <= 1) return;
                currentIndex = (currentIndex + 1) % currentImages.length;
                updateModalView();
            }

            // 카드 클릭 시 팝업 열기
            $cards.on('click', function(e) {
                e.preventDefault();
                var $card = $(this);
                var title = $card.data('title');
                var rawImages = $card.attr('data-images');
                var images = [];

                try {
                    images = JSON.parse(rawImages);
                } catch (err) {
                    images = [$card.find('img').attr('src')];
                }

                openModal(title, images);
            });

            // 이전/다음 화살표 클릭
            $btnPrev.on('click', function(e) {
                e.stopPropagation();
                goPrev();
            });

            $btnNext.on('click', function(e) {
                e.stopPropagation();
                goNext();
            });

            // 닫기 버튼
            $btnClose.on('click', function() {
                closeModal();
            });

            // 배경 클릭 시 닫기
            $lightbox.on('click', function(e) {
                if ($(e.target).closest('.modal_container').length === 0) {
                    closeModal();
                }
            });

            // ESC, 방향키 조작
            $(document).on('keydown', function(e) {
                if (!$lightbox.hasClass('is-open')) return;

                if (e.keyCode === 27) {
                    closeModal();
                } else if (e.keyCode === 37) {
                    goPrev();
                } else if (e.keyCode === 39) {
                    goNext();
                }
            });
        });
    })(jQuery);
</script>

<?php include "../inc/bottom.php"; ?>