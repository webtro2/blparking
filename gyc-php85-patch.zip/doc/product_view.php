<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "2";
$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<!-- Sub Content -->
<div id="subContent">
    <div id="pageCont" class="product_view">
        <div id="subTitle">
            <span class="vis_dep02">제품소개</span>
        </div>

        <div class="inner">
            <section class="sec sec_view_top">
                <div class="view_wrap">
                    <div class="view_gallery">
                        <div class="main_img_box">
                            <img id="mainProductImg" src="/images/main/sec4_img1.webp" alt="네이처 콤비 솔리드">

                            <div class="color_switcher_overlay">
                                <span class="switcher_label">COLOR</span>
                                <ul class="color_chips">
                                    <li class="chip on" data-img="/images/main/sec4_img1.webp" data-color="크림 아이보리" style="background-color: #e8e0d5;" title="크림 아이보리"></li>
                                    <li class="chip" data-img="/images/main/sec1_img1.webp" data-color="애쉬 그레이" style="background-color: #7d8792;" title="애쉬 그레이"></li>
                                    <li class="chip" data-img="/images/main/sec3_img1.webp" data-color="다크 차콜" style="background-color: #2b303a;" title="다크 차콜"></li>
                                    <li class="chip" data-img="/images/sub/intro1_bg1.webp" data-color="웜 베이지" style="background-color: #9e8d7d;" title="웜 베이지"></li>
                                    <li class="chip" data-img="/images/main/sec5_img1.webp" data-color="딥 네이비" style="background-color: #2c3e50;" title="딥 네이비"></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="view_info">
                        <div class="info_header">
                            <h3 class="prod_title" id="prodTitle">네이처 콤비 솔리드</h3>
                        </div>

                        <div class="spec_table_wrap">
                            <table class="spec_table">
                                <colgroup>
                                    <col style="width: 28%;">
                                    <col style="width: 72%;">
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>원단 구분</th>
                                        <td>콤비 블라인드 (Combi Blind)</td>
                                    </tr>
                                    <tr>
                                        <th>소재 구성</th>
                                        <td>Polyester 100%</td>
                                    </tr>
                                    <tr>
                                        <th>원단 폭</th>
                                        <td>2,800mm (280cm)</td>
                                    </tr>
                                    <tr>
                                        <th>중량</th>
                                        <td>165g/㎡ ± 5%</td>
                                    </tr>
                                    <tr>
                                        <th>리피트</th>
                                        <td>Solid 10cm / Mesh 6.5cm</td>
                                    </tr>
                                    <tr>
                                        <th>일광 견뢰도</th>
                                        <td>4급 이상 (Grade 4+)</td>
                                    </tr>
                                    <tr>
                                        <th>포장 단위</th>
                                        <td>50m / Roll</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="view_btn_area">
                            <a href="/doc/comm2.php?prod=네이처 콤비 솔리드 (크림 아이보리)" id="btnInquiry" class="btn_inquiry">상품 문의하기</a>
                            <a href="/doc/product1.php" class="btn_list">목록으로</a>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var prodName = $('#prodTitle').text().trim();

        $('.color_chips .chip').on('click', function() {
            var $this = $(this);
            var targetImg = $this.attr('data-img');
            var colorName = $this.attr('data-color');

            $('.color_chips .chip').removeClass('on');
            $this.addClass('on');

            var inquiryUrl = '/doc/comm2.php?prod=' + encodeURIComponent(prodName + ' (' + colorName + ')');
            $('#btnInquiry').attr('href', inquiryUrl);

            var $mainImg = $('#mainProductImg');
            $mainImg.stop().animate({
                opacity: 0.3
            }, 150, function() {
                $mainImg.attr('src', targetImg);
                $mainImg.stop().animate({
                    opacity: 1
                }, 200);
            });
        });
    });
</script>

<?php include "../inc/bottom.php"; ?>