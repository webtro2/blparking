<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "인사말 | 지와이 참미 하이텍스";
include "../inc/head.php";
include "../inc/link.php";
include "../inc/top.php";
?>

<?php 
$s_num = "1";
$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro1">
        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">
            <!-- 1. 회사소개 (사진 + 헤드라인) -->
            <section class="sec sec_greeting">
                <div class="greet_wrap" data-aos="fade-up">
                    <div class="greet_txt">
                        <span class="eyebrow">회사소개</span>
                        <h3>모든 창에 가치를 더하는<br>원단을 만듭니다.</h3>
                        <p class="sub_tit">프리미엄 블라인드 원단 전문 제조기업 <strong>GY CHAMMI</strong></p>
                        <p class="desc">
                            GY CHAMMI는 2020년에 설립된 프리미엄 블라인드 원단 전문 제조기업으로, 블라인드 원단에 대한 전문적인 기술력과 축적된 제직 노하우를 바탕으로 공간의 가치를 높이는 고품질 윈도우 커버링 원단을 생산하고 있습니다.
                        </p>
                    </div>
                    <div class="greet_img">
                        <img src="/images/sub/intro1_bg1_261020.webp" alt="지와이 참미 하이텍스 블라인드 원단">
                    </div>
                </div>
            </section>

            <!-- 2. 핵심 가치 -->
            <section class="sec sec_point">
                <ul class="point_list" data-aos="fade-up">
                    <li>
                        <div class="ico">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M6 3h12l3 5-9 13L3 8z" />
                                <path d="M3 8h18" />
                                <path d="M9 3 8 8l4 13 4-13-1-5" />
                            </svg>
                        </div>
                        <h4>젊은 에너지와<br>지속적인 혁신</h4>
                        <p>도전 정신을 바탕으로 끊임없는 연구와 품질 혁신을 이어가며, 기능성과 내구성, 세련된 디자인을 갖춘 제품으로 고객의 다양한 요구에 부응합니다.</p>
                    </li>
                    <li>
                        <div class="ico">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="3" />
                                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                            </svg>
                        </div>
                        <h4>신뢰할 수 있는<br>품질과 서비스</h4>
                        <p>원사 선정부터 제직, 후가공, 검사, 포장까지 모든 공정을 철저한 품질관리 기준에 따라 관리하여 일관된 품질과 높은 만족도를 보장합니다.</p>
                    </li>
                    <li>
                        <div class="ico">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="9" />
                                <path d="M3 12h18" />
                                <path d="M12 3a14 14 0 0 1 0 18" />
                                <path d="M12 3a14 14 0 0 0 0 18" />
                            </svg>
                        </div>
                        <h4>글로벌 시장을 향한<br>더 큰 도약</h4>
                        <p>세계적인 경쟁력을 갖춘 제조기업으로서 변화하는 시장과 고객의 기대에 발맞춰 더 우수한 제품과 서비스를 제공하기 위해 끊임없이 노력하고 있습니다.</p>
                    </li>
                </ul>
            </section>

            <!-- 3. 주요 제품 -->
            <section class="sec sec_prod_intro">
                <div class="prod_intro_wrap" data-aos="fade-up">
                    <div class="prod_intro_txt">
                        <span class="eyebrow">주요제품</span>
                        <h3>다양한 창의 스타일을 완성하는<br>프리미엄 블라인드 원단</h3>
                        <p>롤러 블라인드 원단과 콤비 블라인드 원단을 비롯한 다양한 윈도우 커버링 소재를 전문적으로 생산하며, 기능성과 내구성, 현대적인 디자인을 갖춘 제품을 제공합니다.</p>
                    </div>
                    <div class="prod_intro_visual">
                        <img src="/images/sub/intro1_bg2.webp" alt="지와이 참미 하이텍스 블라인드 원단 제품">
                    </div>
                </div>
            </section>

            <!-- 4. 하단 서명 -->
            <section class="sec sec_signature">
                <div class="signature_wrap" data-aos="fade-up">
                    <h3>품질, 혁신, 신뢰를 바탕으로</h3>
                    <p>
                        GY CHAMMI는 고객과의 장기적인 파트너십을 소중히 여기며,<br>
                        글로벌 윈도우 커버링 시장에서 신뢰할 수 있는 최고의 파트너가 되기 위해 지속적으로 노력하겠습니다.
                    </p>
                    <div class="signature_name">GY CHAMMI 일동</div>
                </div>
            </section>
        </div>
    </div>
</div>




<?php include "../inc/bottom.php"; ?>