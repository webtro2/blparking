<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "_common.php"; ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "3";
$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="comm2">
        <div id="subTitle">
            <span class="vis_dep02">온라인 문의</span>
        </div>

        <div class="inner">
            <section class="sec sec_inquiry_top">

                <!-- 빠른 안내 바 -->
                <div class="inquiry_info_bar">
                    <div class="info_col">
                        <span class="tit">고객센터</span>
                        <span class="val">053-000-0000</span>
                    </div>
                    <div class="info_col">
                        <span class="tit">이메일 문의</span>
                        <span class="val"><a href="mailto:gychammi@naver.com">gychammi@naver.com</a></span>
                    </div>
                    <div class="info_col">
                        <span class="tit">상담 시간</span>
                        <span class="val">평일 09:00 ~ 18:00 (주말/공휴일 휴무)</span>
                    </div>
                </div>

                <!-- 문의 폼 -->
                <form name="fwrite2" id="fwrite2" action="/pg/bbs/write_update.php?type=quick" onsubmit="return fwrite_submit2(this);" method="post" enctype="multipart/form-data" autocomplete="off">
                    <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
                    <input type="hidden" name="w" value="<?php echo $w ?>">
                    <input type="hidden" name="bo_table" value="comm2">
                    <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
                    <input type="hidden" name="sca" value="<?php echo $sca ?>">
                    <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
                    <input type="hidden" name="stx" value="<?php echo $stx ?>">
                    <input type="hidden" name="spt" value="<?php echo $spt ?>">
                    <input type="hidden" name="sst" value="<?php echo $sst ?>">
                    <input type="hidden" name="sod" value="<?php echo $sod ?>">
                    <input type="hidden" name="page" value="<?php echo $page ?>">
                    <div class="form_box">
                        <div class="form_table">
                            <!-- 문의 유형 -->
                            <div class="form_row">
                                <div class="form_th"><label>문의 유형 <span class="req">*</span></label></div>
                                <div class="form_td">
                                    <div class="radio_group">
                                        <label class="custom_radio">
                                            <input type="radio" name="ca_name" value="제품 및 원단 문의" checked>
                                            <span class="r_txt">제품 및 원단 문의</span>
                                        </label>
                                        <label class="custom_radio">
                                            <input type="radio" name="ca_name" value="수출 및 대량 견적 문의">
                                            <span class="r_txt">수출 및 대량 견적 문의</span>
                                        </label>
                                        <label class="custom_radio">
                                            <input type="radio" name="ca_name" value="샘플 요청">
                                            <span class="r_txt">샘플 요청</span>
                                        </label>
                                        <label class="custom_radio">
                                            <input type="radio" name="ca_name" value="기타 제휴 문의">
                                            <span class="r_txt">기타 제휴 문의</span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- 회사명 / 고객명 -->
                            <div class="form_row form_row_half">
                                <div class="half_cell">
                                    <div class="form_th"><label for="wr_1">회사명 (업체명)</label></div>
                                    <div class="form_td">
                                        <input type="text" name="wr_1" id="wr_1" class="input_text" placeholder="회사명을 입력해 주세요">
                                    </div>
                                </div>
                                <div class="half_cell">
                                    <div class="form_th"><label for="wr_name">담당자명 (성함) <span class="req">*</span></label></div>
                                    <div class="form_td">
                                        <input type="text" name="wr_name" id="wr_name" class="input_text" placeholder="성함을 입력해 주세요" required>
                                    </div>
                                </div>
                            </div>

                            <!-- 연락처 / 이메일 -->
                            <div class="form_row form_row_half">
                                <div class="half_cell">
                                    <div class="form_th"><label for="wr_2">연락처 <span class="req">*</span></label></div>
                                    <div class="form_td">
                                        <input type="tel" name="wr_2" id="wr_2" class="input_text" placeholder="예: 010-0000-0000" required>
                                    </div>
                                </div>
                                <div class="half_cell">
                                    <div class="form_th"><label for="wr_email">이메일 <span class="req">*</span></label></div>
                                    <div class="form_td">
                                        <input type="email" name="wr_email" id="wr_email" class="input_text" placeholder="예: example@domain.com" required>
                                    </div>
                                </div>
                            </div>

                            <?php 
                            $prod = isset($_GET['prod']) ? htmlspecialchars(trim($_GET['prod'])) : '';
                            $default_subject = !empty($prod) ? '[' . $prod . '] 제품 문의' : '';
                            ?>
                            <!-- 제목 -->
                            <div class="form_row">
                                <div class="form_th"><label for="wr_subject">문의 제목 <span class="req">*</span></label></div>
                                <div class="form_td">
                                    <input type="text" name="wr_subject" id="wr_subject" class="input_text" placeholder="문의 제목을 입력해 주세요" value="<?php echo $default_subject; ?>" required>
                                </div>
                            </div>

                            <!-- 내용 -->
                            <div class="form_row">
                                <div class="form_th"><label for="wr_content">문의 내용 <span class="req">*</span></label></div>
                                <div class="form_td">
                                    <textarea name="wr_content" id="wr_content" class="textarea_box" rows="8" placeholder="필요하신 품목, 수량, 규격, 납기 일정 등 구체적인 문의 내용을 작성해 주시면 더욱 신속한 답변이 가능합니다." required></textarea>
                                </div>
                            </div>

                            <!-- 파일 첨부 -->
                            <div class="form_row">
                                <div class="form_th"><label for="bf_file_0">파일 첨부</label></div>
                                <div class="form_td">
                                    <div class="file_upload_box">
                                        <input type="file" name="bf_file[]" id="bf_file_0" class="file_input">
                                        <div class="file_custom">
                                            <input type="text" id="file_name_display" class="input_text file_text" placeholder="선택된 파일이 없습니다" readonly>
                                            <label for="bf_file_0" class="btn_file">파일 선택</label>
                                        </div>
                                    </div>
                                    <p class="file_guide">※ 최대 20MB까지 첨부하실 수 있습니다.</p>
                                </div>
                            </div>

                            <!-- 개인정보 수집 및 이용 동의 -->
                            <div class="form_row">
                                <div class="form_th"><label>개인정보 처리 <span class="req">*</span></label></div>
                                <div class="form_td">
                                    <div class="privacy_box">
                                        <div class="privacy_content">
                                            <strong>1. 수집하는 개인정보 항목</strong>: 성명, 회사명, 연락처, 이메일, 문의내용<br>
                                            <strong>2. 개인정보의 수집 및 이용목적</strong>: 문의 사항에 대한 답변 및 고객 상담 원활한 진행<br>
                                            <strong>3. 개인정보의 보유 및 이용기간</strong>: 문의 처리 완료 후 관련 법령에 따라 일정 기간 보관 후 파기
                                        </div>
                                        <label class="custom_checkbox">
                                            <input type="checkbox" name="agree_privacy" id="agree_privacy" value="Y" required>
                                            <span class="c_txt">개인정보 수집 및 이용에 동의합니다. (필수)</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 버튼 영역 -->
                        <div class="form_btn_area">
                            <button type="submit" class="btn_submit">문의 접수하기</button>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    </div>
</div>

<script>
    function fwrite2_submit(f) {
        if (!f.agree_privacy.checked) {
            alert('개인정보 수집 및 이용에 동의해 주세요.');
            f.agree_privacy.focus();
            return false;
        }
        if (!f.wr_name.value.trim()) {
            alert('성함을 입력해 주세요.');
            f.wr_name.focus();
            return false;
        }
        if (!f.wr_2.value.trim()) {
            alert('연락처를 입력해 주세요.');
            f.wr_2.focus();
            return false;
        }
        if (!f.wr_email.value.trim()) {
            alert('이메일을 입력해 주세요.');
            f.wr_email.focus();
            return false;
        }
        if (!f.wr_subject.value.trim()) {
            alert('문의 제목을 입력해 주세요.');
            f.wr_subject.focus();
            return false;
        }
        if (!f.wr_content.value.trim()) {
            alert('문의 내용을 입력해 주세요.');
            f.wr_content.focus();
            return false;
        }

        var fileInput = document.getElementById('bf_file_0');
        if (fileInput && fileInput.files && fileInput.files[0]) {
            var maxSize = 20 * 1024 * 1024; // 20MB
            if (fileInput.files[0].size > maxSize) {
                alert('첨부파일 용량은 최대 20MB까지 첨부 가능합니다.');
                fileInput.value = '';
                $('#file_name_display').val('선택된 파일이 없습니다');
                return false;
            }
        }

        return true;
    }

    $(document).ready(function() {
        // 파일명 표시 연동 및 20MB 용량 제한 검사
        $('#bf_file_0').on('change', function() {
            var file = this.files ? this.files[0] : null;
            var maxSize = 20 * 1024 * 1024; // 20MB

            if (file) {
                if (file.size > maxSize) {
                    alert('첨부파일 용량은 최대 20MB까지 첨부 가능합니다.');
                    $(this).val('');
                    $('#file_name_display').val('선택된 파일이 없습니다');
                    return false;
                }
                var fileName = file.name || $(this).val().split('\\').pop();
                $('#file_name_display').val(fileName);
            } else {
                $('#file_name_display').val('선택된 파일이 없습니다');
            }
        });
    });
</script>

<?php include "../inc/bottom.php"; ?>