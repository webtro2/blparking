<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "회사개요 | 지와이 참미 하이텍스";
include "../inc/head.php";
include "../inc/link.php";
include "../inc/top.php";
?>

<?php 
$s_num = "1";
$p_num = "2";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro2">
        <div id="subTitle">
            <span class="vis_dep02">회사개요</span>
        </div>

        <!-- 1. 회사 개요 -->
        <div class="inner">
            <section class="sec sec_profile">
                <div class="s_txt" data-aos="fade-up">
                    <h3>회사 개요</h3>
                    <p>공간의 가치를 더하는 프리미엄 블라인드 원단 제조기업</p>
                </div>

                <div class="profile_box" data-aos="fade-up">
                    <div class="img">
                        <img src="/images/main/sec1_img1.webp" alt="회사 전경">
                    </div>
                    <div class="table_wrap">
                        <table class="profile_table">
                            <colgroup>
                                <col>
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>회사명</th>
                                    <td>(주)지와이 참미 하이텍스</td>
                                </tr>
                                <tr>
                                    <th>대표자</th>
                                    <td>이진호</td>
                                </tr>
                                <tr>
                                    <th>설립일</th>
                                    <td>2020년</td>
                                </tr>
                                <tr>
                                    <th>주요사업</th>
                                    <td>프리미엄 윈도우 커버링 원단 제조 및 수출</td>
                                </tr>
                                <tr>
                                    <th>주요품목</th>
                                    <td>롤러 블라인드 원단, 콤비 블라인드 원단, 방염 및 기능성 원단</td>
                                </tr>
                                <tr>
                                    <th>글로벌 시장</th>
                                    <td>미국, 캐나다, 멕시코, 에콰도르, 콜롬비아, 스페인, 폴란드, 베트남, 대만 등</td>
                                </tr>
                                <tr>
                                    <th>주소</th>
                                    <td>대구광역시 달서구 와룡로28길 101, 2층(감삼동)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>


        <!-- 2. 4대 핵심가치 -->
        <section class="sec sec_values">
            <div class="inner">
                <div class="s_txt" data-aos="fade-up">
                    <h3>4대 핵심가치</h3>
                    <p>품질, 혁신, 신뢰를 바탕으로 고객이 신뢰할 수 있도록</p>
                </div>

                <ul class="value_list" data-aos="fade-up">
                    <li>
                        <div class="img"><img src="/images/main/sec4_img1.webp" alt=""></div>
                        <div class="txt">
                            <h4>Young</h4>
                            <p>트렌디한 감각, 젊은 에너지로 글로벌 트렌드를 기민하게 분석하여 현대적이고 세련된 공간을 디자인합니다.</p>
                        </div>
                    </li>
                    <li>
                        <div class="img"><img src="/images/main/sec4_img2.webp" alt=""></div>
                        <div class="txt">
                            <h4>Quality</h4>
                            <p>원사 선정부터 제직, 후가공, 검사, 포장까지 철저한 품질관리 기준에 따라 안정적인 품질을 보장합니다.</p>
                        </div>
                    </li>
                    <li>
                        <div class="img"><img src="/images/main/sec4_img3.webp" alt=""></div>
                        <div class="txt">
                            <h4>Innovation</h4>
                            <p>끊임없는 직조 기술 혁신과 기능성 신소재 연구를 통해 프리미엄 윈도우 커버링 시장을 선도합니다.</p>
                        </div>
                    </li>
                    <li>
                        <div class="img"><img src="/images/main/sec4_img4.webp" alt=""></div>
                        <div class="txt">
                            <h4>Trust</h4>
                            <p>안정적인 공급과 신뢰할 수 있는 제품으로 전 세계 고객들과 지속 가능한 파트너십을 구축합니다.</p>
                        </div>
                    </li>
                </ul>
            </div>
        </section>


        <!-- 3. 글로벌 네트워크 -->
        <section class="sec sec_network">
            <div class="inner">
                <div class="s_txt" data-aos="fade-up">
                    <h3>글로벌 네트워크</h3>
                    <p>지와이 참미 하이텍스는 전 세계로, 더 넓은 가치를 전달합니다.</p>
                </div>
            </div>

            <div class="map_area">
                <div class="map_wrap" data-aos="fade-up">
                    <img src="/images/main/worldmap-dots.svg" alt="" class="map_dots" draggable="false">

                    <svg viewBox="0 0 198 100" class="map_svg" xmlns="http://www.w3.org/2000/svg">
                        <!-- Vietnam -->
                        <g class="map_node">
                            <circle cx="162.2" cy="52" r="0.75" fill="#227fcb" />
                            <circle cx="162.2" cy="52" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="0s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="0s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Spain -->
                        <g class="map_node">
                            <circle cx="97.0" cy="34" r="0.75" fill="#227fcb" />
                            <circle cx="97.0" cy="34" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="0.2s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="0.2s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Poland -->
                        <g class="map_node">
                            <circle cx="110.6" cy="23.5" r="0.75" fill="#227fcb" />
                            <circle cx="110.6" cy="23.5" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="0.4s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="0.4s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Colombia -->
                        <g class="map_node">
                            <circle cx="55" cy="57" r="0.75" fill="#227fcb" />
                            <circle cx="55" cy="57" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="0.6s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="0.6s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Ecuador -->
                        <g class="map_node">
                            <circle cx="53" cy="61.5" r="0.75" fill="#227fcb" />
                            <circle cx="53" cy="61.5" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="0.8s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="0.8s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Mexico -->
                        <g class="map_node">
                            <circle cx="38" cy="44" r="0.75" fill="#227fcb" />
                            <circle cx="38" cy="44" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="1.0s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="1.0s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- USA -->
                        <g class="map_node">
                            <circle cx="47" cy="35" r="0.75" fill="#227fcb" />
                            <circle cx="47" cy="35" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="1.2s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="1.2s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Canada -->
                        <g class="map_node">
                            <circle cx="32" cy="20" r="0.75" fill="#227fcb" />
                            <circle cx="32" cy="20" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="1.4s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="1.4s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Taiwan -->
                        <g class="map_node">
                            <circle cx="170" cy="45.5" r="0.75" fill="#227fcb" />
                            <circle cx="170" cy="45.5" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="1.6s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="1.6s" repeatCount="indefinite" />
                            </circle>
                        </g>
                        <!-- Korea (HQ) -->
                        <g class="map_node">
                            <circle cx="174" cy="37.1" r="0.75" fill="#227fcb" />
                            <circle cx="174" cy="37.1" r="0.75" fill="#227fcb" opacity="0.5">
                                <animate attributeName="r" from="0.75" to="3" dur="1.6s" begin="1.8s" repeatCount="indefinite" />
                                <animate attributeName="opacity" from="0.6" to="0" dur="1.6s" begin="1.8s" repeatCount="indefinite" />
                            </circle>
                        </g>
                    </svg>

                    <!-- Point Country Flag Images (Official High-Quality FlagCDN) -->
                    <div class="map_pin pin_ca" style="left: 16.16%; top: 20%;" title="캐나다">
                    </div>
                    <div class="map_pin pin_us" style="left: 23.74%; top: 35%;" title="미국">
                    </div>
                    <div class="map_pin pin_mx" style="left: 19.19%; top: 44%;" title="멕시코">
                    </div>
                    <div class="map_pin pin_co" style="left: 27.78%; top: 57%;" title="콜롬비아">
                    </div>
                    <div class="map_pin pin_ec" style="left: 26.77%; top: 61.5%;" title="에콰도르">
                    </div>
                    <div class="map_pin pin_es" style="left: 48.99%; top: 34%;" title="스페인">
                    </div>
                    <div class="map_pin pin_pl" style="left: 55.86%; top: 23.5%;" title="폴란드">
                    </div>
                    <div class="map_pin pin_vn" style="left: 81.92%; top: 52%;" title="베트남">
                    </div>
                    <div class="map_pin pin_tw" style="left: 85.86%; top: 45.5%;" title="대만">
                    </div>
                    <div class="map_pin pin_kr" style="left: 87.88%; top: 37.1%;" title="대한민국 (본사)">
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>




<?php include "../inc/bottom.php"; ?>