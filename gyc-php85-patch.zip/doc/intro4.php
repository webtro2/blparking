<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "오시는 길 | 지와이 참미 하이텍스";
include "../inc/head.php";
include "../inc/link.php";
include "../inc/top.php";
?>

<?php 
$s_num = "1";
$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro4">
        <div id="subTitle">
            <span class="vis_dep02">오시는길</span>
        </div>

        <div class="inner">
            <!-- 상단 헤더 텍스트 -->
            <section class="sec sec_location_top">
                <div class="s_txt" data-aos="fade-up">
                    <h3>오시는 길</h3>
                    <p>지에이 참미 하이텍스로 오시는 길을 상세히 안내해 드립니다.</p>
                </div>

                <!-- 사무실 / 공장 탭 -->
                <div class="loc_tab" data-aos="fade-up">
                    <ul class="tab_list">
                        <li class="on"><button type="button" data-target="office">사무실</button></li>
                        <li><button type="button" data-target="factory">공장</button></li>
                    </ul>
                </div>
            </section>

            <!-- 사무실 -->
            <div class="loc_panel on" data-panel="office">
                <!-- 1. 카카오맵 지도 영역 -->
                <section class="sec sec_map">
                    <div class="map_container" data-aos="fade-up">
                        <div id="daumRoughmapContainer1789617937353" class="root_daum_roughmap root_daum_roughmap_landing"></div>
                        <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://t1.kakaocdn.net/kakaomapweb/roughmap/loader/prod/roughmapLoader.js"></script>
                        <script charset="UTF-8">
                            new daum.roughmap.Lander({
                                "timestamp": "1789617937353",
                                "key": "2wb2t94jtqog",
                                "mapWidth": "100%",
                                "mapHeight": "480"
                            }).render();
                        </script>
                    </div>
                </section>

                <!-- 2. 주소 및 연락처 정보 -->
                <section class="sec sec_contact">
                    <div class="contact_grid" data-aos="fade-up">
                        <div class="contact_item">
                            <div class="tit">주소</div>
                            <div class="val">대구광역시 달서구 와룡로28길 101, 2층(감삼동)</div>
                        </div>
                        <div class="contact_item">
                            <div class="tit">전화번호</div>
                            <div class="val">+82 10 8784 6808<br>+82 53 262 1106</div>
                        </div>
                        <div class="contact_item">
                            <div class="tit">팩스번호</div>
                            <div class="val">070-4790-1102</div>
                        </div>
                        <div class="contact_item">
                            <div class="tit">이메일</div>
                            <div class="val">gychammi.jin@gmail.com <br> gychammi21@naver.com</div>
                        </div>
                    </div>
                </section>

                <!-- 3. 대중교통 이용 안내 -->
                <section class="sec sec_traffic">
                    <div class="s_txt" data-aos="fade-up">
                        <h3>대중교통 안내</h3>
                    </div>

                    <div class="traffic_wrap" data-aos="fade-up">
                        <!-- 지하철 -->
                        <div class="traffic_row">
                            <div class="traffic_th">
                                <span class="ico subway">지하철</span>
                            </div>
                            <div class="traffic_td">
                                <div class="subway_info">
                                    <span class="line line2">대구 2호선</span>
                                    <span class="station_name"><strong>죽전역</strong></span>
                                </div>
                            </div>
                        </div>

                        <!-- 버스 정류장 -->
                        <div class="traffic_row">
                            <div class="traffic_th">
                                <span class="ico bus">주변 정류장</span>
                            </div>
                            <div class="traffic_td">
                                <ul class="stop_list">
                                    <li><a href="https://map.kakao.com/?from=roughmap&busStopId=BS64607" target="_blank">성당코오롱하늘채 <i class="xi-external-link"></i></a></li>
                                    <li><a href="https://map.kakao.com/?from=roughmap&busStopId=BS64599" target="_blank">성당코오롱하늘채2 <i class="xi-external-link"></i></a></li>
                                    <li><a href="https://map.kakao.com/?from=roughmap&busStopId=BS64608" target="_blank">성당래미안e-편한세상앞 <i class="xi-external-link"></i></a></li>
                                    <li><a href="https://map.kakao.com/?from=roughmap&busStopId=BS64598" target="_blank">성당두산위브앞 <i class="xi-external-link"></i></a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- 버스 노선 -->
                        <div class="traffic_row">
                            <div class="traffic_th">
                                <span class="ico bus_line">주변 버스</span>
                            </div>
                            <div class="traffic_td">
                                <div class="bus_group">
                                    <div class="bus_type">
                                        <span class="badge blue">간선버스</span>
                                        <div class="bus_numbers">
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B32235&busStopId=BS64607" target="_blank" class="num blue">306</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B80575&busStopId=BS64607" target="_blank" class="num blue">320</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B80624&busStopId=BS64607" target="_blank" class="num blue">518</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B6418&busStopId=BS64599" target="_blank" class="num blue">156</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B6429&busStopId=BS64599" target="_blank" class="num blue">356</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B6480&busStopId=BS64599" target="_blank" class="num blue">726</a>
                                        </div>
                                    </div>
                                    <div class="bus_type">
                                        <span class="badge green">지선버스</span>
                                        <div class="bus_numbers">
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B80616&busStopId=BS64607" target="_blank" class="num green">달서2</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B80611&busStopId=BS64607" target="_blank" class="num green">달서5</a>
                                            <a href="https://map.kakao.com/?from=roughmap&busInfoId=B80628&busStopId=BS64599" target="_blank" class="num green">남구2</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- 공장 -->
            <div class="loc_panel" data-panel="factory">
                <!-- 1. 카카오맵 지도 영역 -->
                <section class="sec sec_map">
                    <div class="map_container" data-aos="fade-up">
                        <div id="daumRoughmapContainer1792394098604" class="root_daum_roughmap root_daum_roughmap_landing"></div>
                    </div>
                </section>

                <!-- 2. 주소 및 연락처 정보 -->
                <section class="sec sec_contact">
                    <div class="contact_grid" data-aos="fade-up">
                        <div class="contact_item">
                            <div class="tit">주소</div>
                            <div class="val">대구광역시 달성군 옥포읍 이팝나무길 114</div>
                        </div>
                        <div class="contact_item">
                            <div class="tit">전화번호</div>
                            <div class="val">+82 10 8784 6808<br>+82 53 262 1106</div>
                        </div>
                        <div class="contact_item">
                            <div class="tit">팩스번호</div>
                            <div class="val">070-4790-1102</div>
                        </div>
                        <div class="contact_item">
                            <div class="tit">이메일</div>
                            <div class="val">gychammi.jin@gmail.com <br> gychammi21@naver.com</div>
                        </div>
                    </div>
                </section>

                <!-- 3. 대중교통 이용 안내 -->
                <section class="sec sec_traffic">
                    <div class="s_txt" data-aos="fade-up">
                        <h3>대중교통 안내</h3>
                    </div>

                    <div class="traffic_wrap" data-aos="fade-up">
                        <!-- 버스 정류장 -->
                        <div class="traffic_row">
                            <div class="traffic_th">
                                <span class="ico bus">버스 정류장</span>
                            </div>
                            <div class="traffic_td">
                                <div class="subway_info">
                                    <span class="station_name"><strong>신당리2</strong> 정류장 하차 후 도보 약 11분</span>
                                </div>
                            </div>
                        </div>

                        <!-- 버스 노선 -->
                        <div class="traffic_row">
                            <div class="traffic_th">
                                <span class="ico bus_line">주변 버스</span>
                            </div>
                            <div class="traffic_td">
                                <div class="bus_group">
                                    <div class="bus_type">
                                        <span class="badge green">지선버스</span>
                                        <div class="bus_numbers">
                                            <span class="num green">달성2</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<script>
    (function() {
        var tabBtns = document.querySelectorAll('.intro4 .loc_tab .tab_list button');
        var panels = document.querySelectorAll('.intro4 .loc_panel');
        var factoryMapInit = false;

        for (var i = 0; i < tabBtns.length; i++) {
            tabBtns[i].addEventListener('click', function() {
                var target = this.getAttribute('data-target');

                for (var j = 0; j < tabBtns.length; j++) {
                    tabBtns[j].parentElement.classList.remove('on');
                }
                this.parentElement.classList.add('on');

                for (var k = 0; k < panels.length; k++) {
                    panels[k].classList.toggle('on', panels[k].getAttribute('data-panel') === target);
                }

                if (target === 'factory' && !factoryMapInit) {
                    factoryMapInit = true;
                    new daum.roughmap.Lander({
                        "timestamp": "1792394098604",
                        "key": "3iv9p8o4ttv",
                        "mapWidth": "100%",
                        "mapHeight": "480"
                    }).render();
                }
            });
        }
    })();
</script>

<?php include "../inc/bottom.php"; ?>