<div class="s_visual">
    <div class="sv_tit">
        <h2><span class="vis_dep01"></span></h2>
    </div>

    <div class="sub_menu_wrap">
        <div class="in">
            <div class="m_1dep_box m_dep_box">
                <div class="m_dep_tit"><span class="vis_dep01"></span></div>
                <?php  include "../inc/s_gnb0.php" ?>
            </div>
            <div class="m_2dep_box m_dep_box">
                <div class="m_dep_tit"><span class="vis_dep02"></span></div>
                <?php  include "../inc/s_gnb$s_num.php" ?>
            </div>
        </div>
    </div>
</div>