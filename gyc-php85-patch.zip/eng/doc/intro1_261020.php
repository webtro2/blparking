<?php
$page_title = "인사말 | 지와이 참미 하이텍스";
include "../inc/head.php";
include "../inc/link.php";
include "../inc/top.php";
?>

<?php 
$s_num = "1";
$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="intro1">
        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>

        <div class="inner">
            <div class="top_bg" data-aos="fade-up"><img src="/images/sub/intro1_bg1.webp" alt=""></div>
            <div class="txt_cont" data-aos="fade-up">
                <div class="cont c1">
                    <div class="txt">
                        <h3>모든 창에 <br><span>가치</span>를 더하는 <br>원단을 만듭니다.</h3>
                    </div>
                    <div class="logo"><img src="/images/common/logo.webp" alt=""></div>
                </div>

                <div class="cont c2">
                    <p>
                        당사는 2020년에 설립된 프리미엄 블라인드 원단 전문
                        제조업체로, 블라인드 원단 직조 노하우와 기술력을 바탕으로
                        전 세계 고객에게 고품질의 윈도우 커버링 원단을 공급하고
                        있습니다.
                    </p>
                    <p>
                        수출 전문 기업으로서 미국, 캐나다, 멕시코, 에콰도르,
                        콜롬비아, 대만 등 글로벌 시장에 고품질 블라인드 원단을
                        공급하고 있습니다.
                    </p>
                    <p>
                        안정적인 품질, 신뢰할 수 있는 서비스, 그리고 경쟁력 있는
                        제품을 바탕으로 전 세계 고객들과 지속적인 파트너십을
                        구축하고 있습니다.
                    </p>
                </div>

                <div class="cont c3">
                    <p>
                        당사의 주요 제품은 롤러 블라인드 원단(Roller Blind Fabric),
                        콤비 블라인드 원단(Zebra Blind Fabric) 등 다양한 윈도우
                        커버링 소재이며, 기능성, 내구성, 그리고 현대적인 디자인을
                        갖춘 제품을 제공합니다.
                    </p>
                    <p>
                        원사 선정부터 제직, 후가공, 검사, 포장까지 모든 생산 공정을
                        엄격한 품질관리 기준에 따라 관리하여 제품의 안정적인
                        품질과 높은 만족도를 보장하고 있습니다.
                    </p>
                    <p>
                        품질, 혁신, 신뢰를 바탕으로 당사는 글로벌 윈도우 커버링
                        시장에서 고객이 신뢰할 수 있는 최고의 파트너가 되기 위해
                        지속적으로 노력하고 있습니다.
                    </p>
                </div>
            </div>
            <div class="name">
                <p>지와이참미 하이텍스 일동</p>
            </div>
        </div>
    </div>
</div>




<?php include "../inc/bottom.php"; ?>