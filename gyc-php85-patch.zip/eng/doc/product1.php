<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "2";
$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="pageCont" class="product1">
        <div id="subTitle">
            <span class="vis_dep02">제품소개</span>
        </div>

        <div class="inner">
            <!-- 상단 헤더 텍스트 -->
            <section class="sec sec_prod_top">

                <!-- 카테고리 탭 필터 -->
                <div class="prod_tab">
                    <!-- <ul class="tab_list">
                        <li class="on" data-filter="all"><button type="button">전체</button></li>
                        <li data-filter="combi"><button type="button">콤비 블라인드</button></li>
                        <li data-filter="roller"><button type="button">롤러 블라인드</button></li>
                        <li data-filter="blackout"><button type="button">암막 / 방염</button></li>
                        <li data-filter="triple"><button type="button">트리플 블라인드</button></li>
                        <li data-filter="eco"><button type="button">친환경 원단</button></li>
                    </ul> -->
                </div>

                <!-- 제품 목록 상단 정보 바 -->
                <div class="prod_bar">
                    <div class="total">전체 <span>9</span>개</div>
                </div>

                <!-- 제품 목록 그리드 -->
                <div class="prod_grid_wrap">
                    <ul class="prod_list">
                        <!-- Item 1 -->
                        <li class="prod_item" data-category="combi">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec4_img1.webp" alt="네이처 콤비 솔리드">
                                </div>
                                <div class="info">
                                    <h4 class="name">네이처 콤비 솔리드</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 2 -->
                        <li class="prod_item" data-category="roller">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec1_img1.webp" alt="프리미엄 롤러 솔리드">
                                </div>
                                <div class="info">
                                    <h4 class="name">프리미엄 롤러 솔리드</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 3 -->
                        <li class="prod_item" data-category="blackout">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec3_img1.webp" alt="하이 블라인드 암막 & 방염">
                                </div>
                                <div class="info">
                                    <h4 class="name">하이 블라인드 암막 & 방염</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 4 -->
                        <li class="prod_item" data-category="triple">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/sub/intro1_bg1.webp" alt="엘레강스 트리플 쉐이드">
                                </div>
                                <div class="info">
                                    <h4 class="name">엘레강스 트리플 쉐이드</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 5 -->
                        <li class="prod_item" data-category="combi">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec4_img1.webp" alt="자카드 우드 룩 콤비">
                                </div>
                                <div class="info">
                                    <h4 class="name">자카드 우드 룩 콤비</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 6 -->
                        <li class="prod_item" data-category="eco">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec1_img1.webp" alt="에코 리사이클 친환경 원단">
                                </div>
                                <div class="info">
                                    <h4 class="name">에코 리사이클 친환경 원단</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 7 -->
                        <li class="prod_item" data-category="roller">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec3_img1.webp" alt="선스크린 3% 기능성 원단">
                                </div>
                                <div class="info">
                                    <h4 class="name">선스크린 3% 기능성 원단</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 8 -->
                        <li class="prod_item" data-category="blackout">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/sub/intro1_bg1.webp" alt="단열 폼 코팅 암막 원단">
                                </div>
                                <div class="info">
                                    <h4 class="name">단열 폼 코팅 암막 원단</h4>
                                </div>
                            </a>
                        </li>

                        <!-- Item 9 -->
                        <li class="prod_item" data-category="triple">
                            <a href="/doc/product_view.php" class="item_inner">
                                <div class="thumb">
                                    <img src="/images/main/sec4_img1.webp" alt="실크 터치 소프트 트리플">
                                </div>
                                <div class="info">
                                    <h4 class="name">실크 터치 소프트 트리플</h4>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- 페이지네이션 -->
                <div class="pagination">
                    <a href="#none" class="page_btn prev" aria-label="이전 페이지"></a>
                    <a href="#none" class="page_num on">1</a>
                    <a href="#none" class="page_num">2</a>
                    <a href="#none" class="page_num">3</a>
                    <a href="#none" class="page_btn next" aria-label="다음 페이지"></a>
                </div>
            </section>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // 카테고리 탭 필터 인터랙션
        $('.prod_tab .tab_list li').on('click', function() {
            $('.prod_tab .tab_list li').removeClass('on');
            $(this).addClass('on');

            var filterVal = $(this).attr('data-filter');
            var $items = $('.prod_list .prod_item');

            if (filterVal === 'all') {
                $items.fadeIn(300);
                $('.prod_bar .total span').text($items.length);
            } else {
                $items.hide();
                var $filtered = $items.filter('[data-category="' + filterVal + '"]');
                $filtered.fadeIn(300);
                $('.prod_bar .total span').text($filtered.length);
            }
        });
    });
</script>

<?php include "../inc/bottom.php"; ?>