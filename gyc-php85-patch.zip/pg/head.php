<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH . '/head.sub.boa.php');
include_once(G5_LIB_PATH . '/latest.lib.php');
include_once(G5_LIB_PATH . '/outlogin.lib.php');
include_once(G5_LIB_PATH . '/poll.lib.php');
include_once(G5_LIB_PATH . '/visit.lib.php');
include_once(G5_LIB_PATH . '/connect.lib.php');
include_once(G5_LIB_PATH . '/popular.lib.php');


$s_num = "";
$p_num = "";

if ($bo_table == "comm1") {
    $s_num = "3";
    $p_num = "1";
} elseif ($bo_table == "comm2") {
    $s_num = "3";
    $p_num = "2";
} elseif ($bo_table == "comm3") {
    $s_num = "3";
    $p_num = "3";
} elseif ($bo_table == "product1") {
    $s_num = "2";
    $p_num = "1";
} elseif ($bo_table == "product2") {
    $s_num = "2";
    $p_num = "2";
} elseif ($bo_table == "product3") {
    $s_num = "2";
    $p_num = "3";
} elseif ($bo_table == "product4") {
    $s_num = "2";
    $p_num = "4";
} elseif ($bo_table == "product5") {
    $s_num = "2";
    $p_num = "5";
} elseif ($bo_table == "product6") {
    $s_num = "2";
    $p_num = "6";
} elseif ($bo_table == "e_catalog") {
    $s_num = "5";
    $p_num = "1";
} elseif ($bo_table == "project1") {
    $s_num = "6";
    $p_num = "1";
} elseif (($fm_id ?? '') == "1") {
    $s_num = "7";
    $p_num = "2";
}
?>



<?php include __DIR__ . "/../inc/head.php"; ?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>
<?php include __DIR__ . "/../inc/s_visual_board.php"; ?>


<!-- Sub Content -->
<div id="subContent">
    <div id="pageCont" style="font-size:15px;">
        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>
        <div class="inner">