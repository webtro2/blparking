
<header id="header">


  	<h1 id="logo">
  		<a href="/index.php" class="logo" alt="카페퍼플민트">카페퍼플민트</a>
  	</h1>

  	<div id="gnb_pc">
  		<?php  include __DIR__ . "/nav.php" ?>
  	</div>


	<div id="top-cs">
		<ul class="t-tel">
			<li><span>02.543.9562</span></li>
			<a href="tel:025439562">02.543.9562</a>
		</ul>
		<ul class="t-callback">
			<a href="/pg/bbs/write.php?bo_table=callback" target="_blank"><li><span>1시간 내 상담</span></li></a>
		</ul>
	</div>




	<div  id="allmenuWrap">
		<div id="allmenu">
			<a href="#" id="navtoggler">
				<div class="bar"><span class="t"></span><span class="m"></span><span class="b"></span></div>
			</a>
		</div>			
		<nav id="fullscreenmenu">
		<div class="s-inner">
			<?php  include __DIR__ . "/nav.php" ?>			
		</div>
		</nav>
	</div>


	<div class="menuToggle hd_full hd_mbx"><span class="t"></span><span class="m"></span><span class="b"></span></div>


	<div id="gnb_mo" class="fullmenu">
		<?php  include __DIR__ . "/nav.php" ?>
	</div>

</header>


<div id="content">


