<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<!--  -->
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="language" content="ko" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="format-detection" content="telephone=no" />

<meta property="og:type" content="website" />
<meta property="og:site_name" content="카페퍼플민트" />
<meta property="og:description" content="2017년 국내 최초 스타벅스 캡슐 전용 커피자판기 출시. 누적 800대 이상 설치 실적." />
<meta property="og:url" content="https://www.cafepurplemint.co.kr/" />
<meta property="og:image" content="https://www.cafepurplemint.co.kr/og-main.jpg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />

<meta name="twitter:card" content="summary_large_image" />



<?php $site_title = isset($page_title) && $page_title ? $page_title : (isset($g5['title']) && $g5['title'] ? $g5['title'] : "스타벅스 정품캡슐 무인카페 | 카페퍼플민트"); ?>
<title><?php echo $site_title; ?></title>
<meta property="og:title" content="<?php echo $site_title; ?>" />



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
<link rel="stylesheet" type="text/css" href="/css/default.css" />

<link rel="shortcut icon" href="/favicon.ico">

<!-- gnb -->
<script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="/js/common_ui.js"></script>
<script type="text/javascript" src="/js/sub.js"></script>

<!-- js -->
<script type="text/javascript" src="/js/aos.js"></script>
<script src="/js/allmenu.js"></script>


<!-- slick  -->
<script type="text/javascript" src="/js/slick/slick.min.js"></script>
<link media="all" href="/js/slick/slick.css" type="text/css" rel="stylesheet"/>
<link media="all" href="/js/slick/slick-theme.css" type="text/css" rel="stylesheet"/>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


<script type="text/javascript" src="/js/jquery.easeScroll.js"></script>





</head>

<body>

<div id="wrap">
