<ul class="gnb">

  <!--  -->
  <li class="gnb_dp1">
    <div><a href="/product/all.php">제품</a></div>
    <?php  include __DIR__ . "/s_gnb1.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="/startup/cost.php">창업안내</a></div>
    <?php  include __DIR__ . "/s_gnb2.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="/solutions/standalone.php">설치목적별</a></div>
    <?php  include __DIR__ . "/s_gnb3.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="/pg/bbs/board.php?bo_table=cases">설치사례</a></div>
    <?php  include __DIR__ . "/s_gnb4.php" ?>
  </li>


  <li class="gnb_dp1">
    <div><a href="/starbucks/genuine.php">스타벅스 정품캡슐</a></div>
    <?php  include __DIR__ . "/s_gnb5.php" ?>
  </li>


  <li class="gnb_dp1">
    <div><a href="/pg/bbs/board.php?bo_table=faq">고객지원</a></div>
    <?php  include __DIR__ . "/s_gnb6.php" ?>
  </li>


  <li class="gnb_dp1">
    <div><a href="/company/overview.php">회사소개</a></div>
    <?php  include __DIR__ . "/s_gnb7.php" ?>
  </li>


  <li class="gnb_dp1">
    <div><a href="/pg/bbs/board.php?bo_table=callback">상담신청</a></div>
    <?php  include __DIR__ . "/s_gnb8.php" ?>
  </li>


</ul>
