
<div class="s_visual">
<div class="s_visual_in">

		<div class="sv_tit">
			<h2 data-aos="fade-up" data-aos-delay="300"><span class="vis_dep02"></span></h2>				
			<p class="t1"  data-aos="fade-up" data-aos-delay="400"><span>카페퍼플민트는 IoT 캡슐커피머신과 스마트 쇼케이스를 기반으로 <br>스타벅스 정품 캡슐을 제공하는 무인카페 브랜드입니다</span></p>
		</div>


		<div class="sub_menu_wrap"  data-aos="zoom-in" data-aos-delay="600">
			<div class="in">
				<div class="m_1dep_box m_dep_box">
					<div class="m_dep_tit"><span class="vis_dep01"></span></div>
					<?php  include __DIR__ . "/s_gnb0.php" ?>
				</div>
				<div class="m_2dep_box m_dep_box">
					<div class="m_dep_tit"><span class="vis_dep02"></span></div>
					<?php  if (isset($s_num) && preg_match('/^[0-9]+$/', (string)$s_num) && is_file(__DIR__ . "/s_gnb$s_num.php")) include __DIR__ . "/s_gnb$s_num.php" ?>
				</div>
			</div>
		</div>


</div>
</div>


