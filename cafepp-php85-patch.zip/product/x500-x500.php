<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php
$page_title = "X500·M500 스타벅스 정품캡슐 올인원 커피자판기 | 카페퍼플민트";
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "4";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>





</div>
</div>
<?php include "../inc/bottom.php"; ?>
