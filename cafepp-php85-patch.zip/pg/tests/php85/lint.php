<?php
error_reporting(E_ALL);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$root=isset($argv[1]) ? realpath($argv[1]) : dirname(__DIR__, 2);
if (!$root || !is_dir($root)) exit(2);
$passed=$failed=0;
foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root)) as $f){
 if(!$f->isFile()||$f->getExtension()!=='php')continue;
 $output=array();exec(escapeshellarg(PHP_BINARY).' -d short_open_tag=0 -d error_reporting=-1 -d display_errors=1 -d log_errors=0 -l '.escapeshellarg($f->getPathname()).' 2>&1',$output,$status);
 $text=implode("\n",$output);
 if($status || preg_match('/(?:Warning|Deprecated|Fatal error|Parse error):/',$text)){$failed++;echo $text,"\n";}else{$passed++;}
}
echo "LINT $passed passed, $failed failed; PHP ".PHP_VERSION."; short_open_tag=".ini_get('short_open_tag')."\n";
exit($failed ? 1 : 0);
