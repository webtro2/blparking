<?php
// CLI only. Each case has its own process and temporary output directory.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$cases = array('password', 'mail', 'html', 'old-excel', 'excel-xls', 'excel-xlsx', 'excel-pclzip', 'json', 'captcha', 'thumbnail', 'xml-safety');
if (!isset($argv[1])) {
    $failed = 0;
    foreach ($cases as $case) {
        passthru(escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(__FILE__) . ' ' . escapeshellarg($case), $status);
        if ($status !== 0) $failed++;
    }
    echo (count($cases) - $failed) . ' passed, ' . $failed . " failed\n";
    exit($failed ? 1 : 0);
}
if (!in_array($argv[1], $cases, true)) exit(2);
$root = dirname(__DIR__, 2);
$tmp = sys_get_temp_dir() . '/pg-php85-' . bin2hex(random_bytes(8));
mkdir($tmp, 0700);
register_shutdown_function(function () use ($tmp) {
    foreach (glob($tmp . '/*') as $file) if (is_file($file)) unlink($file);
    rmdir($tmp);
});
ob_start();
error_reporting(E_ALL);
set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});
define('_GNUBOARD_', true);
define('G5_FILE_PERMISSION', 0644);
function ensure($condition, $message) { if (!$condition) throw new RuntimeException($message); }
$status = 0;
try {
    switch ($argv[1]) {
        case 'password':
            require $root . '/lib/pbkdf2.compat.php';
            $hash = create_hash('local-test-password');
            ensure(validate_password('local-test-password', $hash), 'Correct password rejected');
            ensure(!validate_password('wrong', $hash), 'Incorrect password accepted');
            break;
        case 'mail':
            require $root . '/plugin/PHPMailer/PHPMailerAutoload.php';
            $mail = new PHPMailer();
            $mail->setFrom('sender@example.invalid');
            $mail->addAddress('recipient@example.invalid');
            $mail->Subject = 'PHP85';
            $mail->Body = 'Local MIME generation only';
            ensure($mail->preSend() && str_contains($mail->getSentMIMEMessage(), 'PHP85'), 'MIME generation failed');
            break;
        case 'html':
            require $root . '/plugin/htmlpurifier/HTMLPurifier.standalone.php';
            $config = HTMLPurifier_Config::createDefault();
            $config->set('Cache.DefinitionImpl', null);
            $purifier = new HTMLPurifier($config);
            $html = $purifier->purify('<p>Hello<script>alert(1)</script><a href="javascript:alert(1)">x</a></p>');
            ensure(str_contains($html, 'Hello') && !str_contains($html, 'script'), 'Unsafe HTML retained');
            break;
        case 'old-excel':
            require $root . '/lib/Excel/php_writeexcel/class.writeexcel_workbook.inc.php';
            require $root . '/lib/Excel/php_writeexcel/class.writeexcel_worksheet.inc.php';
            $workbook = new writeexcel_workbook($tmp . '/old.xls');
            $sheet = $workbook->addworksheet();
            $sheet->write(0, 0, 'PHP85');
            $sheet->write(1, 0, 42);
            $sheet->write(2, 0, '=SUM(A2:A2)');
            $workbook->close();
            ensure(filesize($tmp . '/old.xls') >= 512, 'Empty XLS file');
            break;
        case 'excel-xls':
        case 'excel-xlsx':
        case 'excel-pclzip':
            require $root . '/lib/PHPExcel.php';
            if ($argv[1] === 'excel-xlsx') ensure(class_exists('ZipArchive'), 'PHP zip extension is required');
            if ($argv[1] === 'excel-pclzip') PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
            $book = new PHPExcel();
            $sheet = $book->getActiveSheet();
            $sheet->setCellValue('A1', 'PHP85 테스트');
            $sheet->setCellValue('A2', 42);
            $sheet->setCellValue('A3', '=SUM(A2:A2)');
            $xls = $argv[1] === 'excel-xls';
            $file = $tmp . ($xls ? '/roundtrip.xls' : '/roundtrip.xlsx');
            PHPExcel_IOFactory::createWriter($book, $xls ? 'Excel5' : 'Excel2007')->save($file);
            $reader = PHPExcel_IOFactory::createReader($xls ? 'Excel5' : 'Excel2007');
            $loaded = $reader->load($file);
            ensure($loaded->getActiveSheet()->getCell('A1')->getValue() === 'PHP85 테스트', 'Excel text round trip failed');
            ensure((int) $loaded->getActiveSheet()->getCell('A2')->getValue() === 42, 'Excel number round trip failed');
            ensure((float) $loaded->getActiveSheet()->getCell('A3')->getCalculatedValue() === 42.0, 'Excel formula round trip failed');
            $loaded->disconnectWorksheets();
            $book->disconnectWorksheets();
            break;
        case 'json':
            require $root . '/plugin/sms5/JSON.php';
            $json = new Services_JSON();
            $value = $json->decode($json->encode(array('hello' => 'world', 'items' => array(1, 2))));
            ensure($value->hello === 'world' && $value->items === array(1, 2), 'JSON round trip failed');
            break;
        case 'captcha':
            require $root . '/plugin/kcaptcha/kcaptcha.lib.php';
            $captcha = new KCAPTCHA();
            $captcha->setKeyString('123456');
            ob_start();
            try { $captcha->image(); $image = ob_get_contents(); } finally { ob_end_clean(); }
            ensure(substr($image, 0, 2) === "\xff\xd8", 'Invalid CAPTCHA JPEG');
            break;
        case 'thumbnail':
            require $root . '/lib/thumbnail.lib.php';
            $image = imagecreatetruecolor(180, 120);
            imagejpeg($image, $tmp . '/original.jpg');
            unset($image);
            $file = thumbnail('original.jpg', $tmp, $tmp, 90, 60, true);
            $size = getimagesize($tmp . '/' . $file);
            ensure($size[0] === 90 && $size[1] === 60, 'Incorrect thumbnail size');
            break;
        case 'xml-safety':
            require $root . '/lib/PHPExcel.php';
            PHPExcel_Settings::setLibXmlLoaderOptions(LIBXML_DTDLOAD | LIBXML_DTDATTR | LIBXML_NOENT);
            $flags = PHPExcel_Settings::getLibXmlLoaderOptions();
            ensure(($flags & (LIBXML_DTDLOAD | LIBXML_DTDATTR | LIBXML_NOENT)) === 0, 'Entity loading enabled');
            ensure(($flags & LIBXML_NONET) !== 0, 'External network access not blocked');
            file_put_contents($tmp . '/canary.txt', 'PHP85-ENTITY-CANARY');
            $xml = '<!DOCTYPE data [<!ENTITY canary SYSTEM "file://' . $tmp . '/canary.txt">]><data>&canary;</data>';
            $parsed = simplexml_load_string($xml, 'SimpleXMLElement', $flags);
            ensure($parsed !== false && (string) $parsed !== 'PHP85-ENTITY-CANARY', 'External entity was expanded');
            break;
    }
    echo 'PASS ' . $argv[1] . "\n";
} catch (Throwable $error) {
    $status = 1;
    echo 'FAIL ' . $argv[1] . ': ' . $error->getMessage() . ' at ' . $error->getFile() . ':' . $error->getLine() . "\n";
}
restore_error_handler();
ob_end_flush();
exit($status);
