<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$ca_name = isset($ca_name) && is_string($ca_name) ? $ca_name : '';

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="' . $board_skin_url . '/style.css">', 0);
?>

<section id="bo_w" class="mCallback_wrap">
    <h2 class="sound_only"><?php echo $g5['title'] ?></h2>

    <!-- 게시물 작성/수정 시작 { -->
    <div class="mCallback_box">
        <form name="fwrite" id="fwrite" action="<?php echo $action_url ?>" onsubmit="return fwrite_submit(this);" method="post" enctype="multipart/form-data" autocomplete="off">
            <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
            <input type="hidden" name="w" value="<?php echo $w ?>">
            <input type="hidden" name="bo_table" value="<?php echo $bo_table ?>">
            <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
            <input type="hidden" name="sca" value="<?php echo $sca ?>">
            <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
            <input type="hidden" name="stx" value="<?php echo $stx ?>">
            <input type="hidden" name="spt" value="<?php echo $spt ?>">
            <input type="hidden" name="sst" value="<?php echo $sst ?>">
            <input type="hidden" name="sod" value="<?php echo $sod ?>">
            <input type="hidden" name="page" value="<?php echo $page ?>">
            <input type="hidden" name="wr_subject" value="<?php echo $subject ? $subject : '1시간콜백신청'; ?>">

            <?php
            $option = '';
            $option_hidden = '';
            if ($is_notice || $is_html || $is_secret || $is_mail) {
                $option = '';
                if ($is_notice) {
                    $option .= PHP_EOL . '<span class="voc-chk-box"><input type="checkbox" id="notice" name="notice" value="1" ' . $notice_checked . '><label for="notice"><span></span>공지</label></span>';
                }
                if ($is_html) {
                    if ($is_dhtml_editor) {
                        $option_hidden .= '<input type="hidden" value="html1" name="html">';
                    } else {
                        $option .= PHP_EOL . '<span class="voc-chk-box"><input type="checkbox" id="html" name="html" onclick="html_auto_br(this);" value="' . $html_value . '" ' . $html_checked . '><label for="html"><span></span>html</label></span>';
                    }
                }
                if ($is_secret) {
                    if ($is_admin || $is_secret == 1) {
                        $option .= PHP_EOL . '<span class="voc-chk-box"><input type="checkbox" id="secret" name="secret" value="secret" ' . $secret_checked . '><label for="secret"><span></span>비밀글</label></span>';
                    } else {
                        $option_hidden .= '<input type="hidden" name="secret" value="secret">';
                    }
                }
                if ($is_mail) {
                    $option .= PHP_EOL . '<span class="voc-chk-box"><input type="checkbox" id="mail" name="mail" value="mail" ' . $recv_email_checked . '><label for="mail"><span></span>답변메일받기</label></span>';
                }
            }
            echo $option_hidden;
            ?>

            <ul class="mform">
                <?php if ($is_name) { ?>
                    <li class="w50">
                        <label>성함</label>
                        <input type="text" id="wr_name" name="wr_name" value="<?php echo $name; ?>" required class="cs_txt" placeholder="">
                    </li>
                <?php } ?>

                <li class="w50">
                    <label>연락처</label>
                    <input type="text" id="wr_tel" name="wr_1" value="<?php echo $wr_1; ?>" required class="cs_txt" placeholder="">
                </li>

                <li class="w50">
                    <label>설치예정지역</label>
                    <input type="text" id="wr_2" name="wr_2" value="<?php echo $wr_2; ?>" required class="cs_txt" placeholder="">
                </li>

                <li class="w50">
                    <label for="ca_name">설치 유형</label>
                    <div class="select-wrap">
                        <select id="ca_name" name="ca_name" required class="cs_select">
                            <option value="" selected disabled>선택해주세요</option>
                            <?php if ($is_category && $category_option) { ?>
                                <?php echo $category_option; ?>
                            <?php } else { ?>
                                <option value="신규 설치" <?php echo ($ca_name == '신규 설치' ? 'selected' : ''); ?>>신규 설치</option>
                                <option value="기존 매장 설치" <?php echo ($ca_name == '기존 매장 설치' ? 'selected' : ''); ?>>기존 매장 설치</option>
                                <option value="기타" <?php echo ($ca_name == '기타' ? 'selected' : ''); ?>>기타</option>
                            <?php } ?>
                        </select>
                    </div>
                </li>

                <?php if ($is_password) { ?>
                    <!-- <li class="w50">
                        <label>비밀번호</label>
                        <input type="password" id="wr_password" name="wr_password" <?php echo $password_required; ?> class="cs_txt" placeholder="" autocomplete="new-password">
                    </li> -->
                <?php } ?>

                <?php if ($is_email) { ?>
                    <!-- <li class="w50">
                        <label>이메일</label>
                        <input type="email" id="wr_email" name="wr_email" value="<?php echo $email; ?>" class="cs_txt" placeholder="">
                    </li> -->
                <?php } ?>

                <?php if ($option) { ?>
                    <!-- <li class="w100 voc-opt-li">
                        <label>옵션</label>
                        <div class="voc-opt-wrap">
                            <?php echo $option ?>
                        </div>
                    </li> -->
                <?php } ?>

                <li class="w100">
                    <label>문의하기</label>
                    <textarea class="cs_cont" name="wr_content" id="wr_content" required placeholder="문의사항을 입력해 주세요."><?php echo $content; ?></textarea>
                </li>

                <?php for ($i = 1; $is_link && $i <= G5_LINK_COUNT; $i++) { ?>
                    <!-- <li class="w100">
                        <label for="wr_link<?php echo $i ?>">링크 #<?php echo $i ?></label>
                        <input type="text" name="wr_link<?php echo $i ?>" value="<?php if ($w == "u") {
                                                                                        echo $write['wr_link' . $i];
                                                                                    } ?>" id="wr_link<?php echo $i ?>" class="cs_txt" placeholder="https://">
                    </li> -->
                <?php } ?>

                <?php for ($i = 0; $is_file && $i < $file_count; $i++) { ?>
                    <!-- <li class="w100 voc-file-li">
                        <label for="bf_file_<?php echo $i + 1 ?>">첨부파일 #<?php echo $i + 1 ?></label>
                        <div class="file-upload-wrap">
                            <input type="text" autocomplete="off" placeholder="파일을 첨부해 주세요." readonly="readonly" class="cs_txt file-route">
                            <label class="file-select-btn" for="bf_file_<?php echo $i + 1 ?>">찾아보기</label>
                            <input type="file" name="bf_file[]" id="bf_file_<?php echo $i + 1 ?>" class="hidden-file" title="파일첨부 <?php echo $i + 1 ?> : 용량 <?php echo $upload_max_filesize ?> 이하만 업로드 가능">
                        </div>
                        <?php if ($is_file_content) { ?>
                            <div class="file-content-wrap">
                                <input type="text" name="bf_content[]" id="bf_file_<?php echo $i + 1 ?>_title" value="<?php echo ($w == 'u') ? $file[$i]['bf_content'] : ''; ?>" title="파일 설명을 입력해주세요." placeholder="파일 설명을 입력해주세요." class="cs_txt">
                            </div>
                        <?php } ?>
                        <?php if ($w == 'u' && $file[$i]['file']) { ?>
                            <div class="file-del-wrap">
                                <span class="voc-chk-box"><input type="checkbox" id="bf_file_del<?php echo $i ?>" name="bf_file_del[<?php echo $i;  ?>]" value="1"><label for="bf_file_del<?php echo $i ?>"><span></span><?php echo $file[$i]['source'] . '(' . $file[$i]['size'] . ')';  ?> 파일 삭제</label></span>
                            </div>
                        <?php } ?>
                    </li> -->
                <?php } ?>

                <?php if ($is_use_captcha) { ?>
                    <!-- <li class="w100 voc-captcha-li">
                        <label>자동등록방지</label>
                        <div class="captcha-inner">
                            <?php echo $captcha_html ?>
                        </div>
                    </li> -->
                <?php } ?>
            </ul>

            <div class="agree">
                <div class="agree-check">
                    <input type="checkbox" id="agree1" name="agree" value="1" class="css-checkbox" required <?php echo ($w == 'u') ? 'checked' : ''; ?>>
                    <label for="agree1" class="st1">
                        <span><a href="#" class="privacy-open">개인정보처리방침</a>에 동의합니다.</span>
                    </label>
                </div>
                <div class="btn-group">
                    <button type="submit" id="btn_submit" class="mBtn"><span>1시간 내 연락 요청하기</span><i></i></button>
                </div>
            </div>
        </form>
    </div>

    <!-- 개인정보처리방침 레이어 모달 시작 { -->
    <div class="layer" id="privacyModal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="layer_wrap">
            <div class="close_btn">
                <button type="button" class="privacy-close" aria-label="닫기">✕</button>
            </div>
            <div class="DB_info_detail">
                <h2 id="modalTitle">개인정보처리방침</h2>
                <div class="DB_info_detail_wrap">
                    <p>개인정보란 생존하는 개인에 관한 정보로서 당해 정보에 포함되어 있는 성명 등의 사항에 의하여 당해 개인을 식별할 수 있는 정보(당해 정보만으로는 특정 개인을 식별할 수 없더라도 다른 정보와 용이하게 결합하여 식별할 수 있는 것을 포함합니다)를 말합니다. 당사는 고객의 개인정보보호를 매우 중요시하며, 『정보통신망 이용촉진 및 정보보호 등에 관한 법률』 및 『개인정보 보호법』을 준수하고 있습니다.</p>

                    <dl>
                        <dt>1. 개인정보의 수집 및 이용 목적</dt>
                        <dd>
                            - 성명, 연락처, 설치예정지역, 설치유형: 고객 문의(QnA) 및 상담 요청에 따른 본인 확인 및 상담 진행, 맞춤 견적 안내
                        </dd>
                    </dl>

                    <dl>
                        <dt>2. 수집하는 개인정보 항목</dt>
                        <dd>
                            - 필수항목: 성함(이름), 연락처, 설치예정지역, 설치유형, 문의내용<br>
                            - 선택항목: 이메일, 첨부파일
                        </dd>
                    </dl>

                    <dl>
                        <dt>3. 개인정보의 보유 및 이용기간</dt>
                        <dd>
                            고객의 개인정보는 원칙적으로 상담 접수 및 처리 목적이 달성된 후 지체 없이 파기합니다. 단, 관계법령의 규정에 의하여 보존할 필요가 있는 경우 관련 법령에서 정한 일정 기간 동안 보관합니다.<br>
                            - 소비자의 불만 또는 분쟁처리에 관한 기록: 3년 (전자상거래 등에서의 소비자보호에 관한 법률)
                        </dd>
                    </dl>

                    <dl>
                        <dt>4. 동의 거부 권리 및 불이익</dt>
                        <dd>
                            귀하는 개인정보 수집 및 이용에 대한 동의를 거부할 권리가 있습니다. 단, 필수항목에 대한 동의를 거부할 경우 원활한 상담 접수 및 서비스 이용에 제한이 있을 수 있습니다.
                        </dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
    <!-- } 개인정보처리방침 레이어 모달 끝 -->
</section>

<script>
    $(function() {
        // 파일 첨부 시 경로 표시
        $(".hidden-file").on("change", function() {
            var fileName = $(this).val().split('\\').pop();
            $(this).closest(".file-upload-wrap").find(".file-route").val(fileName);
        });

        // 개인정보처리방침 모달 열기/닫기
        $(".privacy-open").on("click", function(e) {
            e.preventDefault();
            $("#privacyModal").fadeIn(200);
            $("body").css("overflow", "hidden");
        });

        $(".privacy-close, #privacyModal").on("click", function(e) {
            if (e.target === this || $(this).hasClass("privacy-close")) {
                e.preventDefault();
                $("#privacyModal").fadeOut(200);
                $("body").css("overflow", "");
            }
        });

        $(".layer_wrap").on("click", function(e) {
            e.stopPropagation();
        });
    });

    <?php if ($write_min || $write_max) { ?>
        // 글자수 제한
        var char_min = parseInt(<?php echo $write_min; ?>); // 최소
        var char_max = parseInt(<?php echo $write_max; ?>); // 최대
        check_byte("wr_content", "char_count");

        $(function() {
            $("#wr_content").on("keyup", function() {
                check_byte("wr_content", "char_count");
            });
        });
    <?php } ?>

    function html_auto_br(obj) {
        if (obj.checked) {
            var result = confirm("자동 줄바꿈을 하시겠습니까?\n\n자동 줄바꿈은 게시물 내용중 줄바뀐 곳을<br>태그로 변환하는 기능입니다.");
            if (result)
                obj.value = "html2";
            else
                obj.value = "html1";
        } else {
            obj.value = "";
        }
    }

    function fwrite_submit(f) {
        <?php echo $editor_js; // 에디터 사용시 자바스크립트에서 내용을 폼필드로 넣어주며 내용이 입력되었는지 검사함 
        ?>

        if (!f.agree.checked) {
            alert("개인정보처리방침에 동의하셔야 문의 접수가 가능합니다.");
            f.agree.focus();
            return false;
        }

        var subject = "";
        var content = "";
        $.ajax({
            url: g5_bbs_url + "/ajax.filter.php",
            type: "POST",
            data: {
                "subject": f.wr_subject.value,
                "content": f.wr_content.value
            },
            dataType: "json",
            async: false,
            cache: false,
            success: function(data, textStatus) {
                subject = data.subject;
                content = data.content;
            }
        });

        if (subject) {
            alert("제목에 금지단어('" + subject + "')가 포함되어있습니다");
            f.wr_subject.focus();
            return false;
        }

        if (content) {
            alert("내용에 금지단어('" + content + "')가 포함되어있습니다");
            if (typeof(ed_wr_content) != "undefined")
                ed_wr_content.returnFalse();
            else
                f.wr_content.focus();
            return false;
        }

        if (document.getElementById("char_count")) {
            if (char_min > 0 || char_max > 0) {
                var cnt = parseInt(check_byte("wr_content", "char_count"));
                if (char_min > 0 && char_min > cnt) {
                    alert("내용은 " + char_min + "글자 이상 쓰셔야 합니다.");
                    return false;
                } else if (char_max > 0 && char_max < cnt) {
                    alert("내용은 " + char_max + "글자 이하로 쓰셔야 합니다.");
                    return false;
                }
            }
        }

        <?php  //php echo $captcha_js; // 캡챠 사용시 자바스크립트에서 입력된 캡챠를 검사함 
        ?>

        document.getElementById("btn_submit").disabled = "disabled";

        return true;
    }
</script>
<!-- } 게시물 작성/수정 끝 -->