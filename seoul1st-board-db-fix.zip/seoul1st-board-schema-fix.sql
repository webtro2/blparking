-- seoul1st.sql / Gnuboard 5.6.24 schema alignment.
-- MariaDB 10.3+ syntax (ADD COLUMN/INDEX IF NOT EXISTS).
-- Back up the live database first. Select the correct database before running.
-- No USE, DROP, DELETE or INSERT statements; existing posts are preserved.

ALTER TABLE `g5_write_notice01`
  ADD COLUMN IF NOT EXISTS `wr_seo_title` varchar(255) NOT NULL DEFAULT '' AFTER `wr_content`,
  ADD INDEX IF NOT EXISTS `wr_seo_title` (`wr_seo_title`),
  ALTER COLUMN `wr_comment_reply` SET DEFAULT '',
  ALTER COLUMN `wr_facebook_user` SET DEFAULT '',
  ALTER COLUMN `wr_twitter_user` SET DEFAULT '';

ALTER TABLE `g5_write_review01`
  ADD COLUMN IF NOT EXISTS `wr_seo_title` varchar(255) NOT NULL DEFAULT '' AFTER `wr_content`,
  ADD INDEX IF NOT EXISTS `wr_seo_title` (`wr_seo_title`),
  ALTER COLUMN `wr_comment_reply` SET DEFAULT '',
  ALTER COLUMN `wr_facebook_user` SET DEFAULT '',
  ALTER COLUMN `wr_twitter_user` SET DEFAULT '';
