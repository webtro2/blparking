var subFunc = (function($){
	var _snb = function(level1, level2){

		var sub_dep1=$('.sub_menu_wrap .m_1dep_box .menu'+level1);
		var sub_dep2=$('.sub_menu_wrap .m_2dep_box .menu'+level2);
		var sub_dep1_t = $(sub_dep1).text();
		var sub_dep2_t = $(sub_dep2).text();

		$('.s_visual').removeClass(function(index, className){
			return (className.match(/(^|\s)visual\d+/g) || []).join(' ');
		}).addClass('visual' + level1);

		$('span.vis_dep01').text(sub_dep1_t);
		$('span.vis_dep02').text(sub_dep2_t);

		sub_dep1.addClass('on');
		sub_dep2.addClass('on');
		sub_dep2.parent().addClass('s_on');

		$('.sub_menu_wrap .m_dep_tit').click(function(){
			if($(this).hasClass('m_on')){
				$(this).removeClass('m_on');
				$(this).siblings("ul.smenu").slideUp();
			} else {
				$(this).addClass('m_on');
				$(this).siblings("ul.smenu").slideDown();
			}
		});

		$(".sub_menu_wrap .m_dep_box").on("mouseleave", function(){
			if($(this).children(".m_dep_tit").hasClass("m_on")){
				$(this).children(".m_dep_tit").removeClass("m_on");
				$(this).children("ul.smenu").slideUp(300);
			}
		});

		$(window).resize(function(){
			var width = parseInt($(this).width()); //parseint는 정수로 하기 위함
			if(width <= 10000){
				$('.sub_menu_wrap .m_2dep_box .smenu').css({'display':'none'});
			}else{
				$('.sub_menu_wrap .m_2dep_box .smenu').css({'display':'block'});
			}
		}).resize();


	};
	return{
		snb:_snb
	}
})(jQuery);








$(document).ready(function(){

	$('.floorCont').each(function(){

		var $floor = $(this);
		var images = [];
		var current = 0;
		var total = 0;
		var autoTimer = null;
		var autoSpeed = 3000;
		var motionSpeed = 800;
		var isMoving = false;

		$floor.find('.spaceData img').each(function(){
			images.push($(this).attr('src'));
		});

		total = images.length;

		function setInitial(){

			var prev = (current - 1 + total) % total;
			var next = (current + 1) % total;

			$floor.find('.spacePrevImg').html('<img src="' + images[prev] + '" alt="">');
			$floor.find('.spaceCurrentImg').html('<img src="' + images[current] + '" alt="">');
			$floor.find('.spaceNextImg').html('<img src="' + images[next] + '" alt="">');

			updateControl();

		}

		function updateControl(){

			$floor.find('.mvNow').text(current + 1);
			$floor.find('.mvTotal').text(total);
			$floor.find('.mvProgress span').css('width', ((current + 1) / total * 100) + '%');

		}

		function changeImage($box, src, direction){

			var $old = $box.find('img');
			var $new = $('<img src="' + src + '" alt="">');

			var startX = direction === 'next' ? '100%' : '-100%';
			var endX = direction === 'next' ? '-100%' : '100%';

			$new.css({
				transform:'translateX(' + startX + ')'
			});

			$box.append($new);

			$new[0].offsetHeight;

			$new.css({
				transform:'translateX(0)'
			});

			$old.css({
				transform:'translateX(' + endX + ')'
			});

			setTimeout(function(){
				$old.remove();
			}, motionSpeed + 50);

		}

		function updateView(direction){

			if(isMoving) return;

			isMoving = true;

			var prev = (current - 1 + total) % total;
			var next = (current + 1) % total;

			changeImage($floor.find('.spacePrevImg'), images[prev], direction);
			changeImage($floor.find('.spaceCurrentImg'), images[current], direction);
			changeImage($floor.find('.spaceNextImg'), images[next], direction);

			updateControl();

			setTimeout(function(){
				isMoving = false;
			}, motionSpeed);

		}

		function nextSlide(){

			if(isMoving) return;

			current = (current + 1) % total;
			updateView('next');

		}

		function prevSlide(){

			if(isMoving) return;

			current = (current - 1 + total) % total;
			updateView('prev');

		}

		function startAuto(){

			stopAuto();

			autoTimer = setInterval(function(){

				if($floor.hasClass('active') && !isMoving){
					nextSlide();
				}

			}, autoSpeed);

		}

		function stopAuto(){

			if(autoTimer){
				clearInterval(autoTimer);
				autoTimer = null;
			}

		}

		$floor.find('.mvPrev').on('click', function(){

			prevSlide();

			if($floor.hasClass('active')){
				startAuto();
			}

		});

		$floor.find('.mvNext').on('click', function(){

			nextSlide();

			if($floor.hasClass('active')){
				startAuto();
			}

		});

		$floor.data('startAuto', startAuto);
		$floor.data('stopAuto', stopAuto);

		setInitial();

		if($floor.hasClass('active')){
			startAuto();
		}

	});


	$('.spaceTab button').on('click', function(){

		var floor = $(this).data('floor');

		$('.spaceTab button').removeClass('active');
		$(this).addClass('active');

		$('.floorCont').each(function(){

			var stopAuto = $(this).data('stopAuto');

			if(stopAuto){
				stopAuto();
			}

		});

		$('.floorCont').removeClass('active');

		var $target = $('#' + floor);

		$target.addClass('active');

		var startAuto = $target.data('startAuto');

		if(startAuto){
			startAuto();
		}

	});

});








$(document).ready(function(){

    $('[id="faqBG"]').each(function(){

        var $faqWrap = $(this);
        var $faq = $faqWrap.find('.faq-item');

        // 각 FAQ 섹션의 첫 번째 항목 기본 열림
        $faq.find('.faq-answer').hide();
        $faq.removeClass('active');
        $faq.find('.faq-question').attr('aria-expanded', 'false');

        $faq.first().addClass('active').find('.faq-answer').show();
        $faq.first().find('.faq-question').attr('aria-expanded', 'true');

        // FAQ 클릭 이벤트
        $faq.find('.faq-question').on('click', function(){

            var $item = $(this).closest('.faq-item');
            var isActive = $item.hasClass('active');

            // 현재 FAQ 섹션만 닫기
            $faq.removeClass('active');
            $faq.find('.faq-question').attr('aria-expanded', 'false');
            $faq.find('.faq-answer').stop(true, true).slideUp(300);

            // 선택 항목 열기
            if(!isActive){
                $item.addClass('active');
                $item.find('.faq-question').attr('aria-expanded', 'true');
                $item.find('.faq-answer').stop(true, true).slideDown(300);
            }

        });

    });

});







document.addEventListener("DOMContentLoaded", function () {

    const boxes = document.querySelectorAll("#contWrap .box[data-index]");
    const images = document.querySelectorAll("#imgWrap ul li[data-index]");

    let currentIndex = 1;

    function updateImage() {

        const viewportCenter = window.innerHeight / 2;
        let newIndex = 1;

        boxes.forEach(box => {
            const rect = box.getBoundingClientRect();

            if (rect.top <= viewportCenter) {
                newIndex = box.dataset.index;
            }
        });

        currentIndex = newIndex;

        images.forEach(img => {
            img.classList.remove("on");

            if (img.dataset.index == currentIndex) {
                img.classList.add("on");
            }
        });

        boxes.forEach(box => {
            box.classList.remove("on");

            if (box.dataset.index == currentIndex) {
                box.classList.add("on");
            }
        });
    }

    window.addEventListener("scroll", updateImage);
    updateImage();

});









$(function(){
    $('.p-Part[id^="page"]').each(function(){
        var num = parseInt(this.id.replace('page', ''), 10);
        $(this).find('.tabmenu li').removeClass('on').eq(num - 1).addClass('on');
    });
});