$(document).ready(function(){

	var $mv = $('#mVisual');
	var $progress = $('.mvProgress span');
	var autoplaySpeed = 6000;

	function progressStart(){
		$progress.stop(true, true).css({width:'0%'});
		$progress.animate({width:'100%'}, autoplaySpeed, 'linear');
	}

	$mv.on('init reInit afterChange', function(event, slick, currentSlide){
		var index = typeof currentSlide === 'undefined' ? 0 : currentSlide;

		$('.mvNow').text(index + 1);
		$('.mvTotal').text(slick.slideCount);

		progressStart();
	});

	$mv.on('beforeChange', function(){
		$progress.stop(true, true).css({width:'0%'});
	});

	$mv.slick({
		slidesToShow:1,
		slidesToScroll:1,
		infinite:true,
		fade:true,
		speed:1000,
		autoplay:true,
		autoplaySpeed:autoplaySpeed,
		arrows:false,
		pauseOnHover:false,
		pauseOnFocus:false,
		swipe:true,
		draggable:true
	});

	$('.mvPrev').on('click', function(){
		$mv.slick('slickPrev');
	});

	$('.mvNext').on('click', function(){
		$mv.slick('slickNext');
	});

});






gsap.registerPlugin(ScrollTrigger);

$(function(){

	if(window.innerWidth >= 977){

		gsap.fromTo("#mIntro .introImg01",
			{
				y:120
			},
			{
				y:-100,
				ease:"none",
				scrollTrigger:{
					trigger:"#mIntro",
					start:"top bottom",
					end:"bottom top",
					scrub:1.5
				}
			}
		);

		gsap.fromTo("#mIntro .introImg02",
			{
				y:180
			},
			{
				y:-160,
				ease:"none",
				scrollTrigger:{
					trigger:"#mIntro",
					start:"top bottom",
					end:"bottom top",
					scrub:0.8
				}
			}
		);

	}

});





$(document).ready(function(){

	var $slider = $('#mLabia .contWrap');
	var $control = $('#mLabia .labiaControl');
	var slickBreakpoint = 1310;

	function setLabiaProgress(slick, currentSlide){
		var current = (currentSlide || 0) + 1;
		var total = slick.slideCount;
		var progress = (current / total) * 100;

		$control.find('.mvNow').text(current);
		$control.find('.mvTotal').text(total);
		$control.find('.mvProgress span').css('width', progress + '%');
	}

	$slider.on('init reInit', function(event, slick){
		setLabiaProgress(slick, 0);
	});

	$slider.on('afterChange', function(event, slick, currentSlide){
		setLabiaProgress(slick, currentSlide);
	});

	function initLabiaSlider(){

		if($(window).width() <= slickBreakpoint){

			if(!$slider.hasClass('slick-initialized')){

				$slider.slick({
					slidesToShow:4,
					slidesToScroll:1,
					infinite:true,
					speed:700,
					arrows:true,
					dots:false,
					autoplay:true,
					prevArrow:$control.find('.mvPrev'),
					nextArrow:$control.find('.mvNext'),
					responsive:[
						{
							breakpoint:977,
							settings:{
								slidesToShow:3
							}
						},
						{
							breakpoint:641,
							settings:{
								slidesToShow:2
							}
						}
					]
				});

			}

		}else{

			if($slider.hasClass('slick-initialized')){
				$slider.slick('unslick');
			}

		}

	}

	initLabiaSlider();

	var resizeTimer;

	$(window).on('resize', function(){
		clearTimeout(resizeTimer);

		resizeTimer = setTimeout(function(){
			initLabiaSlider();
		}, 100);
	});

});











$(document).ready(function(){

	var $wrap = $('#mReview .contWrap');
	var $track = $('#mReview .reviewTrack');

	if(!$track.length) return;

	var originalHTML = $track.html();

	$track.append(originalHTML);

	var position = 0;
	var speed = 0.55;
	var currentSpeed = speed;
	var targetSpeed = speed;
	var halfWidth = 0;

	function setReviewWidth(){
		var $items = $track.children('.in-box');
		var originalCount = $items.length / 2;
		var width = 0;
		var gap = parseFloat($track.css('gap')) || 0;

		for(var i=0; i<originalCount; i++){
			width += $items.eq(i).outerWidth();
		}

		width += gap * originalCount;

		halfWidth = width;
	}

	function reviewLoop(){
		currentSpeed += (targetSpeed - currentSpeed) * 0.06;
		position -= currentSpeed;

		if(Math.abs(position) >= halfWidth){
			position += halfWidth;
		}

		$track.css('transform','translate3d(' + position + 'px,0,0)');

		requestAnimationFrame(reviewLoop);
	}

	setReviewWidth();
	reviewLoop();

	$track.on('mouseenter','.in-box',function(){
		targetSpeed = 0;
	});

	$track.on('mouseleave','.in-box',function(){
		targetSpeed = speed;
	});

	$(window).on('resize',function(){
		setReviewWidth();
	});

});








$(document).ready(function(){

	var $laserItems = $('#mLaser .contWrap .in-box a');
	var laserIndex = 0;
	var laserTimer = null;
	var laserDelay = 2500;

	function laserActive(index){
		$laserItems.removeClass('active');
		$laserItems.eq(index).addClass('active');
	}

	function laserStart(){
		laserTimer = setInterval(function(){
			laserIndex++;

			if(laserIndex >= $laserItems.length){
				laserIndex = 0;
			}

			laserActive(laserIndex);

		}, laserDelay);
	}

	function laserStop(){
		clearInterval(laserTimer);
	}

	laserActive(0);
	laserStart();

	$laserItems.on('mouseenter', function(){

		laserStop();

		laserIndex = $laserItems.index(this);
		laserActive(laserIndex);

	});

	$laserItems.on('mouseleave', function(){

		laserStart();

	});

});








$(document).ready(function(){

	var $marquee = $('.reneMarquee');
	var $track = $marquee.find('.reneMarquee-track');
	var text = 'RENE Women’s Clinic';
	var position = 0;
	var speed = 0.8;
	var oneSetWidth = 0;

	function buildMarquee(){

		$track.empty();
		position = 0;

		var $sample = $('<span>').text(text);
		$track.append($sample);

		var itemWidth = $sample.outerWidth(true);
		var wrapWidth = $marquee.outerWidth();

		var count = Math.ceil(wrapWidth / itemWidth) + 3;

		$track.empty();

		for(var i = 0; i < count * 2; i++){
			$track.append($('<span>').text(text));
		}

		oneSetWidth = 0;

		$track.children('span').slice(0, count).each(function(){
			oneSetWidth += $(this).outerWidth(true);
		});

	}

	function marqueeLoop(){

		position -= speed;

		if(Math.abs(position) >= oneSetWidth){
			position += oneSetWidth;
		}

		$track.css('transform','translate3d(' + position + 'px,0,0)');

		requestAnimationFrame(marqueeLoop);

	}

	buildMarquee();
	marqueeLoop();

	var resizeTimer;

	$(window).on('resize',function(){

		clearTimeout(resizeTimer);

		resizeTimer = setTimeout(function(){
			buildMarquee();
		},150);

	});

});






$(document).ready(function(){

	var $youtube = $('.youtube-slider');

	function setYoutubePosition(index){

		var $slides = $youtube.find('.slick-slide');

		$slides.removeClass('youtube-prev-item youtube-next-item youtube-center-item');

		var $center = $slides.filter('[data-slick-index="' + index + '"]').first();

		if(!$center.length) return;

		$center.addClass('youtube-center-item');
		$center.prev('.slick-slide').addClass('youtube-prev-item');
		$center.next('.slick-slide').addClass('youtube-next-item');

	}

	$youtube.on('init', function(event, slick){
		setYoutubePosition(slick.currentSlide);
	});

	$youtube.on('beforeChange', function(event, slick, currentSlide, nextSlide){
		setYoutubePosition(nextSlide);
	});

	$youtube.on('afterChange', function(event, slick, currentSlide){
		setYoutubePosition(currentSlide);
	});

	$youtube.slick({
		centerMode:true,
		centerPadding:'0px',
		slidesToShow:1,
		slidesToScroll:1,
		variableWidth:true,
		infinite:true,
		speed:700,
		autoplay:true,
		autoplaySpeed:5000,
		arrows:true,
		prevArrow:$('.youtube-prev'),
		nextArrow:$('.youtube-next'),
		dots:false,
		pauseOnHover:true,
		pauseOnFocus:true,
		swipe:true,
		draggable:true
	});

});













$(document).ready(function() {

	var $doctorSlider = $('#mDoctor .slider-cont');
	var $doctorNav = $('#mDoctor .slider-nav');
	var $progress = $('#mDoctor .mvProgress span');
	var $now = $('#mDoctor .mvNow');
	var $total = $('#mDoctor .mvTotal');

	function setDoctorProgress(slick, currentSlide) {
		var current = (currentSlide ? currentSlide : 0) + 1;
		var total = slick.slideCount;
		var percent = (current / total) * 100;

		$now.text(current);
		$total.text(total);
		$progress.css('width', percent + '%');
	}

	$doctorSlider.on('init reInit afterChange', function(event, slick, currentSlide) {
		setDoctorProgress(slick, currentSlide);
	});

	$doctorSlider.slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: false,
		fade: true,
		autoplay: true,
		autoplaySpeed: 5000,
		asNavFor: '#mDoctor .slider-nav'
	});

	$doctorNav.slick({
		slidesToShow: 2,
		slidesToScroll: 1,
		asNavFor: '#mDoctor .slider-cont',
		dots: false,
		arrows: false,
		centerMode: false,
		focusOnSelect: true,
		responsive: [
			{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3
				}
			},
			{
				breakpoint: 481,
				settings: {
					slidesToShow: 2
				}
			}
		]
	});

	$('#mDoctor .mvPrev').on('click', function() {
		$doctorSlider.slick('slickPrev');
	});

	$('#mDoctor .mvNext').on('click', function() {
		$doctorSlider.slick('slickNext');
	});

});










$(document).ready(function(){

	var $mClinic = $('#mClinic .mClinicSlick');

	$mClinic.slick({
		slidesToShow:4,
		slidesToScroll:1,
		infinite:true,
		arrows:true,
		dots:false,
		autoplay:true,
		autoplaySpeed:3000,
		speed:700,
		pauseOnHover:false,
		pauseOnFocus:false,
		focusOnSelect:false,
		prevArrow:$('#mClinic .rank-prev'),
		nextArrow:$('#mClinic .rank-next'),
		responsive:[
			{
				breakpoint:1025,
				settings:{
					slidesToShow:3
				}
			},		
			{
				breakpoint:481,
				settings:{
					slidesToShow:2
				}
			}
		]
	});

});