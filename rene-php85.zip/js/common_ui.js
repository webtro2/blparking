$(document).ready(function(){
		$('#gnb_pc').hover(function(){
		$('#header').addClass('menu_on');
		$('#header').addClass('on');
		$('#header').stop().slideDown(300);
	},function(){
		$('#header').removeClass('menu_on');
		$('#header').removeClass('on');
	});


	$("#gnb_pc > ul > li").hover(function(){
		$(this).children("ul").stop().slideDown()
	}, function(){
		$(this).children("ul").stop().slideUp()
	})

	$(".menuToggle").click(function(){
		$("#header").toggleClass("mo_on")
	})




	$('#gnb_mo li.gnb_dp1>div').click(function(){
		if($(this).hasClass('on')){
			$(this).removeClass('on');
			$(this).siblings('.smenu').stop().slideUp(300);
		}else{
			$('#gnb_mo .gnb_dp1>div').removeClass('on');
			$('#gnb_mo .smenu').stop().slideUp(300);
			$(this).addClass('on');
			$(this).siblings('.smenu').stop().slideDown(300);
		}
	});

	$('#header .hd_full').click(function(){
		if($(this).hasClass('m_on')){
			$(this).removeClass('m_on');
			$('#gnb_mo').removeClass('m_menuOn');
			$('#header').removeClass('on');
		}else{
			$(this).addClass('m_on');
			$('#gnb_mo').addClass('m_menuOn');
			$('#header').addClass('on');
		}
	});

	$(window).resize(function(){
		if($(window).width() > 1280){
			$("#header").removeClass("mo_on")
			$("html").removeClass("no-scroll")
		}
	})

	$(".mq-Btn").click(function(){
		$(".mq-menu").toggleClass("on")
		$(".Quick-m-bg").toggleClass("on")
		$(this).toggleClass("on")
	})

//마우스우클릭, 드래그 금지
//	$(document).bind("contextmenu", function(e) {
//			alert('저작권 보호를 위하여 마우스 오른쪽버튼 사용이 금지되었습니다.');
//			return false;
//	});

	$(window).resize(function() {
			if($(window).width() <1024) {
				$(".gnb_dp1>div>a").removeAttr("href")
			}
		});

$("#gnb_mo .gnb .gnb_dp1>div>a").removeAttr("href");


$(".go-top").hide();

	//scrolltop
	var jbOffset = $( '#header' ).offset();
	$( window ).scroll( function() {
		if ( $( document ).scrollTop() > (jbOffset.top+100) ) {
			$( '#header' ).addClass( 'scroll' );
			$('.go-top').fadeIn();
		}
		else {
			$( '#header' ).removeClass( 'scroll' );
			$('.go-top').fadeOut();
		}
	});






	$(document).on('click', '.lang-btn', function(e){
		e.preventDefault();
		e.stopPropagation();

		$(this).closest('.t-lang').toggleClass('on');
	});

	$(document).on('click', function(e){
		if(!$(e.target).closest('.t-lang').length){
			$('.t-lang').removeClass('on');
		}
	});



});


$(function(){
	$(".go-top").on("click", function(e){
		e.preventDefault();
		$("body, html").stop().animate({scrollTop:0}, 500);
	});
});
