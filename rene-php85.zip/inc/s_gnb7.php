<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('climac1')" class="menu1">갱년기란?</a></li>
	<li class="submenu2"><a href="javascript:GoPage('climac2')" class="menu2">갱년기증상</a></li>
	<li class="submenu3"><a href="javascript:GoPage('climac3')" class="menu3">갱년기 필수검진</a></li>
	<li class="submenu4"><a href="javascript:GoPage('climac4')" class="menu4">갱년기 치료</a></li>
</ul>
