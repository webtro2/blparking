<?php include_once "_common.php"; ?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="ko" />
    <meta name="viewport" content="initial-scale=1.0, width=device-width" />
    <meta name="format-detection" content="telephone=no" />


    <?php
    $st_title = "르네여성의원";

    if (isset($page_title) && $page_title) {
        $site_title = $page_title . " | " . $st_title;
    } else if (isset($g5_head_title) && $g5_head_title) {
        $site_title = $g5_head_title;
    } else {
        $site_title = $st_title;
    }
    ?>


    <title><?php echo $site_title; ?></title>
    <meta property="og:title" content="<?php echo $site_title; ?>" />



    <meta name="naver-site-verification" content="c99b0744e4fc9cff9daf450b0bbd596837c51108" />
    <meta name="title" content="<?php echo $site_title; ?>">
    <meta name="author" content="https://reneclinic.co.kr" />
    <meta name="description" content="대구 여의사산부인과, 대구 소음순수술, 비수술 요실금 치료, 여성성형, 소음순성형, 당일 수술 가능, 산부인과 수술 상담, 대구 여성성형, 수성구 여성의원" />
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $site_title; ?>">
    <meta property="og:description" content="대구 여의사산부인과, 대구 소음순수술, 비수술 요실금 치료, 여성성형, 소음순성형, 당일 수술 가능, 산부인과 수술 상담, 대구 여성성형, 수성구 여성의원">
    <meta property="og:subject" content="수성구 여성의원 | 범어동 만촌동 | 르네여성의원">
    <meta property="og:url" content="https://reneclinic.co.kr">
    <meta property="og:image" content="https://reneclinic.co.kr/og.png">
    <meta property="al:web:url" content="https://reneclinic.co.kr">

    <?php $canonical_url = !empty($page_canonical) ? $page_canonical : 'https://reneclinic.co.kr/'; ?>
    <link rel="canonical" href="<?php echo htmlspecialchars($canonical_url, ENT_QUOTES, 'UTF-8'); ?>">




    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@graph": [{
                    "@type": "MedicalClinic",
                    "@id": "https://reneclinic.co.kr/#clinic",
                    "name": "르네여성의원",
                    "alternateName": "대구르네여성의원",
                    "url": "https://reneclinic.co.kr/",
                    "description": "대구 수성구 범어동에 위치한 여성의원으로 여성질환 진료, 여성 검진, 갱년기 진료, 유방·갑상선 검진, 여성성형 및 관련 시술을 안내합니다.",
                    "telephone": "+82-53-753-5040",
                    "address": {
                        "@type": "PostalAddress",
                        "streetAddress": "동대구로 311 범어애플타워 3층, 4층",
                        "addressLocality": "수성구",
                        "addressRegion": "대구광역시",
                        "addressCountry": "KR"
                    },
                    "hasMap": "https://naver.me/FZos6Zya",
                    "openingHoursSpecification": [{
                            "@type": "OpeningHoursSpecification",
                            "dayOfWeek": [
                                "https://schema.org/Monday",
                                "https://schema.org/Thursday"
                            ],
                            "opens": "10:00",
                            "closes": "13:00"
                        },
                        {
                            "@type": "OpeningHoursSpecification",
                            "dayOfWeek": [
                                "https://schema.org/Monday",
                                "https://schema.org/Thursday"
                            ],
                            "opens": "14:00",
                            "closes": "20:00"
                        },
                        {
                            "@type": "OpeningHoursSpecification",
                            "dayOfWeek": [
                                "https://schema.org/Tuesday",
                                "https://schema.org/Wednesday",
                                "https://schema.org/Friday"
                            ],
                            "opens": "10:00",
                            "closes": "13:00"
                        },
                        {
                            "@type": "OpeningHoursSpecification",
                            "dayOfWeek": [
                                "https://schema.org/Tuesday",
                                "https://schema.org/Wednesday",
                                "https://schema.org/Friday"
                            ],
                            "opens": "14:00",
                            "closes": "18:00"
                        },
                        {
                            "@type": "OpeningHoursSpecification",
                            "dayOfWeek": "https://schema.org/Saturday",
                            "opens": "10:00",
                            "closes": "14:00"
                        }
                    ],
                    "publicAccess": true,
                    "availableLanguage": "ko",
                    "sameAs": [
                        "https://pf.kakao.com/_Xexmjj",
                        "https://blog.naver.com/clinicinah",
                        "https://www.youtube.com/user/inahhwang/featured",
                        "https://www.facebook.com/ClinicRene"
                    ],
                    "potentialAction": {
                        "@type": "ReserveAction",
                        "target": {
                            "@type": "EntryPoint",
                            "urlTemplate": "https://booking.naver.com/booking/13/bizes/909122",
                            "inLanguage": "ko"
                        }
                    },
                    "hasOfferCatalog": {
                        "@type": "OfferCatalog",
                        "name": "진료 분야 안내",
                        "itemListElement": [{
                                "@type": "OfferCatalog",
                                "name": "소음순성형",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "소음순이란?",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty1.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "최소절개 소음순수술",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty2.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 3,
                                        "item": {
                                            "@type": "Service",
                                            "name": "소음순수술의 진행과정",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty3.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 4,
                                        "item": {
                                            "@type": "Service",
                                            "name": "대음순수술 및 리프팅",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty4.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 5,
                                        "item": {
                                            "@type": "Service",
                                            "name": "음핵 리프팅",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty5.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 6,
                                        "item": {
                                            "@type": "Service",
                                            "name": "레이저 미백",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty6.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 7,
                                        "item": {
                                            "@type": "Service",
                                            "name": "재수술 프로그램",
                                            "url": "https://reneclinic.co.kr/doc/labiaplasty7.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "@type": "OfferCatalog",
                                "name": "질성형·성감개선",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "질성형(이쁜이수술)이란?",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair1.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "르네 질성형수술",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair2.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 3,
                                        "item": {
                                            "@type": "Service",
                                            "name": "비비브 2.0",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair3.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 4,
                                        "item": {
                                            "@type": "Service",
                                            "name": "베스타",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair4.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 5,
                                        "item": {
                                            "@type": "Service",
                                            "name": "소노케어",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair5.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 6,
                                        "item": {
                                            "@type": "Service",
                                            "name": "윙크필 필러",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair6.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 7,
                                        "item": {
                                            "@type": "Service",
                                            "name": "오르네샷",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair7.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 8,
                                        "item": {
                                            "@type": "Service",
                                            "name": "리비브",
                                            "url": "https://reneclinic.co.kr/doc/vaginalrepair8.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "@type": "OfferCatalog",
                                "name": "유방·갑상선센터",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "유방암검진",
                                            "url": "https://reneclinic.co.kr/doc/breast1.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "갑상선질환",
                                            "url": "https://reneclinic.co.kr/doc/breast2.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 3,
                                        "item": {
                                            "@type": "Service",
                                            "name": "갑상선검진",
                                            "url": "https://reneclinic.co.kr/doc/breast3.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "@type": "OfferCatalog",
                                "name": "여성제모클리닉",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "브라질리언 제모",
                                            "url": "https://reneclinic.co.kr/doc/waxing1.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "비키니 제모",
                                            "url": "https://reneclinic.co.kr/doc/waxing2.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "@type": "OfferCatalog",
                                "name": "여성 검진",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "르네 검진패키지",
                                            "url": "https://reneclinic.co.kr/doc/checkup1.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "웨딩검진",
                                            "url": "https://reneclinic.co.kr/doc/checkup2.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 3,
                                        "item": {
                                            "@type": "Service",
                                            "name": "산전검진",
                                            "url": "https://reneclinic.co.kr/doc/checkup3.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 4,
                                        "item": {
                                            "@type": "Service",
                                            "name": "성병검진",
                                            "url": "https://reneclinic.co.kr/doc/checkup4.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "@type": "OfferCatalog",
                                "name": "갱년기클리닉",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "갱년기 필수검진",
                                            "url": "https://reneclinic.co.kr/doc/climac3.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "갱년기 치료",
                                            "url": "https://reneclinic.co.kr/doc/climac4.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "@type": "OfferCatalog",
                                "name": "여성질환클리닉",
                                "itemListElement": [{
                                        "@type": "ListItem",
                                        "position": 1,
                                        "item": {
                                            "@type": "Service",
                                            "name": "임신·피임",
                                            "url": "https://reneclinic.co.kr/doc/clinic1.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 2,
                                        "item": {
                                            "@type": "Service",
                                            "name": "질염",
                                            "url": "https://reneclinic.co.kr/doc/clinic2.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 3,
                                        "item": {
                                            "@type": "Service",
                                            "name": "생리불순",
                                            "url": "https://reneclinic.co.kr/doc/clinic3.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 4,
                                        "item": {
                                            "@type": "Service",
                                            "name": "비정상출혈",
                                            "url": "https://reneclinic.co.kr/doc/clinic4.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 5,
                                        "item": {
                                            "@type": "Service",
                                            "name": "방광염",
                                            "url": "https://reneclinic.co.kr/doc/clinic5.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 6,
                                        "item": {
                                            "@type": "Service",
                                            "name": "영양치료",
                                            "url": "https://reneclinic.co.kr/doc/clinic6.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    },
                                    {
                                        "@type": "ListItem",
                                        "position": 7,
                                        "item": {
                                            "@type": "Service",
                                            "name": "임신중절수술",
                                            "url": "https://reneclinic.co.kr/doc/clinic7.php",
                                            "provider": {
                                                "@id": "https://reneclinic.co.kr/#clinic"
                                            }
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                },
                {
                    "@type": "WebSite",
                    "@id": "https://reneclinic.co.kr/#website",
                    "url": "https://reneclinic.co.kr/",
                    "name": "르네여성의원",
                    "inLanguage": "ko-KR",
                    "publisher": {
                        "@id": "https://reneclinic.co.kr/#clinic"
                    }
                },
                {
                    "@type": "WebPage",
                    "@id": "https://reneclinic.co.kr/#webpage",
                    "url": "https://reneclinic.co.kr/",
                    "name": "르네여성의원 | 여성질환·여성검진·소음순성형·갱년기클리닉",
                    "inLanguage": "ko-KR",
                    "isPartOf": {
                        "@id": "https://reneclinic.co.kr/#website"
                    },
                    "about": {
                        "@id": "https://reneclinic.co.kr/#clinic"
                    },
                    "description": "르네여성의원의 여성질환, 소음순성형, 질성형·성감개선, 여성 검진, 갱년기, 유방·갑상선 검진 및 진료 안내."
                }
            ]
        }
    </script>



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link rel="stylesheet" type="text/css" href="/css/default.css" />

    <link rel="shortcut icon" href="/favicon.ico">

    <!-- gnb -->
    <script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="/js/common_ui.js"></script>
    <script type="text/javascript" src="/js/sub.js"></script>

    <!-- js -->
    <script type="text/javascript" src="/js/aos.js"></script>
    <script src="/js/allmenu.js"></script>

    <!-- slick -->
    <script src="/js/slick/slick.min.js"></script>
    <link rel="stylesheet" href="/js/slick/slick-theme.css">
    <link rel="stylesheet" href="/js/slick/slick.css">


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script type="text/javascript" src="/js/jquery.easeScroll.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>

    <script type="text/javascript" src="/js/TweenMax.min.js"></script>

</head>

<body>

    <div id="wrap">