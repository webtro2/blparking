<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('intro1')" class="menu1">의료진소개</a></li>
	<li class="submenu2"><a href="javascript:GoPage('intro2')" class="menu2">진료시간안내</a></li>	
	<li class="submenu3"><a href="javascript:GoPage('intro3')" class="menu3">둘러보기</a></li>
	<li class="submenu4"><a href="javascript:GoPage('intro4')" class="menu4">오시는 길</a></li>
</ul>
