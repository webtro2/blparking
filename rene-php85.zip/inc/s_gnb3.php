<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('vaginalrepair1')" class="menu1">질성형(이쁜이수술)이란?</a></li>
	<li class="submenu2"><a href="javascript:GoPage('vaginalrepair2')" class="menu2">르네 질성형수술</a></li>
	<p class="cate2">성감개선</p>
	<li class="submenu3"><a href="javascript:GoPage('vaginalrepair3')" class="menu3">비비브 2.0</a></li>
	<li class="submenu4"><a href="javascript:GoPage('vaginalrepair4')" class="menu4">베스타</a></li>
	<li class="submenu5"><a href="javascript:GoPage('vaginalrepair5')" class="menu5">소노케어</a></li>
	<li class="submenu6"><a href="javascript:GoPage('vaginalrepair6')" class="menu6">질필러</a></li>
	<li class="submenu7"><a href="javascript:GoPage('vaginalrepair7')" class="menu7">오르네샷</a></li>
	<li class="submenu8"><a href="javascript:GoPage('vaginalrepair8')" class="menu8">리비브</a></li>
</ul>
