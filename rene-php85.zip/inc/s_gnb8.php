<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('clinic1')" class="menu1">임신/피임</a></li>
	<li class="submenu2"><a href="javascript:GoPage('clinic2')" class="menu2">질염</a></li>
	<li class="submenu3"><a href="javascript:GoPage('clinic3')" class="menu3">생리불순</a></li>
	<li class="submenu4"><a href="javascript:GoPage('clinic4')" class="menu4">비정상출혈</a></li>
	<li class="submenu5"><a href="javascript:GoPage('clinic5')" class="menu5">방광염</a></li>
	<li class="submenu6"><a href="javascript:GoPage('clinic6')" class="menu6">영양치료</a></li>
	<li class="submenu7"><a href="javascript:GoPage('clinic7')" class="menu7">임신중절수술</a></li>
</ul>
