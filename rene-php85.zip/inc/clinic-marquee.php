	<div class="clinic-marquee m-Part-b">
		<div class="clinic-marquee-track">
			<div class="clinic-marquee-group">
				<img src="/images/sub/clinic-marquee.png" alt="RENE WOMEN'S CLINIC">
				<img src="/images/sub/clinic-marquee.png" alt="">
			</div>
			<div class="clinic-marquee-group" aria-hidden="true">
				<img src="/images/sub/clinic-marquee.png" alt="">
				<img src="/images/sub/clinic-marquee.png" alt="">
			</div>
		</div>
	</div>

