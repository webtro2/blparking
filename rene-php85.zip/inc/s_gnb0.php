<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('intro1')" class="menu1">병원소개</a></li>
	<li class="submenu2"><a href="javascript:GoPage('labiaplasty1')" class="menu2">소음순성형</a></li>
	<li class="submenu3"><a href="javascript:GoPage('vaginalrepair1')" class="menu3">질성형·성감개선</a></li>
	<li class="submenu4"><a href="javascript:GoPage('breast1')" class="menu4">유방·갑상선센터</a></li>
	<li class="submenu5"><a href="javascript:GoPage('waxing1')" class="menu5">여성제모클리닉</a></li>
	<li class="submenu6"><a href="javascript:GoPage('checkup1')" class="menu6">여성 검진</a></li>
	<li class="submenu7"><a href="javascript:GoPage('climac1')" class="menu7">갱년기클리닉</a></li>
	<li class="submenu8"><a href="javascript:GoPage('clinic1')" class="menu8">여성질환클리닉</a></li>
	<li class="submenu9"><a href="javascript:GoPage('comm1')" class="menu9">커뮤니티</a></li>
	<li class="submenu10"><a href="javascript:GoPage('terms')" class="menu10">멤버쉽</a></li>
</ul>
