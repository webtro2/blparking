<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('checkup1')" class="menu1">르네 검진패키지</a></li>
	<li class="submenu2"><a href="javascript:GoPage('checkup2')" class="menu2">웨딩검진</a></li>
	<li class="submenu3"><a href="javascript:GoPage('checkup3')" class="menu3">산전검진</a></li>
	<li class="submenu4"><a href="javascript:GoPage('checkup4')" class="menu4">성병검진</a></li>
</ul>
