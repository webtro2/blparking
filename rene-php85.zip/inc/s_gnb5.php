<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('waxing1')" class="menu1">브라질리언 제모</a></li>
	<li class="submenu2"><a href="javascript:GoPage('waxing2')" class="menu2">비키니 제모</a></li>
	<li class="submenu3"><a href="javascript:GoPage('waxing3')" class="menu3">제모레이저 소개</a></li>
	<li class="submenu4"><a href="javascript:GoPage('waxing4')" class="menu4">제모시 주의사항</a></li>
</ul>
