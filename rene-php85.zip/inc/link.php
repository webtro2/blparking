<script language="javascript">
    function GoPage(code) {
        if (!code) {
            window.location = "/";
        } else if (code == "main") {
            window.location = "/index.php";
        }

        ///////
        else if (code == "intro1") {
            window.location = "/doc/intro1.php";
        } else if (code == "intro1-1") {
            window.location = "/doc/intro1.php#subTitle";
        } else if (code == "intro1-2") {
            window.location = "/doc/intro1-2.php#subTitle";
        } else if (code == "intro1-3") {
            window.location = "/doc/intro1-3.php#subTitle";
        } else if (code == "intro1-4") {
            window.location = "/doc/intro1-4.php#subTitle";
        } else if (code == "intro2") {
            window.location = "/doc/intro2.php";
        } else if (code == "intro3") {
            window.location = "/doc/intro3.php";
        } else if (code == "intro4") {
            window.location = "/doc/intro4.php";
        } else if (code == "intro5") {
            window.location = "/doc/intro5.php";
        } else if (code == "intro6") {
            window.location = "/doc/intro6.php";
        } else if (code == "intro7") {
            window.location = "/doc/intro7.php";
        } else if (code == "dr-hwang") {
            window.location = "/pg/bbs/board.php?bo_table=comm09&sca=황인아+원장";
        } else if (code == "dr-lee") {
            window.location = "/pg/bbs/board.php?bo_table=comm09&sca=이지영+원장";
        } else if (code == "dr-tak") {
            window.location = "/pg/bbs/board.php?bo_table=comm09&sca=탁지영+원장";
        } else if (code == "dr-kim") {
            window.location = "/pg/bbs/board.php?bo_table=comm09&sca=김수정+원장";
        } else if (code == "labiaplasty1") {
            window.location = "/doc/labiaplasty1.php";
        } else if (code == "labiaplasty2") {
            window.location = "/doc/labiaplasty2.php";
        } else if (code == "labiaplasty3") {
            window.location = "/doc/labiaplasty3.php";
        } else if (code == "labiaplasty4") {
            window.location = "/doc/labiaplasty4.php";
        } else if (code == "labiaplasty5") {
            window.location = "/doc/labiaplasty5.php";
        } else if (code == "labiaplasty6") {
            window.location = "/doc/labiaplasty6.php";
        } else if (code == "labiaplasty7") {
            window.location = "/doc/labiaplasty7.php";
        } else if (code == "labiaplasty8") {
            window.location = "/pg/bbs/board.php?bo_table=comm03";
        } else if (code == "labiaplasty9") {
            window.location = "/pg/bbs/board.php?bo_table=comm07";
        } else if (code == "vaginalrepair1") {
            window.location = "/doc/vaginalrepair1.php";
        } else if (code == "vaginalrepair2") {
            window.location = "/doc/vaginalrepair2.php";
        } else if (code == "vaginalrepair3") {
            window.location = "/doc/vaginalrepair3.php";
        } else if (code == "vaginalrepair4") {
            window.location = "/doc/vaginalrepair4.php";
        } else if (code == "vaginalrepair5") {
            window.location = "/doc/vaginalrepair5.php";
        } else if (code == "vaginalrepair6") {
            window.location = "/doc/vaginalrepair6.php";
        } else if (code == "vaginalrepair7") {
            window.location = "/doc/vaginalrepair7.php";
        } else if (code == "vaginalrepair8") {
            window.location = "/doc/vaginalrepair8.php";
        } else if (code == "breast1") {
            window.location = "/doc/breast1.php";
        } else if (code == "breast2") {
            window.location = "/doc/breast2.php";
        } else if (code == "breast3") {
            window.location = "/doc/breast3.php";
        } else if (code == "waxing1") {
            window.location = "/doc/waxing1.php";
        } else if (code == "waxing2") {
            window.location = "/doc/waxing2.php";
        } else if (code == "waxing3") {
            window.location = "/doc/waxing3.php";
        } else if (code == "waxing4") {
            window.location = "/doc/waxing4.php";
        } else if (code == "checkup1") {
            window.location = "/doc/checkup1.php";
        } else if (code == "checkup2") {
            window.location = "/doc/checkup2.php";
        } else if (code == "checkup3") {
            window.location = "/doc/checkup3.php";
        } else if (code == "checkup4") {
            window.location = "/doc/checkup4.php";
        } else if (code == "climac1") {
            window.location = "/doc/climac1.php";
        } else if (code == "climac2") {
            window.location = "/doc/climac2.php";
        } else if (code == "climac3") {
            window.location = "/doc/climac3.php";
        } else if (code == "climac4") {
            window.location = "/doc/climac4.php";
        } else if (code == "climac4_1") {
            window.location = "/doc/climac4.php#page01";
        } else if (code == "climac4_2") {
            window.location = "/doc/climac4.php#page02";
        } else if (code == "climac4_3") {
            window.location = "/doc/climac4.php#page03";
        } else if (code == "clinic1") {
            window.location = "/doc/clinic1.php";
        } else if (code == "clinic2") {
            window.location = "/doc/clinic2.php";
        } else if (code == "clinic3") {
            window.location = "/doc/clinic3.php";
        } else if (code == "clinic4") {
            window.location = "/doc/clinic4.php";
        } else if (code == "clinic5") {
            window.location = "/doc/clinic5.php";
        } else if (code == "clinic6") {
            window.location = "/doc/clinic6.php";
        } else if (code == "clinic7") {
            window.location = "/doc/clinic7.php";
        } else if (code == "comm1") {
            window.location = "/pg/bbs/board.php?bo_table=comm01";
        }
        // else if ( code == "comm1" )		{	window.location = "/doc/comm1.php"; }
        else if (code == "comm2") {
            window.location = "/pg/bbs/board.php?bo_table=comm02_renew";
        } else if (code == "comm3") {
            window.location = "/pg/bbs/board.php?bo_table=comm05";
        } else if (code == "comm4") {
            window.location = "/pg/bbs/faq.php?fm_id=6";
        } else if (code == "comm5") {
            window.location = "/pg/bbs/board.php?bo_table=comm09";
        } else if (code == "login") {
            window.location = "/pg/bbs/login.php";
        } else if (code == "join") {
            window.location = "/pg/bbs/register.php";
        } else if (code == "logout") {
            window.location = "/pg/bbs/logout.php";
        } else if (code == "provision") {
            window.location = "/doc/provision.php";
        } else if (code == "privacy") {
            window.location = "/doc/privacy.php";
        } else if (code == "mypage") {
            window.location = "/pg/bbs/member_confirm.php?url=register_form.php";
        } else if (code == "privacy") {
            window.location = "/doc/privacy.php";
        } else if (code == "terms") {
            window.location = "/doc/terms.php";
        } else if (code == "labia-landing") {
            window.open('https://reneclinic.co.kr/landing/', '_blank');
        } else if (code == "naver") {
            window.open('https://booking.naver.com/booking/13/bizes/909122', '_blank');
        } else if (code == "kakao") {
            window.open('https://pf.kakao.com/_Xexmjj', '_blank');
        } else if (code == "blog") {
            window.open('https://blog.naver.com/clinicinah', '_blank');
        } else if (code == "youtube") {
            window.open('https://www.youtube.com/user/inahhwang/featured', '_blank');
        } else if (code == "face") {
            window.open('https://www.facebook.com/ClinicRene', '_blank');
        } else if (code == "kakao-map") {
            window.open('https://kko.to/9UFHAuRixk', '_blank');
        } else if (code == "naver-map") {
            window.open('https://naver.me/FZos6Zya', '_blank');
        } else if (code == "parking2") {
            window.open('https://kko.to/o5rF6KA8N0', '_blank');
        }



    }
</script>