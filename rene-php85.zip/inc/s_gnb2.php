<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('labiaplasty1')" class="menu1">소음순이란?</a></li>
	<li class="submenu2"><a href="javascript:GoPage('labiaplasty2')" class="menu2">최소절개 소음순수술</a></li>
	<li class="submenu3"><a href="javascript:GoPage('labiaplasty3')" class="menu3">소음순수술의 진행과정</a></li>
	<li class="submenu4"><a href="javascript:GoPage('labiaplasty4')" class="menu4">대음순수술&리프팅</a></li>
	<li class="submenu5"><a href="javascript:GoPage('labiaplasty5')" class="menu5">음핵 리프팅</a></li>
	<li class="submenu6"><a href="javascript:GoPage('labiaplasty6')" class="menu6">레이저 미백</a></li>
	<li class="submenu7"><a href="javascript:GoPage('labiaplasty7')" class="menu7">재수술 프로그램</a></li>
	<li class="submenu8"><a href="javascript:GoPage('labiaplasty8')" class="menu8">수술후기</a></li>
	<li class="submenu9"><a href="javascript:GoPage('labiaplasty9')" class="menu9">수술 전후 사진</a></li>
</ul>
