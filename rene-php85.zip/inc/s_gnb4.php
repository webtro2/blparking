<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('breast1')" class="menu1">유방암검진</a></li>
	<li class="submenu2"><a href="javascript:GoPage('breast2')" class="menu2">갑상선질환</a></li>
	<li class="submenu3"><a href="javascript:GoPage('breast3')" class="menu3">갑상선검진</a></li>
</ul>
