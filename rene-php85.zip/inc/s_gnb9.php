<ul class="smenu">
	<li class="submenu1"><a href="javascript:GoPage('comm1')" class="menu1">병원소식</a></li>
	<li class="submenu2"><a href="javascript:GoPage('comm2')" class="menu2">온라인상담</a></li>
	<li class="submenu3"><a href="javascript:GoPage('comm3')" class="menu3">전화상담신청</a></li>
	<li class="submenu4"><a href="javascript:GoPage('comm4')" class="menu4">자주묻는질문</a></li>
	<li class="submenu5"><a href="javascript:GoPage('comm5')" class="menu5">칼럼</a></li>
</ul>
