<?php
$page_title = "오시는 길";
$page_canonical = "https://reneclinic.co.kr/doc/intro4.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "4";
	$category = "오시는 길";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="inner">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="sMap">
		<!-- * 카카오맵 - 지도퍼가기 -->
		<!-- 1. 지도 노드 -->
		<div id="daumRoughmapContainer1790817882605" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%"></div>
		<!--
			2. 설치 스크립트
			* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
		-->
		<script charset="UTF-8" class="daum_roughmap_loader_script" src="https://t1.kakaocdn.net/kakaomapweb/roughmap/loader/prod/roughmapLoader.js"></script>

		<!-- 3. 실행 스크립트 -->
		<script charset="UTF-8">
			new daum.roughmap.Lander({
				"timestamp" : "1790817882605",
				"key" : "2hwgxcmnqsg"
			}).render();
		</script>
	</div>

	<div id="intro4-2">
		<ul class="add">
			<h2>대구시 동대구로 311 <br class="br480">범어애플타워 3층, 4층</h2>
		</ul>
		<ul class="link">
			<li><a href="javascript:GoPage('kakao-map')" class="bg1"><span>카카오맵 길찾기</span></a></li>
			<li><a href="javascript:GoPage('naver-map')" class="bg2"><span>네이버지도 길찾기</span></a></li>
		</ul>
	</div>

	<div id="intro4-3">
		<ul class="bus">			
			<h3><p>대중교통 이용시</p></h3>
			<dl>
				<dt>지하철</dt>
				<dd>2호선 범어역 3번 출구 [도보 1분]</dd>
			</dl>
			<dl>
				<dt>버스 - 그랜드호텔 앞</dt>
				<dd><span>100-1</span><span>232</span><span>413</span><span>509</span><span>814</span><span>동구1</span><span>수성1-1</span><span>급행3</span><span>순환2</span></dd>
			</dl>
			<dl>
				<dt>버스 - 범어역 2번출구</dt>
				<dd><span>309</span><span>609</span><span>649</span><span>990</span><span>991</span></dd>
			</dl>
		</ul>
		
		<ul class="parking">			
			<h3><p>주차장 안내</p></h3>
			<dl>
				<dt>애플타워 지하주차장</dt>
				<dd>본원 건물 지하주차장</dd>
			</dl>
			<dl>
				<dt>애플2타워 주차장</dt>
				<dd>수성구 동대구로 59길 8-12 (도보 1분) <a href="javascript:GoPage('parking2')" class="p-Map">지도보기</a></dd>
			</dl>
		</ul>
	</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
