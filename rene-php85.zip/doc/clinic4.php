<?php
$page_title = "비정상출혈";
$page_canonical = "https://reneclinic.co.kr/doc/clinic4.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "4";
	$category = "비정상출혈";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic4.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">정상적인 월경주기를 벗어나 <br>불규칙하게 나타나는 자궁출혈</h2>
			<ul class="t1">
				<li>비정상 자궁출혈은 정상적인 생리주기와 관계없이 출혈이 발생하거나 생리량과 기간이 평소와 다르게 나타나는 증상을 말합니다.</li>
				<li>호르몬 불균형, 자궁근종, 자궁내막폴립 등 다양한 원인으로 발생할 수 있으며, 일시적인 변화일 수도 있지만 자궁 및 난소 질환과 관련될 수 있어 정확한 검사와 적절한 치료가 중요합니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>비정상출혈의 원인</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>생리를 만들어 내는 몸 속의 호르몬 분비가 적절하게 공급되지 않아 생리가 일어날 때 자궁의 전 부분에서 동시에 생리가 일어나지 않고 국소적으로 번갈아 가면서출혈이 반복됩니다. 그래서 생리도 나오는데 며칠 후에 다시 하혈이 있게 됩니다.</li>
			<li></li>
		</ul>		
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>초경</li>				
				<li>임신</li>
				<li>스트레스</li>
				<li>호르몬 이상</li>
				<li>급격한 체중감소</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl"> </p>
	</div>
</section>









<section id="clinicIntro" class="subBG m-Part p-Part-b">
<div class="inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>비정상출혈 치료 방법</h2>
			<p class="t1">비정상 출혈은 원인과 출혈의 정도, 연령, 향후 임신 계획 등을 고려하여 치료 방법을 결정합니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box w4">
				<li>
					<dl>
						<dt>호르몬 약물치료</dt>
						<dd>호르몬제를 사용하여 자궁내막을 안정시키고 불규칙한 출혈이나 과다월경을 조절합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>비호르몬 약물치료</dt>
						<dd>출혈량을 줄이는 지혈 관련 약물이나 소염진통제 등을 상태에 따라 사용합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>자궁 내 장치 치료</dt>
						<dd>호르몬 방출 자궁 내 장치를 이용하여 자궁내막 증식을 억제하고 월경량 감소를 돕습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>시술 및 수술적 치료</dt>
						<dd>자궁내막폴립이나 자궁근종 등 구조적 원인이 확인되면 필요한 시술이나 수술을 고려합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>비정상출혈, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리 기간이 아닌데 출혈이 있으면 비정상인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>생리 기간 외 출혈은 비정상 자궁출혈에 해당할 수 있습니다. 일시적인 변화도 있지만 반복된다면 정확한 검사가 필요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">출혈량이 적어도 병원에 가야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>소량의 출혈이라도 반복되거나 성관계 후 발생한다면 진료를 권장합니다. 폐경 이후 출혈은 양과 관계없이 검사가 필요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">비정상 자궁출혈 검사는 어떻게 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>출혈 양상과 월경주기를 확인하고 초음파검사, 임신검사, 혈액검사 등을 시행합니다. 필요한 경우 자궁내막 조직검사를 추가합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">피임약 복용 중 출혈이 생겨도 괜찮나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>피임약 복용 초기에는 부정출혈이 나타날 수 있습니다. 다만 출혈이 지속되거나 양이 많다면 다른 원인이 있는지 확인해야 합니다.</p>
                </div>
            </div>

			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">폐경 이후에도 출혈이 발생할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>폐경 후 출혈은 자궁내막 위축 등으로 발생할 수 있지만 자궁내막암 등의 가능성을 배제해야 하므로 반드시 진료가 필요합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
