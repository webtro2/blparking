<?php
$page_title = "둘러보기";
$page_canonical = "https://reneclinic.co.kr/doc/intro3.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "3";
	$category = "둘러보기";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<!-- <h3 id="subTitle"><span class="vis_dep02"></span></h3> -->

		<div id="sTitle" class="center inner">
			<p class="eng fc-M2">LENE  WOMEN's CLINIC SPACE</p>
			<h2>편안한 상담과 섬세한 시술을 위해 <br>쾌적하고 프라이빗한 진료 환경을 준비했습니다.</h2>
			<p class="t1">상담부터 시술, 진료 후 머무는 시간까지 <br>보다 안정되고 편안한 경험이 이어질 수 있도록 세심하게 준비했습니다.</p>
		</div>



<div id="spaceView">

	<div class="spaceTab">
		<button type="button" class="active" data-floor="floor3">3F</button>
		<button type="button" data-floor="floor4">4F</button>
	</div>

	<div class="floorCont active" id="floor3">

		<div class="spaceData">
			<img src="/images/sub/space3-01.jpg" alt="3층 공간">
			<img src="/images/sub/space3-02.jpg" alt="3층 공간">
			<img src="/images/sub/space3-03.jpg" alt="3층 공간">
			<img src="/images/sub/space3-04.jpg" alt="3층 공간">
			<img src="/images/sub/space3-05.jpg" alt="3층 공간">
			<img src="/images/sub/space3-06.jpg" alt="3층 공간">
		</div>

		<div class="spaceVisual">
			<div class="spaceSide spacePrevImg"></div>
			<div class="spaceMain spaceCurrentImg"></div>
			<div class="spaceSide spaceNextImg"></div>
		</div>

		<div class="arrowControl">
			<div class="in-box">
				<div class="mvProgress"><span></span></div>
				<button type="button" class="mvPrev">prev</button>
				<p class="num"><span class="mvNow">1</span> / <span class="mvTotal">4</span></p>
				<button type="button" class="mvNext">next</button>
			</div>
		</div>

	</div>

	<div class="floorCont" id="floor4">

		<div class="spaceData">
			<img src="/images/sub/space4-01.jpg" alt="4층 공간">
			<img src="/images/sub/space4-02.jpg" alt="4층 공간">
			<img src="/images/sub/space4-03.jpg" alt="4층 공간">
			<img src="/images/sub/space4-04.jpg" alt="4층 공간">
			<img src="/images/sub/space4-05.jpg" alt="4층 공간">
			<img src="/images/sub/space4-06.jpg" alt="4층 공간">
			<img src="/images/sub/space4-07.jpg" alt="4층 공간">
			<img src="/images/sub/space4-08.jpg" alt="4층 공간">
			<img src="/images/sub/space4-09.jpg" alt="4층 공간">
			<img src="/images/sub/space4-10.jpg" alt="4층 공간">
		</div>

		<div class="spaceVisual">
			<div class="spaceSide spacePrevImg"></div>
			<div class="spaceMain spaceCurrentImg"></div>
			<div class="spaceSide spaceNextImg"></div>
		</div>

		<div class="arrowControl">
			<div class="in-box">
				<div class="mvProgress"><span></span></div>
				<button type="button" class="mvPrev">prev</button>
				<p class="num"><span class="mvNow">1</span> / <span class="mvTotal">5</span></p>
				<button type="button" class="mvNext">next</button>
			</div>
		</div>

	</div>

</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
