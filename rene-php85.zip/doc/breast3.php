<?php
$page_title = "갑상선검진";
$page_canonical = "https://reneclinic.co.kr/doc/breast3.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "3";
	$category = "갑상선검진";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>




	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-breast3-1.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">갑상선의 작은 변화까지 세밀하게 <br>살피는 정밀 초음파검사</h2>
			<ul class="t1">
				<li>갑상선초음파검사는 고주파 초음파를 이용해 갑상선의 크기와 형태, 내부 조직의 상태를 확인하는 검사입니다.</li>
				<li>갑상선 결절과 낭종 등 다양한 이상 소견을 관찰하고, 결절의 크기와 모양, 내부 특성을 분석하여 악성 가능성을 평가하며 방사선 노출 없이 비교적 간편하게 진행할 수 있으며, 갑상선 질환의 진단과 추적 관찰에 중요한 역할을 합니다.</li>
			</ul>
		</div>
	</div>



<section id="clinicIntro" class="subBG p-Part-b m-Part">
<div class="inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>초음파검사로 확인할 수 있는 질환</h2>
			<p class="t1">갑상선 질환은 초기 증상이 뚜렷하지 않을 수 있으므로 초기 검진이 중요합니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box w4">			
				<li>
					<dl>
						<dt>갑상선 결절</dt>
						<dd>갑상선 내부에 발생한 혹의 크기와 모양, 경계 및 내부 구조를 자세히 관찰하여 양성 또는 악성 가능성을 평가합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>갑상선 낭종</dt>
						<dd>갑상선 내부에 액체가 차 있는 낭성 병변의 크기와 형태, 내부 성분 등을 확인하여 적절한 관리 방향을 판단합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>갑상선염</dt>
						<dd>갑상선 조직의 염증으로 나타나는 크기와 내부 조직의 변화를 관찰하며, 만성 갑상선염 등 다양한 질환의 진단에 도움을 줍니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>갑상선암 의심 병변</dt>
						<dd>결절의 불규칙한 경계, 미세석회화 등 악성이 의심되는 특징과 주변 림프절의 상태를 확인하여 추가 검사 필요성을 판단합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>



<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>초음파검사, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갑상선 초음파검사는 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 약 10~20분 정도 소요되며, 갑상선의 상태와 검사 범위에 따라 달라질 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검사 전 금식이 필요한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적인 갑상선초음파검사는 금식이 필요하지 않으며, 별도의 특별한 준비 없이 검사가 가능합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갑상선 초음파검사는 정기적으로 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>모든 사람에게 정해진 갑상선초음파 검진 주기가 있는 것은 아닙니다. 결절의 유무와 크기, 초음파 소견, 가족력 등에 따라 검사 및 추적 관찰 주기가 달라지므로 전문의와 상담하는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">초음파검사만으로 갑상선암을 확진할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>초음파검사는 악성 가능성을 평가하는 검사로, 암을 확진할 수는 없습니다. 필요한 경우 초음파 유도 세침흡인검사 등 추가 검사를 시행합니다.</p>
                </div>
            </div>
           
        </div>
    </div>
</div>



<?php include "../inc/clinic-marquee.php"; ?>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-breast3-2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">갑상선 결절의 정확한 진단을 위한 <br>초음파 유도 세침흡인검사</h2>
			<ul class="t1">
				<li>갑상선에 결절(혹이나 덩어리 등)이 만져지는 등 갑상선암이 의심되는 경우 이것이 실제 암인지 아닌지를 확실하게 알아보기 위해 갑상선 세포검사를 시행합니다.</li>
				<li>갑상선 세포검사를 통해 80~90%정도 암의 여부를 확실히 가릴 수 있습니다.</li>
				<li>단, 경우에 따라 굵은 바늘을 이용한 조직검사를 시행하거나 여러 번 반복 시행해도 암인지 확인이 어려운 경우에는 드물게 수술을 통한 절제생검을 시행하기도 합니다.</li>
			</ul>
		</div>
	</div>






<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class="s-inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>갑상선 암 진단방법</h2>
		<p class="t1">갑상선암은 초기에는 뚜렷한 증상이 없는 경우가 많아 정확한 검사를 통한 진단이 중요합니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4">
			<li>
				<h3><p>초음파로 결절 확인</p></h3>
				<img src="/images/sub/breast3-2-img1.png">
				<p class="t1">초음파를 이용해 갑상선 결절의 위치와 크기, 형태를 확인하고 검사 부위를 소독합니다.</p>
			</li>
			<li>
				<h3><p>세침을 이용한 세포 채취</p></h3>
				<img src="/images/sub/breast3-2-img2.png">
				<p class="t1">초음파로 결절의 위치를 확인하면서 가느다란 바늘을 삽입해 세포를 채취합니다.</p>
			</li>
			<li>
				<h3><p>검사 마무리 및 세포 분석</p></h3>
				<img src="/images/sub/breast3-2-img3.png">
				<p class="t1">검사 부위를 압박하여 지혈하고, 채취한 세포를 현미경으로 분석해 악성 여부를 평가합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>세침흡인검사, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">세침흡인검사 전 주의사항은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 금식은 필요하지 않습니다. 다만 아스피린, 와파린 등 항응고제나 항혈소판제를 복용 중이라면 반드시 의료진에게 알려야 합니다. 복용 중인 약은 임의로 중단하지 말고 의료진의 안내를 따라주세요.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">세침흡인검사는 통증이 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>가느다란 바늘을 사용하기 때문에 검사 중 따끔한 통증이나 압박감이 느껴질 수 있습니다. 통증의 정도는 개인마다 다르며, 대부분 비교적 짧은 시간 안에 검사가 마무리됩니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검사 시간은 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>세포 채취 자체는 보통 수분 이내에 진행되며, 초음파 확인과 소독, 검사 후 지혈 등을 포함하면 약 10~20분 정도 소요될 수 있습니다. 결절의 상태에 따라 검사 시간은 달라질 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검사 후 주의사항은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>검사 후에는 출혈 예방을 위해 검사 부위를 충분히 압박해야 합니다. 당일에는 격한 운동이나 목에 무리가 가는 활동을 피하고, 검사 부위를 강하게 문지르거나 마사지하지 않는 것이 좋습니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검사 후 바로 일상생활이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>대부분 검사 후 특별한 문제가 없다면 일상생활이 가능합니다. 다만 검사 부위에 일시적인 통증이나 멍이 생길 수 있으므로 당일에는 무리한 활동을 피하고 충분한 휴식을 취하는 것이 좋습니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검사 결과는 언제 확인할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>채취한 세포를 병리학적으로 분석하는 과정이 필요하므로 일반적으로 수일에서 약 1주일 정도 소요됩니다. 검사기관에 따라 달라질 수 있으며, 결과가 불명확한 경우 재검사가 필요할 수 있습니다.</p>
                </div>
            </div>
           
        </div>
    </div>
</div>





</div>
</div>
<?php include "../inc/bottom.php"; ?>
