<?php
$page_title = "소음순이란";
$page_canonical = "https://reneclinic.co.kr/doc/labiaplasty1.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "1";
	$category = "소음순이란";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-labia1.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">대음순과 함께 외부 자극으로부터 <br>내부 생식기를 보호합니다.</h2>
			<ul class="t1">
				<li>여성의 외음부에 있는 한쌍의 주름으로, 대개는 두꺼운 대음순으로 덮여 있으며 <br>미세 혈관과 신경이 많이 분포되어 성적 흥분을 일으키고 윤활액을 분비합니다. </li>
				<li>모양과 색깔은 여성에 따라 다르며, 자극에 예민하고 쉽게 부을 수 있습니다. </li>
				<li>안쪽의 음핵, 요도, 질입구를 보호하고 있습니다.</li>
				<li>유전적 요소에 의해 모양이 결정되는 경우가 많으나, 자극이나 염증으로 인해 <br>변형이 일어날 수 있습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>이상적인 소음순의 모양이란?</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>소음순은 개인마다 크기와 모양, 좌우 대칭 정도가 다르며, 정해진 이상적인 형태는 없습니다. </li>
			<li>일반적으로 양측 소음순이 자연스러운 균형을 이루고, 과도한 늘어짐이나 마찰로 인한 불편함 없이 편안한 상태를 유지하는 것이 중요합니다.</li>
		</ul>		
		<img src="/images/sub/labia1-img1.png" alt="이상적인 소음순 모양" class="labia1-img1">
		<p class="t2 fc-bl">무엇보다 가장 이상적인 소음순은 <br>
단순한 크기나 비율보다 개인의 신체 구조에 어울리는 자연스러운 조화와 기능적인 편안함에 있습니다.</p>
	</div>
</section>




<section id="clinicIntro" class="subBG p-Part-b m-Part">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>소음순수술이 필요한 경우</h2>
			<p class="t1">개인의 신체 구조와 불편함의 원인을 세심하게 살펴 <br>자연스러운 형태와 균형, 기능적인 편안함을 함께 고려합니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>소음순 비대</dt>
						<dd>소음순의 크기가 너무 커서 타이트한 바지, 스타킹을 입거나 자전거같은 운동을 할 때 끼거나 불편한 느낌이 드시는 분</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>소음순 비대칭</dt>
						<dd>소음순 좌우의 크기나 모양이 달라 신경이 쓰이시는 분, 소음순 한쪽만 대음순 밖으로 노출되어 쓸림이 생기거나, 소변이 한쪽으로 타고 흘러 불편할 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>반복적인 염증</dt>
						<dd>소음순에 자주 뾰루지가 생기고 염증이 생겨, 붓고 아픈 상태가 반복되는 분</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>소음순 착색</dt>
						<dd>소음순 끝의 색이 진하게 변하여 갈색, 회색으로 보이는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>성관계 시 불편감</dt>
						<dd>관계를 가질 때 소음순이 말려들어가 통증이 생기거나 점점 더 늘어지는 느낌이 드는 분, 소음순이 늘어져 이전 같은 자극감, 오르가즘이 없는 분</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>







<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>소음순수술, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술은 어떤 경우에 필요한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>소음순은 개인마다 크기와 모양이 다르며, 반드시 수술이 필요한 것은 아닙니다.<br>
                    다만 비대칭이나 과도한 늘어짐으로 일상생활에서 마찰, 통증 또는 위생 관리에 불편함이 있는 경우 수술을 고려할 수 있습니다.<br>
                    충분한 상담과 정밀한 진찰을 통해 개인의 상태에 맞는 수술 방향을 결정하는 것이 중요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 후 일상생활은 언제부터 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 후 회복 속도는 개인마다 차이가 있으며, 초기에는 붓기나 가벼운 통증이 나타날 수 있습니다.<br>
                    가벼운 일상생활은 상태에 따라 수일 내 가능하지만, 격한 운동이나 성관계 등은 일반적으로 4~6주 정도 피하는 것이 권장됩니다.<br>
                    정확한 활동 재개 시점은 수술 부위의 회복 상태를 확인한 후 의료진과 상의하는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 후 흉터나 감각 변화가 생길 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 부위에는 개인의 피부 특성과 회복 과정에 따라 흉터가 남을 수 있습니다.<br>
                    또한 일시적이거나 지속적인 감각 변화가 발생할 가능성이 있으며, 붓기가 가라앉고 조직이 안정되기까지 수개월이 걸릴 수 있습니다.<br>
                    충분한 회복 기간을 두고 의료진의 안내에 따라 경과를 관찰하는 것이 중요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 후 발생할 수 있는 부작용은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 후 일시적인 붓기, 멍, 통증 등이 나타날 수 있으며, 출혈이나 감염, 혈종, 상처 벌어짐 등의 합병증이 발생할 수 있습니다.<br>
                    개인에 따라 흉터, 비대칭 또는 감각 변화가 남을 가능성도 있습니다.<br>
                    심한 통증이나 지속적인 출혈, 발열, 비정상적인 분비물 등이 나타나면 즉시 의료진의 진료를 받아야 합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 전후에는 어떤 점을 주의해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 전에는 복용 중인 약물과 기저질환, 알레르기 여부 등을 의료진에게 정확히 알려야 합니다.<br>
                    수술 후에는 수술 부위를 청결하게 관리하고, 꽉 끼는 옷이나 과도한 마찰을 피하는 것이 좋습니다.<br>
                    처방받은 약물과 수술 후 관리 지침을 준수하며, 정기적인 경과 확인을 통해 회복 상태를 점검하는 것이 중요합니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
