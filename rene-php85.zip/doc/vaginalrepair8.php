<?php
$page_title = "리비브";
$page_canonical = "https://reneclinic.co.kr/doc/vaginalrepair8.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "8";
	$category = "리비브";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-vaginal8.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">멀티웨이브 고주파 에너지로 <br>질 속 깊은 곳부터 탄력 있게</h2>
			<ul class="t1">
				<li>리비브는 멀티웨이브 고주파(RF) 에너지를 질 내부 조직에 전달하여 콜라겐 생성과 <br>조직의 탄력 개선을 유도하는 비수술적 여성 시술입니다.</li>
			<li>절개 없이 진행되는 방식으로 질 이완과 탄력 저하, 질 건조로 인한 불편함 등 <br>여성의 다양한 고민에 대한 개선을 기대할 수 있습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>콜라겐 생성 촉진 · 질 내부 탄력성 증가</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>단일 주파수 방식과 달리 여러 주파수의 고주파 에너지를 활용하는 멀티웨이브 기술을 적용합니다.</li>
			<li>질 내부에 전달된 고주파 에너지는 조직의 전기저항에 의해 열에너지로 전환되며, 이러한 열 자극은 콜라겐 재구성과 <br>조직의 탄력 개선을 유도하는 데 활용됩니다.</li>
			<li>또한 시술 부위의 온도를 실시간으로 감지하고 에너지 출력을 제어하여 과도한 열 발생을 억제하고, <br>보다 균일한 에너지 전달을 돕습니다.</li>
		</ul>		
	</div>	
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>성감개선 타이트닝</li>
				<li>질 건조증 개선</li>
				<li>요실금 개선</li>
				<li>생리통 완화</li>
				<li>외음부 타이트닝</li>				
				<li>악취·염증 개선</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">르네여성의원은 개인의 질 건강 상태와 탄력 저하 정도를 충분히 확인하고, <br>산부인과 전문의의 상담을 통해 적합한 시술 방향을 제안합니다.</p>
	</div>
</section>



<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>리비브,  <br class="br480">이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>아랫배가 냉하신 분</p></li>
				<li><p>생리통이 있으신 분</p></li>
				<li><p>질이 건조해져 고통을 느끼시는 분</p></li>
				<li><p>요실금이 있으신 분</p></li>
				<li><p>질 염증이 있으신 분</p></li>
				<li><p>외음부의 색상이 검게 변하신 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>






<section class="subBG p-Part-b">
<div id="labia2-2" class=" s-inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>리비브만의 차별점</h2>
		<p class="t1">열량제어방식을 통해 인체 내부의 저항을 조절하여 보다 안정적인 시술 효과를 기대할 수 있습니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4">
			<li>
				<h3><p>멀티웨이브</p></h3>
				<img src="/images/sub/vaginal8-2-img1.png">
				<p class="t1">한번의 펄스에 반응하는 분극현상이 멀티웨이브로 인해 반응의 빈번함과 운동량이 많아져 훨씬 강력한 효과를 보입니다.</p>
			</li>
			<li>
				<h3><p>열량제어방식</p></h3>
				<img src="/images/sub/vaginal8-2-img2.png">
				<p class="t1">온도감지센서가 실시간으로 온도를 파악하여, 시술자의 플랜대로 필요한 만큼의 열에너지를 전달합니다.</p>
			</li>
			<li>
				<h3><p>RF에너지</p></h3>
				<img src="/images/sub/vaginal8-2-img3.png">
				<p class="t1">RF(고주파) 에너지를 조직의 특정 부위에 정밀하게 전달하여 열을 발생시키고, 조직 내부에 열에너지가 고르게 작용하여 콜라겐 수축과 재생을 촉진합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>리비브, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">리비브 시술 시간은 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>리비브는 절개 없이 고주파(RF) 에너지를 이용하는 비수술적 시술입니다. 시술 시간은 적용 범위와 개인의 상태에 따라 달라질 수 있으며, 정확한 소요 시간은 상담 후 안내해 드립니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시 통증은 어느 정도인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 중 따뜻한 열감이나 가벼운 불편함이 느껴질 수 있습니다. 통증의 정도는 개인마다 다르며, 시술 중 반응을 확인하면서 에너지 강도를 조절합니다.</p>
                </div>
            </div>


            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술은 몇 회 정도 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>필요한 시술 횟수와 간격은 질 조직의 상태, 개선 목적, 개인별 반응에 따라 달라집니다. 충분한 상담과 진찰을 통해 적합한 시술 계획을 결정합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 후 일상생활은 바로 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>절개나 봉합이 필요하지 않아 일반적으로 시술 후 일상생활이 가능합니다. 다만 일시적인 열감이나 불편함이 발생할 수 있으므로 의료진이 안내하는 주의사항을 지켜주시는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">오르네샷 시술 후 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>비수술적 시술이지만 일시적인 열감, 붓기, 통증, 분비물 변화 등이 나타날 수 있으며 드물게 화상이나 조직 손상이 발생할 가능성도 있습니다. 불편한 증상이 지속되거나 심해지는 경우 의료진의 진료를 받으셔야 합니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
