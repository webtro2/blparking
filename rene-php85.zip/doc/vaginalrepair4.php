<?php
$page_title = "베스타";
$page_canonical = "https://reneclinic.co.kr/doc/vaginalrepair4.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "4";
	$category = "베스타";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-vaginal4.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">360도 콜라겐 리모델링, <br>베스타 질 타이트닝 & 요실금 치료</h2>
			<ul class="t1">
				<li>질의 벽이라고 할 수 있는 질 점막은 매우 얇고 약한 부위이기에 노화와 출산등으로 늘어지게 됩니다.</li>
			<li>늘어난 부위에 분비물이 고이면 냄새가 자주 나고 불쾌한 감정을 느끼게 되고
질 점막이 탄력을 잃고 늘어나 수축력이 떨어지게 되면서 성관계 시 민감도 역시 낮아질 수 있습니다.</li>
			<li>프랙셔널 레이저를 이용하여 콜라겐 형성을 활성화시켜 탄력을 잃은 질벽을 탄력있게 타이트닝 해줍니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>피부 프락셀처럼 질 점막을 새롭게 리뉴얼</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>피부과에서 흉터나 탄력 개선을 위해 받는 '프락셀' 레이저와 유사한 원리를 질 건강에 적용한 시술입니다.</li>
			<li>특수 레이저 에너지를 이용해 질 점막 표면에 아주 미세한 마이크로 단위의 상처를 유도하고, 이것이 자연적으로 치유되는 과정을 거칩니다. 이 재생 과정에서 낡고 늘어난 세포는 자연스럽게 탈락·파괴되고, 그 자리에 탄력 있고 건강한 새 세포와 콜라겐이 촘촘하게 채워지게 됩니다.</li>
		</ul>
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>요실금 개선</li>
				<li>질탄력 강화</li>
				<li>질건조 개선</li>
				<li>성감향상</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">결과적으로 헐거워지고 탄력을 잃은 질벽이 타이트하게 수축하며, <br>전반적인 질 내 환경(수축력, 건조증, 민감도 등)이 젊고 건강했던 상태로 리모델링되는 효과를 기대할 수 있습니다.</p>
	</div>
</section>




<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>베스타,  <br class="br480">이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>기침이나 재채기를 할 때 소변이 찔끔 새는 분</p></li>
				<li><p>화장실을 가고 싶은 생각이 들면 참지 못하고 실수하는 분</p></li>
				<li><p>질 이완증이 심해 질방귀가 생기는 분</p></li>
				<li><p>부부관계에서 충분한 자극감이 없는 분</p></li>
				<li><p>수술적 치료가 걱정되고 거부감이 있는 분</p></li>
				<li><p>갱년기 증상으로 질건조증, 질염의 잦은 재발이 있는 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>





<section id="clinicIntro" class="subBG p-Part-b">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>르네여성의원의 베스타 시술</h2>
			<p class="t1">프락셀 원리로 질 점막을 재생하는 베스타 레이저는, <br>통증과 흉터 걱정 없이 10~15분 만에 콜라겐을 생성하여 타이트닝과 요실금을 동시에 개선합니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>프락셀 원리의 점막 재생</dt>
						<dd>미세한 자극과 회복 과정을 통해 낡은 세포는 파괴하고, 건강한 새 세포를 생성해 질 환경을 리뉴얼합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>콜라겐 생성 & 타이트닝</dt>
						<dd>고출력 레이저 에너지가 질벽 깊숙이 콜라겐 활성화를 유도해 탄력을 잃은 조직을 쫀쫀하게 수축해 줍니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>요실금과 탄력을 동시에</dt>
						<dd>이완된 질 탄력 회복은 물론, 약해진 요도 주변 조직을 지지해 주어 요실금 증상까지 한 번에 해결합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>통증 부담 없는 짧은 시간</dt>
						<dd>마취 부담과 통증이 거의 없으며, 짧은 시간 안에 끝나는 간편한 시술로 바쁜 일상에도 지장이 없습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>흉터 걱정 없는 비수술</dt>
						<dd>절개나 봉합이 필요 없어 겉으로 흉터가 전혀 남지 않으며, 시술 후 즉시 일상 복귀가 가능합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>베스타, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">베스타 시술은 어떤 원리인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>레이저 빔을 질 벽에 조사하여 콜라겐을 자극시키는 원리로 질 점막의 탄력이 증가하여 요실금 개선 및 성감이 향상됩니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시간은 얼마나 되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>베스타 레이저 시술 시간은 준비 과정을 포함해도 약 15분에서 20분 내외로 매우 짧습니다. <br>
실제 레이저가 조사되는 시간은 단 몇 분 정도이며, 절개나 마취 과정이 거의 필요 없어 바쁜 직장인이나 육아 중인 분들도 부담 없이 받으실 수 있습니다. 시술 직후 바로 일상생활로 복귀하실 수 있어 시간적 여유가 부족하신 분들에게 매우 효율적인 시술입니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술은 몇 회를 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>베스타 레이저 시술은 개인의 질 이완 정도와 탄력 상태, 그리고 원하는 개선 목표에 따라 차이가 있을 수 있지만 보통은 1달 간격으로 3회 정도 받는 것을 기본 코스로 권장합니다. 한 번의 시술만으로도 콜라겐 재생과 타이트닝 효과를 느낄 수 있지만, 피부 관리와 마찬가지로 여러 차례 누적해서 시술을 받으셔야 점막 세포가 튼튼하게 리모델링되어 가장 오랫동안 효과를 유지할 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술은 언제 받아야 가장 좋은가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술시기 및 연령대 제한 없이, 생리기간만 피하면 언제든 시술 받으실 수 있습니다.</p>
                </div>
            </div>

			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">베스타 시술 후 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>베스타 레이저는 절개나 봉합이 없는 비수술적 레이저 시술로, 피부과 프락셀과 유사하게 인체의 자연 치유 원리를 이용하기 때문에 심각한 부작용이나 흉터 걱정은 거의 없습니다.
다만, 시술 후 회복 과정에서 아래와 같은 일시적인 현상이 나타날 수 있으나 이는 정상적인 회복 반응이므로 안심하셔도 좋습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>





</div>
</div>
<?php include "../inc/bottom.php"; ?>
