<?php
$page_title = "소음순수술의 진행과정";
$page_canonical = "https://reneclinic.co.kr/doc/labiaplasty3.php"  
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "3";
	$category = "소음순수술의 진행과정";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-labia3.png"></div>
		<div id="topcont" class="labia3">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">당일 수술을 원하실 경우 <br>꼭 사전 전화상담과 예약이 필요합니다.</h2>
			<ul class="t1">
				<li>충분한 상담과 정밀한 디자인을 시작으로 섬세한 절개, 지혈, 미세봉합까지 <br>각 과정을 체계적으로 진행하며, 자연스러운 형태와 기능적인 편안함을 함께 고려합니다.</li>
				<li>수술 후에도 회복 상태를 꼼꼼하게 확인하고 개인별 경과에 맞춘 사후관리를 통해 <br>안정적인 회복을 돕습니다.</li>
			</ul>
		</div>
	</div>





<?php include "../inc/clinic-marquee.php"; ?>





<div id="ScrollWrap" class="p-Part-b pt0 s-inner">

	<div id="imgWrap">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>소음순수술의 진행과정</h2>
			<p class="t1">미적인 균형과 기능적인 개선을 함께 추구하여 <br>보다 편안하고 만족스러운 일상으로 이어질 수 있도록 합니다.</p>
		</div>
		<ul class="mt80">
			<li class="img1 on"  data-index="1"><img src="/images/sub/labia3-2-img1.png"></li>
			<li class="img2"  data-index="2"><img src="/images/sub/labia3-2-img2.png"></li>
			<li class="img3"  data-index="3"><img src="/images/sub/labia3-2-img3.png"></li>
			<li class="img4"  data-index="4"><img src="/images/sub/labia3-2-img4.png"></li>
			<li class="img5"  data-index="5"><img src="/images/sub/labia3-2-img5.png"></li>
			<li class="img6"  data-index="6"><img src="/images/sub/labia3-2-img6.png"></li>
			<li class="img7"  data-index="7"><img src="/images/sub/labia3-2-img7.png"></li>
			<li class="img8"  data-index="8"><img src="/images/sub/labia3-2-img8.png"></li>
			<li class="img9"  data-index="9"><img src="/images/sub/labia3-2-img9.png"></li>
			<li class="img10"  data-index="10"><img src="/images/sub/labia3-2-img10.png"></li>
		</ul>
	</div>
	<div id="contWrap">
			<li class="img"><img src="/images/sub/labia3-2-img1.png"></li>
			<div class="box nth1" data-index="1">
					<h3><span class="step"><em>STEP 1</em></span>내원상담</h3>
					<ul class="t1">
						<li>소음순의 크기와 모양, 비대칭, 늘어짐 등으로 인한 불편함과 고민을 충분히 상담합니다. </li>
						<li>일상생활에서 느끼는 마찰이나 통증, 위생적인 불편함 등을 세심하게 확인하고, 개인의 신체적 특징과 원하는 개선 방향을 종합적으로 고려하여 적합한 수술 방법을 안내합니다.</li>
					</ul>
			</div>
			
			<li class="img"><img src="/images/sub/labia3-2-img2.png"></li>
			<div class="box" data-index="2">
					<h3><span class="step"><em>STEP 2</em></span>상세진찰</h3>
					<ul class="t1">
						<li>담당 의료진의 세밀한 진찰을 통해 소음순의 크기와 형태, 좌우 비대칭, 피부의 늘어짐 정도 및 주변 조직의 상태를 종합적으로 확인합니다.</li>
						<li>필요한 경우 사진 촬영을 통해 현재 상태를 객관적으로 분석하고, 개인의 해부학적 구조와 개선이 필요한 부분을 고려하여 적합한 수술 범위와 방법을 계획합니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img3.png"></li>
			<div class="box" data-index="3">
					<h3><span class="step"><em>STEP 3</em></span>수술옵션의 제공</h3>
					<ul class="t1">
						<li>상세 진찰 결과를 바탕으로 소음순의 형태와 상태, 개인이 원하는 개선 방향을 종합적으로 고려하여 적합한 수술 방법을 안내합니다.</li>
						<li>각 수술 방법의 특징과 기대할 수 있는 개선 효과, 수술 범위 및 회복 과정 등을 충분히 설명하고, 환자가 자신의 상태에 맞는 수술 방법을 신중하게 선택할 수 있도록 돕습니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img4.png"></li>
			<div class="box" data-index="4">
					<h3><span class="step"><em>STEP 4</em></span>수술일자 결정 및 검사</h3>
					<ul class="t1">
						<li>환자의 건강 상태와 개인 일정을 고려하여 적절한 수술 날짜를 결정하고 예약을 진행합니다.</li>
						<li>안전한 수술을 위해 필요한 사전 검사를 시행하고, 복용 중인 약물이나 기저질환, 알레르기 여부 등을 확인합니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img5.png"></li>
			<div class="box" data-index="5">
					<h3><span class="step"><em>STEP 5</em></span>수술 전 안내</h3>
					<ul class="t1">
						<li>수술 하루 전, 원활하고 안전한 수술 진행을 위해 필요한 준비사항과 주의사항을 안내 메시지로 전달합니다.</li>
						<li>수술 당일 내원 시간과 준비물, 복장 및 개인위생 관리 등 사전에 확인해야 할 사항을 상세히 안내하여 환자가 편안한 마음으로 수술을 준비할 수 있도록 돕습니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img6.png"></li>
			<div class="box" data-index="6">
					<h3><span class="step"><em>STEP 6</em></span>수술 당일 동의서 작성</h3>
					<ul class="t1">
						<li>수술 당일 집도의가 직접 환자의 상태와 수술 계획을 다시 한번 확인하고, 수술 방법과 진행 과정에 대해 상세히 설명합니다.</li>
						<li>수술 후 예상되는 회복 과정과 발생 가능한 부작용 및 합병증, 주의사항과 사후관리 방법 등을 충분히 안내하며, 환자가 내용을 이해하고 동의한 후 수술 동의서를 작성합니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img7.png"></li>
			<div class="box" data-index="7">
					<h3><span class="step"><em>STEP 7</em></span>수술</h3>
					<ul class="t1">
						<li>수면마취와 국소마취를 병행하여 수술 중 통증과 불편함을 최소화합니다. </li>
						<li>개인의 소음순 형태와 해부학적 구조를 고려하여 수술 부위를 정밀하게 디자인한 후, 베살리우스 장비를 이용해 출혈을 조절하며 섬세하게 절개와 지혈을 진행합니다. 이후 아주 가는 흡수성 미세봉합사를 사용하여 조직을 세밀하게 봉합하며, 자연스러운 형태와 기능적인 편안함을 함께 고려합니다.</li>
						<li>수술 시간은 약 1시간 전후로, 개인의 상태와 수술 범위에 따라 달라질 수 있습니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img8.png"></li>
			<div class="box" data-index="8">
					<h3><span class="step"><em>STEP 8</em></span>회복 및 퇴원</h3>
					<ul class="t1">
						<li>수술 후 약 1~2시간 동안 회복실에서 안정을 취하며 마취에서 충분히 회복할 수 있도록 돕습니다.</li>
						<li>의료진이 환자의 의식 상태와 수술 부위의 출혈, 통증 및 전반적인 회복 상태를 세심하게 확인하고, 특별한 이상이 없으면 퇴원하게 됩니다.</li>
					</ul>
			</div>


			<li class="img"><img src="/images/sub/labia3-2-img9.png"></li>
			<div class="box" data-index="9">
					<h3><span class="step"><em>STEP 9</em></span>수술 후 관리</h3>
					<ul class="t1">
						<li>수술 당일에는 출혈과 부종을 줄이기 위해 의료진의 안내에 따라 수술 부위를 적절히 압박하고, 병원에서 제공한 아이스팩을 이용해 냉찜질을 시행합니다.</li>
						<li>처방받은 약은 안내된 용법에 따라 복용하며, 수술 다음 날부터는 의료진의 지시에 따라 좌욕과 재생연고를 이용해 수술 부위를 청결하게 관리합니다.</li>
						<li>회복 과정에서 나타날 수 있는 증상과 주의사항을 충분히 안내하여 안정적인 회복을 돕습니다.</li>
					</ul>
			</div>



			<li class="img"><img src="/images/sub/labia3-2-img10.png"></li>
			<div class="box nth10" data-index="10">
					<h3><span class="step"><em>STEP 10</em></span>내원 관리</h3>
					<ul class="t1">
						<li>수술 약 1주일 후 병원에 내원하여 수술 부위의 회복 상태를 확인합니다.</li>
						<li>담당 의료진이 상처의 아물어가는 정도와 부종, 출혈 및 염증 여부 등을 세심하게 살피고, 필요한 경우 봉합사 제거 등 적절한 처치를 시행합니다.</li>
						<li>개인별 회복 경과에 따라 추가 관리 방법과 주의사항을 안내하여 안정적인 회복을 돕습니다.</li>
					</ul>
			</div>




	</div>
</div>








</div>
</div>
<?php include "../inc/bottom.php"; ?>
