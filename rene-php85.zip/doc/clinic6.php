<?php
$page_title = "영양치료";
$page_canonical = "https://reneclinic.co.kr/doc/clinic6.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "6";
	$category = "영양치료";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic6.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">부족한 영양을 채우고, <br>건강한 일상을 위한 영양치료</h2>
			<ul class="t1">
				<li>영양주사는 비타민, 미네랄 등 신체에 필요한 영양성분을 정맥으로 공급하는 치료 방법입니다.</li>
				<li>피로감이나 영양 불균형 등 개인의 건강 상태를 고려하여 필요한 성분을 선택하며, 영양 결핍이 있거나 경구 섭취가 어려운 경우 도움이 될 수 있습니다. 충분한 상담과 진찰을 통해 개인에게 적합한 영양성분과 투여 방법을 결정하는 것이 중요합니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>영양치료의 장점</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>피로, 스트레스 완화에 효과가 있고 그 밖에 면역력 강화, 기력회복, 피부 영양 공급, 항노화, 항산화 등의 효과도 기대할 수 있습니다.</li>
			<li>먹는 비타민제는 아무리 좋은 제제를 먹더라도 제대로 흡수되기가 어려워 충분한 혈중농도에 도달할 수 없습니다.</li>
			<li>영양치료는 혈관 내로 직접 투여하게 되므로, 투여된 용량의 99% 이상이 혈관을 통해 세포에 도달할 수 있습니다.</li>
		</ul>		
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>피로 및 스트레스 관리</li>				
				<li>면역기능 <br>강화 지원</li>
				<li>항노화 및 <br>항산화 관리</li>
				<li>갱년기 건강 관리</li>
				<li>피부 건강 및 <br>활력 관리</li>
				<li>에너지 대사 및 <br>영양 균형 개선</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">부족한 영양을 채워 건강한 일상과 활력을 위한 영양 관리를 시작하세요.</p>
	</div>
</section>






<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class=" inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>영양치료의 종류</h2>
		<p class="t1">영양치료는 개인의 건강 상태에 따라 필요한 비타민과 미네랄 등의 영양성분을 공급하는 방법입니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4">
			<li>
				<h3><p>신데렐라 주사</p></h3>
				<img src="/images/sub/clinic6-1-img1.png">
				<p class="t1 mb30">알파리포산(티옥트산)을 주요 성분으로 하는 주사로, 체내 에너지 대사와 항산화 작용에 관여하는 성분을 공급합니다. 개인의 건강 상태와 영양 상태를 고려하여 투여 여부를 결정합니다.</p>
				<span class="point">항산화</span><span class="point">에너지 대사</span><span class="point">세포 보호</span>
			</li>
			<li>
				<h3><p>글루타치온 주사</p></h3>
				<img src="/images/sub/clinic6-1-img2.png">
				<p class="t1 mb30">체내에서 생성되는 대표적인 항산화 물질인 글루타치온을 공급하는 주사로 글루타치온은 활성산소에 대응하는 항산화 방어체계와 세포 보호 과정에 관여하는 성분입니다.</p>
				<span class="point">항산화</span><span class="point">세포 보호</span><span class="point">산화 스트레스 조절</span>
			</li>
			<li>
				<h3><p>마이어스 칵테일</p></h3>
				<img src="/images/sub/clinic6-1-img3.png">
				<p class="t1 mb30">비타민 B군, 비타민 C, 마그네슘 등 여러 영양성분을 혼합하여 정맥으로 공급하는 영양주사로 영양소의 부족 여부와 개인의 건강 상태에 따라 필요한 성분을 조합합니다.</p>
				<span class="point">영양 보충</span><span class="point">에너지 대사</span><span class="point">비타민 공급</span>
			</li>
			<li>
				<h3><p>비타민D 주사</p></h3>
				<img src="/images/sub/clinic6-1-img4.png">
				<p class="t1 mb30">뼈 건강과 칼슘 흡수에 중요한 비타민 D를 공급하는 주사로 혈중 비타민 D 수치가 부족한 경우 결핍 상태를 개선하고, 정상적인 골격과 근육 기능을 유지하는 데 도움을 줄 수 있습니다.</p>
				<span class="point">뼈 건강</span><span class="point">칼슘 흡수</span><span class="point">근육 기능</span>
			</li>
			<li>
				<h3><p>감초 주사</p></h3>
				<img src="/images/sub/clinic6-1-img5.png">
				<p class="t1 mb30">감초 유래 성분인 글리시리진 등을 함유한 주사로, 제품에 따라 간기능 개선 등의 목적으로 사용됩니다. 간 건강 상태와 복용 중인 약물 등을 확인하여 적절한 투여 여부를 결정합니다.</p>
				<span class="point">간기능 개선 보조</span><span class="point">항염 관련 성분</span><span class="point"> 간 건강</span>
			</li>
			<li>
				<h3><p>태반 주사</p></h3>
				<img src="/images/sub/clinic6-1-img6.png">
				<p class="t1 mb30">인태반 유래 성분을 함유한 주사로, 제품에 따라 갱년기 증상 개선 또는 간기능 개선 등의 목적으로 사용됩니다. 개인의 증상과 건강 상태를 확인하고 허가된 효능에 맞춰 치료를 진행합니다.</p>
				<span class="point">갱년기 증상 개선</span><span class="point">간기능 개선 보조</span><span class="point"> 건강 관리</span>
			</li>
		</ul>
	</div>
</div>
</section>






<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>영양치료, <br class="br480">이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList w2 clinic6">
			<ul class="flex-Box">
				
				<li><p>호르몬의 불균형으로 자궁출혈이 자주 있는 분</p></li>
				<li><p>평소에 자주 피로하고 잔병치레가 많으신 분</p></li>				
				<li><p>갱년기 증상들로 인하여 고생하고 계시는 분</p></li>
				<li><p>스트레스, 신경통, 관절염, 만성통증 개선을 원하시는 분</p></li>
				<li><p>수술 후에 힘들거나 빠른 회복을 원하시는 분</p></li>
				<li><p>평소 술을 자주 마셔 간 해독이 필요하신 분</p></li>
				<li><p>종합적인 영양을 보충하고 싶으신 분</p></li>
				<li><p>다이어트, 산후 다이어트가 필요하신 분</p></li>
			</ul>
		</div>
	</div>
</div>





<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>영양치료, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">영양치료는 얼마나 자주, 주기로 관리해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로는 1주일에 1~2회 간격으로 진행하는 경우가 많으며, 피로가 극심하거나 면역력 증진이 필요할 때는 의료진과 상담 후 횟수와 주기를 조절하게 됩니다. 무조건 자주 맞는 것보다는 본인의 몸 상태에 맞게 꾸준히 관리하는 것이 중요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">영양주사를 맞을 때 주의해야 할 부작용이나 주의사항이 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>대부분 안전하지만, 혈관을 통해 주입되기 때문에 드물게 주사 부위의 통증, 멍, 부기, 가려움증 등이 나타날 수 있습니다.<br>또한, 심장 질환이나 신장 질환 등 기저질환이 있는 경우 성분에 따라 무리가 갈 수 있으므로 반드시 사전에 의료진과 충분히 상담한 후 본인에게 맞는 성분을 선택해야 합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">영양주사를 맞으면 효과가 바로 나타나나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>개인의 체질과 피로도에 따라 다르지만, 맞고 난 직후 혹은 하루 이내에 몸이 가벼워지고 피로가 줄어드는 것을 체감하는 분들이 많습니다. 효과 지속 시간은 보통 며칠에서 일주일 정도 유지되며, 일시적인 피로 해소 목적보다는 꾸준한 건강 관리와 면역력 유지를 위해 정기적으로 찾는 분들이 많습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
