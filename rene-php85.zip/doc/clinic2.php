<?php
$page_title = "질염";
$page_canonical = "https://reneclinic.co.kr/doc/clinic2.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "2";
	$category = "질염";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">여성이라면 한번쯤 겪는 질염 <br>단순한 청결의 문제가 아닙니다.</h2>
			<ul class="t1">
				<li>여성이라면 누구나 질염의 위험에 노출되어 있다고 생각해도 과언이 아닐 만큼 가장 흔한 산부인과 질환입니다.</li>
				<li>질염 초기엔 심한 증상을 호소하지 않아 치료를 소홀히 하기 쉽고 또한 치료를 받더라도 재발이 흔합니다. 하지만 간단한 질의 염증이라고 얕잡아 봤다가는 심한 증상과 심각한 후유증을 가져올 수도 있습니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>





<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>질염의 주요 증상</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>질염은 질 내부의 미생물 환경 변화나 감염 등으로 발생하는 여성의 흔한 질환 중 하나입니다.</li>
			<li>가려움증, 분비물 증가, 불쾌한 냄새, 따가움 등 다양한 증상이 나타날 수 있으며 원인에 따라 증상과 치료 방법이 달라집니다.</li>
		</ul>		
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>질 분비물 증가</li>				
				<li>불쾌한 냄새</li>
				<li>외음부 가려움증</li>
				<li>따가움 및 화끈거림</li>
				<li>배뇨 시 불편감</li>
				<li>성관계 시 통증</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">질염은 분비물의 양과 색, 냄새의 변화뿐 아니라 가려움증이나 통증 등 다양한 형태로 나타날 수 있습니다.</p>
	</div>
</section>







<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class="s-inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>질염의 종류</h2>
		<p class="t1">질염은 발생 원인에 따라 여러 종류로 구분되며, 각각 특징적인 증상과 치료 방법이 다릅니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4">
			<li>
				<h3><p>세균성 질염</p></h3>
				<img src="/images/sub/clinic2-1-img1.png">
				<p class="t1">질 내부의 유익균이 감소하고 특정 세균이 과도하게 증식하면서 발생합니다. 회백색의 묽은 분비물과 비린 냄새가 특징적이며, 가려움증 없이 나타나기도 합니다.</p>
			</li>
			<li>
				<h3><p>칸디다 질염</p></h3>
				<img src="/images/sub/clinic2-1-img2.png">
				<p class="t1">칸디다라는 진균이 과도하게 증식하여 발생합니다. 심한 가려움증과 외음부 발적, 두껍고 하얀 덩어리 형태의 분비물이 나타날 수 있습니다.</p>
			</li>
			<li>
				<h3><p>트리코모나스 질염</p></h3>
				<img src="/images/sub/clinic2-1-img3.png">
				<p class="t1">성접촉을 통해 전파되는 원충 감염으로 발생합니다. 거품이 섞인 황록색 분비물과 악취, 가려움증 등이 나타날 수 있으며 성 파트너의 동시 치료가 필요합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>








<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>질염, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">질염은 꼭 성관계가 있어야 생기나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>질 내에는 Lactobacillus, Corynebacterium, Streptococcos와 같은 균들이 서로 균형을 이루고 있어야 합니다.
그래서 약산성을 유지하여야 질염을 일으키는 나쁜 균들이 살지 못합니다. 그러나 여성의 신체의 대사작용이나 면역작용, 질 세정제의 사용 혹은 성관계 등에 의해 질내의 균형이 깨지면 나쁜 균들이 살게 되어 질염을 유발합니다.<br>
몸이 매우 피곤하거나 심한 스트레스를 받을 때 질염이 잘 생기는 이유이기도 합니다. 그러므로 단순히 성관계 때문에 질염이 생긴다고 볼 수는 없으며 다른 원인에 의해서도 질염은 생길 수 있는 것입니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">질염은 성병인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>질염이 꼭 성관계에 때문에 생기는 것이 아니기 때문에 질염은 성병이 아닙니다.
하지만 질염 중에서 트리코모나스 질염은 성관계 시에 옮길 수 있기 때문에 남자도 같이 치료를 받아야 합니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">질염 검사는 어떻게 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>질 분비물의 상태와 질 점막을 확인하고, 분비물을 채취하여 염증 및 감염 여부를 검사합니다. 필요한 경우 현미경 검사나 PCR 검사를 통해 원인균을 확인하고 질염의 종류를 진단합니다.</p>
                </div>
            </div>

			
            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">질염 치료는 어떻게 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>병원에 가기 귀찮다는 이유로 그냥 지내시거나 혹은 집에서 질 세정제 등으로 자가 치료를 하시는 분이 많습니다. 하지만 자가 치료는 일시적으로 냉의 양은 줄지만 균을 완전히 치료하는 데는 도움이 되지 않으며, 오히려 만성적인 질염을 만들 수 있습니다. 
또한 약국에서 처방전 없이 파는 일반의약품 약들은 항생제 계통이 없기 때문에 질염을 치료할 수 없습니다.
빨리 치료를 받지 않고 방치해 두면 골반염, 추후 임신시의 합병증 등의 원인이 되므로 적절한 치료가 필요합니다.</p>
                </div>
            </div>


            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">질염은 완치가 되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>질염은 대부분 쉽게 치료가 됩니다. 하지만 다음에 또 생길 수 있습니다.<br>
한번 치료를 하고 완치가 되더라도 나중에 질의 환경에 문제가 생기면 다시 질염이 생기게 되며, 다시 치료를 받으셔야 합니다.
그러나 재발 방지를 위하여 어느 정도의 의학적인 예방치료가 가능하며, 치료 후 재발방지를 위하여 자세한 안내를 해드리고 있습니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
