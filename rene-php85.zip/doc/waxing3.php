<?php
$page_title = "제모레이저 소개";
$page_canonical = "https://reneclinic.co.kr/doc/waxing3.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "5";
	$p_num = "3";
	$category = "제모레이저 소개";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-waxing3.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">두 가지 레이저 파장으로 완성하는 <br>아포지 엘리트 플러스</h2>
			<ul class="t1">
				<li>아포지 엘리트 플러스는 미국 사이노슈어(Cynosure)사의 듀얼 파장 레이저 장비로, 755nm 알렉산드라이트와 1064nm Nd:YAG 레이저를 활용하여 다양한 피부 타입과 모질에 맞춘 제모가 가능합니다.</li>
				<li>모낭의 멜라닌 색소에 선택적으로 에너지를 전달하여 털의 성장을 억제하며, 피부 상태에 따른 파장과 에너지 조절 및 냉각 시스템을 통해 보다 효율적이고 편안한 시술을 추구합니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>듀얼 파장 시스템으로 모낭을 정교하게 타깃</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>엘리트플러스는 모낭을 타겟하는 755-nm 롱펄스 알렉산드라이트와 침투 깊이가 깊고 모낭에 영양을 공급하는 혈관에 대해 <br>선택적으로 흡수되는 1064-nm 롱펄스 엔디야그를 이용하여 주위 피부 조직의 손상 없이 멜라닌, 모낭/모근 및 혈관만을 타겟하여 <br>안전하고 강력한 효과를 나타냅니다.</li>
		</ul>		
	</div>	
		<ul id="waxing3-1" class="flex-Box">
			<li>
				<h3><p>755mm : 높은 멜라닌 흡수율</p></h3>
				<img src="/images/sub/waxing3-img1.png">
				<p class="t1">모발의 멜라닌 색소에 대한 흡수율이 높아 비교적 밝은 피부에서 색소가 풍부한 털을 선택적으로 타깃하는 데 적합합니다.</p>
			</li>
			<li>
				<h3><p>1064nm : 깊은 에너지 전달</p></h3>
				<img src="/images/sub/waxing3-img2.png">
				<p class="t1">피부 표면의 멜라닌 흡수가 상대적으로 낮고 조직 깊숙이 에너지를 전달할 수 있어 다양한 피부색과 깊은 모낭에 대응할 수 있습니다.</p>
			</li>
		</ul>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">서로 다른 두 파장의 장점을 활용해 피부 타입과 모질에 맞는 정교하고 효율적인 레이저 제모를 추구합니다.</p>
	</div>
</section>










<section id="clinicIntro" class="subBG p-Part-b m-Part">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>아포지 엘리트 플러스의 장점</h2>
			<p class="t1">피부 타입과 모질에 따른 맞춤형 에너지 조절로 불필요한 털의 성장을 억제하고, <br>주변 피부 조직에 미치는 영향을 최소화하면서 효율적인 제모 효과를 추구합니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">			
				<li>
					<dl>
						<dt>선택적인 모낭 타깃</dt>
						<dd>주변 피부 조직의 손상을 최소화하면서 모낭에 레이저 에너지를 선택적으로 전달합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>정교하고 효과적인 제모</dt>
						<dd>모발의 멜라닌 색소를 타깃하여 모낭의 털 생성 관련 구조에 열에너지를 전달하고 털의 재성장을 억제합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>장기간 제모 효과 유지</dt>
						<dd>반복적인 시술을 통해 모발의 성장을 점진적으로 억제하여 장기간 털 감소 효과를 기대할 수 있습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>다양한 피부 타입에 적용</dt>
						<dd>755nm와 1064nm 듀얼 파장을 활용하여 피부색과 모질에 적합한 맞춤형 제모가 가능합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>혈관 병변 치료에도 활용</dt>
						<dd>특정 혈관의 혈색소에 레이저 에너지를 전달하여 일부 혈관성 병변 개선에도 활용할 수 있습니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>









<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>제모레이저, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술은 몇 회 정도 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>제모레이저는 성장기 모발에 효과적으로 작용하므로 일반적으로 여러 차례 반복 시술이 필요합니다. 필요한 횟수와 간격은 제모 부위, 모질, 피부 상태에 따라 달라지며 의료진의 진찰 후 결정합니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시 통증은 어느 정도인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>레이저 조사 시 고무줄로 가볍게 튕기는 듯한 따끔함이나 열감이 느껴질 수 있습니다. 에어쿨링 냉각 시스템을 함께 사용하여 불편함을 줄이는 데 도움을 주지만, 통증 정도는 개인마다 다릅니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">피부색이 어두운 경우에도 제모할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>1064nm Nd:YAG 파장은 피부 표면의 멜라닌 흡수가 상대적으로 낮아 어두운 피부 타입에도 활용할 수 있습니다. 다만 피부색과 색소침착 상태 등을 먼저 확인하여 적절한 파장과 출력으로 진행해야 합니다.</p>
                </div>
            </div>

			
            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 후 털이 바로 없어지나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>제모 직후 모든 털이 즉시 사라지는 것은 아닙니다. 레이저가 작용한 털은 시간이 지나면서 자연스럽게 탈락할 수 있으며, 모발 성장 주기에 따라 반복 시술이 필요합니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">제모레이저 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 후 일시적인 붉어짐, 부기, 따가움 또는 모낭 주변의 부종이 나타날 수 있으며, 드물게 화상이나 색소침착, 색소저하, 물집 등이 발생할 수 있습니다. 피부 상태에 맞는 에너지 설정과 적절한 냉각이 중요합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
