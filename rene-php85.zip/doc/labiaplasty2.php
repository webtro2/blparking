<?php
$page_title = "최소절개 소음순수술";
$page_canonical = "https://reneclinic.co.kr/doc/labiaplasty2.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "2";
	$category = "최소절개 소음순수술";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-labia2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">소음순수술은 디자인과 테크닉이 <br>가장 큰 비중을 차지합니다.</h2>
			<ul class="t1">
				<li>소음순은 생긴 모양이 다들 다르기 때문에 적합한 수술 방법도 모두 다릅니다.</li>
				<li>단순히 자르고 봉합하는 작업이 아닌 모양과 크기, 두께, 색, 감각을 모두 고려한 수술이 <br>되어야 합니다.</li>
				<li>통증과 감염 가능성이 현저히 적으며 회복일 빨라 수술 후 활동에 큰 제한이 없으며, <br>다음날 바로 샤워 가능합니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>르네여성의원의 소음순수술</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>르네여성의원의 소음순수술은 이상적인 형태를 갖추면서도 기능적인 측면이 손상되지 않도록 <br>최소 절개법과 미세봉합법을 통해 효과적이고 안전한 시술을 추구합니다.</li>
			<li>내원하실 때 정확한 진찰을 통해서 의사와의 일대일 상담이 이루어지고, <br>최적으로 적용될 수 있는 디자인과 발생할 수 있는 부작용에 대한 자세한 설명을 해드립니다.</li>
		</ul>
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>최소절개법</li>
				<li>미세봉합법</li>
				<li>국소마취</li>
				<li>짧은 수술시간</li>
				<li>당일수술 가능</li>				
				<li>체계적인 사후관리</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">본인의 불편감이 무엇인지, 기대하는 측면이 무엇인지에 대해 알려주시면 <br>그 부분을 적극적으로 해결하여 만족도 높은 결과를 얻으실 수 있도록 하겠습니다.</p>
	</div>
</section>




<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class=" inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>소음순수술 과정</h2>
		<p class="t1">개인의 소음순 형태와 신체적 특성을 세심하게 고려하여 각 과정을 체계적으로 진행합니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box">
			<li>
				<h3><p>디자인</p></h3>
				<img src="/images/sub/labia2-2-img1.png">
				<p class="t1">개인의 소음순 형태와 비대칭 정도를 고려하여 수술 범위와 디자인을 계획합니다.</p>
			</li>
			<li>
				<h3><p>절개</p></h3>
				<img src="/images/sub/labia2-2-img2.png">
				<p class="t1">계획된 디자인을 따라 불필요한 조직을 섬세하게 절개합니다.</p>
			</li>
			<li>
				<h3><p>지혈</p></h3>
				<img src="/images/sub/labia2-2-img3.png">
				<p class="t1">출혈 부위를 꼼꼼하게 확인하고 세심한 지혈로 수술 부위를 정리합니다.</p>
			</li>
			<li>
				<h3><p>미세봉합</p></h3>
				<img src="/images/sub/labia2-2-img4.png">
				<p class="t1">자연스러운 형태와 조직의 균형을 고려하여 정교하게 미세봉합합니다.</p>
			</li>
			<li>
				<h3><p>수술 후</p></h3>
				<img src="/images/sub/labia2-2-img5.png">
				<p class="t1">회복 상태를 확인하고 주의사항 안내와 체계적인 사후관리를 진행합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>



<div id="halfImg"  class="flex-Box">
	<div class="imgWrap labia2"></div>
	<div class="contWrap">
		<div class="in-box">
			<div class="clinicTit">
				<h2 class="fc-wh">베살리우스(Vesalious)</h2>
			</div>
			<dl>
				<dt class="fc-M3">섬세한 절개와 정교한 지혈을 위한 <br class="br1280">공명파 수술 장비</dt>
				<dd class="fc-wh">QMR(양자분자공명) 기술을 적용한 고주파 수술 장비로, 낮은 작동 온도에서 섬세한 조직 절개와 정밀한 지혈을 돕고 주변 조직으로 전달되는 열을 줄이도록 설계되어 정교함이 요구되는 여성성형 수술에 활용됩니다.</dd>
			</dl>
			<div class="checkList">
				<ul class="flex-Box">
					<li><p>QMR 공명파 기술</p></li>
					<li><p>섬세하고 정교한 절개</p></li>
					<li><p>주변 조직의 열 손상 감소</p></li>
					<li><p>정밀한 지혈 기능</p></li>
				</ul>
			</div>
		</div>
	</div>
</div>





<div id="another" class="inner p-Part">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>함께할 수 있는 시술</h2>
		<p class="t1">함께하면 더욱 만족스러운 변화를 기대할 수 있는 시술을 소개합니다.</p>
	</div>
	<div class="flex-Box labia2">
		<div class="box bg1">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>음핵리프팅</dt>
				<dd>소음순 늘어짐을 개선하고 리프팅과 타이트닝을 통해 음핵 노출 및 성감 향상에 도움을 줄 수 있습니다.</dd>
			</dl>
		</div>
		<div class="box bg2">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>외음부 미백레이저</dt>
				<dd>소음순 수술 후에도 일부 남아있는 착색을 교정하고, 대음순 부위의 색감도 밝게 해줄 수 있습니다.</dd>
			</dl>
		</div>
		<div class="box bg3">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>질성형, 회음부성형</dt>
				<dd>소음순 수술 후 질입구가 더 넓게 느껴질 수 있습니다. 함께 교정하여 최적의 모양을 만들어드립니다.</dd>
			</dl>
		</div>
		<div class="box bg4">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>비비브/베스타 <br>(타이트닝 레이저)</dt>
				<dd>소음순 부위를 비롯, 질내부까지 탄탄하게 만들어주는 시술입니다.</dd>
			</dl>
		</div>
	</div>
</div>





<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>소음순수술, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 전 주의사항은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 전 충분한 상담을 통해 건강 상태와 복용 중인 약물을 의료진에게 알려주세요. <br>생리 기간은 가급적 피하고, 수술 부위에 염증이나 감염이 있다면 미리 확인이 필요합니다. 아스피린이나 항응고제 등 출혈에 영향을 줄 수 있는 약물은 반드시 의료진과 상의해 주세요.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 후 주의사항은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 후에는 충분한 휴식을 취하고 수술 부위를 청결하게 관리하는 것이 중요합니다. <br>회복 기간에는 심한 운동이나 자전거 타기, 장시간 앉아 있기 등 수술 부위에 자극을 주는 행동을 피해주세요. 처방받은 약은 안내에 따라 복용하고, 의료진의 지시에 맞춰 관리해 주세요.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술 후 발생할 수 있는 부작용은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 후 일시적인 붓기, 멍, 통증, 소량의 출혈 등이 나타날 수 있으며 대부분 회복 과정에서 점차 완화됩니다. <br>다만 감염, 혈종, 상처 벌어짐, 흉터, 비대칭, 감각 변화 등의 부작용이 발생할 수 있습니다. <br>출혈이 지속되거나 통증과 부종이 심해지는 경우에는 즉시 의료진의 진료를 받으시기 바랍니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">수술 후 실밥은 언제 제거하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 본원에서는 수술 약 1주일 후 내원하여 회복 상태를 확인한 뒤 실밥을 제거합니다. <br>개인의 회복 상태와 봉합 방법에 따라 제거 시기는 달라질 수 있으며, 의료진의 안내에 따라 진행됩니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">수술 후 목욕이나 부부관계는 언제부터 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술 약 1개월 후 내원하여 회복 경과를 확인하고, 상처의 회복 상태에 따라 통목욕 및 부부관계 가능 여부를 결정합니다. <br>개인마다 회복 속도가 다르므로 무리하지 않고 의료진의 확인을 받은 후 진행하는 것이 안전합니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
