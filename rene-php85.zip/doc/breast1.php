<?php
$page_title = "유방암검진";
$page_canonical = "https://reneclinic.co.kr/doc/breast1.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "1";
	$category = "유방암검진";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-breast1.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">작은 변화도 놓치지 않는 세심한 검진, <br>유방 건강을 지키는 첫걸음</h2>
			<ul class="t1">
				<li>유방암은 초기에는 뚜렷한 증상이 나타나지 않는 경우가 많아 정기적인 검진을 통한 <br>조기 발견이 중요합니다.</li>
				<li>유방촬영술과 유방초음파 등 개인의 연령과 유방 상태에 적합한 검사를 통해 유방 조직의 <br>이상 여부를 확인하고, 혹이나 통증 등 다양한 유방 질환을 살펴봅니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>연령별 조기 검진 권고안</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>유방암 선별검사는 조기 발견과 사망률 감소에 효과적인 검사로, 유방암 사망률을 약 15~30% 낮추는 것으로 보고되고 있습니다.</li>
			<li>보건복지부는 유방암을 5대암 중 하나로 선정하고, 이에 대한 표준 암검진 권고안을 개발하여 시행 중에 있습니다.</li>
		</ul>		
	</div>
		
	<div class=" mt50">
            <table class="tb-style1">
                <colgroup>
                    <col width="">
					<col width="">
					<col width="42%">
                </colgroup>
                <thead>
                    <tr>
                        <th>나이</th>
                        <th>검진간격</th>
						<th>방법</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>30세 이후</th>
                        <td>매월</td>
						<td>유방 자가 검진</td>
                    </tr>
					<tr>
                        <th>35세 이후</th>
                        <td>2년</td>
						<td>의사에 의한 임상 검진</td>
                    </tr>
					<tr>
                        <th>40세 이후</th>
                        <td>1~2년</td>
						<td>임상 진찰과 유방 촬영</td>
                    </tr>
					<tr>
                        <th>고위험군</th>
                        <td>수시</td>
						<td>유방 전문의와 상담</td>
                    </tr>
                </tbody>
            </table>
        </div>
</section>






<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class="inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>유방암 자가진단법</h2>
		<p class="t1">생리가 끝난 후 3~4일 뒤에 하는 것이 정확도를 높일 수 있으며, <br>자가검진을 통해 멍울이 만져지거나 유두에서 분비물이 나오는 경우, 유방에서 습진성 병변이 발견되는 경우 <br>병원을 찾아 정밀 검진을 받는 것을 권장합니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box breast1">
			<li>
				<h3><p>양쪽 유방의 모양과 변화 관찰</p></h3>
				<img src="/images/sub/breast1-2-img1.png">
				<p class="t1">양손을 허리에 짚고 거울을 보며 양쪽 유방의 크기와 모양, 좌우 대칭 여부 및 피부에 평소와 다른 변화가 있는지 꼼꼼하게 관찰합니다.</p>
			</li>
			<li>
				<h3><p>팔을 올려 유방의 변화 관찰</p></h3>
				<img src="/images/sub/breast1-2-img2.png">
				<p class="t1">양팔을 머리 위로 들어 올린 상태에서 피부의 함몰이나 주름, 유두의 변화가 있는지 관찰합니다.</p>
			</li>
			<li>
				<h3><p>원을 그리며 유방 전체 촉진</p></h3>
				<img src="/images/sub/breast1-2-img3.png">
				<p class="t1">유방의 바깥쪽부터 안쪽까지 원을 그리듯 촉진하며 조직의 변화를 살펴봅니다.</p>
			</li>
			<li>
				<h3><p>유두 및 분비물 확인</p></h3>
				<img src="/images/sub/breast1-2-img4.png">
				<p class="t1">유두의 모양과 피부 변화를 살펴보고, 저절로 나오는 분비물이 있는지 확인합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>





<div id="halfImg"  class="flex-Box">
	<div class="imgWrap breast1-2"></div>
	<div class="contWrap">
		<div class="in-box">
			<div class="clinicTit">
				<h2 class="fc-wh">유방초음파 검사</h2>
			</div>
			<dl>
				<dt class="fc-M3">유방 내부 조직과 병변의 특성을 정밀하게 확인</dt>
				<dd class="fc-wh">유방초음파는 고주파 음파를 이용해 유방 내부 조직을 영상으로 확인하는 검사입니다. <br>유방의 멍울이나 낭종, 종괴 등의 이상 여부를 살펴볼 수 있으며, 특히 유방 조직이 치밀한 여성에게 유용합니다.</dd>
			</dl>
			<div class="checkList breast1-2">
				<ul class="flex-Box">
					<li><p>방사선 노출 없는 검사</p></li>
					<li><p>치밀유방의 보완 검사</p></li>
					<li><p>멍울 및 종괴 확인</p></li>
					<li><p>낭종과 고형 종괴 구별</p></li>
				</ul>
			</div>
		</div>
	</div>
</div>








	<div id="clinicTop" class="m-Part">
		<div id="topimg"><img src="/images/sub/clinictop-breast1-3.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">눈에 보이지 않는 미세한 변화까지 <br>확인하는 유방촬영술</h2>
			<h3 class="fc-M1">미세석회화와 초기 유방암의 징후를 조기에 발견</h3>
			<ul class="t1">
				<li>유방의 통증이나 종양을 의심할 만한 멍울이 만져지는 경우, 유방의 모양과 대칭성이 <br>변한 경우와 같이 유방의 이상소견이 있는 경우 시행하게 됩니다.</li>
			<li>40세 이상의 여성은 2년마다 유방 촬영술을 권하며 가족력이 있는 경우 35세부터 <br>정기적인 촬영을 권장합니다.</li>
			<li>또한 호르몬 치료 중인 여성의 경우 매년 검사할 것을 권하고 있습니다.</li>
			
			</ul>
		</div>
	</div>




<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>유방암의 정확한 진단을 위한 유방촬영술</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>유방촬영술은 저선량 X선을 이용해 유방 내부 조직을 촬영하는 대표적인 유방암 검진 방법입니다.</li>
			<li>손으로 만져지지 않는 작은 종괴나 미세석회화 등 초기 유방암의 징후를 발견하는 데 도움이 되며, 정기적인 검진을 통해 <br>유방의 이상 변화를 조기에 확인할 수 있습니다.</li>
		</ul>		
	</div>
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>유방암 조기 발견</li>
				<li>미세석회화 발견</li>
				<li>저선량 X선 검사</li>
				<li>비교적 짧은 <br>검사 시간</li>
			</ul>
		</div>
</section>


<div id="halfImg"  class="flex-Box m-Part">
	<div class="imgWrap breast1-3"></div>
	<div class="contWrap">
		<div class="in-box">
			<div class="clinicTit">
				<h2 class="fc-wh">XP-맘모마트 레벌레이션</h2>
			</div>
			<dl>
				<dt class="fc-M3">정밀한 영상 기술로 유방의 작은 변화까지</dt>
				<dd class="fc-wh">XP-Mammomat Revelation은 첨단 디지털 유방촬영 장비로, 50° 광각 3D 토모신테시스 기술을 통해 유방 조직의 겹침을 줄이고 미세한 병변까지 정밀하게 관찰할 수 있도록 돕습니다.<br>또한 환자별 맞춤 압박과 저선량 촬영 기술을 적용하여 검사 시 불편함과 방사선 노출을 줄이는 데 도움을 줍니다.</dd>
			</dl>
			<div class="checkList breast1-2">
				<ul class="flex-Box">
					<li><p>50° 광각 3D 정밀 촬영</p></li>
					<li><p>미세 병변 관찰</p></li>
					<li><p>저선량 방사선 촬영</p></li>
					<li><p>환자 맞춤형 압박 시스템</p></li>
				</ul>
			</div>
		</div>
	</div>
</div>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>유방암검진, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">유방암 검진은 몇 살부터 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>우리나라 국가암검진에서는 40세 이상 여성에게 2년마다 유방촬영술을 권장하고 있습니다. 다만 가족력이 있거나 유방에 이상 증상이 있다면 연령과 관계없이 전문의와 상담하여 적절한 검사를 받는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">유방초음파와 유방촬영술은 어떤 차이가 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>유방촬영술은 X선을 이용해 미세석회화와 종괴 등을 확인하는 검사이며, 유방초음파는 초음파를 이용해 유방 내부의 혹이나 낭종 등을 관찰하는 검사입니다. 두 검사는 상호 보완적이며, 필요에 따라 함께 시행할 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">유방에 멍울이 만져지거나 통증이 있다면 어떻게 해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>유방에 멍울이 만져지거나 유두 분비물, 피부 변화 등의 증상이 나타나면 정기 검진 시기를 기다리지 말고 전문의의 진료를 받는 것이 좋습니다. 증상에 따라 유방초음파나 유방촬영술 등 필요한 검사를 진행합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">유방암 검진 전 주의사항이 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>유방촬영술을 받는 날에는 겨드랑이나 가슴 부위에 데오도란트, 파우더, 로션 등의 사용을 피하는 것이 좋습니다. 또한 임신 중이거나 임신 가능성이 있다면 반드시 검사 전에 의료진에게 알려야 합니다.</p>
                </div>
            </div>
        </div>
    </div>
</div>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
