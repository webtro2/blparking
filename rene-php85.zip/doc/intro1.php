<?php
$page_title = "의료진소개";
$page_canonical = "https://reneclinic.co.kr/doc/intro1.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
	$category = "의료진소개";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="intro1Top"  class="inner">
		<h2>1,000례 이상의 수술 경험, <br class="br976">결과로 이어지는 전문성</h2>
		<li class="t1">
			<p >다양한 케이스를 통해 축적된 풍부한 수술 경험과 <br class="br480">노하우를 바탕으로 <br>개인의 상태와 고민을 세심하게 살펴  <br class="br480">꼭 필요한 방향으로 수술을 진행합니다.</p>
			<p>여의사가 직접 상담부터 수술, 경과 확인과 수술 후 관리까지 꼼꼼하게 함께합니다.</p>
		</li>
	</div>


	<div id="introTab" class="inner">
		<ul>
		<a href="javascript:GoPage('intro1-1')" class="on">
			<li class="img"><img src="/images/sub/intro1tab-img1.png"></li>
			<li class="txt">김수정 원장</li>
		</a>
		</ul>
		<ul>
		<a href="javascript:GoPage('intro1-2')">
			<li class="img"><img src="/images/sub/intro1tab-img2.png"></li>
			<li class="txt">탁지영 원장</li>
		</a>
		</ul>
		<ul>
		<a href="javascript:GoPage('intro1-3')">
			<li class="img"><img src="/images/sub/intro1tab-img3.png"></li>
			<li class="txt">이지영 원장</li>
		</a>
		</ul>
		<ul>
		<a href="javascript:GoPage('intro1-4')">
			<li class="img"><img src="/images/sub/intro1tab-img4.png"></li>
			<li class="txt">황인아 원장</li>
		</a>
		</ul>
	</div>




<div id="intro1" class="m-Part">
<div class="inner  intro1-1">
	<div class="imgWrap">
		<div id="goColumn">
			<a href="javascript:GoPage('dr-kim')"><span>칼럼보기</span></a>
		</div>
	</div>
	<div class="contWrap">
		<p class="room">제1진료실</p>
		<dl>
			<dt>김수정 원장</dt>
			<dd>산부인과 전문의</dd>
		</dl>
		<ul class="care">
			<li>소음순수술</li>
			<li>질레이저</li>
			<li>질필러</li>
		</ul>
		<div class="profile">
			<ul>
				<h3>학력 및 경력</h3>
				<li><p>연세대학교 원주의과대학 졸업</p></li>
				<li><p>경북대학교 인턴 수료</p></li>
				<li><p>경북대학교 산부인과 전공의 수료</p></li>
			</ul>
			<ul>
				<h3>학회활동</h3>
				<li><p>대한산부인과학회 정회원</p></li>
				<li><p>대한초음파학회 정회원</p></li>
				<li><p>대한산부인과내분비학회 정회원</p></li>
				<li><p>대한폐경기학회 정회원</p></li>
				<li><p>대한비만미용치료학회 정회원</p></li>
				<li><p>대한산부인과내분비학회 정회원</p></li>
				<li><p>대한모체태아의학회 정회원</p></li>
			</ul>
		</div>
	</div>
</div>
</div>



<div id="dr-Schedule" class="s-inner p-Part">
	<dl>
		<dt>진료스케줄</dt>
		<dd class="fc-M2">김수정 원장</dd>
	</dl>
        <div class="scroll1">
            <table class="tb-style1">
                <colgroup>
                    <col width="">
                </colgroup>
                <thead>
                    <tr>
                        <th></th>
                        <th>월</th>
						<th>화</th>
						<th>수</th>
						<th>목</th>
						<th>금</th>
						<th>토</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>오전</th>
                        <td>수술</td>
						<td class="red">휴진</td>
						<td>외래</td>
						<td>수술</td>
						<td>시술</td>
						<td>외래</td>
                    </tr>
					<tr>
                        <th>오후</th>
                        <td>시술</td>
						<td class="red">휴진</td>
						<td>외래</td>
						<td>외래·수술</td>
						<td>시술</td>
						<td></td>
                    </tr>
					<tr>
                        <th>야간</th>
                        <td></td>
						<td> </td>
						<td> </td>
						<td>진료</td>
						<td> </td>
						<td> </td>
                    </tr>
                </tbody>
            </table>
        </div>
	<p class="scroll-t1">※ 스크롤을 좌·우측으로 움직여 확인해 주세요.</p>
</div>







</div>
</div>
<?php include "../inc/bottom.php"; ?>
