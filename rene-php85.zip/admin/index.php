<script language='JavaScript'> 
    document.location.replace( '/pg/bbs/login.php?url=%2Fpg%2Fadm%2Findex.php%3F' ); 
</script> 