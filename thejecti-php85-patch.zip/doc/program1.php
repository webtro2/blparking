<?php require_once(__DIR__ . '/_common.php');  $page_title = "국내연수 프로그램"; ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">
    
	<div id="subTitle">
        <span class="vis_dep01"></span>
    </div>
    
    <div id="pageCont">
        <div class="inner">
            <div class="training_wrap">
                <ul class="tabmenu" data-aos="fade-up" data-aos-duration="1000">
                    <li class="on"><a href="#program" class="menu1" data-tab="program">국내연수 프로그램</a></li>
                    <li><a href="#instructor" class="menu2" data-tab="instructor">전문강사진</a></li>
                    <li><a href="#guide" class="menu3" data-tab="guide">연수안내</a></li>
                </ul>

                <div id="program" class="training_cont on">

                    <div class="training_intro program_intro" data-aos="fade-up" data-aos-duration="1000">
                        <div class="tit">
                            <h4>PROFESSIONAL TRAINING</h4>
                            <h3>지방의회를 위한 맞춤형 의정연수</h3>
                        </div>
                        <div class="desc">
                            <p> 20년간 축적한 경험과 전문성을 바탕으로<br> 각 의회의 목적과 특성에 맞는 <b>맞춤형 의정연수</b>를 제공합니다. </p>
                        </div>
                    </div>

                    <div class="program_feature program_row">
                        <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                            <h4>TRAINING FEATURES</h4>
                            <h3>더조은의정연수 <br><span>주요 특징</span></h3>
                            <p>20년간 축적한 경험과 전문성을 바탕으로 <br>차별화된 의정연수를 제공합니다.</p>
                        </div>

                        <ul class="feature_list">
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="txt">
                                    <span>01</span>
                                    <h3>20년간의 <br>연수 경험과 노하우</h3>
                                </div>
                                <div class="icon"><i class="fa-solid fa-medal"></i></div>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="txt">
                                    <span>02</span>
                                    <h3>지방의회에 최적화된<br> 맞춤식 의정연수</h3>
                                </div>
                                <div class="icon"><i class="fa-solid fa-sliders"></i></div>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="txt">
                                    <span>03</span>
                                    <h3>의정분야<br> 전문 강사진 구성</h3>
                                </div>
                                <div class="icon"><i class="fa-solid fa-chalkboard-user"></i></div>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="txt">
                                    <span>04</span>
                                    <h3>지역 특색을 반영한 문화체험 <br><br class="br768">및 현장방문 벤치마킹</h3>
                                </div>
                                <div class="icon"><i class="fa-solid fa-location-dot"></i></div>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="txt">
                                    <span>05</span>
                                    <h3>의정연수에 필요한<br> 각종 편의물품 제공</h3>
                                </div>
                                <div class="icon"><i class="fa-solid fa-gift"></i></div>
                            </li>
                        </ul>
                    </div>

                    <div class="program_system program_row">
                        <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                            <h4>PROGRAM SYSTEM</h4>
                            <h3>더조은의정 <br><span>전문 운영 시스템</span></h3>
                        </div>

                        <div class="system_cont">
                            <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="system_head">
                                <span class="label">EXPERT</span>
                                    <h3>전문성과 현장 경험을 갖춘 강사진</h3>
                                </div>

                                <ul>
                                    <li>지방의회에 특화된 전문·맞춤형 교육 제공</li>
                                    <li>예산·결산, 행정사무감사, 조례, 정책개발 등 분야별 전문강사진 확보</li>
                                    <li>풍부한 현장 경험을 통한 실질적인 의정역량 강화</li>
                                </ul>
                            </div>

                            <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="system_head">
                                <span class="label">KNOW-HOW</span>
                                    <h3>의회 중심의 전문 운영 역량</h3>
                                </div>

                                <ul>
                                    <li>의원·의회 사무국 맞춤형 의정연수 기획·운영</li>
                                    <li>지방의회 관계자와의 유기적인 협력 네트워크 구축</li>
                                    <li>기획부터 기관방문·현장 진행까지 체계적인 운영</li>
                                </ul>
                            </div>

                            <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="system_head">
                                <span class="label">OPERATION</span>
                                    <h3>최적의 교육환경과 책임 있는 현장 운영</h3>
                                </div>

                                <ul>
                                    <li>교육·숙박·식음 등 최적의 연수환경 사전 확보</li>
                                    <li>지방의회 요구사항을 반영한 맞춤형 운영</li>
                                    <li>시설·방문기관 등 철저한 사전 점검과 책임 운영</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="program_process program_row">
                        <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                            <h4>TRAINING PROCESS</h4>
                            <h3>국내연수 <br><span>진행 절차</span></h3>
                            <p>의회 요구 파악부터 공식연수 진행까지 <br>단계별로 체계적으로 진행합니다.</p>
                        </div>

                        <div class="process_list">
                            <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="icon"><i data-lucide="clipboard-list"></i></div>
                                <span class="num">01</span>
                                <h3>의회 요구 파악 및 <br>기획안 수립</h3>
                            </div>

                            <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="icon"><i data-lucide="messages-square"></i></div>
                                <span class="num">02</span>
                                <h3>협의 및 최종 <br>계획안 수립</h3>
                            </div>

                            <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="icon"><i data-lucide="calendar-check"></i></div>
                                <span class="num">03</span>
                                <h3>현지예약 및<br> 강사 확정</h3>
                            </div>

                            <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="icon"><i data-lucide="presentation"></i></div>
                                <span class="num">04</span>
                                <h3>공식연수<br> 진행</h3>
                            </div>
                        </div>
                    </div>
                </div>


                <div id="instructor" class="training_cont">

                    <div class="training_intro instructor_intro" data-aos="fade-up" data-aos-duration="1000">
                        <div class="tit">
                            <h4>PROFESSIONAL INSTRUCTORS</h4>
                            <h3>전문성과 경험을 갖춘 전문강사진</h3>
                        </div>

                        <div class="desc">
                            <p>의정활동 및 지방자치 분야의 전문성과 실무 경험을 갖춘<br><b>분야별 전문강사진</b>과 함께합니다.</p>
                        </div>
                    </div>

                    <div class="instructor_contents">

                        <ul class="instructor_list">

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor01.jpg" alt="최민수 교수"></div>
                                <div class="info">
                                    <h3>최민수 <span>교수</span></h3>
                                    <p>국회사무처 연수국장 / 국회도서관 입법정보실장(관리관) / 국회사무처 기획조정실장</p>
                                    <p>국회문방위원회, 국회 운영위원회 수석전문위원(차관보)</p>
                                    <p>저서 : 지방의회운영, 지방의회 이야기, 행정사무감사 기법&사례 등</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>행정사무감사, 예산 및 결산, 조례, 민간위탁 및 보조금 등 의정실무</dd>
                                </dl>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor02.jpg" alt="김용석 교수"></div>
                                <div class="info">
                                    <h3>김용석 <span>교수</span></h3>
                                    <p>제8·9·10대 서울시의회 의원/ 제9대 전반기 기획경제위원장</p>
                                    <p>제3·4·5대 도봉구의회 의원(3선, 1998~2010)</p>
                                    <p>전국 최연소의장(만31세, 제4대 도봉구의회 의장) </p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>행정사무감사, 예산 및 결산, 조례, 민간위탁 및 보조금 등 의정실무</dd>
                                </dl>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor03.jpg" alt="강인태 교수"></div>
                                <div class="info">
                                    <h3>강인태 <span>교수</span></h3>
                                    <p>법학박사</p>
                                    <p>지방자치단체 예산분석 전문가</p>
                                    <p>서강대학교 대학원 법학과 졸업</p>
                                    <p>경상북도의회 정책지원담당관 </p>
                                    <p>미국 코네티컷 대학 로스쿨 미국법 연수과정 수료</p>
                                    <p>경기도의회 자문위원</p>
                                    <p>전국시도의회의장협의회 지방자치법개정특별위원회 실무위원 역임</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>행정사무감사, 예산 및 결산 등 의정실무</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor04.jpg" alt="윤진훈 교수"></div>
                                <div class="info">
                                    <h3>윤진훈 <span>교수</span></h3>
                                    <p>THE조은의정 지방자치의정연구원 소장</p>
                                    <p>국회의정연수원 교수</p>
                                    <p>국회 입법민원과장, 의안과장, 총무과장, 법제심의관</p>
                                    <p>국회 환경노동위원회 전문위원, 의정연수원 교수</p>
                                    <p>상지영서대학 행정학과 겸임교수, 방재시험연구원 원장</p>
                                    <p>명지대학교 일반대학원 행정학과 졸업(행정학 박사)</p>
                                    <p>저서 : 지방예산결산, 자치법규 길라잡이, 행정사무감사 기법&사례</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>행정사무감사, 예산 및 결산 등 의정실무</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor06_261002.jpg" alt="우지영 교수"></div>
                                <div class="info">
                                    <h3>우지영 <span>교수</span></h3>
                                    <p>한국지방정치연구소 소장</p>
                                    <p>성공회대 시민평화대학원 외래교수 </p>
                                    <p>대통력직속 정책기획위원회 자문위원</p>
                                    <p>기획재정부 재정정책지문위원회 위원</p>
                                    <p>행정안정부 정부혁신추진협의회 위원</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>행정사무감사, 예산 및 결산 등 의정실무</dd>
                                </dl>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor05_261002.jpg" alt="김희창 교수"></div>
                                <div class="info">
                                    <h3>김회창 <span>교수</span></h3>
                                    <p>한국지방정부연구원 원장</p>
                                    <p>연세대학교 행정대학원 행정학 박사</p>
                                    <p>한국지방자치법연구회 회장 </p>
                                    <p>한국지방자치발전연구원 이사</p>
                                    <p>전국 시군자치구의회 의장회 자문위원</p>
                                    <p>인천대학교 행정대학원 강사(2008-2014)</p>
                                    <p>저서 : 위장된 지방자치, 지방의회 해킹하기</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>행정사무감사, 예산 및 결산, 조례, 민간위탁 및 보조금 등 의정실무</dd>
                                </dl>
                            </li>
                            
                            <!-- <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor07.jpg" alt="민기 교수"></div>
                                <div class="info">
                                    <h3>민기 <span>교수</span></h3>
                                    <p>제주대학교 행정학과 교수</p>
                                    <p>예산결산 및 의정실무 강의</p>
                                </div>
                            </li> -->
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor08.jpg" alt="김종일 교수"></div>
                                <div class="info">
                                    <h3>김종일 <span>교수</span></h3>
                                    <p>연세대행정대학원(석사) </p>
                                    <p>사단법인) KPO명강사협회 회장</p>
                                    <p>국민권익위원회 청렴연수원 청렴교육 전문강사</p>
                                    <p>공무원연금공단 퇴직예정자 미래설계과정 강사 (제주, 부산, 수안보, 천안, 
                                    설악오색)</p>
                                    <p>보건복지부 인구교육 전문강사, 전문주례인</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>청렴, 이해충돌방지법 등</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor09_261001.jpg" alt="이지문 교수"></div>
                                <div class="info">
                                    <h3>이지문 <span>교수</span></h3>
                                    <p>현) 사단법인 한국청렴운동본부 이사장</p>
                                    <p>현) 경기도 공익제보지원위원회 위원장</p>
                                    <p>현) 보건복지부 청렴시민감사관</p>
                                    <p>전) 경찰청 반부패협의회 위원, 경기청렴사회민관협의회 위원</p>
                                    <p>전) 정부 청렴사회민관협의회 위원</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>청렴, 이해충돌방지법 등</dd>
                                </dl>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor10.jpg" alt="정인자 교수"></div>
                                <div class="info">
                                    <h3>정인자 <span>교수</span></h3>
                                    <p>한국폭력예방교육전문강사협회</p>
                                    <p>폭력예방통합전문강사(한국양성평등교육진흥원위촉)</p>
                                    <p>성희롱/성폭력/가정폭력예방교육강사(한국양성평등교육원위촉)</p>
                                    <p>양성평등교육/성매매방지교육강사(한국양성평등교육원위촉) </p>
                                    <p>청소년폭력예방/에이즈예방교육/성교육전문강사</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>공공기관 4대폭력 예방교육</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor17.jpg" alt="황미정 교수"></div>
                                <div class="info">
                                    <h3>황미정 <span>교수</span></h3>
                                    <p>영남미래교육센터 대표 </p>
                                    <p>한국장애인식개선교육강사협회 대표 </p>
                                    <p>국제장애인태권도연맹 홍보이사 </p>
                                    <p>한국장애인고용공단 전문강사 </p>
                                    <p>한국장애인개발원 전문강사 </p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>공공기관 4대폭력 예방교육</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor11.jpg" alt="정춘아 교수"></div>
                                <div class="info">
                                    <h3>정춘아 <span>교수</span></h3>
                                    <p>전) 부산광역시장애인평생교육원 원장</p>
                                    <p>한국양성평등교육진흥원 위촉 폭력예방 통합교육 전문강사</p>
                                    <p>한국장애인고용공단 위촉 직장 내 장애인식개선 강사</p>
                                    <p>꿈을 찾는 사람들 교육원 선임 대표 팀장</p>
                                    <p>부산시거점형양성평등센터 위촉 성평등 강사</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>공공기관 4대폭력 예방교육</dd>
                                </dl>
                            </li>
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor18.jpg" alt="김지우 교수"></div>
                                <div class="info">
                                    <h3>김지우 <span>교수</span></h3>
                                    <p>브랜드어셈블 대표</p>
                                    <p>국제이미지경영연구소 컨설턴트</p>
                                    <p>SBS/CJB청주방송 공채 MC</p>
                                    <p>TBN한국교통방송 교통캐스터</p>
                                    <p>청주KBS 리포터</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>이미지 메이킹, 스피치 등</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor12.jpg" alt="이용미 교수"></div>
                                <div class="info">
                                    <h3>이용미 <span>교수</span></h3>
                                    <p>나다운 스피치 &amp; 퍼스널 브랜딩 대표</p>
                                    <p>고려대학교 미디어 대학원 석사 </p>
                                    <p>전)케이블TV 원주방송 아나운서 </p>
                                    <p>전)KBS 대전방송 리포터 </p>
                                    <p>전)CBS 전북방송 아나운서</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>이미지 메이킹, 스피치 등</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor19.jpg" alt="고은천 교수"></div>
                                <div class="info">
                                    <h3>고은천 <span>교수</span></h3>
                                    <p>전) DB생명,대신증권, 동양생명 아나운서</p>
                                    <p>전) SBS  광주방송 (kbc) 아나운서 </p>
                                    <p>전) 한국경제TV아나운서 </p>
                                    <p>전) STN sports 스포츠 캐스터 </p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>이미지 메이킹, 스피치 등</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor14.jpg" alt="문향복 교수"></div>
                                <div class="info">
                                    <h3>문향복 <span>교수</span></h3>
                                    <p>퍼스널컬러 교육전문가</p>
                                    <p>골격진단 & 이미지컨설팅 교육전문가</p>
                                    <p>퍼스널브랜딩 교육전문가</p>
                                    <p>퍼스널브랜딩 2급 지도사(한국콘텐츠컨설팅진흥원)</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>이미지 메이킹, 스피치 등</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor13.jpg" alt="김진희 교수"></div>
                                <div class="info">
                                    <h3>김진희 <span>교수</span></h3>
                                    <p>현) 미래교육아카데미 대표</p>
                                    <p>현) 한국강사교육협회 협회장</p>
                                    <p>현) 과학기술정보통신부 인가 사단법인 4차산업혁명연구원 선임연구원</p>
                                    <p>현) 한국메타버스 ESG연구원 전문위원</p>
                                    <p>현) 중소상공인 SNS마케팅 지원협회 이사</p>
                                    <p>현) 국제AI협회(IAA) 이사</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>챗GPT, 선거전략 SNS</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor20.jpg" alt="손정영 교수"></div>
                                <div class="info">
                                    <h3>손정영 <span>교수</span></h3>
                                    <p>현) 한국강사교육협회 이사</p>
                                    <p>현) 한국강사교육협회 경남.부산 지회장</p>
                                    <p>현) 미래교육아카데미 전임강사</p>
                                    <p>현) 챗GPT 생성AI 교육 전문가</p>
                                    <p>전) KTC 디지털 교육 강사</p>
                                    <p>챗GPT 생성AI 교육전문가 1급 </p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>챗GPT, 선거전략 SNS</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor21.jpg" alt="박종혁 교수"></div>
                                <div class="info">
                                    <h3>박종혁 <span>교수</span></h3>
                                    <p>한경대 대학원 행정관리학과(전공: 행정학)</p>
                                    <p>국민대 대학원 행정학과(전공 : 행정학/정책학)</p>
                                    <p>현) 조창현지방자치연구원 원장</p>
                                    <p>현) 챗GPT 및 메타버스 강의 </p>
                                    <p>현) 한양대 강등문제연구소 전문위원 </p>
                                    <p>전) 한양대 공공정책대학원 겸임교수 </p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>지방분권·지역균형발전, AI·디지털 시대의 의정활동</dd>
                                </dl>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor15_261002.jpg" alt="김성삼 교수"></div>
                                <div class="info">
                                    <h3>김성삼 <span>교수</span></h3>
                                    <p>대구한의대학교 정교수</p>
                                    <p>국가기관(공무원, 교육원) 외래교수</p>
                                    <p>한국대학교육협의회 교수법 전담교수</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>감성인문학, 감성 행복특강, 리더쉽, 건강/힐링 등</dd>
                                </dl>
                            </li>

                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor22.jpg" alt="박영재 교수"></div>
                                <div class="info">
                                    <h3>박영재 <span>교수</span></h3>
                                    <p>한국은퇴생활연구소 대표</p>
                                    <p>한국금융연수원 외래교수</p>
                                    <p>한국능률협회 퇴직자교육 전임교수</p>
                                    <p>KBS-1라디오, ‘함께하는 저녁길 오영실입니다’, 박영재의 행복한 인생설계’ 출연 </p>
                                    <p>WOW한국경제TV ‘행복한 은퇴’ 고정패널</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>퇴직 후 자산관리</dd>
                                </dl>
                            </li>
                            
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <div class="photo"><img src="/images/sub/instructor16.jpg" alt="이재우 교수"></div>
                                <div class="info">
                                    <h3>이재우 <span>교수</span></h3>
                                    <p>한국 웃음치료 본부 본부장</p>
                                    <p>행복한 조직문화 연구소 소장</p>
                                    <p>펀 경영 컨설턴트, 동기부여가</p>
                                    <p>전)한국 웃음치료사 연합회 총무</p>
                                    <p>행복 아카데미 자문 이사</p>
                                </div>
                                <dl>
                                    <dt>진행강의</dt>
                                    <dd>웃음치료, 힐링, 행복, 자신감, 리더십</dd>
                                </dl>
                            </li>
                        </ul>
                    </div>
                </div>

                <div id="guide" class="training_cont">

                    <div class="training_intro guide_intro" data-aos="fade-up" data-aos-duration="1000">
                        <div class="tit">
                            <h4>TRAINING GUIDE</h4>
                            <h3>체계적으로 준비하는 의정연수</h3>
                        </div>

                        <div class="desc">
                            <p>연수 대상부터 프로그램 구성과 준비까지<br>맞춤형 의정연수에 필요한 사항을 안내합니다.</p>
                        </div>
                    </div>

                    <div class="guide_contents">
                        <div class="guide_row">
                            <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                                <h4>TRAINING TARGET</h4>
                                <h3>연수 대상</h3>
                                <p>지방의회 의원 및 공무원, <br>지자체 공무원을 대상으로<br>맞춤형 연수를 진행합니다.</p>
                            </div>

                            <div class="guide_cont">
                                <div class="guide_target">
                                    <div class="target_box" data-aos="fade-up" data-aos-duration="1000">
                                        <div class="icon"><i class="fa-solid fa-landmark"></i></div>
                                        <div class="txt">
                                            <h3>지방의회 의원</h3>
                                        </div>
                                    </div>

                                    <div class="target_box" data-aos="fade-up" data-aos-duration="1000">
                                        <div class="icon"><i class="fa-solid fa-user-tie"></i></div>
                                        <div class="txt">
                                            <h3>지방의회 공무원 및 지자체 공무원</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="guide_row">
                            <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                                <h4>TRAINING PROGRAM</h4>
                                <h3>연수 구성</h3>
                                <p>의회의 요청사항과 연수 목적을 반영하여<br>맞춤형 프로그램을 구성합니다.</p>
                            </div>

                            <div class="guide_cont">
                                <ul class="guide_program">
                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>PROGRAM 01</span>
                                        <div class="icon"><i class="fa-solid fa-chalkboard-user"></i></div>
                                        <h3>전문 교육</h3>
                                        <p>의정분야 전문강사진을 통한 맞춤형 교육</p>
                                    </li>

                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>PROGRAM 02</span>
                                        <div class="icon"><i class="fa-solid fa-masks-theater"></i></div>
                                        <h3>문화체험</h3>
                                        <p>문화체험 프로그램을 연계한 연수 구성</p>
                                    </li>

                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>PROGRAM 03</span>
                                        <div class="icon"><i class="fa-solid fa-building-columns"></i></div>
                                        <h3>현장방문 · 벤치마킹</h3>
                                        <p>의정활동과 연계한 현장방문 및 벤치마킹</p>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="guide_row">
                            <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                                <h4>TRAINING SUPPORT</h4>
                                <h3>연수 준비 및 지원</h3>
                                <p>원활한 의정연수를 위해<br>준비부터 운영까지 지원합니다.</p>
                            </div>

                            <div class="guide_cont">
                                <ul class="guide_support">
                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>01</span>
                                        <div class="txt">
                                            <h3>교육 준비</h3>
                                            <p>교육에 필요한 각종 시설 및 다과 사전준비</p>
                                        </div>
                                    </li>

                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>02</span>
                                        <div class="txt">
                                            <h3>방문기관 협의</h3>
                                            <p>의회 관련 시설 및 방문기관 사전협의와 선정완료</p>
                                        </div>
                                    </li>

                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>03</span>
                                        <div class="txt">
                                            <h3>편의물품 제공</h3>
                                            <p>의정연수에 필요한 각종 편의물품 제공</p>
                                        </div>
                                    </li>

                                    <li data-aos="fade-up" data-aos-duration="1000">
                                        <span>04</span>
                                        <div class="txt">
                                            <h3>책임 운영</h3>
                                            <p>모든 교육행사가 원활히 진행되도록 책임 운영</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    </div>
</div>


<script>
    $(document).ready(function(){

    function trainingTab(tabId){
        $('.tabmenu li').removeClass('on');
        $('.training_cont').removeClass('on');

        $('.tabmenu a[data-tab="' + tabId + '"]').parent('li').addClass('on');
        $('#' + tabId).addClass('on');
    }

    $('.tabmenu a').click(function(e){
        e.preventDefault();

        var tabId = $(this).data('tab');

        trainingTab(tabId);
        history.replaceState(null, null, '#' + tabId);
    });

    var trainingHash = window.location.hash.replace('#', '');

    if(trainingHash === 'program' || trainingHash === 'instructor' || trainingHash === 'guide'){
        trainingTab(trainingHash);
    }else{
        trainingTab('program');
    }

    });
</script>



<?php include "../inc/bottom.php"; ?>