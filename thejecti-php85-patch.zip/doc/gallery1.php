<?php require_once(__DIR__ . '/_common.php');  $page_title = ""; ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">
    
	<div id="subTitle">
        <span class="vis_dep01"></span>
    </div>
    
    <div id="pageCont">
        <div class="inner">
        </div>
    
    </div>
</div>




<?php include "../inc/bottom.php"; ?>