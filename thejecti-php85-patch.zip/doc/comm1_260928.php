<?php require_once(__DIR__ . '/_common.php');  $page_title = ""; ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
$s_num = "5";
$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="subTitle">
        <span class="vis_dep01"></span>
    </div>

    <div id="pageCont">
        <div class="s-inner">
            <div class="inquiry_form">
                <form name="fwrite2" id="fwrite2" action="/pg/bbs/write_update.php?type=quick" onsubmit="return fwrite_submit2(this);" method="post" enctype="multipart/form-data" autocomplete="off">
                    <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
                    <input type="hidden" name="w" value="<?php echo $w ?>">
                    <input type="hidden" name="bo_table" value="comm1">
                    <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
                    <input type="hidden" name="sca" value="<?php echo $sca ?>">
                    <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
                    <input type="hidden" name="stx" value="<?php echo $stx ?>">
                    <input type="hidden" name="spt" value="<?php echo $spt ?>">
                    <input type="hidden" name="sst" value="<?php echo $sst ?>">
                    <input type="hidden" name="sod" value="<?php echo $sod ?>">
                    <input type="hidden" name="page" value="<?php echo $page ?>">
                    <div class="form_section">
                        <div class="form_title">
                            <div>
                                <h3>기본정보</h3>
                            </div>
                        </div>
                        <div class="form_grid col2">
                            <div class="form_item">
                                <label>기관명 <b>*</b></label>
                                <input type="text" name="company" placeholder="기관명을 입력해주세요.">
                            </div>

                            <div class="form_item">
                                <label>이름 / 직함 <b>*</b></label>
                                <input type="text" name="name" placeholder="이름 및 직함을 입력해주세요.">
                            </div>

                            <div class="form_item">
                                <label>연락처 <b>*</b></label>
                                <input type="text" name="tel" placeholder="연락처를 입력해주세요.">
                            </div>

                            <div class="form_item">
                                <label>이메일 <b>*</b></label>
                                <input type="email" name="email" placeholder="이메일을 입력해주세요.">
                            </div>
                        </div>
                    </div>


                    <div class="form_section">
                        <div class="form_title">
                            <div>
                                <h3>연수견적 문의</h3>
                            </div>
                        </div>

                        <div class="form_grid col3">
                            <div class="form_item">
                                <label>일정 <b>*</b></label>
                                <input type="text" name="schedule" placeholder="예) 2026. 10. 15 ~ 10. 17">
                            </div>

                            <div class="form_item">
                                <label>지역 <b>*</b></label>
                                <input type="text" name="area" placeholder="희망 지역을 입력해주세요.">
                            </div>

                            <div class="form_item">
                                <label>인원 <b>*</b></label>
                                <input type="text" name="people" placeholder="예) 20명">
                            </div>

                            <div class="form_item">
                                <label>강의주제 및 횟수</label>
                                <input type="text" name="lecture" placeholder="추천이 필요한 경우 함께 작성해주세요.">
                            </div>

                            <div class="form_item">
                                <label>공식방문 및 견학지</label>
                                <input type="text" name="visit" placeholder="희망하시는 곳을 입력해주세요.">
                            </div>

                            <div class="form_item">
                                <label>객실타입 및 수량</label>
                                <input type="text" name="room" placeholder="예) 1인 1실 / 10실">
                            </div>

                            <div class="form_item">
                                <label>차량 임차 여부</label>
                                <select name="vehicle">
                                    <option value="">선택해주세요.</option>
                                    <option value="yes">필요</option>
                                    <option value="no">불필요</option>
                                    <option value="consult">협의 필요</option>
                                </select>
                            </div>
                        </div>
                    </div>


                    <div class="form_section">
                        <div class="form_title">
                            <div>
                                <h3>문의내용</h3>
                            </div>
                        </div>

                        <div class="form_grid">
                            <div class="form_item">
                                <label>제목 <b>*</b></label>
                                <input type="text" name="subject" placeholder="문의 제목을 입력해주세요.">
                            </div>

                            <div class="form_item">
                                <label>내용 <b>*</b></label>
                                <textarea name="content" placeholder="문의하실 내용을 입력해주세요."></textarea>
                            </div>

                            <div class="form_grid col2 form_subgrid">
                                <div class="form_item">
                                    <label>참고 링크 01</label>
                                    <input type="text" name="link1" placeholder="참고하실 링크가 있다면 입력해주세요.">
                                </div>

                                <div class="form_item">
                                    <label>참고 링크 02</label>
                                    <input type="text" name="link2" placeholder="참고하실 링크가 있다면 입력해주세요.">
                                </div>
                            </div>

                            <div class="form_item">
                                <label>파일첨부</label>
                                <div class="file_box">
                                    <input type="file" name="file" id="inquiry_file">
                                    <label for="inquiry_file">
                                        <i class="fa-solid fa-paperclip"></i>
                                        <span>파일 선택</span>
                                    </label>
                                    <p>연수계획서 등 참고자료가 있다면 첨부해주세요.</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="privacy_agree">
                        <div class="agree_head">
                            <div>
                                <h3>개인정보 수집 및 이용 동의</h3>
                                <p>문의 접수 및 답변을 위해 아래와 같이 개인정보를 수집·이용합니다.</p>
                            </div>

                            <label class="agree_check">
                                <input type="checkbox" name="privacy" value="1">
                                <span>개인정보 수집 및 이용에 동의합니다. <b>(필수)</b></span>
                            </label>
                        </div>

                        <div class="agree_cont">
                            <dl>
                                <dt>수집·이용 목적</dt>
                                <dd>문의에 대한 고객 요청 처리 및 결과 회신</dd>
                            </dl>
                            <dl>
                                <dt>수집 항목</dt>
                                <dd>기관명, 이름/직함, 연락처, 이메일</dd>
                            </dl>
                            <dl>
                                <dt>보유·이용 기간</dt>
                                <dd>고객 요청 처리 후 3개월</dd>
                            </dl>
                        </div>

                        <p class="agree_notice">※ 개인정보 수집 및 이용에 대한 동의를 거부할 권리가 있으며, 동의 거부 시 문의 서비스 이용이 제한될 수 있습니다.</p>
                    </div>


                    <div class="form_btn">
                        <button type="submit">
                            <span>문의하기</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>




<?php include "../inc/bottom.php"; ?>