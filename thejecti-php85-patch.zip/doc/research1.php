<?php require_once(__DIR__ . '/_common.php');  $page_title = "의원정책연구용역"; ?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
    $s_num = "6";
    $p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">

    <div id="subTitle">
        <span class="vis_dep01"></span>
    </div>

    <div id="pageCont">
        <div class="inner">
            <div class="training_wrap research_wrap">
                <div class="training_intro rsc_intro" data-aos="fade-up" data-aos-duration="1000">
                    <div class="tit">
                        <h4>POLICY RESEARCH SERVICE</h4>
                        <h3>지역의 현안을 정책으로,<br>실효성 있는 대안을 제시합니다.</h3>
                    </div>
                    <div class="desc">
                        <p>
                            더조은의정은 지방의회의 현안과 지역 특성에 맞는 정책연구과제를 발굴하고,<br>
                            전문적인 조사·분석을 통해 <b>실효성 있는 정책대안</b>을 제시합니다.
                        </p>
                    </div>
                </div>

                <div class="program_row">
                    <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                        <h4>POLICY RESEARCH</h4>
                        <h3>의원정책 <br><span>연구용역</span></h3>
                        <p>
                            지역 현안 분석부터 정책대안 도출까지<br>
                            체계적인 정책연구를 지원합니다.
                        </p>
                    </div>
                    <div class="system_cont">
                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">LOCAL POLICY</span>
                                <h3>지역과 의회를 이해하는 정책연구</h3>
                            </div>
                            <ul>
                                <li>지역 현안과 주민 수요를 바탕으로 정책연구과제를 발굴합니다.</li>
                                <li>의정활동 및 조례·정책개발과 연계 가능한 연구방향을 설정합니다.</li>
                                <li>전문적인 조사와 분석을 통해 실질적으로 활용 가능한 정책대안을 제시합니다.</li>
                            </ul>
                        </div>
                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">RESEARCH SUPPORT</span>
                                <h3>기획부터 결과 활용까지 체계적인 지원</h3>
                            </div>
                            <ul>
                                <li>연구과제 기획 및 연구용역 설계</li>
                                <li>사례조사·통계분석·전문가 자문 등 전문 연구 수행</li>
                                <li>연구결과보고서 작성 및 정책토론회·간담회 연계</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="program_process program_row">
                    <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                        <h4>RESEARCH PROCESS</h4>
                        <h3>정책연구용역 <br><span>진행 절차</span></h3>
                        <p>
                            과제 발굴부터 연구결과 활용까지<br>
                            단계별로 체계적으로 진행합니다.
                        </p>
                    </div>

                    <div class="process_list research_process_list">
                        <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="icon"><i data-lucide="search"></i></div>
                            <span class="num">01</span>
                            <h3>정책연구<br>과제 발굴</h3>
                        </div>
                        <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="icon"><i data-lucide="clipboard-list"></i></div>
                            <span class="num">02</span>
                            <h3>연구용역 <br>기획·설계</h3>
                        </div>
                        <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="icon"><i data-lucide="chart-no-axes-combined"></i></div>
                            <span class="num">03</span>
                            <h3>전문 연구 <br>및 조사</h3>
                        </div>
                        <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="icon"><i data-lucide="lightbulb"></i></div>
                            <span class="num">04</span>
                            <h3>정책대안 및 <br>실행방안 제시</h3>
                        </div>
                        <div class="process_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="icon"><i data-lucide="file-check-2"></i></div>
                            <span class="num">05</span>
                            <h3>연구결과 보고 <br>및 활용 지원</h3>
                        </div>
                    </div>
                </div>

                <div class="program_system program_row">
                    <div class="program_title" data-aos="fade-up" data-aos-duration="1000">
                        <h4>RESEARCH SERVICE</h4>
                        <h3>단계별 <br><span>연구 수행내용</span></h3>
                        <p>
                            정책연구의 목적과 방향에 맞춰<br> 
                            전문적인 연구를 수행합니다.
                        </p>
                    </div>


                    <div class="system_cont">
                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">STEP 01</span>
                                <h3>정책연구과제 발굴</h3>
                            </div>
                            <ul>
                                <li>지역 현안 및 주민 수요 분석</li>
                                <li>의정활동과 연계한 연구주제 발굴</li>
                                <li>조례·정책개발과 연계 가능한 과제 기획</li>
                                <li>의원연구단체 연구과제 기획 지원</li>
                            </ul>
                        </div>

                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">STEP 02</span>
                                <h3>연구용역 기획·설계</h3>
                            </div>
                            <ul>
                                <li>연구목적 및 추진방향 설정</li>
                                <li>연구범위 및 주요 연구내용 구성</li>
                                <li>연구방법 및 추진일정 설계</li>
                                <li>과업내용서 작성 지원</li>
                            </ul>
                        </div>

                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">STEP 03</span>
                                <h3>전문 연구 및 조사</h3>
                            </div>
                            <ul>
                                <li>국내외 사례조사</li>
                                <li>지역 현황 및 통계자료 분석</li>
                                <li>전문가 자문 및 의견수렴</li>
                                <li>현장조사 및 관계기관 인터뷰</li>
                                <li>정책·제도 분석</li>
                            </ul>
                        </div>

                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">STEP 04</span>
                                <h3>정책대안 및 실행방안 제시</h3>
                            </div>
                            <ul>
                                <li>지역 맞춤형 정책대안 도출</li>
                                <li>정책별 기대효과 및 추진방안 제시</li>
                                <li>조례 제·개정 등 제도개선 방안 검토</li>
                                <li>단계별 실행계획 제안</li>
                            </ul>
                        </div>

                        <div class="system_item" data-aos="fade-up" data-aos-duration="1000">
                            <div class="system_head">
                                <span class="label">STEP 05</span>
                                <h3>연구결과 보고 및 활용 지원</h3>
                            </div>
                            <ul>
                                <li>연구결과보고서 작성</li>
                                <li>의원 및 의회 대상 결과보고</li>
                                <li>정책토론회·간담회 연계</li>
                                <li>연구결과의 의정활동 활용 지원</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Sub Content -->


<?php include "../inc/bottom.php"; ?>