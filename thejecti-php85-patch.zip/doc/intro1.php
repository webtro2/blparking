<?php require_once(__DIR__ . '/_common.php');  $page_title = "회사소개"; ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent">
    
	<div id="subTitle">
        <span class="vis_dep01"></span>
    </div>
    
    <div id="pageCont">
        <div class="inner">
            <div class="intro1">
                <div class="top"><h3>의정의 가치를 높이고, <br class="br980">더 나은 지방자치를 만들어가는 <br><span>더(THE)조은의정</span>이 되겠습니다.</h3></div>
                <div class="img"><p>LEADING <br class="br980">THE FUTURE OF COUNCIL TRAINING</p></div>
                <div class="cont">
                    <h3>안녕하십니까. <br>더(THE)조은의정을 찾아주신 <br class="br768">여러분께 진심으로 감사드립니다.</h3>
                    <p>더(THE)조은의정은 지방의회 의원님과 <br class="br768">의회 사무국·과 직원 여러분을 위한 <br><b>전문적인 의정연수 및 교육 프로그램을 기획·운영</b>하고 있습니다.</p>
                    <p>풍부한 현장 경험과 전문성을 바탕으로 <br class="br768">각 의회의 특성에 맞는 차별화된 연수 프로그램을 제공하며, <br>교육의 품질과 세심한 현장 진행, 신뢰를 최우선 가치로 생각합니다.</p>
                    <p>앞으로도 의정활동에 실질적인 도움이 되는 <br class="br768">알찬 프로그램과 최상의 서비스를 제공하며, <br>의회와 함께 성장하는 든든한 파트너가 되겠습니다.</p>
                    <p>감사합니다.</p>
                    <p class="name"><b>더(THE)조은의정</b></p>
                </div>
            </div>
        </div>
    
    </div>
</div>




<?php include "../inc/bottom.php"; ?>