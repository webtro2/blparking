<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="' . $latest_skin_url . '/style.css">', 0);
$thumb_width = 382;
$thumb_height = 300;
$list_count = (is_array($list) && $list) ? count($list) : 0;
if ($list_count > 0) {
    usort($list, function($a, $b) {
        $dateA = isset($a['wr_1']) ? strtotime(str_replace('.', '-', $a['wr_1'])) : 0;
        $dateB = isset($b['wr_1']) ? strtotime(str_replace('.', '-', $b['wr_1'])) : 0;

        return $dateB <=> $dateA;
    });
}
?>


<?php
for ($i = 0; $i < $list_count; $i++) {

    $img_link_html = '';

    $wr_href = get_pretty_url($bo_table, $list[$i]['wr_id']);

    $thumb = get_list_thumbnail($bo_table, $list[$i]['wr_id'], $thumb_width, $thumb_height, false, true);

    if ($thumb['src']) {
        $img = $thumb['src'];
    } else {
        $img = G5_IMG_URL . '/no_img.png';
        $thumb['alt'] = '이미지가 없습니다.';
    }
    $img_content = '<img src="' . $img . '" alt="' . $thumb['alt'] . '" >';
    $img_link_html = '<a href="' . $wr_href . '" class="lt_img" >' . run_replace('thumb_image_tag', $img_content, $thumb) . '</a>';
?>
    <div class="gall_item">
        <a href="<?php echo $list[$i]['href'] ?>">
            <div class="img">
                <?php echo $img_content; ?>
            </div>
            <div class="txt">
                <h3><?php echo $list[$i]['subject'] ?></h3>
                <!-- <p><?php //php echo date("y.m.d", strtotime($list[$i]['datetime'])) ?></p> -->
                <p>
                    <?php
                    $display_date = '';
                    $wr_1 = isset($list[$i]['wr_1']) ? trim($list[$i]['wr_1']) : '';
                    $wr_2 = isset($list[$i]['wr_2']) ? trim($list[$i]['wr_2']) : '';

                    if ($wr_1) {
                        $t1 = strtotime(str_replace('.', '-', $wr_1));

                        if ($t1) {
                            $y1 = date('y', $t1);
                            $m1 = date('n', $t1);
                            $d1 = date('j', $t1);

                            if ($wr_2) {
                                $t2 = strtotime(str_replace('.', '-', $wr_2));

                                if ($t2) {
                                    $y2 = date('y', $t2);
                                    $m2 = date('n', $t2);
                                    $d2 = date('j', $t2);

                                    if ($y1 === $y2 && $m1 === $m2) {
                                        $display_date = ($d1 === $d2)
                                            ? "{$y1}.{$m1}.{$d1}"
                                            : "{$y1}.{$m1}.{$d1}~{$d2}";
                                    } else if ($y1 === $y2) {
                                        $display_date = "{$y1}.{$m1}.{$d1}~{$m2}.{$d2}";
                                    } else {
                                        $display_date = "{$y1}.{$m1}.{$d1}~{$y2}.{$m2}.{$d2}";
                                    }
                                } else {
                                    $display_date = "{$y1}.{$m1}.{$d1}";
                                }
                            } else {
                                $display_date = "{$y1}.{$m1}.{$d1}";
                            }
                        } else {
                            $display_date = $wr_1;
                        }
                    } else {
                        $display_date = date("y.m.d", strtotime($list[$i]['datetime']));
                    }

                    echo $display_date;
                    ?>
                    </p>
            </div>
        </a>
    </div>
<?php }  ?>
<?php if ($list_count == 0) { //게시물이 없을 때  
?>
    <div class="empty_li center" style="font-size:16px;">게시물이 없습니다.</div>
<?php }  ?>