<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="' . $board_skin_url . '/style.css">', 0);
?>

<script src="<?php echo G5_JS_URL; ?>/viewimageresize.js"></script>

<!-- 게시물 읽기 시작 { -->

<!-- 게시물 상단 버튼 시작 { -->
<div class="board-btn bo-v-btn-wrap">
    <div class="bo-v-btn-left">
        <?php if ($update_href) { ?><a href="<?php echo $update_href ?>" class="btn-bo-modify">수정</a><?php } ?>
        <?php if ($delete_href) { ?><a href="<?php echo $delete_href ?>" class="btn-bo-delete" onclick="del(this.href); return false;">삭제</a><?php } ?>
        <?php if ($copy_href) { ?><a href="<?php echo $copy_href ?>" class="btn-bo-copy" onclick="board_move(this.href); return false;">복사</a><?php } ?>
        <?php if ($move_href) { ?><a href="<?php echo $move_href ?>" class="btn-bo-move" onclick="board_move(this.href); return false;">이동</a><?php } ?>
    </div>
    <div class="bo-v-btn-right">
        <?php if ($search_href) { ?><a href="<?php echo $search_href ?>" class="btn-bo-search">검색목록</a><?php } ?>
        <a href="<?php echo $list_href ?>" class="btn-bo-list" title="목록">목록</a>
        <?php if ($reply_href) { ?><a href="<?php echo $reply_href ?>" class="btn-bo-reply" title="답변">답변</a><?php } ?>
        <?php if ($write_href) { ?><a href="<?php echo $write_href ?>" class="btn-bo-write" title="글쓰기">글쓰기</a><?php } ?>
    </div>
</div>
<!-- } 게시물 상단 버튼 끝 -->

<article id="bo_v" style="width:<?php echo $width; ?>">

    <?php
    // 첨부파일 2~11번째를 이미지 슬라이드로 출력 (1번째 파일은 하단 다운로드 버튼 전용)
    // viewimageresize()가 #bo_v_atc 내부 이미지를 건드리므로 슬라이드/팝업은 section 밖에 둔다
    $v_slide_files = array();
    for ($i = 1; $i <= 10; $i++) {
        if (isset($view['file'][$i]['source']) && $view['file'][$i]['source']) {
            $v_slide_files[] = $view['file'][$i];
        }
    }
    if (count($v_slide_files)) {
    ?>
        <div id="bo_v_slide" class="bo_v_slide">
            <div class="bo_v_slide_track">
                <?php foreach ($v_slide_files as $v_slide_idx => $v_slide_file) { ?>
                    <div class="bo_v_slide_item"><img src="<?php echo $v_slide_file['href']; ?>" alt="<?php echo get_text($v_slide_file['source']); ?>" class="bo_v_slide_img" data-index="<?php echo $v_slide_idx; ?>"></div>
                <?php } ?>
            </div>
            <?php if (count($v_slide_files) > 1) { ?>
                <button type="button" class="bo_v_slide_btn bo_v_slide_prev" aria-label="이전"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                <button type="button" class="bo_v_slide_btn bo_v_slide_next" aria-label="다음"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
            <?php } ?>
        </div>

        <!-- 이미지 레이어팝업 -->
        <div id="bo_v_lightbox" class="bo_v_lightbox">
            <div class="bo_v_lightbox_dim"></div>
            <div class="bo_v_lightbox_inner">
                <button type="button" class="bo_v_lightbox_close" aria-label="닫기">&times;</button>
                <div class="bo_v_lightbox_main">
                    <button type="button" class="bo_v_lightbox_nav bo_v_lightbox_prev" aria-label="이전"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                    <img alt="" class="bo_v_lightbox_img">
                    <button type="button" class="bo_v_lightbox_nav bo_v_lightbox_next" aria-label="다음"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
                </div>
                <!-- <a href="#" target="_blank" class="bo_v_lightbox_original">원본보기</a> -->
                <div class="bo_v_lightbox_thumbs"></div>
            </div>
        </div>
    <?php } ?>

    <!-- <section id="bo_v_atc">
        <h2 id="bo_v_atc_title">본문</h2> -->
    <!-- <div id="bo_v_share">
			<div class="board-btn">
				<?php if ($scrap_href) { ?><a href="<?php echo $scrap_href;  ?>" target="_blank" class="scrap-btn" onclick="win_scrap(this.href); return false;">스크랩</a><?php } ?>
				<a href="#" class="share-btn">공유</a>
			</div>
        	<?php include_once(G5_SNS_PATH . "/view.sns.skin.php"); ?>
	    </div> -->

    <script>
        $(function() {
            $(".share-btn").click(function(e) {
                e.stopPropagation();
                if (!$(this).hasClass('active')) {
                    console.log('adsf');
                    $(this).addClass('active');
                    $("#bo_v_sns").addClass('active');
                } else {
                    $(this).removeClass('active');
                    $("#bo_v_sns").removeClass('active');
                }
                return false;
            });
            $(document).on("click", function(e) {
                if (!$(e.target).closest('#bo_v_sns.active').length) {
                    $(".share-btn").removeClass('active');
                    $("#bo_v_sns").removeClass('active');
                }
            });
        });
    </script>

    <!-- 본문 내용 시작 { -->
    <?php //echo $view['rich_content']; // {이미지:0} 과 같은 코드를 사용할 경우 
    ?>
    <!-- } 본문 내용 끝 -->

    <?php if ($is_signature) { ?><p><?php echo $signature ?></p><?php } ?>


    <!--  추천 비추천 시작 { -->
    <?php if ($good_href || $nogood_href) { ?>
        <div id="bo_v_act">
            <?php if ($good_href) { ?>
                <span class="bo_v_act_gng">
                    <a href="<?php echo $good_href . '&amp;' . $qstr ?>" id="good_button" class="bo_v_good"><span class="sound_only">추천</span><strong><?php echo number_format($view['wr_good']) ?></strong></a><b id="bo_v_act_good"></b>
                </span>
            <?php } ?>
            <?php if ($nogood_href) { ?>
                <span class="bo_v_act_gng">
                    <a href="<?php echo $nogood_href . '&amp;' . $qstr ?>" id="nogood_button" class="bo_v_nogood"><span class="sound_only">비추천</span><strong><?php echo number_format($view['wr_nogood']) ?></strong></a><b id="bo_v_act_nogood"></b>
                </span>
            <?php } ?>
        </div>
        <?php } else {
        if ($board['bo_use_good'] || $board['bo_use_nogood']) {
        ?>
            <div id="bo_v_act">
                <?php if ($board['bo_use_good']) { ?><span class="bo_v_good"><span class="sound_only">추천</span><strong><?php echo number_format($view['wr_good']) ?></strong></span><?php } ?>
                <?php if ($board['bo_use_nogood']) { ?><span class="bo_v_nogood"><span class="sound_only">비추천</span><strong><?php echo number_format($view['wr_nogood']) ?></strong></span><?php } ?>
            </div>
    <?php
        }
    }
    ?>
    <!-- }  추천 비추천 끝 -->
    </section>

    <?php
    $cnt = 0;
    if ($view['file']['count']) {
        foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
            if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view'])
                $cnt++;
        }
    }
    ?>

    <?php if (isset($view['link']) && array_filter($view['link'])) { ?>
        <!-- 관련링크 시작 { -->
        <section id="bo_v_link">
            <h2>관련링크</h2>
            <ul>
                <?php
                // 링크
                $cnt = 0;
                for ($i = 1; $i <= count($view['link']); $i++) {
                    if ($view['link'][$i]) {
                        $cnt++;
                        $link = cut_str($view['link'][$i], 70);
                ?>
                        <li>
                            <a href="<?php echo $view['link_href'][$i] ?>" target="_blank">
                                <strong><?php echo $link ?></strong>
                            </a>
                            <span class="bo_v_link_cnt"><?php echo $view['link_hit'][$i] ?>회 연결</span>
                        </li>
                <?php
                    }
                }
                ?>
            </ul>
        </section>
        <!-- } 관련링크 끝 -->
    <?php } ?>

    <!-- 고정 안내문구 + 전화/메일/다운로드 버튼 시작 { -->
    <div class="bo_v_notice">
        <p>※ 하기 '다운로드' 버튼을 클릭하시면 교육일정, 신청서 다운 가능합니다.</p>
        <p>※ 신청서 작성 후 <a href="mailto:the1253@naver.com">the1253@naver.com</a> 메일로 신청 부탁드립니다.</p>
    </div>
    <div class="bo_v_notice_btns">
        <a href="tel:1551-5840" class="bo_v_notice_btn bo_v_notice_call"><i class="fa fa-phone" aria-hidden="true"></i> 전화</a>
        <a href="mailto:the1253@naver.com" class="bo_v_notice_btn bo_v_notice_mail"><i class="fa fa-envelope" aria-hidden="true"></i> 메일</a>
        <?php if (isset($view['file'][0]['source']) && $view['file'][0]['source']) { ?>
            <a href="<?php echo $view['file'][0]['href']; ?>" class="bo_v_notice_btn bo_v_notice_download view_file_download"><i class="fa fa-download" aria-hidden="true"></i> 다운로드</a>
        <?php } ?>
    </div>
    <!-- } 고정 안내문구 + 전화/메일/다운로드 버튼 끝 -->

    <?php if ($prev_href || $next_href) { ?>
        <ul class="bo_v_nb">
            <?php if ($prev_href) { ?><li class="btn_prv"><span class="nb_tit"><i class="fa fa-chevron-up" aria-hidden="true"></i> 이전글</span><a href="<?php echo $prev_href ?>"><?php echo $prev_wr_subject; ?></a> <span class="nb_date"><?php echo str_replace('-', '.', substr($prev_wr_date, '2', '8')); ?></span></li><?php } ?>
            <?php if ($next_href) { ?><li class="btn_next"><span class="nb_tit"><i class="fa fa-chevron-down" aria-hidden="true"></i> 다음글</span><a href="<?php echo $next_href ?>"><?php echo $next_wr_subject; ?></a> <span class="nb_date"><?php echo str_replace('-', '.', substr($next_wr_date, '2', '8')); ?></span></li><?php } ?>
        </ul>
    <?php } ?>

    <?php
    // 코멘트 입출력
    // include_once(G5_BBS_PATH.'/view_comment.php');
    ?>
</article>
<!-- } 게시판 읽기 끝 -->

<script>
    <?php if ($board['bo_download_point'] < 0) { ?>
        $(function() {
            $("a.view_file_download").click(function() {
                if (!g5_is_member) {
                    alert("다운로드 권한이 없습니다.\n회원이시라면 로그인 후 이용해 보십시오.");
                    return false;
                }

                var msg = "파일을 다운로드 하시면 포인트가 차감(<?php echo number_format($board['bo_download_point']) ?>점)됩니다.\n\n포인트는 게시물당 한번만 차감되며 다음에 다시 다운로드 하셔도 중복하여 차감하지 않습니다.\n\n그래도 다운로드 하시겠습니까?";

                if (confirm(msg)) {
                    var href = $(this).attr("href") + "&js=on";
                    $(this).attr("href", href);

                    return true;
                } else {
                    return false;
                }
            });
        });
    <?php } ?>

    function board_move(href) {
        window.open(href, "boardmove", "left=50, top=50, width=500, height=550, scrollbars=1");
    }
</script>

<script>
    $(function() {
        $("a.view_image").click(function() {
            window.open(this.href, "large_image", "location=yes,links=no,toolbar=no,top=10,left=10,width=10,height=10,resizable=yes,scrollbars=no,status=no");
            return false;
        });

        // 추천, 비추천
        $("#good_button, #nogood_button").click(function() {
            var $tx;
            if (this.id == "good_button")
                $tx = $("#bo_v_act_good");
            else
                $tx = $("#bo_v_act_nogood");

            excute_good(this.href, $(this), $tx);
            return false;
        });

        // 이미지 리사이즈
        $("#bo_v_atc").viewimageresize();

        // 첨부파일 이미지 슬라이드 (PC 2장씩 / 모바일 1장씩)
        var $slide = $("#bo_v_slide");
        if ($slide.length) {
            var $track = $slide.find(".bo_v_slide_track");
            var $items = $slide.find(".bo_v_slide_item");
            var slideCount = $items.length;
            var pageIdx = 0;

            function itemsPerView() {
                return window.matchMedia("(max-width: 760px)").matches ? 1 : 2;
            }

            function totalPages() {
                return Math.max(1, Math.ceil(slideCount / itemsPerView()));
            }

            function goPage(idx) {
                var perView = itemsPerView();
                var pages = totalPages();
                pageIdx = (idx + pages) % pages;
                var targetIdx = Math.min(pageIdx * perView, slideCount - 1);
                var trackLeft = $track[0].getBoundingClientRect().left;
                var itemLeft = $items.eq(targetIdx)[0].getBoundingClientRect().left;
                var offset = itemLeft - trackLeft;
                $track.css("transform", "translateX(-" + offset + "px)");
            }

            $slide.find(".bo_v_slide_prev").click(function() {
                goPage(pageIdx - 1);
            });
            $slide.find(".bo_v_slide_next").click(function() {
                goPage(pageIdx + 1);
            });

            $(window).on("resize", function() {
                pageIdx = 0;
                goPage(0);
            });

            goPage(0);
        }

        // 이미지 레이어팝업 (큰 이미지 + 썸네일)
        var $lightbox = $("#bo_v_lightbox");
        if ($lightbox.length) {
            var $slideImgs = $slide.find(".bo_v_slide_img");
            var $lbImg = $lightbox.find(".bo_v_lightbox_img");
            var $lbOriginal = $lightbox.find(".bo_v_lightbox_original");
            var $lbThumbs = $lightbox.find(".bo_v_lightbox_thumbs");
            var lbIdx = 0;

            $slideImgs.each(function(i) {
                $lbThumbs.append(
                    $("<img>").attr("src", $(this).attr("src")).attr("data-index", i).addClass("bo_v_lightbox_thumb")
                );
            });
            var $lbThumbItems = $lbThumbs.find(".bo_v_lightbox_thumb");

            function showLightbox(idx) {
                lbIdx = (idx + $slideImgs.length) % $slideImgs.length;
                var src = $slideImgs.eq(lbIdx).attr("src");
                $lbImg.attr("src", src);
                $lbOriginal.attr("href", src);
                $lbThumbItems.removeClass("active").eq(lbIdx).addClass("active");
                $lightbox.addClass("active");
            }

            function hideLightbox() {
                $lightbox.removeClass("active");
            }

            $slideImgs.click(function() {
                showLightbox($(this).data("index"));
            });
            $lbThumbItems.click(function() {
                showLightbox($(this).attr("data-index"));
            });
            $lightbox.find(".bo_v_lightbox_prev").click(function() {
                showLightbox(lbIdx - 1);
            });
            $lightbox.find(".bo_v_lightbox_next").click(function() {
                showLightbox(lbIdx + 1);
            });
            $lightbox.find(".bo_v_lightbox_close, .bo_v_lightbox_dim").click(function() {
                hideLightbox();
            });
            $(document).on("keydown", function(e) {
                if (!$lightbox.hasClass("active")) return;
                if (e.key === "Escape") hideLightbox();
                if (e.key === "ArrowLeft") showLightbox(lbIdx - 1);
                if (e.key === "ArrowRight") showLightbox(lbIdx + 1);
            });
        }
    });

    function excute_good(href, $el, $tx) {
        $.post(
            href, {
                js: "on"
            },
            function(data) {
                if (data.error) {
                    alert(data.error);
                    return false;
                }

                if (data.count) {
                    $el.find("strong").text(number_format(String(data.count)));
                    if ($tx.attr("id").search("nogood") > -1) {
                        $tx.text("이 글을 비추천하셨습니다.");
                        $tx.fadeIn(200).delay(2500).fadeOut(200);
                    } else {
                        $tx.text("이 글을 추천하셨습니다.");
                        $tx.fadeIn(200).delay(2500).fadeOut(200);
                    }
                }
            }, "json"
        );
    }
</script>
<!-- } 게시글 읽기 끝 -->