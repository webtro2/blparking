<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="/css/scont.css">', 0);
add_stylesheet('<link rel="stylesheet" href="' . $board_skin_url . '/style.css">', 1);
?>

<script src="<?php echo G5_JS_URL; ?>/viewimageresize.js"></script>

<style>
    /* scont.css 디자인 시스템 완벽 연동 */
    .inquiry_form input[readonly] {
        background-color: #f7f8f7 !important;
        color: #222 !important;
        border: 1px solid #ddd !important;
        cursor: default;
    }

    .inquiry_form .form_view_content {
        width: 100%;
        min-height: 22rem;
        padding: 2rem;
        border: 1px solid #ddd;
        border-radius: 0.8rem;
        background: #fff;
        color: #222;
        font-size: 1.5rem;
        line-height: 1.7;
        box-sizing: border-box;
        word-break: break-all;
    }

    .inquiry_form .form_link_box {
        display: flex;
        align-items: center;
        height: 5rem;
        padding: 0 2rem;
        background: #f7f8f7;
        border: 1px solid #ddd;
        border-radius: 0.8rem;
        box-sizing: border-box;
    }

    .inquiry_form .form_link_box a {
        color: var(--color1, #007440);
        font-size: 1.5rem;
        text-decoration: underline;
        word-break: break-all;
    }

    .inquiry_form .file_box_view {
        min-height: 8rem;
        padding: 1.5rem 2rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 1rem;
        background: #f7f8f7;
        border: 1px solid #e5e5e5;
        border-radius: 0.8rem;
        box-sizing: border-box;
    }

    .inquiry_form .file_view_item a {
        display: inline-flex;
        align-items: center;
        gap: 0.8rem;
        color: #222;
        font-size: 1.5rem;
        font-weight: 500;
        transition: color 0.25s ease;
    }

    .inquiry_form .file_view_item a i {
        color: var(--color1, #007440);
    }

    .inquiry_form .file_view_item a:hover {
        color: var(--color1, #007440);
    }

    .inquiry_form .no_file {
        color: #999;
        font-size: 1.4rem;
        margin: 0;
    }

    .bo_v_info_bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.5rem 2rem;
        background: #f7f8f7;
        border: 1px solid #e5e5e5;
        border-radius: 0.8rem;
        margin-bottom: 3rem;
        font-size: 1.5rem;
        color: #555;
    }

    .bo_v_info_bar .info_left strong {
        color: #222;
        margin-right: 2rem;
    }
</style>

<!-- 게시물 읽기 시작 { -->
<article id="bo_v" style="width:<?php echo $width; ?>">

    <!-- 게시물 상단 버튼 시작 { -->
    <div class="board-btn bo-v-btn-wrap">
        <div class="bo-v-btn-left">
            <?php if ($update_href) { ?><a href="<?php echo $update_href ?>" class="btn-bo-modify">수정</a><?php } ?>
            <?php if ($delete_href) { ?><a href="<?php echo $delete_href ?>" class="btn-bo-delete" onclick="del(this.href); return false;">삭제</a><?php } ?>
            <?php if ($copy_href) { ?><a href="<?php echo $copy_href ?>" class="btn-bo-copy" onclick="board_move(this.href); return false;">복사</a><?php } ?>
            <?php if ($move_href) { ?><a href="<?php echo $move_href ?>" class="btn-bo-move" onclick="board_move(this.href); return false;">이동</a><?php } ?>
        </div>
        <div class="bo-v-btn-right">
            <?php if ($search_href) { ?><a href="<?php echo $search_href ?>" class="btn-bo-search">검색목록</a><?php } ?>
            <a href="<?php echo $list_href ?>" class="btn-bo-list" title="목록">목록</a>
            <?php if ($reply_href) { ?><a href="<?php echo $reply_href ?>" class="btn-bo-reply" title="답변">답변</a><?php } ?>
            <?php if ($write_href) { ?><a href="<?php echo $write_href ?>" class="btn-bo-write" title="글쓰기">글쓰기</a><?php } ?>
        </div>
    </div>
    <!-- } 게시물 상단 버튼 끝 -->

    <div class="bo_v_info_bar">
        <div class="info_left">
            <strong>작성자: <?php echo get_text($view['wr_name']); ?></strong>
            <span>작성일: <?php echo str_replace("-", ".", date("Y.m.d H:i", strtotime($view['wr_datetime']))); ?></span>
        </div>
        <div class="info_right">
            <span>조회수: <?php echo number_format($view['wr_hit']); ?>회</span>
        </div>
    </div>

    <div class="inquiry_form">
        <!-- 기본정보 -->
        <div class="form_section">
            <div class="form_title">
                <div>
                    <h3>기본정보</h3>
                </div>
            </div>
            <div class="form_grid col2">
                <div class="form_item">
                    <label>기관명</label>
                    <input type="text" value="<?php echo get_text($view['wr_1']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>이름 / 직함</label>
                    <input type="text" value="<?php echo get_text($view['wr_name']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>연락처</label>
                    <input type="text" value="<?php echo get_text($view['wr_2']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>이메일</label>
                    <input type="text" value="<?php echo get_text($view['wr_email']); ?>" readonly>
                </div>
            </div>
        </div>

        <!-- 연수견적 문의 -->
        <div class="form_section">
            <div class="form_title">
                <div>
                    <h3>연수견적 문의</h3>
                </div>
            </div>

            <div class="form_grid col3">
                <div class="form_item">
                    <label>일정</label>
                    <input type="text" value="<?php echo get_text($view['wr_3']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>지역</label>
                    <input type="text" value="<?php echo get_text($view['wr_4']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>인원</label>
                    <input type="text" value="<?php echo get_text($view['wr_5']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>강의주제 및 횟수</label>
                    <input type="text" value="<?php echo get_text($view['wr_6']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>공식방문 및 견학지</label>
                    <input type="text" value="<?php echo get_text($view['wr_7']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>객실타입 및 수량</label>
                    <input type="text" value="<?php echo get_text($view['wr_8']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>차량 임차 여부</label>
                    <input type="text" value="<?php echo get_text($view['wr_9']); ?>" readonly>
                </div>
            </div>
        </div>

        <!-- 문의내용 -->
        <div class="form_section">
            <div class="form_title">
                <div>
                    <h3>문의내용</h3>
                </div>
            </div>

            <div class="form_grid">
                <div class="form_item">
                    <label>제목</label>
                    <input type="text" value="<?php echo get_text($view['wr_subject']); ?>" readonly>
                </div>

                <div class="form_item">
                    <label>내용</label>
                    <div class="form_view_content">
                        <?php
                        // 첨부 이미지 출력
                        $v_img_count = count($view['file']);
                        if ($v_img_count) {
                            echo "<div id=\"bo_v_img\" style=\"margin-bottom:15px;\">\n";
                            foreach ($view['file'] as $view_file) {
                                echo get_file_thumbnail($view_file);
                            }
                            echo "</div>\n";
                        }
                        ?>
                        <?php echo get_view_thumbnail($view['content']); ?>
                    </div>
                </div>

                <div class="form_grid col2 form_subgrid">
                    <div class="form_item">
                        <label>참고 링크 01</label>
                        <?php if (isset($view['link'][1]) && $view['link'][1]) { ?>
                            <div class="form_link_box">
                                <a href="<?php echo $view['link_href'][1]; ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo get_text($view['link'][1]); ?>
                                </a>
                            </div>
                        <?php } else { ?>
                            <input type="text" value="등록된 링크가 없습니다." readonly>
                        <?php } ?>
                    </div>

                    <div class="form_item">
                        <label>참고 링크 02</label>
                        <?php if (isset($view['link'][2]) && $view['link'][2]) { ?>
                            <div class="form_link_box">
                                <a href="<?php echo $view['link_href'][2]; ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo get_text($view['link'][2]); ?>
                                </a>
                            </div>
                        <?php } else { ?>
                            <input type="text" value="등록된 링크가 없습니다." readonly>
                        <?php } ?>
                    </div>
                </div>

                <div class="form_item">
                    <label>파일첨부</label>
                    <div class="file_box_view">
                        <?php
                        $cnt = 0;
                        if (isset($view['file']['count']) && $view['file']['count']) {
                            foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
                                if (isset($view['file'][$i]['source']) && $view['file'][$i]['source']) {
                                    $cnt++;
                        ?>
                                    <div class="file_view_item">
                                        <a href="<?php echo $view['file'][$i]['href']; ?>" class="view_file_download">
                                            <i class="fa-solid fa-paperclip"></i>
                                            <span><?php echo get_text($view['file'][$i]['source']); ?> (<?php echo $view['file'][$i]['size']; ?>)</span>
                                        </a>
                                    </div>
                        <?php
                                }
                            }
                        }
                        if (!$cnt) {
                            echo "<p class='no_file'>첨부된 참고자료가 없습니다.</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if ($prev_href || $next_href) { ?>
        <ul class="bo_v_nb" style="margin-top:40px;">
            <?php if ($prev_href) { ?><li class="btn_prv"><span class="nb_tit"><i class="fa fa-chevron-up" aria-hidden="true"></i> 이전글</span><a href="<?php echo $prev_href ?>"><?php echo $prev_wr_subject; ?></a> <span class="nb_date"><?php echo str_replace('-', '.', substr($prev_wr_date, '2', '8')); ?></span></li><?php } ?>
            <?php if ($next_href) { ?><li class="btn_next"><span class="nb_tit"><i class="fa fa-chevron-down" aria-hidden="true"></i> 다음글</span><a href="<?php echo $next_href ?>"><?php echo $next_wr_subject; ?></a> <span class="nb_date"><?php echo str_replace('-', '.', substr($next_wr_date, '2', '8')); ?></span></li><?php } ?>
        </ul>
    <?php } ?>

    <!-- 게시물 하단 버튼 시작 { -->
    <div class="board-btn bo-v-btn-wrap" style="margin-top:20px;">
        <div class="bo-v-btn-left">
            <?php if ($update_href) { ?><a href="<?php echo $update_href ?>" class="btn-bo-modify">수정</a><?php } ?>
            <?php if ($delete_href) { ?><a href="<?php echo $delete_href ?>" class="btn-bo-delete" onclick="del(this.href); return false;">삭제</a><?php } ?>
            <?php if ($copy_href) { ?><a href="<?php echo $copy_href ?>" class="btn-bo-copy" onclick="board_move(this.href); return false;">복사</a><?php } ?>
            <?php if ($move_href) { ?><a href="<?php echo $move_href ?>" class="btn-bo-move" onclick="board_move(this.href); return false;">이동</a><?php } ?>
        </div>
        <div class="bo-v-btn-right">
            <?php if ($search_href) { ?><a href="<?php echo $search_href ?>" class="btn-bo-search">검색목록</a><?php } ?>
            <a href="<?php echo $list_href ?>" class="btn-bo-list" title="목록">목록</a>
            <?php if ($reply_href) { ?><a href="<?php echo $reply_href ?>" class="btn-bo-reply" title="답변">답변</a><?php } ?>
            <?php if ($write_href) { ?><a href="<?php echo $write_href ?>" class="btn-bo-write" title="글쓰기">글쓰기</a><?php } ?>
        </div>
    </div>
    <!-- } 게시물 하단 버튼 끝 -->

</article>

<script>
    <?php if (isset($board['bo_download_point']) && $board['bo_download_point'] < 0) { ?>
        $(function() {
            $("a.view_file_download").click(function() {
                if (!g5_is_member) {
                    alert("다운로드 권한이 없습니다.\n회원이시라면 로그인 후 이용해 보십시오.");
                    return false;
                }

                var msg = "파일을 다운로드 하시면 포인트가 차감(<?php echo number_format($board['bo_download_point']) ?>점)됩니다.\n\n포인트는 게시물당 한번만 차감되며 다음에 다시 다운로드 하셔도 중복하여 차감하지 않습니다.\n\n그래도 다운로드 하시겠습니까?";

                if (confirm(msg)) {
                    var href = $(this).attr("href") + "&js=on";
                    $(this).attr("href", href);

                    return true;
                } else {
                    return false;
                }
            });
        });
    <?php } ?>

    function board_move(href) {
        window.open(href, "boardmove", "left=50, top=50, width=500, height=550, scrollbars=1");
    }

    $(function() {
        $("a.view_image").click(function() {
            window.open(this.href, "large_image", "location=yes,links=no,toolbar=no,top=10,left=10,width=10,height=10,resizable=yes,scrollbars=no,status=no");
            return false;
        });

        // 이미지 리사이즈
        $("#bo_v_atc").viewimageresize();
    });
</script>
<!-- } 게시글 읽기 끝 -->