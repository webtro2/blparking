<div class="s_visual" style="background-image:url(/images/sub/s_visual<?php  echo ($s_num); ?>.jpg)">
    <div class="s_visual_in">
        <div class="sv_tit">
            <p class="eng">THEJOEUN COUNCIL TRANING INSTITUTE</p>
            <h3><span class="vis_dep01"></span></h3>
            <p class="t1">의정의 가치를 높이는 <br>전문 의정연수 파트너 <b>THE조은의정</b></p>
        </div>
    </div>
</div>


<div id="subContent">
    <div class="sub_menu_wrap">
        <div class="in">
            <div class="m_home"><a href="javascript:GoPage('main')"></a></div>
            <div class="m_1dep_box m_dep_box">
                <div class="m_dep_tit"><span class="vis_dep01"></span></div>
                <?php  include __DIR__ . "/s_gnb0.php" ?>
            </div>
            <div class="m_2dep_box m_dep_box">
                <div class="m_dep_tit"><span class="vis_dep02"></span></div>
                <?php  if (isset($s_num) && preg_match('/^[0-9]+$/', (string)$s_num) && is_file(__DIR__ . "/s_gnb$s_num.php")) include __DIR__ . "/s_gnb$s_num.php" ?>
            </div>
        </div>
    </div>
</div>