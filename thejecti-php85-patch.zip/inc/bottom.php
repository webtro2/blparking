<!-- footer -->
<div id="footer">
    <div class="inner">
        <div class="top">
            <div class="lt">
                <div class="logo"><img src="/images/common/f_logo.png" alt=""></div>
                <ul>
                    <li><b>더(THE)조은의정</b></li>
                    <li>서울특별시 영등포구 당산로 41길 22-3 서광빌딩 201호</li>
                    <li>TEL : 1551-5840</li>
                    <li>E-mail : the1253@naver.com</li>
                    <li>사업자등록번호 : 221-25-52466</li>
                </ul>
            </div>
        </div>
        <div class="bot">
            <ul>
                <li><a href="javascript:GoPage('intro1')">회사소개</a></li>
                <li><a href="javascript:GoPage('term')">이용약관</a></li>
                <li><a href="javascript:GoPage('privacy')"><b>개인정보처리방침</b></a></li>
            </ul>
            <div class="rt">
                <p>Copyright ⓒ 더조은의정. All Rights Reserved.</p>
                <a href="https://www.webtro.co.kr/" target="_blank">DESIGN BT WEBTRO</a>
            </div>
        </div>
    </div>
</div>
<!-- //footer -->


</div>

<script type="text/javascript">
	$(function(){
		subFunc.snb("<?php  echo($s_num ?? '');?>", "<?php  echo($p_num ?? '');?>");
	});
</script>
<script src="/js//aos/aos.js"></script>
<script>
   AOS.init({
     duration: 600,
     offset: 0,
     delay: 100,
     easing: 'ease-out-quad',
   });
</script>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
lucide.createIcons();
</script>

</body>
</html>