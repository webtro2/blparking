<ul class="gnb">

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('intro1')">회사소개</a></div>
        <?php // include __DIR__ . "/s_gnb1.php" ?>
    </li>
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('sch1')">교육일정</a></div>
    </li>
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('pro1')">국내연수 프로그램</a></div>
    </li>
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('research1')">의원정책연구용역</a></div>
    </li>
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('gall1')">갤러리</a></div>
    </li>
    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('comm1')">문의/신청</a></div>
    </li>

</ul>
