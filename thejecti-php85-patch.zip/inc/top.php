<!-- header -->
<div id="header">
    <h1 id="logo">
        <a href="javascript:GoPage('main')" class="logo" alt="더조은의정"></a>
    </h1>

    <div id="gnb_pc">
        <?php  include __DIR__ . "/nav.php" ?>
    </div>

    <div  id="allmenuWrap">
        <div id="allmenu">
            <a href="#" id="navtoggler">
                <div class="bar"><span class="t"></span><span class="m"></span><span class="b"></span></div>
            </a>
        </div>
        <nav id="fullscreenmenu">
            <?php  include __DIR__ . "/nav.php" ?>			
        </nav>
    </div>

    <div class="menuToggle hd_full hd_mbx"><span class="t"></span><span class="m"></span><span class="b"></span></div>

    <div id="gnb_mo" class="fullmenu">
        <?php  include __DIR__ . "/nav.php" ?>
    </div>
</div>
<!-- //header -->