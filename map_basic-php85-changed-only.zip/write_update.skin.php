<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// common.php에서 처리한 입력값을 사용하고 미선택·생략된 값은 빈 문자열로 저장합니다.
foreach (array('ext3_0', 'ext3_1', 'ext3_2', 'ext4_0', 'ext4_1', 'ext4_2', 'ext4_3', 'wr_12', 'wr_15', 'wr_16', 'wr_17') as $map_field) {
    if (!isset($$map_field) || !is_scalar($$map_field)) $$map_field = '';
}
$wr_id = (int)$wr_id;
//time
$wr_3 = "$ext3_0|$ext3_1|$ext3_2";
$sql3 = " update $write_table set wr_3 = '$wr_3' where wr_id = '$wr_id' ";
sql_query($sql3);

$wr_4 = "$ext4_0|$ext4_1|$ext4_2|$ext4_3";
$sql4 = " update $write_table set wr_4 = '$wr_4' where wr_id = '$wr_id' ";
sql_query($sql4);


$sql12 = " update $write_table set wr_12 = '$wr_12' where wr_id = '$wr_id' ";
sql_query($sql12);

$sql15 = " update $write_table set wr_15 = '$wr_15' where wr_id = '$wr_id' ";
sql_query($sql15);

$sql16 = " update $write_table set wr_16 = '$wr_16' where wr_id = '$wr_id' ";
sql_query($sql16);

$sql17 = " update $write_table set wr_17 = '$wr_17' where wr_id = '$wr_id' ";
sql_query($sql17);

//$sqld = " update $write_table set wr_datetime = '$wr_datetime' where wr_id = '$wr_id' ";
//sql_query($sqld);

/*if($w != "u"){
	alert("온라인상담이 정상적으로 신청되었습니다","./write.php?bo_table=$bo_table"); 
}*/
//if (!$board['bo_use_tag']) return;
//include_once(G5_TAG_PATH."/view.tag.update.skin.php");
?>