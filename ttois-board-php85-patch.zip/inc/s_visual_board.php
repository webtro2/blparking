<div class="s_visual" style="background-image:url('/images/sub/s_visual<?php  echo ($s_num); ?>.jpg')">
    <div class="s_visual_in">
        <div class="sv_tit">
            <h3><span class="vis_dep01"></span></h3>
            <p class="t1">바삭한 즐거움부터 깊은 맛까지, 두 가지 매력에 빠지다</p>
        </div>

        <div class="sv_menu">
            <ul class="sv_menu_list"></ul>
        </div>
    </div>
</div>

<div class="sub_menu_wrap">
    <div class="m_1dep_box">
        <?php  include __DIR__ . "/s_gnb0.php" ?>
    </div>
    <div class="m_2dep_box">
        <?php  if (isset($s_num) && preg_match('/^[0-9]+$/', (string)$s_num) && is_file(__DIR__ . "/s_gnb$s_num.php")) include __DIR__ . "/s_gnb$s_num.php" ?>
    </div>
</div>


<script>
    setTimeout(function() {
        $('.s_visual').addClass('active');
    }, 800);
</script>