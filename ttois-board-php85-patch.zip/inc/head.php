<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="ko" />
    <meta name="viewport" content="initial-scale=1.0, width=device-width" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="shortcut icon" href="/favi.ico">
    <meta property="og:image" content="/og_img.png">
    <meta property="og:image:width" content="800">
    <meta property="og:image:height" content="400">

    <?php
    $st_title = "또이스치킨찜닭";

    if (isset($page_title) && $page_title) {
        $site_title = $page_title . " | " . $st_title;
    } else if (isset($g5_head_title) && $g5_head_title) {
        $site_title = $g5_head_title;
    } else {
        $site_title = $st_title;
    }
    ?>

    <title><?php echo $site_title; ?></title>
    <script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="/js/common.js"></script>
    <script type="text/javascript" src="/js/main.js"></script>
    <script type="text/javascript" src="/js/sub.js"></script>
    <script type="text/javascript" src="/js/aos.js"></script>

    <meta name="title" content="<?php echo $site_title; ?>">
    <meta name="author" content="주소">
    <meta name="description" content="">
    <meta name="subject" content="">
    <meta name="keywords" content="">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $site_title; ?>">
    <meta property="og:subject" content="">
    <meta property="og:description" content="">
    <meta property="og:url" content="주소">
    <link rel="canonical" href="주소">
    <meta property="al:web:url" content="주소">

    <link rel="stylesheet" type="text/css" href="/css/default.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/layout.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/main.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/sub.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/scont.css?v=1" />
    <link rel="stylesheet" type="text/css" href="/css/aos.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.14.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.14.2/ScrollTrigger.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- slick -->
    <script src="/js/slick/slick.min.js"></script>
    <link rel="stylesheet" href="/js/slick/slick-theme.css">
    <link rel="stylesheet" href="/js/slick/slick.css">

</head>

<body>

    <div id="wrap">