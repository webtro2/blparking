<ul class="gnb">

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('intro1')">또이스치킨찜닭</a></div>
        <?php  include __DIR__ . "/s_gnb1.php" ?>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('menu1')">메뉴안내</a></div>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('store1')">매장안내</a></div>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('info1')">창업안내</a></div>
    </li>

    <li class="gnb_dp1">
        <div><a href="javascript:GoPage('comm1')">고객센터</a></div>
    </li>

</ul>
