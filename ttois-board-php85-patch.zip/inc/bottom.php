<!-- footer -->
<div id="footer">
    <div class="inner">
        <div class="top">
            <div class="lt">
                <h3>또이스, <br>찜닭은 항상 옳다.</h3>
            </div>
            <div class="line"></div>
            <div class="rt"><img src="/images/common/f_logo.png" alt=""></div>
        </div>
        <div class="bottom">
            <div class="lt">
                <ul>
                    <li>또이스치킨찜닭</li>
                    <li>주소 대구시 남구 양지북길 100</li>
                    <li class="red">가맹문의 053) 626-1584</li>
                    <li>E-mail ttois@naver.com</li>
                    <li>사업자등록번호 100-00-123456</li>
                </ul>
                <p>ⓒ TTOIS. All Rights Reserved. <a href="https://www.webtro.co.kr/" target="_blank">DESIGNED BY WEBTRO</a></p>
            </div>
            <div class="rt">
                <ul>
                    <li><a href="javascript:GoPage('term')">이용약관</a></li>
                    <li><a href="javascript:GoPage('privacy')">개인정보처리방침</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- //footer -->

<div id="quickContact">
    <div class="quick_tel">
        <a href="tel:0536261584">
            <div class="quick_tel_info">
                <span><img src="/images/common/quick_tel.png" alt=""> 가맹문의</span>
                <strong>053) 626-1584</strong>
            </div>
        </a>
    </div>

    <div class="quick_form">
        <form name="fwrite2" id="quickContactForm" action="/pg/bbs/write_update.php?type=quick" onsubmit="return fwrite_submit2(this);" method="post" autocomplete="off">
            <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
            <input type="hidden" name="w" value="<?php echo $w ?>">
            <input type="hidden" name="bo_table" value="franchise">
            <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
            <input type="hidden" name="sca" value="<?php echo $sca ?>">
            <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
            <input type="hidden" name="stx" value="<?php echo $stx ?>">
            <input type="hidden" name="spt" value="<?php echo $spt ?>">
            <input type="hidden" name="sst" value="<?php echo $sst ?>">
            <input type="hidden" name="sod" value="<?php echo $sod ?>">
            <input type="hidden" name="page" value="<?php echo $page ?>">
            <input type="hidden" name=wr_subject value="가맹문의">
            <input type="hidden" name=wr_content value="가맹문의">
            <div class="quick_fields">
                <input type="text" name="wr_name" placeholder="성함" aria-label="성함" required>
                <input type="tel" name="wr_1" placeholder="연락처" aria-label="연락처" required>
                <select name="ca_name" aria-label="창업희망지역" required>
                    <option value="">창업희망지역</option>
                    <option value="서울">서울</option>
                    <option value="경기">경기</option>
                    <option value="인천">인천</option>
                    <option value="부산">부산</option>
                    <option value="대구">대구</option>
                    <option value="경북">경북</option>
                    <option value="경남">경남</option>
                    <option value="대전">대전</option>
                    <option value="충남">충남</option>
                    <option value="충북">충북</option>
                    <option value="광주">광주</option>
                    <option value="전남">전남</option>
                    <option value="전북">전북</option>
                    <option value="강원">강원</option>
                    <option value="제주">제주</option>
                    <option value="세종">세종</option>
                    <option value="울산">울산</option>
                </select>
            </div>

            <div class="quick_agree">
                <label>
                    <input type="checkbox" name="privacy_agree" value="Y" required>
                    <span class="quick_check"></span>
                    <span>개인정보 수집 및 이용동의</span>
                </label>
                <button type="button" class="quick_privacy_view">약관보기</button>
            </div>

            <button type="submit" class="quick_submit">상담신청</button>
        </form>
    </div>
</div>

<div id="privacyModal" class="privacy_modal" aria-hidden="true">
    <div class="privacy_dim"></div>
    <div class="privacy_box" role="dialog" aria-modal="true" aria-labelledby="privacyModalTitle" tabindex="-1">
        <div class="privacy_head">
            <h3 id="privacyModalTitle">개인정보 수집 및 이용 동의</h3>
            <button type="button" class="privacy_close" aria-label="닫기"></button>
        </div>

        <div class="privacy_body">
            <h4>1. 개인정보 수집 및 이용 목적</h4>
            <p>창업 상담 신청 접수, 상담 진행, 문의사항에 대한 답변 및 관련 안내</p>

            <h4>2. 수집하는 개인정보 항목</h4>
            <p>성함, 연락처, 창업 희망 지역, 문의내용</p>

            <h4>3. 개인정보 보유 및 이용 기간</h4>
            <p>실제 개인정보 처리방침에 명시된 보유 및 이용 기간을 입력해주세요.</p>

            <h4>4. 개인정보 수집 및 이용 동의 거부 권리</h4>
            <p>개인정보 수집 및 이용에 동의하지 않을 권리가 있으며, 동의하지 않을 경우 온라인 창업 상담 신청이 제한될 수 있습니다.</p>
        </div>

        <div class="privacy_foot">
            <button type="button" class="privacy_confirm">확인</button>
        </div>
    </div>
</div>

<script>
    $(function() {
        $('#quickContact .quick_privacy_view').on('click', function() {
            $('#privacyModal').addClass('on').attr('aria-hidden', 'false');
            $('html').addClass('contact_privacy_open');
            $('#privacyModal .privacy_box').trigger('focus');
        });
    });
</script>


</div>

<script type="text/javascript">
    $(function() {
        subFunc.snb("<?php  echo ($s_num ?? ''); ?>", "<?php  echo ($p_num ?? ''); ?>");
    });
</script>
<script src="/js//aos/aos.js"></script>
<script>
    AOS.init({
        duration: 600,
        offset: 0,
        delay: 100,
        easing: 'ease-out-quad',
    });
</script>

</body>

</html>