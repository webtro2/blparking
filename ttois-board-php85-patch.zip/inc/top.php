<!-- header -->
<div id="header">
    <h1 id="logo">
        <a href="javascript:GoPage('main')" class="logo" alt="또이스치킨찜닭"></a>
    </h1>

    <div id="gnb_pc">
        <?php  include __DIR__ . "/nav.php" ?>
    </div>


    <div id="hd_tel" class="">
        <dl>
        <dd>053.626.1584</dd>
        </dl>
        <a href="tel:0536261584" class="hd_mbx">전화걸기</a>
    </div>



	<div class="menuToggle hd_full hd_mbx"><span class="t"></span><span class="m"></span><span class="b"></span></div>


	<div id="gnb_mo" class="fullmenu">
		<?php  include __DIR__ . "/nav.php" ?>
	</div>

</div>
<!-- //header -->