<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH . '/head.sub.boa.php');
include_once(G5_LIB_PATH . '/latest.lib.php');
include_once(G5_LIB_PATH . '/outlogin.lib.php');
include_once(G5_LIB_PATH . '/poll.lib.php');
include_once(G5_LIB_PATH . '/visit.lib.php');
include_once(G5_LIB_PATH . '/connect.lib.php');
include_once(G5_LIB_PATH . '/popular.lib.php');


$s_num = "";
$p_num = "";

if ($bo_table == "comm1") {
    $s_num = "5";
    $p_num = "1";
} elseif ($bo_table == "franchise") {
    $s_num = "5";
    $p_num = "2";
} elseif (($fm_id ?? '') == "1") {
    $s_num = "7";
    $p_num = "2";
}
?>



<?php include __DIR__ . "/../inc/head.php"; ?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>
<?php include __DIR__ . "/../inc/s_visual_board.php"; ?>


<!-- Sub Content -->
<div id="subContent">
    <?php if ($bo_table == "comm1") { ?>
        <div id="subTitle">
            <span class="vis_dep03">고객센터</span>
        </div>
    <?php } else { ?>
        <div id="subTitle">
            <span class="vis_dep02"></span>
        </div>
    <?php } ?>

    <div id="pageCont" style="font-size:15px;">

        <div class="inner">