<?php
if (!defined('_GNUBOARD_') || !defined('G5_DB_DOWNLOAD_RUNNING')) {
    http_response_code(403);
    exit;
}

final class G5DatabaseDownload
{
    private $db;
    private $write;
    private $database;

    public function __construct(mysqli $db, callable $write, string $database)
    {
        $this->db = $db;
        $this->write = $write;
        $this->database = $database;
    }

    private function query(string $sql, int $mode = MYSQLI_STORE_RESULT)
    {
        $result = $this->db->query($sql, $mode);
        if ($result === false) throw new RuntimeException('Database read failed', $this->db->errno);
        return $result;
    }

    private function identifier(string $name): string
    {
        return '`'.str_replace('`', '``', $name).'`';
    }

    private function literal(string $value): string
    {
        return "'".$this->db->real_escape_string($value)."'";
    }

    private function emit(string $text): void
    {
        ($this->write)($text);
    }

    private function withoutDefiner(string $sql): string
    {
        // Only remove the account in the CREATE prefix, never text in a view/body.
        $sql = preg_replace('/\A(CREATE\s+(?:OR\s+REPLACE\s+)?(?:ALGORITHM\s*=\s*\w+\s+)?)DEFINER\s*=\s*`(?:``|[^`])*`@`(?:``|[^`])*`\s*/i', '$1', $sql, 1);
        // SHOW CREATE qualifies local references. Keep them local on restore,
        // while preserving quoted data (including strings that resemble SQL).
        $parts = preg_split('/(\'(?:\\\\.|\'\'|[^\'])*\'|"(?:\\\\.|""|[^"])*")/s', $sql, -1, PREG_SPLIT_DELIM_CAPTURE);
        foreach ($parts as $i => $part) {
            if ($i % 2 === 0) $parts[$i] = str_replace($this->identifier($this->database).'.', '', $part);
        }
        return implode('', $parts);
    }

    public function prepare(): array
    {
        if (!$this->db->select_db($this->database)) throw new RuntimeException('Database unavailable');
        if (!$this->db->set_charset('utf8mb4')) throw new RuntimeException('UTF-8 connection required');
        $this->query("SET SESSION time_zone = '+00:00'");
        // Escape literals with predictable backslash handling during the export.
        $this->query("SET SESSION sql_mode = 'NO_AUTO_VALUE_ON_ZERO'");
        $this->query('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
        $this->query('START TRANSACTION WITH CONSISTENT SNAPSHOT');
        $plan = array('tables' => array(), 'views' => array(), 'triggers' => array());
        $objects = $this->query('SHOW FULL TABLES');
        $items = array();
        while ($row = $objects->fetch_row()) $items[] = $row;
        $objects->free();
        foreach ($items as $object) {
            $name = $object[0];
            $type = strtoupper($object[1]);
            $quoted = $this->identifier($name);
            if ($type !== 'BASE TABLE' && $type !== 'VIEW') {
                throw new RuntimeException('Unsupported database object type');
            }
            $result = $this->query('SHOW CREATE '.($type === 'VIEW' ? 'VIEW ' : 'TABLE ').$quoted);
            $ddl = $result->fetch_assoc();
            $result->free();
            $columns = array();
            $bitColumns = array();
            $result = $this->query('SHOW FULL COLUMNS FROM '.$quoted);
            while ($column = $result->fetch_assoc()) {
                // MySQL DEFAULT_GENERATED is an ordinary insertable column.
                if ($type === 'BASE TABLE' && preg_match('/\b(VIRTUAL|STORED|PERSISTENT)\b/i', $column['Extra'])) continue;
                $columns[] = $column['Field'];
                if (preg_match('/^bit\((\d+)\)$/i', $column['Type'], $match)) {
                    $bitColumns[$column['Field']] = 2 * intdiv((int) $match[1] + 7, 8);
                }
            }
            $result->free();
            $probe = $this->query('SELECT * FROM '.$quoted.' LIMIT 0');
            $probe->free();
            if ($type === 'VIEW') {
                $plan['views'][] = array('name' => $name, 'ddl' => $this->withoutDefiner($ddl['Create View']), 'columns' => $columns);
            } else {
                $plan['tables'][] = array('name' => $name, 'ddl' => $ddl['Create Table'], 'columns' => $columns, 'bit_columns' => $bitColumns);
            }
        }
        $result = $this->query('SHOW TRIGGERS');
        $triggers = array();
        while ($row = $result->fetch_assoc()) $triggers[] = $row['Trigger'];
        $result->free();
        foreach ($triggers as $name) {
            $result = $this->query('SHOW CREATE TRIGGER '.$this->identifier($name));
            $row = $result->fetch_assoc();
            $result->free();
            $plan['triggers'][] = array('name' => $name, 'ddl' => $this->withoutDefiner($row['SQL Original Statement']), 'mode' => $row['sql_mode']);
        }
        return $plan;
    }

    private function tableData(array $table): void
    {
        $name = $this->identifier($table['name']);
        $columns = array_map(array($this, 'identifier'), $table['columns']);
        $selectParts = array();
        foreach ($table['columns'] as $column) {
            $q = $this->identifier($column);
            $selectParts[] = isset($table['bit_columns'][$column]) ? "LPAD(HEX(".$q."),".$table['bit_columns'][$column].",'0') AS ".$q : $q;
        }
        $selection = $selectParts ? implode(',', $selectParts) : '1';
        $result = $this->query('SELECT '.$selection.' FROM '.$name, MYSQLI_USE_RESULT);
        $fields = $result->fetch_fields();
        $prefix = 'INSERT INTO '.$name.' ('.implode(',', $columns).") VALUES\n";
        $batch = '';
        $count = 0;
        try {
            while ($row = $result->fetch_row()) {
                $values = array();
                if ($columns) foreach ($row as $i => $value) {
                    if ($value === null) {
                        $values[] = 'NULL';
                        continue;
                    }
                    if (isset($table['bit_columns'][$table['columns'][$i]])) {
                        if (!preg_match('/\A[0-9A-F]+\z/i', (string) $value)) throw new RuntimeException('Invalid BIT representation');
                        $values[] = "X'".$value."'";
                        continue;
                    }
                    $field = $fields[$i];
                    $binaryTypes = array(MYSQLI_TYPE_BIT, MYSQLI_TYPE_TINY_BLOB, MYSQLI_TYPE_MEDIUM_BLOB, MYSQLI_TYPE_LONG_BLOB, MYSQLI_TYPE_BLOB, MYSQLI_TYPE_STRING, MYSQLI_TYPE_VAR_STRING, MYSQLI_TYPE_GEOMETRY);
                    $isBinary = $field->type === MYSQLI_TYPE_BIT || ($field->charsetnr === 63 && in_array($field->type, $binaryTypes, true));
                    $values[] = $isBinary && $value !== '' ? "X'".bin2hex($value)."'" : $this->literal((string) $value);
                }
                $tuple = '('.implode(',', $values).')';
                if ($batch !== '' && (strlen($batch) + strlen($tuple) > 1048576 || $count >= 100)) {
                    $this->emit($prefix.$batch.";\n");
                    $batch = '';
                    $count = 0;
                }
                $batch .= ($batch === '' ? '' : ",\n").$tuple;
                $count++;
            }
            if ($this->db->errno) throw new RuntimeException('Database stream failed', $this->db->errno);
            if ($batch !== '') $this->emit($prefix.$batch.";\n");
        } finally {
            $result->free();
        }
    }

    public function export(array $plan): void
    {
        $this->emit("-- GNUboard database backup\n-- UTC: ".gmdate('Y-m-d H:i:s')."\n-- Routines and scheduled events are not included.\n");
        $this->emit("SET @G5_OLD_SQL_MODE=@@SQL_MODE;\nSET @G5_OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS;\nSET @G5_OLD_TIME_ZONE=@@TIME_ZONE;\nSET @G5_OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT;\nSET @G5_OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS;\nSET @G5_OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION;\nSET NAMES utf8mb4;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET FOREIGN_KEY_CHECKS=0;\nSET TIME_ZONE='+00:00';\n\n");
        // Remove triggers first so restoring data cannot execute an old trigger.
        foreach ($plan['triggers'] as $trigger) $this->emit('DROP TRIGGER IF EXISTS '.$this->identifier($trigger['name']).";\n");
        foreach (array_reverse($plan['views']) as $view) $this->emit('DROP VIEW IF EXISTS '.$this->identifier($view['name']).";\n");
        foreach ($plan['tables'] as $table) {
            $this->emit("\n-- Table\nDROP TABLE IF EXISTS ".$this->identifier($table['name']).";\n".$table['ddl'].";\n");
            $this->tableData($table);
        }
        // Temporary view definitions support references to other views.
        foreach ($plan['views'] as $view) {
            $parts = array();
            foreach ($view['columns'] as $column) $parts[] = '1 AS '.$this->identifier($column);
            $this->emit('CREATE VIEW '.$this->identifier($view['name']).' AS SELECT '.implode(',', $parts).";\n");
        }
        foreach ($plan['views'] as $view) {
            $ddl = preg_replace('/\ACREATE\s+/i', 'CREATE OR REPLACE ', $view['ddl'], 1);
            $this->emit($ddl.";\n");
        }
        foreach ($plan['triggers'] as $trigger) {
            // MariaDB/MySQL command-line clients limit delimiter length.
            do {
                $delimiter = '$G5'.bin2hex(random_bytes(4)).'$';
            } while (strpos($trigger['ddl'], $delimiter) !== false);
            $this->emit('SET SQL_MODE='.$this->literal($trigger['mode']).";\nDELIMITER ".$delimiter."\n".$trigger['ddl'].$delimiter."\nDELIMITER ;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n");
        }
        $this->query('ROLLBACK');
        $this->emit("\nSET SQL_MODE=@G5_OLD_SQL_MODE;\nSET FOREIGN_KEY_CHECKS=@G5_OLD_FOREIGN_KEY_CHECKS;\nSET TIME_ZONE=@G5_OLD_TIME_ZONE;\nSET CHARACTER_SET_CLIENT=@G5_OLD_CHARACTER_SET_CLIENT;\nSET CHARACTER_SET_RESULTS=@G5_OLD_CHARACTER_SET_RESULTS;\nSET COLLATION_CONNECTION=@G5_OLD_COLLATION_CONNECTION;\n-- G5_DB_BACKUP_COMPLETE\n");
    }
}
