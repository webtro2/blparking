<?php
// Install this file and db_download.lib.php in the existing GNUboard admin folder.
ob_start();
chdir(__DIR__);
require_once __DIR__.'/_common.php';

$backup_authorized = isset($member['mb_id'], $config['cf_admin'], $is_admin)
    && $is_admin === 'super'
    && (string) $member['mb_id'] !== ''
    && (string) $member['mb_id'] === (string) $config['cf_admin']
    && (string) get_session('ss_mb_id') === (string) $member['mb_id'];
if (!$backup_authorized) {
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    exit('최고관리자로 로그인한 경우에만 DB 백업을 사용할 수 있습니다.');
}

header('Cache-Control: no-store');

function g5_backup_error(string $message, int $status = 400): void
{
    while (ob_get_level() > 0) ob_end_clean();
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
    }
    exit($message);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stored = get_session('ss_g5_db_download');
    $submitted = $_POST['backup_token'] ?? null;
    if (!is_array($stored) || !is_string($submitted) || !isset($stored['token'], $stored['time'])
        || time() - (int) $stored['time'] > 300 || time() < (int) $stored['time']
        || !hash_equals((string) $stored['token'], $submitted)) {
        g5_backup_error('요청이 만료되었거나 올바르지 않습니다. 백업 화면을 새로 열고 다시 시도해 주세요.', 403);
    }
    // Consume the token before doing any work; replaying a POST cannot start another dump.
    set_session('ss_g5_db_download', null);
    $format = $_POST['backup_format'] ?? 'sql';
    if (!is_string($format) || !in_array($format, array('sql', 'gz'), true)) g5_backup_error('지원하지 않는 파일 형식입니다.');
    if ($format === 'gz' && (!function_exists('deflate_init') || !function_exists('deflate_add'))) g5_backup_error('이 서버는 압축 다운로드를 지원하지 않습니다. SQL 형식을 선택해 주세요.');
    if (!isset($g5['connect_db']) || !($g5['connect_db'] instanceof mysqli) || !defined('G5_MYSQL_DB')) {
        g5_backup_error('mysqli DB 연결을 확인할 수 없습니다. 그누보드 DB 설정과 PHP 확장을 확인해 주세요.', 500);
    }
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    @set_time_limit(0);
    define('G5_DB_DOWNLOAD_RUNNING', true);
    require_once __DIR__.'/db_download.lib.php';
    $reference = bin2hex(random_bytes(6));
    $compression = null;
    $started = false;
    $writer = static function (string $chunk) use (&$compression): void {
        if ($compression !== null) {
            $chunk = deflate_add($compression, $chunk, ZLIB_NO_FLUSH);
            if ($chunk === false) throw new RuntimeException('Compression failed');
        }
        echo $chunk;
        if (connection_aborted()) throw new RuntimeException('Download disconnected');
    };
    try {
        $exporter = new G5DatabaseDownload($g5['connect_db'], $writer, G5_MYSQL_DB);
        $plan = $exporter->prepare();
        if ($format === 'gz') {
            $compression = deflate_init(ZLIB_ENCODING_GZIP, array('level' => 6));
            if ($compression === false) throw new RuntimeException('Compression unavailable');
        }
        while (ob_get_level() > 0) ob_end_clean();
        if (headers_sent()) throw new RuntimeException('Download headers already sent');
        @ini_set('zlib.output_compression', '0');
        @ini_set('display_errors', '0');
        $basename = preg_replace('/[^A-Za-z0-9_-]/', '_', (string) G5_MYSQL_DB);
        $filename = 'db-backup-'.substr($basename, 0, 60).'-'.date('Ymd_His').'.sql'.($format === 'gz' ? '.gz' : '');
        header('Content-Type: '.($format === 'gz' ? 'application/gzip' : 'application/sql; charset=utf-8'));
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: private, no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('X-Content-Type-Options: nosniff');
        $started = true;
        $exporter->export($plan);
        if ($compression !== null) {
            $tail = deflate_add($compression, '', ZLIB_FINISH);
            if ($tail === false) throw new RuntimeException('Compression failed');
            echo $tail;
        }
    } catch (Throwable $error) {
        error_log('[gnuboard.db_backup] ref='.$reference.'; type='.get_class($error).'; code='.(int) $error->getCode().'; line='.(int) $error->getLine());
        if (!$started) g5_backup_error('DB 백업 준비에 실패했습니다. 서버 오류 로그에서 참조번호 '.$reference.'를 확인해 주세요.', 500);
        // Mark a partial dump as unusable; never present it as a completed backup.
        try {
            $writer("\n-- BACKUP INCOMPLETE: ".$reference."\nSIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Incomplete backup: ".$reference."';\n");
            if ($compression !== null) {
                $tail = deflate_add($compression, '', ZLIB_FINISH);
                if ($tail !== false) echo $tail;
            }
        } catch (Throwable $ignored) {
        }
    }
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'GET') g5_backup_error('허용되지 않은 요청입니다.', 405);
$backup_token = bin2hex(random_bytes(32));
set_session('ss_g5_db_download', array('token' => $backup_token, 'time' => time()));
$g5['title'] = 'DB 백업 다운로드';
$sub_menu = '100990';
include_once G5_ADMIN_PATH.'/admin.head.php';
$backup_gzip = function_exists('deflate_init') && function_exists('deflate_add');
?>
<div class="local_desc01 local_desc">
    <p>현재 DB 설정에 연결된 데이터베이스의 모든 일반 테이블과 데이터, 조회 가능한 뷰·트리거를 내려받습니다.</p>
    <p>백업 파일은 서버에 저장하지 않습니다. 프로시저·함수·예약 이벤트와 업로드 이미지 등 실제 파일은 포함하지 않습니다.</p>
    <p>백업 중 등록·수정 작업을 줄여주세요. 특히 MyISAM 테이블은 백업 중 변경되면 데이터 시점이 서로 다를 수 있습니다.</p>
</div>
<form method="post" action="<?php echo htmlspecialchars(G5_ADMIN_URL.'/db_download.php', ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off">
    <input type="hidden" name="backup_token" value="<?php echo htmlspecialchars($backup_token, ENT_QUOTES, 'UTF-8'); ?>">
    <div class="tbl_frm01 tbl_wrap"><table><tbody>
    <tr><th scope="row">대상 DB</th><td><?php echo htmlspecialchars((string) G5_MYSQL_DB, ENT_QUOTES, 'UTF-8'); ?></td></tr>
    <tr><th scope="row"><label for="backup_format">파일 형식</label></th><td>
        <select name="backup_format" id="backup_format">
            <?php if ($backup_gzip) { ?><option value="gz">압축 SQL (.sql.gz)</option><?php } ?>
            <option value="sql">일반 SQL (.sql)</option>
        </select>
    </td></tr>
    </tbody></table></div>
    <div class="btn_fixed_top"><button type="submit" class="btn_submit btn">DB 백업 다운로드</button></div>
</form>
<?php include_once G5_ADMIN_PATH.'/admin.tail.php'; ?>
