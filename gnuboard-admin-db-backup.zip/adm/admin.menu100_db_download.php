<?php
if (!defined('_GNUBOARD_')) {
    http_response_code(403);
    exit;
}
if (isset($is_admin, $member['mb_id'], $config['cf_admin']) && $is_admin === 'super'
    && (string) $member['mb_id'] === (string) $config['cf_admin']
    && isset($menu['menu100']) && is_array($menu['menu100'])) {
    $backup_menu_exists = false;
    foreach ($menu['menu100'] as $backup_menu_item) {
        if (isset($backup_menu_item[0]) && $backup_menu_item[0] === '100990') $backup_menu_exists = true;
    }
    if (!$backup_menu_exists) {
        $menu['menu100'][] = array('100990', 'DB 백업 다운로드', G5_ADMIN_URL.'/db_download.php', 'db_download');
    }
}
