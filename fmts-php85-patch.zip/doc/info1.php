<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3>전체보기</h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
				<li><span class="vis_dep03">전체보기</span></li>
			</ul>
		</div>

<div id="pageCont" >


		<div id="tab01" class="tab01">             
			<?php include "../inc/tab_info1.php"; ?>
		</div>

		
<img src="/images/sub/homepage-on.png">
<img src="/images/sub/homepage-off.png">



<div id="infoSearch">
<div class="in-box">
	
	<div id="select-box">
			<div class="search-select">
				<select name="subject" class="select-style">
						<option value="">제목</option>
							<option value="subject1">제목</option>
							<option value="subject2">내용</option>
							<option value="subject3">글쓴이</option>
					</select>
			</div>
	</div>
	<div id="search-num">
			<input type="text" name="enter-sch" class="enter-sch" required="" placeholder="">
	</div>
	<div id="btn-box">
					<button type="submit" class="search_btn"><p>Search</p></button>
	</div>

</div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
