<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
    </div>


<div id="pageCont" class="ptd">

    <div class="ab1">
        <div class="top">
            <div class="img"></div>
            <h3>Future Automotive Conversion! <br>One-stop solution.</h3>
        </div>
        <div class="mid">
            <h4>지역기업 미래차 전환 지원 컨트롤 타워</h4>
            <h3>대구 미래차 전환 종합지원센터</h3>
            <div class="l-line"></div>
            <p>
                지역기업·기관의 역량 결집과 미래모빌리티 전자부품 산업 집중 육성을 위해 <br>
                속도감 있는 미래차 전환 지원을 통해 미래 모빌리티 신생태계 확대 및 협의체 연대 협력 강화에 앞장섭니다.
            </p>
        </div>
        <div class="i-t">
            <div class="img"><img src="/images/sub/ab1_img01.png" alt=""></div>
            <div class="txt">
                <h3>대구시 미래차전환 비전선포식 개최<br> 및 전환협의체 발족('22.1.5.)</h3>
                <ul>
                    <li><p>대구시, 대구시의회, 기업, 대학, 지원기관, 금융기관 등 18개 기관</p></li>
                    <li><p>지능형자동차부품진흥원 전담기관으로 미래차 전환 종합지원센터 구축 및 운영</p></li>
                </ul>
            </div>
        </div>
        <div class="ab-box">
            <div class="lt">
                <h3>운영목적</h3>
            </div>
            <div class="rt">
                <ul class="d_list">
                    <li>지역기업·기관의 역량 결집과 미래모빌리티 전장부품 산업 집중 육성을 위한 속도감 있는 미래차 전환 지원</li>
                    <li>미래 모빌리티 신생태계 확대 및 협의체 연대 협력 강화</li>
                    <li>산·학·연·관 협업 거점 구축</li>
                </ul>
            </div>
        </div>
        <div class="ab-box">
            <div class="lt">
                <h3>추진방향</h3>
            </div>
            <div class="rt">
                <ul class="b_list">
                    <li>
                        <h3>01</h3>
                        <h4>협업강화</h4>
                        <div class="w-line"></div>
                        <p>지원기관 연계 · 협력을 통해 <br>기업지원 시너지 창출</p>
                    </li>
                    <li>
                        <h3>02</h3>
                        <h4>소통강화</h4>
                        <div class="w-line"></div>
                        <p>對기업 소통강화를 통해 <br>기업 중심의 지원사업 추진</p>
                    </li>
                    <li>
                        <h3>03</h3>
                        <h4>선택과 집중</h4>
                        <div class="w-line"></div>
                        <p>유망기업 집중 지원으로 <br>미래차 유니콘 기업 육성</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="ab-box">
            <div class="lt">
                <h3>추진체계</h3>
            </div>
            <div class="rt">
                <div class="chart">
                    <div class="t"><h3>대구 미래차 전환 종합지원센터</h3></div>
                    <div class="m">
                        <div class="l_box">
                            <div class="gray"><p>중 앙 정 부 <br>사업재편 지원단</p></div>
                            <div class="line-box">
                                <h3>기업협의체</h3>
                                <div class="w-line"></div>
                                <p>미래차 전환 협력을 위한<br> 기업 소통 창구</p>
                            </div>
                        </div>
                        <div class="r_box">
                            <div class="line-box">
                                <h3>미래차 전환 지원 협의체</h3>
                                <div class="w-line"></div>
                                <p>대구시, 의회,<br> 유관기관</p>
                            </div>
                            <div class="line-box">
                                <ul>
                                    <li>연구기관</li>
                                    <li>지원기관</li>
                                    <li>대학</li>
                                    <li>금융기관</li>
                                    <li>이전공공기관</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="b">
                        <div class="l_box">
                            <div class="box">
                                <h3>기술개발 (R&amp;D)</h3>
                                <p>R&amp;D 과제 발굴<br> 애로기술 해소</p>
                            </div>
                            <div class="box no">
                                <h3>사업화</h3>
                                <p>개발기술 제품화,<br>사업화지원</p>
                            </div>
                            <div class="box">
                                <h3>창업</h3>
                                <p>창업 지원 및<br> 스타트업 육성</p>
                            </div>
                        </div>
                        <div class="r_box">
                            <div class="box">
                                <h3>판로개척</h3>
                                <p>국내외 판로개척, <br>공동 마케팅</p>
                            </div>
                            <div class="box no">
                                <h3>인력양성</h3>
                                <p>재직자 교육, <br>고급 전문인력 양성</p>
                            </div>
                            <div class="box">
                                <h3>금융지원</h3>
                                <p>전환 기반마련<br> 금융지원</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>




</div>
<?php include "../inc/bottom_250326.php"; ?>