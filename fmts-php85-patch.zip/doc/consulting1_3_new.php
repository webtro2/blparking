<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
        <div class="t_box">
            <ul class="tab">
                <li><a href="javascript:GoPage('consulting1')">애로사항 상담 <br class="mo">안내 및 프로세스</a></li>
                <li><a href="javascript:GoPage('consulting1_2')">신청서작성</a></li>
                <li class="on"><a href="javascript:GoPage('consulting1_3')">신청 처리 현황</a></li>
            </ul>
        </div>
    </div>


    <div id="pageCont" class="ptd">
        
    </div>
</div>





</div>
<?php include "../inc/bottom_250326.php"; ?>
