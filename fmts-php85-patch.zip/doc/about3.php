<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "3";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
    </div>


<div id="pageCont" class="ptd">

    <div class="ab3">
        <div class="mMap">
            <!-- * 카카오맵 - 지도퍼가기 -->
            <!-- 1. 지도 노드 -->
            <div id="daumRoughmapContainer1743147225573" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%"></div>

            <!--
                2. 설치 스크립트
                * 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
            -->
            <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

            <!-- 3. 실행 스크립트 -->
            <script charset="UTF-8">
                new daum.roughmap.Lander({
                    "timestamp" : "1743147225573",
                    "key" : "2nhwb",
                    "mapWidth" : "100%",
                    "mapHeight" : "500"
                }).render();
            </script>
        </div>
        <div class="cont">
            <div class="t-txt">
                <h3>대구 미래차 전환 종합지원센터<br/></h3>
            </div>
            <ul class="info">
                <li><i class="fa fa-map-marker" aria-hidden="true"></i><p>대구광역시 달성군 현풍읍 테크노공원로 16, 대구테크비즈센터 603호</p></li>
                <li><i class="fa fa-phone" aria-hidden="true"></i><p>053.670.4781</p></li>
                <li><i class="fa fa-fax" aria-hidden="true"></i><p>053.615.0201</p></li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i><p>dgfmts@gmail.com</p></li>
            </ul>
        </div>
        <ul class="go_m">
            <li><a href="https://naver.me/GpCWZKVd" target="_blank">네이버지도</a></li>
            <li><a href="https://kko.kakao.com/JCykuWsG5l" target="_blank">카카오맵</a></li>
        </ul>
	</div>
    <div class="ab-box">
        <div class="lt">
            <h3>주변정류장</h3>
        </div>
        <div class="rt">
            <ul class="bus">
                <li>포산서사거리1</li>
                <li>포산서사거리2</li>
                <li>LH천년나무2단지건너</li>
                <li>현풍경남은행앞</li>
                <li>LH천년나무2단지앞</li>
            </ul>
        </div>
    </div>
    <div class="ab-box">
        <div class="lt">
            <h3>주변버스</h3>
        </div>
        <div class="rt">
            <ul class="bus_c">
                <li class="b_green">달성5</li>
                <li class="b_red">급행8-1</li>
                <li class="b_red">급행8</li>
                <li class="b_blue">665</li>
            </ul>
        </div>
    </div>

</div>




</div>
<?php include "../inc/bottom_250326.php"; ?>
