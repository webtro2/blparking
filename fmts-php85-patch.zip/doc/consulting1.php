<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "1";
    $d_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
        <div class="t_box">
            <ul class="tab">
                <li class="on"><a>애로사항 상담 <br class="mo">안내 및 프로세스</a></li>
                <li><a href="javascript:GoPage('consulting1_2')">신청서작성</a></li>
                <li><a href="javascript:GoPage('consulting1_3')">신청 처리 현황</a></li>
            </ul>
        </div>
    </div>


    <div id="pageCont" class="ptd">
        <div class="ab-box mt50">
            <div class="lt">
                <h3>애로상담 <br class="br980">신청방법</h3>
            </div>
            <div class="rt">
                <ul class="b_list w100">
                    <li>
                        <h3>01</h3>
                        <h4>홈페이지 신청접수</h4>
                        <div class="w-line"></div>
                        <p>애로상담 신청서를 작성해주시면, 접수 내역 확인 후 지원기관/전문가가 답변을 남겨드립니다.<br>
                        신청 접수는 SNS/이메일을 통해 수신 드리며 답변 내용은 홈페이지를 통해 확인 하실 수 있습니다.</p>
                        <a href="javascript:GoPage('consulting1_2')">신 청 하 기</a>
                    </li>
                    <li>
                        <h3>02</h3>
                        <h4>카카오톡 상담톡</h4>
                        <div class="w-line"></div>
                        <p>카카오 채널을 이용하여 상담 신청을 해주시면, 홈페이지를 통한 신청 접수를 도와드립니다.<br>
                        카카오톡 채팅 검색창에서 [대구 미래차 전환 종합지원센터] 채널 추가</p>
                        <a href="javascript:GoPage('kakao')" target="_blank">상 담 하 기</a>
                    </li>
                    <li>
                        <h3>03</h3>
                        <h4>전화 및 방문 상담</h4>
                        <div class="w-line"></div>
                        <p>상담 전화를 이용하여 상담 신청을 해주시면, 홈페이지를 통한 신청 접수를 도와드립니다. <br>
                        센터 내방 또는 기업체 방문 상담이 필요한 경우, 접수내역 또는 SNS/이메일을 통해 방문 안내 드립니다.</p>
                        <a href="javascript:GoPage('about3')">찾아오시는 길</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="ab-box">
            <div class="lt">
                <h3>애로상담 <br class="br980">신청절차</h3>
            </div>
            <div class="rt">
                <ul class="process">
                    <li>
                        <h4>01</h4>
                        <h3>회원가입 및 로그인</h3>
                    </li>
                    <li>
                        <h4>02</h4>
                        <h3>기업애로 상담 신청접수</h3>
                    </li>
                    <li>
                        <h4>03</h4>
                        <h3>접수 내역 확인 및 전문가 매칭</h3>
                    </li>
                    <li>
                        <h4>04</h4>
                        <h3>기업맞춤형 애로 상담</h3>
                    </li>
                    <li>
                        <h4>05</h4>
                        <h3>상담 완료 및 추가 상담</h3>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>





</div>
<?php include "../inc/bottom_250326.php"; ?>
