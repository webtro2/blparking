<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
    </div>


    <div id="pageCont" class="ptd">

    <div class="info1_list">
        <ul>
            <li class="on">
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon01.png" alt=""></div>
                    <h3>전체보기</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon02.png" alt=""></div>
                    <h3>기술개발 지원 <br>(R&amp;D)</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon03.png" alt=""></div>
                    <h3>사업화 지원 <br>(비 R&amp;D)</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon04.png" alt=""></div>
                    <h3>창업지원</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon05.png" alt=""></div>
                    <h3>교육/채용 <br class="mo">지원</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon06.png" alt=""></div>
                    <h3>금융지원</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon07.png" alt=""></div>
                    <h3>장비/인프라 <br class="mo">지원</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <div class="img"><img src="/images/sub/info1_icon08.png" alt=""></div>
                    <h3>기타</h3>
                </a>
            </li>
        </ul>
    </div>

    </div>
</div>





</div>
<?php include "../inc/bottom_250326.php"; ?>
