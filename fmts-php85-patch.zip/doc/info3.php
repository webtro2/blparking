<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "3";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
    </div>


    <div id="pageCont" class="ptd">
    <div class="ab2">
        <div class="ab2_list">
            <div class="top b6"><h3>장비활용</h3><h4>Equipment Utilization</h4></div>
            <ul class="w5">
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo21.png" alt=""></div>
                    <a href="https://www.itube.or.kr/" target="_blank"> 사이트 바로가기</a>
                    <h3>산업기술개발장비공동이용시스템</h3>
                    <ul>
                        <li><p>공정별 R&amp;D 지원장비 정보</p></li>
                        <li><p class="ds">17개 R&amp;D 기관 구축 장비 활용 검색 서비스</p></li>
                        <li><p>R&amp;D 지원 패키지 서비스</p></li>
                        <li><p class="ds">업종, 품목별 시험/인증 관련 정보 제공</p></li>
                        <li><p>업종별 연구기반 서비스맵</p></li>
                        <li><p class="ds">업종, 종목별 유형화한 서비스 맵 제공</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo22.png" alt=""></div>
                    <a href="https://www.dris.or.kr/" target="_blank"> 사이트 바로가기</a>
                    <h3>대구 연구장비정보시스템</h3>
                    <ul>
                        <li><p>대구 지역 연구장비 예약 서비스</p></li>
                        <li><p class="ds">지역 연구장비 6,032점 등록</p></li>
                        <li><p>국가 연구장비 공동활용 서비스</p></li>
                        <li><p class="ds">공동활용장비 3,577점 등록</p></li>
                        <li><p>기관 기업지원 사업 정보 제공</p></li>
                        <li><p class="ds">등록기관 36개 기관</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo23.png" alt=""></div>
                    <a href="https://www.zeus.go.kr/main" target="_blank"> 사이트 바로가기</a>
                    <h3>장비활용종합포털</h3>
                    <ul>
                        <li><p>ZEUS 신규 서비스 및 정책, 뉴스 제공</p></li>
                        <li><p class="ds">연구시설관련 정책, 지원사업 제공</p></li>
                        <li><p>연구시설 및 연구장비 정보 제공</p></li>
                        <li><p class="ds">전체등록장비 84,001점</p></li>
                        <li><p>연구시설 장비교육 정보 제공</p></li>
                        <li><p class="ds">연구장비 운용 지식 및 교육 정보 제공</p></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="ab2_list">
            <div class="top b7"><h3>사업재편</h3><h4>Business Restructuring</h4></div>
            <ul class="w2">
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo24.png" alt=""></div>
                    <a href="https://biz.katech.re.kr/main/" target="_blank"> 사이트 바로가기</a>
                    <h3>미래차 전환 종합정보시스템</h3>
                    <ul>
                        <li><p>미래차 산업 정보 제공</p></li>
                        <li><p class="ds">미래차 전환 및 산업 관련 정부 정책, 동향 제공</p></li>
                        <li><p>기업지원사업 운영</p></li>
                        <li><p class="ds">구조진단, 기업수요발굴, 기업지원 사업 등</p></li>
                        <li><p>미래차 부품 전시장 운영</p></li>
                        <li><p class="ds">전기차 부품 전시 상시 운영</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo25.png" alt=""></div>
                    <a href="http://www.oneshot.or.kr/Service/main/appl/main.asp" target="_blank"> 사이트 바로가기</a>
                    <h3>사업재편종합지원센터</h3>
                    <ul>
                        <li><p>사업재편 기업수요 발굴 및 사전심사</p></li>
                        <li><p>사업재편 지원사업 운영 관리</p></li>
                        <li><p>산업동향 조사 및 분석 데이터 제공</p></li>
                    </ul>
                </li>
            </ul>
        </div>
        
        <div class="ab2_list">
            <div class="top b8"><h3>교육</h3><h4>Training</h4></div>
            <ul class="w5">
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo26.png" alt=""></div>
                    <a href="https://www.kapkorea.org/" target="_blank"> 사이트 바로가기</a>
                    <h3>자동차부품산업진흥재단</h3>
                    <ul>
                        <li><p>자동차 부품사 인재육성</p></li>
                        <li><p class="ds">품질학교, 기술학교, 경영 등</p></li>
                        <li><p>현장 방문교육 서비스</p></li>
                        <li><p class="ds">금속, 비금속 업종 기술 지도 및 경영 진단 등</p></li>
                        <li><p>업종별 기술 세미나</p></li>
                        <li><p class="ds">기술지도 중인 12개 업종에 대한 기초이론 교육 및 신기술 동향 세미나</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo27.png" alt=""></div>
                    <a href="http://hrd.sambomotors.com/" target="_blank"> 사이트 바로가기</a>
                    <h3>삼보모터스 기술연수원</h3>
                    <ul>
                        <li><p>대중소상생 공동훈련센터 운영</p></li>
                        <li><p class="ds">자동차부품 공정, 제조현장 생산관리 등 교육 프로그램 운영</p></li>
                        <li><p>산업전환 공동훈련센터 운영</p></li>
                        <li><p class="ds">전기자동차, 자율자동차 등 미래차 관련 교육 프로그램 운영</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo28.png" alt=""></div>
                    <a href="https://edu.hyundai-ngv.com/main/index.jsp" target="_blank"> 사이트 바로가기</a>
                    <h3>현대 NGV</h3>
                    <ul>
                        <li><p>지능형 자동차, 신에너지 자동차 등 미래차 관련 교육</p></li>
                        <li><p class="ds">지능형 자동차 4개 기술분야 9개 과정</p></li>
                        <li><p class="ds">신에너지 4개 기술분야 18개 과정</p></li>
                        <li><p>생산기술 교육</p></li>
                        <li><p class="ds">현대자동차 기반 생산기술 3개 과정</p></li>
                    </ul>
                </li>
            </ul>
        </div>

    </div>
</div>





</div>
<?php include "../inc/bottom_250326.php"; ?>
