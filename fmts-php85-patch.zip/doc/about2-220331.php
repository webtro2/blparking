<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "2";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->



<!-- 스타일 -->
<style>
#about2 {margin-top:2em; display:flex; flex-wrap:wrap; align-items: top; }
#about2 > div {width:calc(25% - 15px); margin-left:20px; margin-bottom:20px; text-align:center; border:1px solid #e9e9e9; box-sizing:border-box}
#about2 > div:nth-child(4n+1) { margin-left:0}
#about2 a .img {margin:10px; line-height:100px;}
#about2 a .img img {width:100%;  vertical-align:middle}
#about2 a .txt { height:56px; background: rgba(54, 99, 174, 0.04);}
#about2 a .txt .t1 {color:#222; line-height:1.3em; position:relative; top:50%;  transform:translateY(-50%)  }
#about2 a:hover .txt {background: #3663ae}
#about2 a:hover .txt .t1 {color:#FFF}
@media screen and (max-width:780px){	
	#about2 > div {width:calc(33.3333% - 13.3333px);}
	#about2 > div:nth-child(4n+1) { margin-left:20px}
	#about2 > div:nth-child(3n+1) { margin-left:0}
}
@media screen and (max-width:580px){	
	#about2 > div {width:calc(50% - 5px);  margin-left:10px; margin-bottom:10px;}
	#about2 > div:nth-child(4n+1), 
	#about2 > div:nth-child(3n+1) { margin-left:10px}
	#about2 > div:nth-child(2n+1) { margin-left:0}
}
@media screen and (max-width:430px){	
	#about2 > div {width:100%;  margin-left:0; }
	#about2 > div:nth-child(4n+1), 
	#about2 > div:nth-child(3n+1) { margin-left:0}
	#about2 a .img {margin:10px 20px; }
}


.about2-pop {display:none; background:rgba(0,0,0,0.3); width:100%; height:100%; z-index:9998;position:fixed; left:0; top:0}
.about2-pop .close {position:absolute; right:0; top:0; background:#222; padding:10px 15px; font-family:'Jost'; font-weight:600; color:#FFF; font-size:1.5em}
.about2-pop .in-pop {padding:3em; width:90%; max-width:700px; background:#FFF; text-align:center;
							position:fixed; top:20%; left:50%; margin-left:-350px;}
.about2-pop .in-pop .pop-img {padding:10px; border:1px solid #e9e9e9; width:90%; max-width:382px; margin:0 auto }
.about2-pop .in-pop .pop-img img {width:100%}
.about2-pop .in-pop h3 {margin:1.3em 0 0.5em; display:inline-block; padding:0 0.5em; font-size:2.0em; color:#222; line-height: 1.2em; font-family: 'DWImpactamin'; font-weight:normal;}
.about2-pop .in-pop .cont { padding:1em;  border-top:2px solid #eee; border-bottom:2px solid #eee; line-height:1.6em;}
.pop-btn {margin-top:2.5em; display:inline-block; border-radius:30px; background:#3663ae; padding:0.5em 1.5em 0.7em; line-height:1.2em;  text-align:center; color:#FFF}
.pop-btn:hover {background:#222}

@media screen and (max-width:780px){	
.about2-pop .in-pop {  left:5%; margin-left:0}
}
@media screen and (max-width:580px){	
	.about2-pop .close {font-size:1.0em;  }
	.about2-pop .in-pop h3 { font-size:1.5em; }
}
@media screen and (max-width:480px){	
.about2-pop .in-pop {top:15%; padding:2em 1.5em;}
.about2-pop .in-pop .pop-img {width:80%; }
}
</style>

<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

<div id="pageCont" >


	<div id="infoSearch">
		<div class="in-box">
			
			<div id="select-box">
					<div class="search-select">
						<select name="subject" class="select-style">
								<option value="">제목</option>
									<option value="subject1">제목</option>
									<option value="subject2">내용</option>
									<option value="subject3">글쓴이</option>
							</select>
					</div>
			</div>
			<div id="search-num">
					<input type="text" name="enter-sch" class="enter-sch" required="" placeholder="">
			</div>
			<div id="btn-box">
							<button type="submit" class="search_btn"><p>Search</p></button>
			</div>

		</div>
	</div> <!--  infoSearch -->




	<div id="about2">

		<!-- s -->
		<div>
		<a href="javascript:openModal('modal1');">
			<div class="img">
				<img src="/images/sub/about2-img1.png">
			</div>
			<div class="txt">
				<p class="t1">지능형자동차부품진흥원</p>
			</div>
		</a>
		</div>
		<!-- f -->

		<!-- s -->
		<div>
		<a href="javascript:openModal('modal2');">
			<div class="img">
				<img src="/images/sub/about2-img2.png">
			</div>
			<div class="txt">
				<p class="t1">한국전자통신연구원 대경권연구센터</p>
			</div>
		</a>
		</div>
		<!-- f -->

		<!-- s -->
		<div>
		<a href="javascript:openModal('modal3');">
			<div class="img">
				<img src="/images/sub/about2-img1.png">
			</div>
			<div class="txt">
				<p class="t1">지능형자동차부품진흥원</p>
			</div>
		</a>
		</div>
		<!-- f -->

		<!-- s -->
		<div>
		<a href="javascript:openModal('modal4');">
			<div class="img">
				<img src="/images/sub/about2-img1.png">
			</div>
			<div class="txt">
				<p class="t1">지능형자동차부품진흥원</p>
			</div>
		</a>
		</div>
		<!-- f -->

	</div> <!-- about2 -->


<div class="about2-pop modal1">
<div class="in-pop">
   <a href="#none" class="close">X</a>
   <div class="popCont">
		
		<div class="pop-img">
			<img src="/images/sub/about2-img1.png">
		</div>
		<h3>지능형자동차부품진흥원</h3>
		<div class="cont">
			차세대 자동차기술 개발 관련 부품업체 및 연구기관 지원 시험전문 기관(주행시험장 보유, 실차평가 및 시험 시설 인프라 구축, 기업지원)
		</div>
		<a href="http://www.kiapi.or.kr/" target="_blank" class="pop-btn">홈페이지 바로가기</a>
   </div>
</div>
</div>


<div class="about2-pop modal2">
<div class="in-pop">
   <a href="#none" class="close">X</a>
   <div class="popCont">
		
		<div class="pop-img">
			<img src="/images/sub/about2-img2.png">
		</div>
		<h3>한국자동차연구원 대구경북본부</h3>
		<div class="cont">
			2004년 국책연구기관으로 출범한 DGIST는 2011년 대학원 석박사 과정을 개설하고, 2014년 학부과정을 개설해 교육을 시작함.DGIST(대구경북과학기술원)는 첨단과학기술의 혁신을 선도할 고급과학기술인재를 양성하고 지역산업의 기술적 발전 및 경쟁력 향상을 위하여 지식기반산업 및 첨단과학분야를 연구개발하고 그 성과를 보급함으로써 지역균형발전과 국가과학기술발전에 이바지함을 목적으로 한다. 융합연구원 산하 미래자동차연구부는 전기차기반 자율주행차 핵심부품, 시스템 및 AI 자율주행기술을 연구함
		</div>
		<a href="http://www.kiapi.or.kr/" target="_blank" class="pop-btn">홈페이지 바로가기</a>
   </div>
</div>
</div>


<div class="about2-pop modal3">
<div class="in-pop">
   <a href="#none" class="close">X</a>
   <div class="popCont">
3333
   </div>
</div>
</div>


<div class="about2-pop modal4">
<div class="in-pop">
   <a href="#none" class="close">X</a>
   <div class="popCont">
4444
   </div>
</div>
</div>



<script>
function openModal(modalname) {
            document.get
            $("." + modalname).fadeIn(300);
        }

// 팝업 닫기
$('.about2-pop .close').click(function() {
            $('.about2-pop').fadeOut(300);
        });
    
</script>







</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>


