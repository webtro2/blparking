<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top_250326.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "2";
?>


<!-- visual -->
<?php include "../inc/s_visual_250327.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="inner2">

    <div id="s_Title">
        <ul class="subLoca">
            <li class="home"><img src="/images/sub/home.png" alt=""/></li>
            <li><span class="vis_dep01"></span></li>
            <li><span class="vis_dep02"></span></li>
        </ul>
        <h3><span class="vis_dep02"></span></h3>
    </div>


<div id="pageCont" class="ptd">
    <div class="ab2">
        <div class="ab2_list">
            <div class="top"><h3>행/재정 및 협력지원</h3><h4>Administration / Finance and Partnership Support</h4></div>
            <ul>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo01.png" alt=""></div>
                    <h3>대구시</h3>
                    <ul>
                        <li><p>미래차 전환 종합지원센터 및 협의체 운영 제반사항에 대한 행정적 지원</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo02.png" alt=""></div>
                    <h3>대구시의회</h3>
                    <ul>
                        <li><p>지역 부품기업의 성공적인 미래차 전환을 위한 재정적 지원</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo03.png" alt=""></div>
                    <h3>대구상공회의소</h3>
                    <ul>
                        <li><p>지자체 및 지원기관 협업을 통한 미래차 전환 정책 확산, 실태조사 공동 추진</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo04.png" alt=""></div>
                    <h3>지능형 자동차 부품 진흥원</h3>
                    <ul>
                        <li><p>대구 미래차 전환 종합지원센터 전담운영</p></li>
                        <li><p>미래차 전환을 위한 지역 기관 연계하여 밀착 지원</p></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="ab2_list">
            <div class="top b2"><h3>컨설팅 &amp; R&amp;D</h3><h4>Consulting and R&amp;D</h4></div>
            <ul>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo05.png" alt=""></div>
                    <h3>한국산업기술평가 관리원</h3>
                    <ul>
                        <li><p>지역상생컨설팅</p></li>
                        <li><p class="ds">지역기업 R&amp;D 자문 (애로기술해소), 지역기관 협업 등</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo06.png" alt=""></div>
                    <h3>한국자동차연구원 대경본부</h3>
                    <ul>
                        <li><p>전장/자율주행 R&amp;D</p></li>
                        <li><p class="ds">미래차 R&amp;D 과제 발굴, 국제표준 시험평가 지원, 산업현장 교육 프로그램 개발 등</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo07.png" alt=""></div>
                    <h3>한국생산기술연구원 대경본부</h3>
                    <ul>
                        <li><p>미래차 부품 제조기술 R&amp;D</p></li>
                        <li><p class="ds">미래차 핵심부품 개발사업 공동 기획 및 연구, 개발기술 확산</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo08.png" alt=""></div>
                    <h3>한국전자통신 연구원 대경권 연구센터</h3>
                    <ul>
                        <li><p>융합산업 R&amp;D</p></li>
                        <li><p class="ds">AI, 로봇, 자율주행 융합기술 기반 지역 부품기업 컨설팅, 미주센터 연계 해외 진출 지원</p></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="ab2_list">
            <div class="top b3"><h3>사업화, 판로개척, 창업</h3><h4>Business Development · Market Entry · Startups</h4></div>
            <ul class="w5">
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo04.png" alt=""></div>
                    <h3>지능형 자동차 부품 진흥원</h3>
                    <ul>
                        <li><p>사업화/시험평가 등</p></li>
                        <li><p class="ds">사업화 지원, 시험평가 지원, 인력양성, 네트워킹, 미래차 전환 정보 제공 등</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo09.png" alt=""></div>
                    <h3>대구테크노파크</h3>
                    <ul>
                        <li><p>사업화/판로개척</p></li>
                        <li><p class="ds">제품 사업화, 해외 판로개척, 유망기술 발굴 및 이전 지원, 펀드 투자, IR, IPO 지원 등</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo10.png" alt=""></div>
                    <h3>대구기계부품연구원</h3>
                    <ul>
                        <li><p>PM 기반 R&amp;BD</p></li>
                        <li><p class="ds">부품 국산화 기술개발, 사업회 지원, 해외 신흥시장 개척</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo11.png" alt=""></div>
                    <h3>대구디지털혁신진흥원</h3>
                    <ul>
                        <li><p>ICT/SW 융합</p></li>
                        <li><p class="ds">자동차부품기업-ICT/SW 기업 연계 사업화 및 마케팅 지원, ICT/SW 재직자 교육</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo12.png" alt=""></div>
                    <h3>대구창조경제혁신센터</h3>
                    <ul>
                        <li><p>창업/펀딩</p></li>
                        <li><p class="ds">미래차 스타업 창업 및 마케팅 지원, 투자유치 기회 제공</p></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="ab2_list">
            <div class="top b4"><h3>인력양성(R&amp;D 포함)</h3><h4>Workforce Development, including R&D</h4></div>
            <ul class="w5">
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo13.png" alt=""></div>
                    <h3>경북대학교</h3>
                    <ul>
                        <li><p>미래자동차 + IT 융합학과 연계 고급 R&amp;D 인력 양성</p></li>
                        <li><p>대학 보유 인적/물적 자원 연계 선도기술 개발 (자율주행SW, 전기차HW)</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo14.png" alt=""></div>
                    <h3>계명대학교</h3>
                    <ul>
                        <li><p>HuStar 혁신대학사업 (미래차 분야) 주관대학</p></li>
                        <li><p>현장 맞춤형 커리큘럼 개발 및 전문인력 양성</p></li>
                        <li><p>인력양성 연계 산학연 R&amp;D 프로젝트 발굴</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo15.png" alt=""></div>
                    <h3>대구경북과학기술원</h3>
                    <ul>
                        <li><p>미래자동차 분야 오픈 이노베이션 센터 연계 융합형 R&amp;D 과제 기획</p></li>
                        <li><p>SW 중심 제어/설계 전문인력 양성</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo16.png" alt=""></div>
                    <h3>영남이공대학교</h3>
                    <ul>
                        <li><p>미래차 검사, 정비 산업 중심의 서비스 인력 양성</p></li>
                        <li><p>미래차 전환기 대응 재직자 전환 교육 프로그램 개발 및 교육</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo17.png" alt=""></div>
                    <h3>영진전문대학교</h3>
                    <ul>
                        <li><p>지역의 중소/중견기업 협업을 통한 전장 분야 재직자 교육 프로그램 개발 및 인력 양성</p></li>
                        <li><p>미래차 배터리 관리시스템(BMS) 연구개발</p></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="ab2_list">
            <div class="top b5"><h3>정책금융 등</h3><h4>Policy Finance and Others</h4></div>
            <ul class="w3">
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo18.png" alt=""></div>
                    <h3>IM뱅크</h3>
                    <ul>
                        <li><p>지역 대표은행으로서 지역 금융기관 협업을 통한 미래차 전환 금융지원</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo19.png" alt=""></div>
                    <h3>대구신용보증재단</h3>
                    <ul>
                        <li><p>미래차 전환기에 대응하여 2/3차 협력사 자동차 부품 기업 중심의 금융지원</p></li>
                    </ul>
                </li>
                <li>
                    <div class="img"><img src="/images/sub/ab2_logo20.png" alt=""></div>
                    <h3>중소벤처기업진흥공단 대구지역본부</h3>
                    <ul>
                        <li><p>미래차 전환모색 및 스케일업을 위한 정책자금 지원(2백억원 목표)</p></li>
                        <li><p>지역산업 '구조혁신지원센터' 지정과 연계하여 미래차 전환 패키지 지원</p></li>
                        <img src="/images/sub/ab2_img01.png" alt="" class="pc">
                        <img src="/images/sub/ab2_img02.png" alt="" class="mo">
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>




</div>
<?php include "../inc/bottom_250326.php"; ?>
