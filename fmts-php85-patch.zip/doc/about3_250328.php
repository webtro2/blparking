<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "3";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

<div id="pageCont" >

		<div id="sMap">
			<!-- * 카카오맵 - 지도퍼가기 -->
<!-- 1. 지도 노드 -->
<div id="daumRoughmapContainer1694078866311" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%;"></div>

<!--
	2. 설치 스크립트
	* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
-->
<script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

<!-- 3. 실행 스크립트 -->
<script charset="UTF-8">
	new daum.roughmap.Lander({
		"timestamp" : "1694078866311",
		"key" : "2g54m",
		"mapHeight" : "100%"
	}).render();
</script>
		</div>

			<div id="sMap_info">
				<div class="tit">
					<h4>Location</h4>
					<p>지능형자동차부품진흥원 <br>미래차전환 종합지원센터</p>
				</div>
				<div class="txt">
					<p class="add"><i class="fa fa-map-marker" aria-hidden="true"></i>(43017) 대구시 달성군 현풍읍 테크노공원로 16, 테크비즈센터 603호</p>
					<p class="tel"><i class="fa fa-phone" aria-hidden="true"></i>053-615-7602</p>
					<p class="fax"><i class="fa fa-fax" aria-hidden="true"></i>053-615-7620</p>
					<p class="mail"><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:master@kiapi.or.kr">dgfmts@gmail.com</a></p>
				</div>
			</div>


</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>