<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3>애로사항 상담 안내 및 프로세스</h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
				<li><span class="vis_dep03">애로사항 상담 안내 및 프로세스</span></li>
			</ul>
		</div>

<div id="pageCont" >


 <div id="consulting1">
	<div class="consulting1-tit">
		<h3>애로상담 <span class="h3line">신청 방법</span></h3>
	</div>
	<ul class="counsel_box">
		<li>
			<div class="box">	
					<div class="boxWrap">
						<div class="in-box">
						<em>홈페이지 신청 접수</em>
						<div class="cont">
							<p>
								애로상담 신청서를 작성해주시면, 접수 내역 확인 후 지원기관/전문가가 답변을 남겨드립니다. <br>
								신청 접수는 SNS/이메일을 통해 수신 드리며 답변 내용은 홈페이지를 통해 확인 하실 수 있습니다.
							</p>
							<a href="javascript:GoPage('consulting1_2')" class="cs-btn">신청하기</a>
						</div>
						</div>
					</div>
			</div>
		</li>
		<li>
			<div class="box">	
					<div class="boxWrap">
						<div class="in-box">
						<em>카카오톡 상담톡</em>
						<div class="cont">
							<p>
								카카오 채널을 이용하여 상담 신청을 해주시면, 홈페이지를 통한 신청 접수를 도와드립니다.<br>
								카카오톡 채팅 검색창에서 [대구 미래차 전환 종합지원센터] 채널 추가
							</p>
							<a href="javascript:GoPage('kakao')" class="cs-btn">상담하기</a>
						</div>
						</div>
					</div>
			</div>
		</li>
		<li>
			<div class="box">	
				<div class="boxWrap">
						<div class="in-box">
						<em>전화 및 방문 상담</em>
						<div class="cont">
							<p>
								상담 전화를 이용하여 상담 신청을 해주시면, 홈페이지를 통한 신청 접수를 도와드립니다.<br>
								센터 내방 또는 기업체 방문 상담이 필요한 경우, 접수내역 또는 SNS/이메일을 통해 방문 안내 드립니다.
							</p>
							<a href="javascript:GoPage('about3')" class="cs-btn">찾아오시는 길</a>
						</div>
						</div>
					</div>
			</div>
		</li>
	</ul>
 </div>

<script>
	$(".counsel_box > li").bind("mouseenter focusin" , function(){
		$(".counsel_box > li").removeClass("active");
		$(this).addClass("active");
	});
	$(".counsel_box > li").bind("mouseleave focusout" , function(){
		$(".counsel_box > li").removeClass("active");
	});

	$(".counsel_box .btn").focus(function(){
		$(".counsel_box > li").removeClass("active");
		$(this).parent().parent().parent().addClass("active");
	});
	$(".counsel_box .btn").focusout(function(){
		$(this).parent().parent().parent().removeClass("active");
	});
</script>




<div id="consulting1-2">
	<div class="consulting1-tit">
		<h3>애로상담 <span class="h3line">신청 절차</span></h3>
	</div>
	<div class="img pc">
		<img src="/images/sub/consulting1-2-img.png">
	</div>
	<div class="img mo">
		<img src="/images/sub/consulting1-2-img-mo.png">
	</div>
</div>





</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>