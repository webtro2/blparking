<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php 
$g5_path = "../pg"; // common.php 의 상대 경로
include_once("$g5_path/common.php");
?>