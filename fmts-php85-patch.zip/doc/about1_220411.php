<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

<div id="pageCont" >



			<div id="about1_top">				
			</div>
			<div id="about1_top_txt">	
				<h3>지역기업 미래차 전환 지원 컨트롤타워<p class="t1">미래차 종합지원센터</p></h3>
				<p class="eng">Future Automotive Conversion! One-stop solution.</p>
			</div>

			<div class="twWrap bg1">
					<div class="twCont about1-1">
						<dl class="tw-cont">
							<dt>운영목적</dt>
							<dd>
								<ul class="dotList">
									<li><p>지역기업·기관의 역량 결집과 미래모빌리티 전장부품 산업 집중 육성을 위한 속도감 있는 미래차 전환 지원</p></li>
									<li><p>미래 모빌리티 신생태계 확대 및 협의체 연대 협력 강화</p></li>
									<li><p>산·학·연·관 협업 거점 구축</p></li>
								</ul>
							</dd>
						</dl>
					</div>
					<div class="twCont about1-2">
						<dl class="tw-cont">
							<dt>지원내용</dt>
							<dd>
								<ul class="dotList">
									<li><p>미래차 전환 과정에서 발생하는 다양한 기업 수요에 대한 원스톱 지원 및 양질의 서비스 제공</p></li>
									<li><p>미래차 선도기술 개발 지원</p></li>
									<li><p>미래 모빌리티 신생태계 확대 및 협의체 연대 협력 강화</p></li>
								</ul>
							</dd>
						</dl>
					</div>					
			</div>




<div class="s-part">		
	<div id="about1-3">	</div>
</div>



			<div class="s-tit">
				<h3>지원상세</h3>
			</div>
			<div class="dl-table">				
					<dl>
						<dt>R&D</dt>
						<dd>미래차 관련 과제 발굴 등 지원</dd>
					</dl>	
					<dl>
						<dt>컨설팅</dt>
						<dd>미래차 전환 관련 컨설팅 지원</dd>
					</dl>	
					<dl>
						<dt>사업화</dt>
						<dd>시제품 제작, 시험/평가/인증, 비R&D 지원</dd>
					</dl>	
					<dl>
						<dt>인력양성</dt>
						<dd>지역대학 연계 전문 인력 양성 및 재직자 교육·채용 연계 지원</dd>
					</dl>	
					<dl>
						<dt>금융지원</dt>
						<dd>설비투자·기술개발 자금 등 기업 대출상담 및 금융기관 후속 지원</dd>
					</dl>	
					<dl>
						<dt>창업</dt>
						<dd>창업 교육, 아이디어 고도화 지원 등 창업 지원</dd>
					</dl>	
					<dl>
						<dt>판로개척</dt>
						<dd>지역기업 제품의 국·내외 판로개척 및 해외 공동마케팅 지원</dd>
					</dl>	
					<dl>
						<dt>협의체</dt>
						<dd>기업 애로사항·요구사항 청취, 정부과제 공모 등 정보 제공</dd>
					</dl>	
			</div>



</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
