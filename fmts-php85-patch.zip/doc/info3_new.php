<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "3";
?>

<div class="s_visual">
	<div class="s_visual_in">
		<div class="sv_tit">
			<h2 data-aos="fade-up" data-aos-delay="300"><span>유용사이트</span></h2>
			<p class="txt" data-aos="fade-up" data-aos-delay="500"><span>미래차 산업의 새로운 길을 개척해 나갑니다.</span></p>
		</div>
	</div>
</div>
<!-- 적용시 변경필요 -->

<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep02"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb2.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb2.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

    <div id="pageCont" >
        <div class="site-box">
            <h2>장비활용</h2>
            <ul>
                <li>
                    <a href="https://www.itube.or.kr/" target="_blank">
                        <div class="txt-t" style="background-color:#FF6D60;">
                            <p class="name">산업기술개발장비공동이용시스템</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img1.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> itube.or.kr</p>
                            <p class="c1">• 공정별 R&D 지원장비 정보</p>
                            <p class="c2">- 17개 R&D 기관 구축 장비 활용 검색 서비스</p>
                            <p class="c1">• R&D 지원 패키지 서비스</p>
                            <p class="c2">- 업종, 품목별 시험/인증 관련 정보 제공</p>
                            <p class="c1">• 업종별 연구기반 서비스맵</p>
                            <p class="c2">- 업종, 품목별 유형화한 서비스 맵 제공</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.dris.or.kr/" target="_blank">
                        <div class="txt-t" style="background-color:#F7D060;">
                            <p class="name">대구 연구장비정보시스템</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img2.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> dris.or.kr</p>
                            <p class="c1">• 대구 지역 연구장비 예약 서비스</p>
                            <p class="c2">- 지역 연구장비 6,032점 등록</p>
                            <p class="c1">• 국가 연구장비 공동활용 서비스</p>
                            <p class="c2">- 공동활용장비 3,577점 등록</p>
                            <p class="c1">• 기관 기업지원 사업 정보 제공</p>
                            <p class="c2">- 등록기관 36개 기관</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.zeus.go.kr/" target="_blank">
                        <div class="txt-t" style="background-color:#95BDFF;">
                            <p class="name">장비활용종합포털</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img3.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> zeus.go.kr</p>
                            <p class="c1">• ZEUS 신규 서비스 및 정책,뉴스 제공</p>
                            <p class="c2">- 연구시설관련 정책, 지원사업 제공</p>
                            <p class="c1">• 연구시설 및 연구장비 정보 제공</p>
                            <p class="c2">- 전체등록장비 84,001점</p>
                            <p class="c1">• 연구시설 장비교육 정보 제공</p>
                            <p class="c2">- 연구장비 운용 지식 및 교육 정보 제공</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>

        <div class="site-box2 mt30">
            <h2>사업재편</h2>
            <ul>
                <li>
                    <a href="https://transform-katech.re.kr/" target="_blank">
                        <div class="txt-t" style="background-color:#7743DB;">
                            <p class="name">미래차 전환 종합정보시스템</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img4.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> transform-katech.re.kr</p>
                            <p class="c1">• 미래차 산업 정보 제공</p>
                            <p class="c2">- 미래차 전환 및 산업 관련 정부 정책, 동향 제공</p>
                            <p class="c1">• 기업지원사업 운영</p>
                            <p class="c2">- 구조진단, 기업수요발굴, 기업지원 사업 등</p>
                            <p class="c1">• 미래차 부품 전시장 운영</p>
                            <p class="c2">- 전기차 부품 전시 상시 운영</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="http://www.oneshot.or.kr/" target="_blank">
                        <div class="txt-t" style="background-color:#277BC0;">
                            <p class="name">사업재편종합지원센터</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img5.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> oneshot.or.kr</p>
                            <p class="c1">• 사업재편 기업수요 발굴 및 사전심사</p>
                            <p class="c2"></p>
                            <p class="c1">• 사업재편 지원사업 운영 관리</p>
                            <p class="c2"></p>
                            <p class="c1">• 산업동향 조사 및 분석 데이터 제공</p>
                            <p class="c2"></p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>

        <div class="site-box mt30">
            <h2 style="background-color:#0A6EBD;">교육</h2>
            <ul>
                <li>
                    <a href="http://www.kapkorea.org/" target="_blank">
                        <div class="txt-t" style="background-color:#65C18C;">
                            <p class="name">자동차부품산업진흥재단</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img6.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> kapkorea.org</p>
                            <p class="c1">• 자동차 부품사 인재육성</p>
                            <p class="c2">- 품질학교, 기술학교, 경영 등</p>
                            <p class="c1">• 현장 방문교육 서비스</p>
                            <p class="c2">- 금속, 비금속 업종 기술 지도 및 경영 진단 등</p>
                            <p class="c1">• 업종별 기술 세미나</p>
                            <p class="c2">- 기술지도 중인 12개 업종에 대하 기초이론 교육 및 신기술 동향 세미나</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="http://hrd.sambomotors.com/" target="_blank"> 
                        <div class="txt-t" style="background-color:#DD4A48;">
                            <p class="name">삼보모터스 기술연수원</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img7.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> hrd.sambomotors.com</p>
                            <p class="c1">• 대중소상생 공동훈련센터 운영</p>
                            <p class="c2">- 자동차부품 공정, 제조현장 생산관리 등 교육 프로그램 운영</p>
                            <p class="c1">• 산업전환 공동훈련센터 운영</p>
                            <p class="c2">- 전기자동차, 자율자동차 등 미래차 관련 교육 프로그램 운영</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://edu.hyundai-ngv.com/main/index.jsp" target="_blank">
                        <div class="txt-t" style="background-color:#D47AE8;">
                            <p class="name">현대 NGV</p>
                        </div>
                        <div class="txt-c">
                            <div class="img">
                                <img src="/images/sub/intro3_img8.png" alt="">
                            </div>
                            <p class="ad"><i class="fa fa-link" aria-hidden="true"></i> edu.hyundai-ngv.com</p>
                            <p class="c1">• 지능형자동차, 신에너지 자동차 등 미래차 관련 교육</p>
                            <p class="c2">- 지능형자동차 4개 기술분야 9개 과정</p>
                            <p class="c2">- 신에너지 4개 기술분야 18개 과정</p>
                            <p class="c1">• 생산기술 교육</p>
                            <p class="c2">- 현대자동차 기반 생산기술 3개 과정</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>



    </div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>