<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "2";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

<div id="pageCont" >


	<div id="info2-view">	
		<div class="v-img">
			<img src="/images/sub/info2-v-logo.png">
		</div>	
			
		<h3 class="vTitle">한국전자통신연구원 대경권연구센터</h3>
		
		<div class="v-cont">
			<ul>		
				<li>
					<dl>
						<dt>기관명</dt>
						<dd>
							<p>한국전자통신연구원 대경권연구센터</p>
						</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>주소</dt>
						<dd>
							<p>대구광역시 달성군 유가읍 테크노순환로 10길1</p>
						</dd>
					</dl>
				</li>
			</ul>
			<ul class="w50">		
				<li>
					<dl>
						<dt>전화번호</dt>
						<dd>
							<p>053-670-8000</p>
						</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>홈페이지</dt>
						<dd>
							<a href="https://www.etri.re.kr/" target="_blank"><p>www.etri.re.kr</p></a>
						</dd>
					</dl>
				</li>				
			</ul>
			<ul>
				<li>
					<dl>
						<dt>지원분야</dt>
						<dd>
							<p>R&D 공동연구, R&D 기술 지원</p>
						</dd>
					</dl>
				</li>
				<li class="bb0">
					<dl>
						<dt>기관소개</dt>
						<dd>
							<p class="t2">국가의 신가치 창출, 산업경쟁력 강화, 신시장 개척 등의 국가의 국력신장에 이바지하기 위하여 설립되었으며 이를 위하여 정보통신을 포함한 광범위한 디지털혁신 기술을 연구개발하는 기관</p>
						</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
