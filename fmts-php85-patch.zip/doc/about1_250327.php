<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

<div id="pageCont" >



			<div id="about1_top">				
			</div>
			<div id="about1_top_txt">	
				<h3>지역기업 미래차 전환 지원 컨트롤타워<p class="t1">미래차 종합지원센터</p></h3>
				<p class="eng">Future Automotive Conversion! One-stop solution.</p>
			</div>


			<div id="about1-5">
				<div class="img">
					<img src="/images/sub/about1-5-img.png">
				</div>
				<div class="cont">
					<div class="in-box">
						<h4>대구시 미래차전환 비전선포식 개최 및 전환협의체 발족(’22.1.5.)</h4>
						<ul class="dotList">
							<li><p>대구시, 대구시의회, 기업, 대학, 지원기관, 금융기관 등 18개 기관 </p></li>
							<li><p>지능형자동차부품진흥원 전담기관으로 미래차 전환 종합지원센터  구축 및 운영</p></li>
						</ul>
					</div>
				</div>
			</div>




			<div class="twWrap bg1">
					<div class="twCont about1-1">
						<dl class="tw-cont">
							<dt>운영목적</dt>
							<dd>
								<ul class="dotList">
									<li><p>지역기업·기관의 역량 결집과 미래모빌리티 전장부품 산업 집중 육성을 위한 속도감 있는 미래차 전환 지원</p></li>
									<li><p>미래 모빌리티 신생태계 확대 및 협의체 연대 협력 강화</p></li>
									<li><p>산·학·연·관 협업 거점 구축</p></li>
								</ul>
							</dd>
						</dl>
					</div>
					<div class="twCont about1-2">
						<dl class="tw-cont">
							<dt>추진방향</dt>
							<dd>
								<ul class="dotList">
									<li><p>(협업강화) 지원기관 연계･협력을 통해 기업지원 시너지 창출</p></li>
									<li><p>(소통강화) 對기업 소통강화를 통해 기업 중심의 지원사업 추진</p></li>
									<li><p>(선택과 집중) 유망기업 집중 지원으로 미래차 유니콘 기업 육성</p></li>
								</ul>
							</dd>
						</dl>
					</div>					
			</div>




<div class="s-part mb0">	
	<div class="s-tit center">
		<h3 class="mb30">추진체계</h3>
	</div>
	<div id="about1-6">	</div>
</div>




</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
