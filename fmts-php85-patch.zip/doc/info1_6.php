<?php require_once(__DIR__ . '/../pg/common.php'); ?>
<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "1";
?>


<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include "../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include "../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include "../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3>금융지원</h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
				<li><span class="vis_dep03">금융지원</span></li>
			</ul>
		</div>

<div id="pageCont" >

		<div id="tab01" class="tab06">             
			<?php include "../inc/tab_info1.php"; ?>
		</div>

준비중


</div>

</div>
</div>
<?php include "../inc/bottom.php"; ?>
