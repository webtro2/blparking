<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH.'/head.sub.boa.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

$login = "/pg/bbs/login.php";		// 로그인
$logout = "/pg/bbs/logout.php";		// 로그아웃
$join = "/pg/bbs/register.php";		// 회원가입
$join1 = "/pg/bbs/register_form.php";		// 회원가입
$join2 = "/pg/bbs/register_result.php";		// 회원가입
$mypage = "/pg/bbs/member_mypage.php";		// 마이페이지
$modify = "/pg/bbs/member_confirm.php?url=register_form.php";		// 정보수정
$idpw = "/pg/bbs/password_lost.php";		// 아이디/비밀번호찾기
$leave = "/pg/bbs/member_confirm.php?url=member_leave.php";		// 회원탈퇴

$mstr = $_SERVER["SCRIPT_NAME"]."?".$_SERVER["QUERY_STRING"];
if (trim($_SERVER["QUERY_STRING"]) == "") $mstr = $_SERVER["SCRIPT_NAME"];	

$s_num = "";
$p_num = "";
$t_num = "";

if($bo_table == "about2"){
	$s_num = "1";
	$p_num = "2";
}elseif($bo_table == "info1"){
	$s_num = "2";
	$p_num = "1";
	$t_num = "1";
	}elseif($sca=="기술개발지원"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "2";
	}elseif($bo_table == "info1" && $sca=="사업화지원"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "3";
	}elseif($bo_table == "info1" && $sca=="창업지원"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "4";
	}elseif($bo_table == "info1" && $sca=="인력채용지원"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "5";
	}elseif($bo_table == "info1" && $sca=="금융지원"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "6";
	}elseif($bo_table == "info1" && $sca=="장비인프라지원"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "7";
	}elseif($bo_table == "info1" && $sca=="기타"){
		$s_num = "2";
		$p_num = "1";
		$t_num = "8";
}elseif($bo_table == "info2"){
	$s_num = "2";
	$p_num = "2";
}elseif($bo_table == "consulting1_2"){
	$s_num = "3";
	$p_num = "1";
}elseif($bo_table == "comm1"){
	$s_num = "4";
	$p_num = "1";
}elseif($bo_table == "comm2"){
	$s_num = "4";
	$p_num = "2";
}elseif($bo_table == "comm3"){
	$s_num = "4";
	$p_num = "3";

} else if($mstr == $join) {
	$s_num = "5";
	$p_num = "3";
}else if($mstr == $join1 && $w == "u") {
	$s_num = "5";
	$p_num = "3";
}else if($mstr == $join1) {
	$s_num = "5";
	$p_num = "4";
}else if($mstr == $join2) {
	$s_num = "5";
	$p_num = "4";
}else if($mstr == $modify) {
	$s_num = "5";
	$p_num = "4";
}else if($mstr == $leave) {
	$s_num = "5";
	$p_num = "3";

}
?>


<?php include __DIR__ . "/../inc/head.php"; ?>
<?php include __DIR__ . "/../inc/link.php"; ?>
<?php include __DIR__ . "/../inc/top.php"; ?>

<!-- visual -->
<?php include __DIR__ . "/../inc/s_visual.php"; ?>
<!-- END visual -->


<!-- Sub Content -->
<div id="subContent" class="s-inner">

	<div id="s_gnb">
		<div class="s_depth1 s_depth">
			<h2 class="deptit"><span class="vis_dep01"></span></h2>
			<div class="hide"><?php  include __DIR__ . "/../inc/s_gnb0.php" ?></div>
		</div>
		<div class="s_depth2 s_depth">
			<div class="deptit"><span class="vis_dep02"></span></div>
			<?php  include __DIR__ . "/../inc/s_gnb$s_num.php" ?>
		</div>
		<?php include __DIR__ . "/../inc/left_cs.php"; ?>
	</div>


<div id="pageWrap">

		<div id="subTitle">
			<h3><span class="vis_dep02"></span></h3>
			<ul class="subLoca">
				<li class="home"><img src="/images/sub/ico_home.png" alt=""/></li>
				<li><span class="vis_dep01"></span></li>
				<li><span class="vis_dep02"></span></li>
			</ul>
		</div>

<div id="pageCont" >

<?php if ($bo_table == "info1"){?>
		<div id="tab01" class="tab0<?php if ($sca=="기술개발지원"){?>2<?php }elseif ($sca=="사업화지원"){?>3<?php }elseif ($sca=="창업지원"){?>4<?php }elseif ($sca=="인력채용지원"){?>5<?php }elseif ($sca=="교육채용지원"){?>5<?php }elseif ($sca=="금융지원"){?>6<?php }elseif ($sca=="장비인프라지원"){?>7<?php }elseif ($sca=="기타"){?>8<?php }else{?>1<?php }?>">             
			<?php include __DIR__ . "/../inc/tab_info1.php"; ?>
		</div>
<?php }?>