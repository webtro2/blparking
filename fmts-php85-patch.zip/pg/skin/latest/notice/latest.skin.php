<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$latest_skin_url.'/style.css">', 0);
add_javascript('<script src="'.G5_JS_URL.'/jquery.bxslider.js"></script>', 10);
$list_count = (is_array($list) && $list) ? count($list) : 0;
?>


    <?php for ($i=0; $i<count($list); $i++) {  ?>
	<?php if($i == "0"){?>

				<li class="bb-dotted">
					<a href="<?php echo $list[$i]['href'] ?>">				
					  <div class="dateBox"><span><?=date("d", strtotime($list[$i]['wr_datetime']))?></span><?=date("y.m", strtotime($list[$i]['wr_datetime']))?></div>
					  <div class="txt2">
						<h4><?php  echo $list[$i]['subject'];	?></h4>
						<p class="t1">​<?=cut_str(strip_tags($list[$i]['wr_content'], ""),"150","..")?></p>
					  </div>
				</a>
			  </li>

	  <?php }else{?>

			  <li>
				<a href="<?php echo $list[$i]['href'] ?>">
				  <div class="txt dot"><p><?php  echo $list[$i]['subject'];	?></p></div>
				  <div class="date"><?=date("y.m.d", strtotime($list[$i]['wr_datetime']))?></div>
				</a>
			  </li>

	<?php }?>
    <?php }  ?>
    <?php if (count($list) == 0) { //게시물이 없을 때  ?>
    <li class="empty_li">게시물이 없습니다.</li>
    <?php }  ?>

