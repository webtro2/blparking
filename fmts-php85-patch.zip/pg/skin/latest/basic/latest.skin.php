<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$latest_skin_url.'/style.css">', 0);
$list_count = (is_array($list) && $list) ? count($list) : 0;
?>





    <?php for ($i=0; $i<$list_count; $i++) {  ?>

				<li>
				<a href="<?php echo $list[$i]['href'] ?>">
				  <div class="txt dot"><p><?php  echo $list[$i]['subject'];	?></p></div>
				  <div class="date"><?=date("y.m.d", strtotime($list[$i]['wr_datetime']))?></div>
				</a>
			  </li>

    <?php }  ?>
    <?php if ($list_count == 0) { //게시물이 없을 때  ?>
    <li class="empty_li">게시물이 없습니다.</li>
    <?php }  ?>
