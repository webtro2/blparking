<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$write = isset($write) && is_array($write) ? $write : array();
$write += array('wr_datetime' => '');
$write += array_fill_keys(array_map(static function ($n) { return 'wr_' . $n; }, range(1, 10)), '');
foreach (range(1, 10) as $fmts_field_no) {
    $fmts_field = 'wr_' . $fmts_field_no;
    if (!isset($$fmts_field)) $$fmts_field = $write[$fmts_field];
}


// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$board_skin_url.'/style.css">', 0);
?>

<section id="bo_w">
    <h2 class="sound_only"><?php echo $g5['title'] ?></h2>

    <!-- 게시물 작성/수정 시작 { -->
    <form name="fwrite" id="fwrite" action="<?php echo $action_url ?>" onsubmit="return fwrite_submit(this);" method="post" enctype="multipart/form-data" autocomplete="off" style="width:<?php echo $width; ?>">
    <input type="hidden" name="uid" value="<?php echo get_uniqid(); ?>">
    <input type="hidden" name="w" value="<?php echo $w ?>">
    <input type="hidden" name="bo_table" value="<?php echo $bo_table ?>">
    <input type="hidden" name="wr_id" value="<?php echo $wr_id ?>">
    <input type="hidden" name="sca" value="<?php echo $sca ?>">
    <input type="hidden" name="sfl" value="<?php echo $sfl ?>">
    <input type="hidden" name="stx" value="<?php echo $stx ?>">
    <input type="hidden" name="spt" value="<?php echo $spt ?>">
    <input type="hidden" name="sst" value="<?php echo $sst ?>">
    <input type="hidden" name="sod" value="<?php echo $sod ?>">
    <input type="hidden" name="page" value="<?php echo $page ?>">
    <?php
    $option = '';
    $option_hidden = '';
    if ($is_notice || $is_html || $is_secret || $is_mail) { 
        $option = '';
        if ($is_notice) {
            $option .= PHP_EOL.'<li class="chk_box"><input type="checkbox" id="notice" name="notice"  class="selec_chk" value="1" '.$notice_checked.'>'.PHP_EOL.'<label for="notice"><span></span>공지</label></li>';
        }
        if ($is_html) {
            if ($is_dhtml_editor) {
                $option_hidden .= '<input type="hidden" value="html1" name="html">';
            } else {
                $option .= PHP_EOL.'<li class="chk_box"><input type="checkbox" id="html" name="html" onclick="html_auto_br(this);" class="selec_chk" value="'.$html_value.'" '.$html_checked.'>'.PHP_EOL.'<label for="html"><span></span>html</label></li>';
            }
        }
        if ($is_secret) {
            if ($is_admin || $is_secret==1) {
                $option .= PHP_EOL.'<li class="chk_box"><input type="checkbox" id="secret" name="secret"  class="selec_chk" value="secret" '.$secret_checked.'>'.PHP_EOL.'<label for="secret"><span></span>비밀글</label></li>';
            } else {
                $option_hidden .= '<input type="hidden" name="secret" value="secret">';
            }
        }
        if ($is_mail) {
            $option .= PHP_EOL.'<li class="chk_box"><input type="checkbox" id="mail" name="mail"  class="selec_chk" value="mail" '.$recv_email_checked.'>'.PHP_EOL.'<label for="mail"><span></span>답변메일받기</label></li>';
        }
    }
    echo $option_hidden;
    ?>




		<div id="pageCont" >


			<h4 class="stit3">기업지원 사업 등록</h4>
			<table class="tb-style2 tb-write mob">
				<tr>
					<th><label class="wr_label">분야</label></th>
					<td><input type="text" name="wr_4" value="<?php echo $wr_4 ?>" id="wr_4" class="wr_input">
						<!-- <?php if ($is_category) { ?>
						<div class="bo_w_select write_div">
							<label for="ca_name" class="sound_only">분류<strong>필수</strong></label>
							<select name="ca_name" id="ca_name" required>
								<option value="">분류를 선택하세요</option>
								<?php echo $category_option ?>
							</select>
						</div>
						<?php } ?> -->
					</td>
					<th><label class="wr_label">기관명</label></th>
					<td><input type="text" name="wr_subject" value="<?php echo $subject ?>" required id="wr_subject" class="wr_input required"></td>
				</tr>
				<tr>
					<th><label class="wr_label">주소</label></th>
					<td colspan="3"><input type="text" name="wr_1" value="<?php echo $wr_1 ?>" id="wr_1" class="wr_input"></td>
				</tr>
				<!-- <tr>
					<th><label class="wr_label">날짜</label></th>
					<td colspan="3"><input type='text' class="wr_input" style="width:32%;" name='wr_datetime' itemname='순서' value='<?=$write["wr_datetime"]?>' > 2021-01-01 11:35:19 양식에 맞게 넣어주세요.</td>
				</tr> -->
				<tr>
					<th><label class="wr_label">전화번호</label></th>
					<td><input type="text" name="wr_2" value="<?php echo $wr_2 ?>" id="wr_2" class="wr_input"></td>
					<th><label class="wr_label">홈페이지</label></th>
					<td><input type="text" name="wr_3" value="<?php echo $wr_3 ?>" id="wr_3" class="wr_input" placeholder="http:// 빼고 입력"></td>
				</tr>
				<tr class="row5">
					<th><label class="wr_label">기관소개</label></th>
					<td colspan="3">
					<?php if($write_min || $write_max) { ?>
					<!-- 최소/최대 글자 수 사용 시 -->
					<p id="char_count_desc">이 게시판은 최소 <strong><?php echo $write_min; ?></strong>글자 이상, 최대 <strong><?php echo $write_max; ?></strong>글자 이하까지 글을 쓰실 수 있습니다.</p>
					<?php } ?>
					<?php echo $editor_html; // 에디터 사용시는 에디터로, 아니면 textarea 로 노출 ?>
					<?php if($write_min || $write_max) { ?>
					<!-- 최소/최대 글자 수 사용 시 -->
					<div id="char_count_wrap"><span id="char_count"></span>글자</div>
					<?php } ?>
					</td>
				</tr>
				<tr>
					<th><label class="wr_label">첨부파일</label></th>
					<td colspan="3">
					<?php for ($i=0; $is_file && $i<$file_count; $i++) { ?>
					<div class="bo_w_flie write_div">
						<div class="file_wr write_div">
							<label for="bf_file_<?php echo $i+1 ?>" class="lb_icon"><i class="fa fa-folder-open" aria-hidden="true"></i><span class="sound_only"> 파일 #<?php echo $i+1 ?></span></label>
							<input type="file" name="bf_file[]" id="bf_file_<?php echo $i+1 ?>" title="파일첨부 <?php echo $i+1 ?> : 용량 <?php echo $upload_max_filesize ?> 이하만 업로드 가능" class="frm_file ">
						</div>
						<?php if ($is_file_content) { ?>
						<input type="text" name="bf_content[]" value="<?php echo ($w == 'u') ? $file[$i]['bf_content'] : ''; ?>" title="파일 설명을 입력해주세요." class="full_input frm_input" size="50" placeholder="파일 설명을 입력해주세요.">
						<?php } ?>

						<?php if($w == 'u' && $file[$i]['file']) { ?>
						<span class="file_del">
							<input type="checkbox" id="bf_file_del<?php echo $i ?>" name="bf_file_del[<?php echo $i;  ?>]" value="1"> <label for="bf_file_del<?php echo $i ?>"><?php echo $file[$i]['source'].'('.$file[$i]['size'].')';  ?> 파일 삭제</label>
						</span>
						<?php } ?>
						
					</div>
					<?php } ?>					
					</td>
				</tr>
				<!-- <tr>
					<th><label class="wr_label">LINK</label></th>
					<td colspan="3">
					<?php for ($i=1; $is_link && $i<=G5_LINK_COUNT; $i++) { ?>
					<div class="bo_w_link write_div">
						<label for="wr_link<?php echo $i ?>"><i class="fa fa-link" aria-hidden="true"></i><span class="sound_only"> 링크  #<?php echo $i ?></span></label>
						<input type="text" name="wr_link<?php echo $i ?>" value="<?php if($w=="u"){ echo $write['wr_link'.$i]; } ?>" id="wr_link<?php echo $i ?>" class="frm_input full_input" size="50">
					</div>
					<?php } ?>					
					</td>
				</tr> -->
				<?php if ($is_use_captcha) { //자동등록방지  ?>
				<tr class="row5">
					<th><label class="wr_label">자동등록방지</label></th>
					<td colspan="3">
						<?php echo $captcha_html ?>
					</td>
				</tr>
				<?php } ?>
			</table>

			<div class="center mt30">
				<button type="submit" id="btn_submit" accesskey="s" class="btn_submit btn">등록하기</button>
				<!-- <button type="submit" id="btn_submit" accesskey="s" class="btn_st1">등록하기</button> -->
				<!-- <a href="#" class="btn_st1">구인신청하기</a> -->
			</div>

		</div>

    </form>

    <script>
    function html_auto_br(obj)
    {
        if (obj.checked) {
            result = confirm("자동 줄바꿈을 하시겠습니까?\n\n자동 줄바꿈은 게시물 내용중 줄바뀐 곳을<br>태그로 변환하는 기능입니다.");
            if (result)
                obj.value = "html2";
            else
                obj.value = "html1";
        }
        else
            obj.value = "";
    }

    function fwrite_submit(f)
    {
        <?php echo $editor_js; // 에디터 사용시 자바스크립트에서 내용을 폼필드로 넣어주며 내용이 입력되었는지 검사함   ?>

        var subject = "";
        var content = "";
        $.ajax({
            url: g5_bbs_url+"/ajax.filter.php",
            type: "POST",
            data: {
                "subject": f.wr_subject.value,
                "content": f.wr_content.value
            },
            dataType: "json",
            async: false,
            cache: false,
            success: function(data, textStatus) {
                subject = data.subject;
                content = data.content;
            }
        });

        if (subject) {
            alert("이름에 금지단어('"+subject+"')가 포함되어있습니다");
            f.wr_subject.focus();
            return false;
        }

        if (content) {
            alert("업무에 금지단어('"+content+"')가 포함되어있습니다");
            if (typeof(ed_wr_content) != "undefined")
                ed_wr_content.returnFalse();
            else
                f.wr_content.focus();
            return false;
        }

        if (document.getElementById("char_count")) {
            if (char_min > 0 || char_max > 0) {
                var cnt = parseInt(check_byte("wr_content", "char_count"));
                if (char_min > 0 && char_min > cnt) {
                    alert("내용은 "+char_min+"글자 이상 쓰셔야 합니다.");
                    return false;
                }
                else if (char_max > 0 && char_max < cnt) {
                    alert("내용은 "+char_max+"글자 이하로 쓰셔야 합니다.");
                    return false;
                }
            }
        }

        <?php echo $captcha_js; // 캡챠 사용시 자바스크립트에서 입력된 캡챠를 검사함  ?>

        document.getElementById("btn_submit").disabled = "disabled";

        return true;
    }
    </script>

</section>
<!-- } 게시물 작성/수정 끝 -->