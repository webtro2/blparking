<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH.'/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$board_skin_url.'/style.css">', 0);
?>

<?php
$ex8_filed = array_pad(explode("|", (string)($view['wr_8'] ?? '')), 2, ''); 
$ext8_00  = $ex8_filed[0];//문자수신
$ext8_01  = $ex8_filed[1];//이메일수신

$ex9_filed = array_pad(explode("|", (string)($view['wr_9'] ?? '')), 2, ''); 
$ext9_00  = $ex9_filed[0];//동의
$ext9_01  = $ex9_filed[1];//미동의

$ex10_filed = array_pad(explode("|", (string)($view['wr_10'] ?? '')), 4, ''); 
$ext10_00  = $ex10_filed[0];//현장방문
$ext10_01  = $ex10_filed[1];//전화상담
$ext10_02  = $ex10_filed[2];//이메일상담
$ext10_03  = $ex10_filed[3];//상담희망일자

?>

<script src="<?php echo G5_JS_URL; ?>/viewimageresize.js"></script>

<!-- 게시물 읽기 시작 { -->

<article id="bo_v" style="width:<?php echo $width; ?>">

    <section id="bo_v_info">
        <h2>페이지 정보</h2>
        <div class="profile_info">
        	<div class="profile_info_ct">
        		<span class="sound_only">작성자</span> <strong><?php echo $view['name'] ?><?php if ($is_ip_view) { echo "&nbsp;($ip)"; } ?></strong>
        		<strong class="if_date"><span class="sound_only">작성일</span><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date("y-m-d H:i", strtotime($view['wr_datetime'])) ?></strong>
    		</div>
    	</div>

    	<!-- 게시물 상단 버튼 시작 { -->
	    <div id="bo_v_top">
	        <?php ob_start(); ?>

	        <ul class="btn_bo_user bo_v_com">
				<li><a href="<?php echo $list_href ?>" class="btn_b01 btn" title="목록"><i class="fa fa-list" aria-hidden="true"></i><span class="sound_only">목록</span></a></li>

	            <?php if ($write_href) { ?><li><a href="<?php echo $write_href ?>" class="btn_b01 btn" title="등록"><i class="fa fa-pencil" aria-hidden="true"></i><span class="sound_only">등록</span></a></li><?php } ?>
	        	<?php if($update_href || $delete_href || $copy_href || $move_href || $search_href) { ?>
	        	<li>
	        		<button type="button" class="btn_more_opt is_view_btn btn_b01 btn"><i class="fa fa-ellipsis-v" aria-hidden="true"></i><span class="sound_only">게시판 리스트 옵션</span></button>
		        	<ul class="more_opt is_view_btn"> 
			            <?php if ($update_href) { ?><li><a href="<?php echo $update_href ?>">수정<i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li><?php } ?>
			            <?php if ($delete_href) { ?><li><a href="<?php echo $delete_href ?>" onclick="del(this.href); return false;">삭제<i class="fa fa-trash-o" aria-hidden="true"></i></a></li><?php } ?>
			            <!-- <?php if ($copy_href) { ?><li><a href="<?php echo $copy_href ?>" onclick="board_move(this.href); return false;">복사<i class="fa fa-files-o" aria-hidden="true"></i></a></li><?php } ?>
			            <?php if ($move_href) { ?><li><a href="<?php echo $move_href ?>" onclick="board_move(this.href); return false;">이동<i class="fa fa-arrows" aria-hidden="true"></i></a></li><?php } ?> -->
			        </ul> 
	        	</li>
	        	<?php } ?>
	        </ul>
	        <script>

            jQuery(function($){
                // 게시판 보기 버튼 옵션
				$(".btn_more_opt.is_view_btn").on("click", function(e) {
                    e.stopPropagation();
				    $(".more_opt.is_view_btn").toggle();
				})
;
                $(document).on("click", function (e) {
                    if(!$(e.target).closest('.is_view_btn').length) {
                        $(".more_opt.is_view_btn").hide();
                    }
                });
            });
            </script>
	        <?php
	        $link_buttons = ob_get_contents();
	        ob_end_flush();
			?>
	    </div>
	    <!-- } 게시물 상단 버튼 끝 -->
    </section>

    <section id="bo_v_atc">




		<div id="pageCont" >

			<h4 class="stit3">기업정보</h4>
			<table class="tb-style2 tb-write mob">
				<tr>
					<th><label class="wr_label">기업명</label></th>
					<td><?php echo $view['wr_1'] ?></td>
					<th><label class="wr_label">대표자</label></th>
					<td><?php echo $view['wr_2'] ?></td>
				</tr>
				<tr>
					<th><label class="wr_label">사업자등록번호</label></th>
					<td><?php echo $view['wr_3'] ?></td>
					<th><label class="wr_label">업종구분</label></th>
					<td><?php echo $view['wr_4'] ?></td>
				</tr>
				<tr>
					<th><label class="wr_label">주소</label></th>
					<td colspan="3"><?php echo $view['wr_5'] ?></td>
				</tr>
			</table>

			<h4 class="stit3 mt40">신청인 정보</h4>
			<table class="tb-style2 tb-write mob">
				<tr>
					<th><label class="wr_label">성명</label></th>
					<td><?php echo $view['wr_name'] ?></td>
					<th><label class="wr_label">소속 및 직위</label></th>
					<td><?php echo $view['wr_6'] ?></td>
				</tr>
				<tr>
					<th><label class="wr_label">연락처</label></th>
					<td><?php echo $view['wr_7'] ?></td>
					<th><label class="wr_label">이메일</label></th>
					<td><?php echo $view['wr_email'] ?></td>
				</tr>
				<tr>
					<th><label class="wr_label">통지방법</label></th>
					<td>
							<input type="checkbox" name="ext8_00" value="문자수신" <?php if ($ext8_00 == '문자수신') echo "checked";?>>&nbsp;문자수신&nbsp;&nbsp;
							<input type="checkbox" name="ext8_01" value="이메일수신" <?php if ($ext8_01 == '이메일수신') echo "checked";?>>&nbsp;이메일수신
					</td>
					<th><label class="wr_label">개인정보활용동의</label></th>
					<td><?=$ext9_00?><?=$ext9_01?>
					</td>
				</tr>
			</table>


			<h4 class="stit3 mt40">애로사항 및 상담 신청</h4>
			<table class="tb-style2 tb-write mob">
				<tr>
					<th><label class="wr_label">상담분야</label></th>
					<td><?php echo $view['ca_name']; // 분류 출력 끝 ?>	</td>
					<th><label class="wr_label">상담일자</label></th>
					<td><?php echo $ext10_03 ?></td>
				</tr>	
				<tr>
					<th><label class="wr_label">제목</label></th>
					<td colspan="3"><?php echo $view['wr_subject']; // 분류 출력 끝 ?></td>
				</tr>
				<tr class="row5">
					<th><label class="wr_label">상담내용</label></th>
					<td colspan="3">
					<?php
					// 파일 출력
					$v_img_count = count($view['file']);
					if($v_img_count) {
						echo "<div id=\"bo_v_img\">\n";

						foreach($view['file'] as $view_file) {
							echo get_file_thumbnail($view_file);
						}

						echo "</div>\n";
					}
					 ?>					
					<?php echo get_view_thumbnail($view['content']); ?></td>
				</tr>

				<tr>
					<th><label class="wr_label">희망상담방법</label></th>
					<td colspan="3">
							<input type="checkbox" name="ext10_00" value="현장방문" <?php if ($ext10_00 == '현장방문') echo "checked";?>>&nbsp;현장방문&nbsp;&nbsp;
							<input type="checkbox" name="ext10_01" value="전화상담" <?php if ($ext10_01 == '전화상담') echo "checked";?>>&nbsp;전화상담&nbsp;&nbsp;					
							<input type="checkbox" name="ext10_02" value="이메일상담" <?php if ($ext10_02 == '이메일상담') echo "checked";?>>&nbsp;이메일상담					
					</td>
				</tr>

    <?php
    $cnt = 0;
    if ($view['file']['count']) {
        for ($i=0; $i<count($view['file']); $i++) {
            if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view'])
                $cnt++;
        }
    }
	?>
    <?php if($cnt) { ?>
        <?php
        // 가변 파일
        for ($i=0; $i<count($view['file']); $i++) {
            if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view']) {
         ?>
				<tr class="row5">
					<th><label class="wr_label">첨부파일</label></th>
					<td colspan="3">

						<!-- 첨부파일 시작 { -->
						<section id="bo_v_file">
							<h2>첨부파일</h2>

									<a href="<?php echo $view['file'][$i]['href'];  ?>" class="view_file_download">
										<strong><?php echo $view['file'][$i]['source'] ?></strong> <?php echo $view['file'][$i]['content'] ?> (<?php echo $view['file'][$i]['size'] ?>)
									</a>
									<br>
									<span class="bo_v_file_cnt"><?php echo $view['file'][$i]['download'] ?>회 다운로드 | DATE : <?php echo $view['file'][$i]['datetime'] ?></span>

						</section>
						<!-- } 첨부파일 끝 -->

				</td>
				</tr>
        <?php
            }
        }
         ?>
    <?php } ?>

				<tr>
					<th><label class="wr_label">개인정보취급방침</label></th>
					<td colspan="3">동의 합니다.</label>				
					</td>
				</tr>

			</table>

			<div class="center mt30">
				<a href="<?php echo $update_href ?>"  class="btn_st1">수정하기</a>
			</div>

		</div>

    </section>


    <?php if(isset($view['link']) && array_filter($view['link'])) { ?>
    <!-- 관련링크 시작 { -->
    <section id="bo_v_link">
        <h2>관련링크</h2>
        <ul>
        <?php
        // 링크
        $cnt = 0;
        for ($i=1; $i<=count($view['link']); $i++) {
            if ($view['link'][$i]) {
                $cnt++;
                $link = cut_str($view['link'][$i], 70);
            ?>
            <li>
                <i class="fa fa-link" aria-hidden="true"></i>
                <a href="<?php echo $view['link_href'][$i] ?>" target="_blank">
                    <strong><?php echo $link ?></strong>
                </a>
                <br>
                <span class="bo_v_link_cnt"><?php echo $view['link_hit'][$i] ?>회 연결</span>
            </li>
            <?php
            }
        }
        ?>
        </ul>
    </section>
    <!-- } 관련링크 끝 -->
    <?php } ?>
    


    <?php
    // 코멘트 입출력
    //include_once(G5_BBS_PATH.'/view_comment.php');
	?>
</article>
<!-- } 게시판 읽기 끝 -->

<script>
<?php if ($board['bo_download_point'] < 0) { ?>
$(function() {
    $("a.view_file_download").click(function() {
        if(!g5_is_member) {
            alert("다운로드 권한이 없습니다.\n회원이시라면 로그인 후 이용해 보십시오.");
            return false;
        }

        var msg = "파일을 다운로드 하시면 포인트가 차감(<?php echo number_format($board['bo_download_point']) ?>점)됩니다.\n\n포인트는 게시물당 한번만 차감되며 다음에 다시 다운로드 하셔도 중복하여 차감하지 않습니다.\n\n그래도 다운로드 하시겠습니까?";

        if(confirm(msg)) {
            var href = $(this).attr("href")+"&js=on";
            $(this).attr("href", href);

            return true;
        } else {
            return false;
        }
    });
});
<?php } ?>

function board_move(href)
{
    window.open(href, "boardmove", "left=50, top=50, width=500, height=550, scrollbars=1");
}
</script>

<script>
$(function() {
    $("a.view_image").click(function() {
        window.open(this.href, "large_image", "location=yes,links=no,toolbar=no,top=10,left=10,width=10,height=10,resizable=yes,scrollbars=no,status=no");
        return false;
    });

    // 추천, 비추천
    $("#good_button, #nogood_button").click(function() {
        var $tx;
        if(this.id == "good_button")
            $tx = $("#bo_v_act_good");
        else
            $tx = $("#bo_v_act_nogood");

        excute_good(this.href, $(this), $tx);
        return false;
    });

    // 이미지 리사이즈
    $("#bo_v_atc").viewimageresize();
});

function excute_good(href, $el, $tx)
{
    $.post(
        href,
        { js: "on" },
        function(data) {
            if(data.error) {
                alert(data.error);
                return false;
            }

            if(data.count) {
                $el.find("strong").text(number_format(String(data.count)));
                if($tx.attr("id").search("nogood") > -1) {
                    $tx.text("이 글을 비추천하셨습니다.");
                    $tx.fadeIn(200).delay(2500).fadeOut(200);
                } else {
                    $tx.text("이 글을 추천하셨습니다.");
                    $tx.fadeIn(200).delay(2500).fadeOut(200);
                }
            }
        }, "json"
    );
}
</script>
<!-- } 게시글 읽기 끝 -->