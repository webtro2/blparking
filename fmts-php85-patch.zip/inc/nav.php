<ul class="gnb">

  <!--  -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('about1')">센터소개</a></div>
    <?php  include __DIR__ . "/s_gnb1.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('info1')">기업지원정보</a></div>
    <?php  include __DIR__ . "/s_gnb2.php" ?>
  </li>

  <li class="gnb_dp1">
    <div class="dep1"><a href="javascript:GoPage('consulting1')">기업애로 상담</a></div>
    <?php  include __DIR__ . "/s_gnb3.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('comm1')">알림마당</a></div>
    <?php  include __DIR__ . "/s_gnb4.php" ?>
  </li>


</ul>
