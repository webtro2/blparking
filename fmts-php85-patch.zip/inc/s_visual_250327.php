<div class="s_visual">
	<div class="s_visual_in">
		<div class="sv_tit">
			<h2 data-aos="fade-up" data-aos-delay="300"><span class="vis_dep01"></span></h2>
			<p class="txt" data-aos="fade-up" data-aos-delay="500"><span>전장부품 산업의 성장 가속화,<br> 지속가능한 미래차 전환을 지원합니다.</span></p>
		</div>
	</div>
</div>
<div id="s_gnb2" class="inner2">
    <div class="s_depth1 s_depth" style="display:none;">
        <h2 class="deptit"><span class="vis_dep01"></span></h2>
        <div class="hide"><?php  include __DIR__ . "/s_gnb0.php" ?></div>
    </div>
    <div class="s_depth2 s_depth">
        <?php  if (isset($s_num) && preg_match('/^[0-9]+$/', (string)$s_num) && is_file(__DIR__ . "/s_gnb$s_num.php")) include __DIR__ . "/s_gnb$s_num.php" ?>
    </div>
</div>


<script>
    var subFunc = (function($){
	var _snb = function(level1, level2){

		var sub_dep1=$('#s_gnb2 .s_depth1 .menu'+level1);
		var sub_dep2=$('#s_gnb2 .s_depth2 .menu'+level2);
		var sub_dep1_t = $(sub_dep1).text();
		var sub_dep2_t = $(sub_dep2).text();

		$('.s_visual').css({"background-image":"url(/images/sub/s_visual"+level1+".png?v=1)"});

		$('span.vis_dep01').text(sub_dep1_t);
		$('span.vis_dep02').text(sub_dep2_t);
        

		sub_dep1.addClass('on');
		sub_dep2.addClass('on');
		sub_dep2.parent().addClass('s_on');


		$('#s_gnb2 .deptit').click(function(){
			if($(this).hasClass('m_on')){
				$(this).removeClass('m_on');
				$(this).siblings("ul.smenu").slideUp();
			} else {
				$(this).addClass('m_on');
				$(this).siblings("ul.smenu").slideDown();
			}
		});

		$("#s_gnb2 .s_depth").on("mouseleave", function(){
			if($(this).children(".deptit").hasClass("m_on")){
				$(this).children(".deptit").removeClass("m_on");
				$(this).children("ul.smenu").slideUp(300);
			}
		});

		$(window).resize(function(){
			var width = parseInt($(this).width()); //parseint는 정수로 하기 위함
			if(width <= 977){
				$('#s_gnb2 .s_depth .smenu').css({'display':'none'});
			}else{
				$('#s_gnb2 .s_depth .smenu').css({'display':'block'});
			}
		}).resize();


	};
	return{
		snb:_snb
	}
})(jQuery);

</script>


<style>
    .s_visual{height: 580px; padding-top: 100px;}
    .s_visual .sv_tit h2{font-family: 'GongGothicBold';font-size: 50px;}
    .s_visual .sv_tit p{font-family: 'Pretendard'; margin-top: 20px; font-size: 18px;}
    #s_gnb2 .s_depth2 ul{display: flex !important; height: 80px; background: #fff; border-radius: 10px; border: 1px solid #ddd; margin-top: -40px; align-items: center;font-family: 'Pretendard';z-index: 100; position: relative;}
    #s_gnb2 .s_depth2 ul li{width: calc(100%/3); text-align: center; height: 100%;line-height: 80px; position: relative;}
    #s_gnb2 .s_depth2 ul.n3 li{width: 100%;}
    #s_gnb2 .s_depth2 ul li:after{height: 25px; width: 1px; content:'';position: absolute; top: 50%; right: 0; transform:translateY(-50%); background: #bbbbbb;}
    #s_gnb2 .s_depth2 ul li:last-child:after{display: none;}
    #s_gnb2 .s_depth2 ul li a{width: 100%; height: 100%; display: inline-block;  font-size: 18px; color: #383838;transition: 0.3s;}
    #s_gnb2 .s_depth2 ul li:hover a{color: #3663ae; transition: 0.3s;}
    #s_gnb2 .s_depth2 ul li.s_on {background: #3663ae; border-radius: 8px;box-shadow: 0 0 0 1px #3663ae;}
    #s_gnb2 .s_depth2 ul li.s_on a{color: #fff;font-weight: bold;}
    #s_gnb2 .s_depth2 ul li.s_on:after{display: none;}
    #s_gnb2 .s_depth2 .depth3{display: none !important;}
    @media screen and (max-width:1280px){
        .s_visual{height: 500px; padding-top: 80px;}
        .s_visual .sv_tit h2{font-size: 40px;}
        .s_visual .sv_tit p{font-size: 16px;}
        #s_gnb2 .s_depth2 ul{height: 70px; margin-top: -35px;}
        #s_gnb2 .s_depth2 ul li{line-height: 70px;}
        #s_gnb2 .s_depth2 ul li a{font-size: 16px;}
    }
    @media screen and (max-width:1080px){
        .s_visual{height: 490px; padding-top: 70px;}
    }
    @media screen and (max-width:768px){
        .s_visual{height: 400px; padding-top: 60px;}
        .s_visual .sv_tit h2{font-size: 35px;}
        #s_gnb2 .s_depth2 ul{height: 50px; margin-top: -25px;}
        #s_gnb2 .s_depth2 ul li{line-height: 50px;}
        #s_gnb2 .s_depth2 ul li a{font-size: 15px;}
    }
    @media screen and (max-width:480px){
        .s_visual{height: 380px; padding-top: 60px;}
        .s_visual .sv_tit h2{font-size: 30px;}
        .s_visual .sv_tit p{font-size: 14px; margin-top: 10px;}
        #s_gnb2 .s_depth2 ul{height: 45px; margin-top: -22.5px;}
        #s_gnb2 .s_depth2 ul li{line-height: 45px;}
        #s_gnb2 .s_depth2 ul li:after{height: 15px;}
        #s_gnb2 .s_depth2 ul li a{font-size: 3.3vw;}
    }
</style>