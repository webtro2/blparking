<header id="header">
<div class="inner">
	<h1 id="logo">
		<a href="javascript:GoPage('main')">
         <img src="/images/common/logo.png"  alt="" />
      </a>
	</h1>

	<div id="gnb_pc2">
		<?php  include "nav_230612.php" ?>
	</div>
	
	<div id="t-mem">
		<?php if($member['mb_id']){?>
		<a href="javascript:GoPage('logout')">logout</a>
		<?php if($is_admin){?>
		<a href="/pg/adm/">관리자</a>
		<?php }else{?>
		<a href="javascript:GoPage('mypage')">정보수정</a>
		<?php  } ?>
		<?php }else{?>
		<a href="javascript:GoPage('login')" class="on">Login</a>
		<a href="javascript:GoPage('join')">Join</a>
		<?php }?>
	</div>



</div>
	<div class="menuToggle"><span class="t"></span><span class="m"></span><span class="b"></span></div>

	<div class="hd_tel">
		<a href="tel:0536707949"></a>
	</div>

   <div id="gnb_mo">	
   	<?php  include __DIR__ . "/nav.php" ?>
	<div id="t-mem-mo">
		<a href="javascript:GoPage('login')" class="on">Login</a>
		<a href="javascript:GoPage('join')">Join</a>
	</div>
   </div>

</header>

<div id="content">

