<header id="header_n">
    <h1 id="logo">
        <a href="javascript:GoPage('main')" class="logo" alt="대구미래차전환종합지원센터"></a>
    </h1>

    <div id="g_pc">
        <?php  include __DIR__ . "/nav.php" ?>

        <div id="t-m">
            <?php if($member['mb_id']){?>
            <a href="javascript:GoPage('logout')">LOGOUT</a>
            <?php if($is_admin){?>
            <a href="/pg/adm/" class="ad">관리자</a>
            <?php }else{?>
            <a href="javascript:GoPage('mypage')" class="ad">정보수정</a>
            <?php  } ?>
            <?php }else{?>
            <a href="javascript:GoPage('login')" class="on">LOGIN</a>
            <a href="javascript:GoPage('join')" class="join">JOIN</a>
            <?php }?>
        </div>
    </div>

	

	<div  id="allmenuWrap">
		<div id="allmenu">
			<a href="#" id="navtoggler">
				<div class="bar"><span class="t"></span><span class="m"></span><span class="b"></span></div>
			</a>
		</div>
		<nav id="fullscreenmenu">
				<?php  include __DIR__ . "/nav.php" ?>			
		</nav>
	</div>


	<div class="menuToggle hd_full hd_mbx"><span class="t"></span><span class="m"></span><span class="b"></span></div>


	<div id="g_mo" class="fullmenu">
        <div id="t-m">
            <?php if($member['mb_id']){?>
            <a href="javascript:GoPage('logout')">LOGOUT</a>
            <?php if($is_admin){?>
            <a href="/pg/adm/" class="ad">관리자</a>
            <?php }else{?>
            <a href="javascript:GoPage('mypage')" class="ad">정보수정</a>
            <?php  } ?>
            <?php }else{?>
            <a href="javascript:GoPage('login')" class="on">LOGIN</a>
            <a href="javascript:GoPage('join')" class="join">JOIN</a>
            <?php }?>
        </div>
		<?php  include __DIR__ . "/nav.php" ?>
	</div>

</header>


<div id="content">

