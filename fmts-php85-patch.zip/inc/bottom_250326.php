</div>

<div id="siteList_n">
    <div class="inner2">
        <h3>유관기관</h3>
        <button class="play slideCtr">재생</button>
        <button class="pause slideCtr">정지</button>
        <div class="siteSlide">
            <div class="item"><a href="https://www.daegu.go.kr/intro.jsp" target="_blank"><img src="/images/common/site0.png" alt="대구광역시" /></a></div>
            <div class="item"><a href="http://www.kiapi.or.kr/" target="_blank"><img src="/images/common/site1_230112.png" alt="지능형자동차부품진흥원" /></a></div>
            <div class="item"><a href="https://www.etri.re.kr/" target="_blank"><img src="/images/common/site2.png" alt="한국전자통신연구원 대경권연구센터" /></a></div>
            <div class="item"><a href="https://www.ync.ac.kr/" target="_blank"><img src="/images/common/site3.png" alt="영남이공대학교" /></a></div>
            <div class="item"><a href="https://www.dip.or.kr/" target="_blank"><img src="/images/common/site4_230111.png" alt="대구디지털산업진흥원" /></a></div>
            <div class="item"><a href="https://ccei.creativekorea.or.kr/daegu/main.do" target="_blank"><img src="/images/common/site5.png" alt="대구창조경제혁신센터" /></a></div>
            <div class="item"><a href="https://www.kosmes.or.kr/intro/kosme_intro.html" target="_blank"><img src="/images/common/site6.png" alt="중소벤처기업진흥공단" /></a></div>
            <div class="item"><a href="http://www.katech.re.kr/" target="_blank"><img src="/images/common/site7.png" alt="한국자동차연구원 대구경북본부" /></a></div>
            <div class="item"><a href="https://www.yju.ac.kr/kr/index.do" target="_blank"><img src="/images/common/site8.png" alt="영진전문대학교" /></a></div>
            <div class="item"><a href="https://www.knu.ac.kr/" target="_blank"><img src="/images/common/site9.png" alt="경북대학교" /></a></div>
            <div class="item"><a href="https://www.dgist.ac.kr/kr/" target="_blank"><img src="/images/common/site10.png" alt="대구경북과학기술원" /></a></div>
            <div class="item"><a href="https://www.ttg.co.kr/" target="_blank"><img src="/images/common/site11.png" alt="대구신용보증재단" /></a></div>
            <div class="item"><a href="https://www.kitech.re.kr/main/" target="_blank"><img src="/images/common/site12.png" alt="한국생산기술연구원" /></a></div>
            <div class="item"><a href="https://www.keit.re.kr/" target="_blank"><img src="/images/common/site13.png" alt="한국산업기술평가관리원" /></a></div>
            <div class="item"><a href="https://www.dcci.or.kr/" target="_blank"><img src="/images/common/site14.png" alt="대구상공회의소" /></a></div>
            <div class="item"><a href="https://www.ttp.org/" target="_blank"><img src="/images/common/site15_230111.png" alt="대구테크노파크" /></a></div>
        </div>
    </div>
</div>


<!-- footer -->
<div id="footer_n">
    <div class="w-inner">    
        <div class="top">
            <div class="lt">
                <div class="logo"><img src="/images/common/f_logo_n.png" alt=""></div>
                <p>대구광역시 달성군 현풍읍 테크노공원로 16, 대구테크비즈센터 603호 (43017)</p>
                <p><span>TEL : 053-670-4781</span> <span>FAX : 053-615-0201</span></p>
            </div>
            <div class="rt">
                <ul>
                    <li><a href="javascript:GoPage('about1')">종합지원센터소개</a></li>
                    <li><a href="javascript:GoPage('provision')">이용약관</a></li>
                    <li><a href="javascript:GoPage('privacy')">개인정보처리방침</a></li>
                    <li><a href="javascript:GoPage('about3')">찾아오시는 길</a></li>
                </ul>
            </div>
        </div>
        <div class="bot">
            <p>COPYRIGHT (C) DFACSC. ALL RIGTH RESERVED.</p>
        </div>
	</div>
</div>
<!-- //footer -->


<script>
    AOS.init({
        duration: 600,
        offset: 0,
        delay: 100,
        easing: 'ease-out-quad',
    });
</script>

<script type="text/javascript">
	$(document).ready(function() {
		subFunc.snb("<?=($s_num ?? '')?>", "<?=($p_num ?? '')?>");
	});
</script>


<script type="text/javascript">
    $('.select_btn').click(function(event) {
        event.stopPropagation();
        $(this).next('.select_list').slideToggle();
        $(this).toggleClass('on');
    });
    $(document).click(function() {
        $(this).next('.select_list').slideUp();
    });

    //스크롤 시 리스트 닫힘
    $(window).scroll(function(){
        $('.select_list').slideUp();
    });

</script>

<script type="text/javascript" src="/js/main.js"></script>

</body>
</html>
