<?php require_once(__DIR__ . '/../pg/common.php'); ?>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="language" content="ko" />
<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<meta name="format-detection" content="telephone=no" />

<meta name="author" content="http://d-fmts.or.kr"> 
<meta name="description" content="지원협의체소개, 기업지원정보, 기업애로 상담, 산업 및 정책자료, 종합지원센터"> 
<meta name="keywords" content="지원협의체소개, 기업지원정보, 기업애로 상담, 산업 및 정책자료, 종합지원센터"> 
<meta property="og:type" content="website">
<meta property="og:title" content="대구미래차전환종합지원센터">
<meta property="og:subject" content="지원협의체소개, 기업지원정보, 기업애로 상담, 산업 및 정책자료, 종합지원센터 ">
<meta property="og:description" content="지원협의체소개, 기업지원정보, 기업애로 상담, 산업 및 정책자료, 종합지원센터">
<meta property="og:image" content="http://d-fmts.or.kr/og.jpg">
<meta property="og:url" content="http://d-fmts.or.kr"> 
<link rel="canonical" href="http://d-fmts.or.kr"> 
<meta property="al:web:url" content="http://d-fmts.or.kr">
<meta name="naver-site-verification" content="2463910706c642044acaadb47a318d9b95d2d4d7" />

<title>대구 미래차 전환 종합지원센터</title>

<link rel="stylesheet" type="text/css" href="/css/default.css?v=20211202" />
<link rel="stylesheet" type="text/css" href="/css/layout_230612.css" />
<link rel="stylesheet" type="text/css" href="/css/scont.css?v=250716" />
<link rel="stylesheet" type="text/css" href="/css/main_new.css?v=1" />
<link rel="stylesheet" type="text/css" href="/css/layout_new.css?v=1" />
<link rel="stylesheet" type="text/css" href="/css/allmenu.css" />
<link rel="stylesheet" type="text/css" href="/css/sub.css?v=1" />
<script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">



<!-- js -->
<script type="text/javascript" src="/js/aos.js"></script>

<!-- gnb -->
<script type="text/javascript" src="/js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="/js/common.js"></script>
<script type="text/javascript" src="/js/common_230612.js"></script>
<script type="text/javascript" src="/js/sub.js"></script>
<script type="text/javascript" src="/js/common_new.js"></script>
<script type="text/javascript" src="/js/allmenu.js"></script>

<!-- slick  -->
<script type="text/javascript" src="/js/slick/slick.min.js"></script>
<link media="all" href="/js/slick/slick.css" type="text/css" rel="stylesheet"/>
<link media="all" href="/js/slick/slick-theme.css" type="text/css" rel="stylesheet"/>

</head>

<body id="wrap">
