<?php  include "../inc/head.php"; ?>
<?php
$cf_1_count = isset($config['cf_1']) && trim($config['cf_1']) !== '' ? trim($config['cf_1']) : '1,394';
$cf_1_digits = str_replace(',', '', $cf_1_count);
$cf_1_is_num = ctype_digit($cf_1_digits);
// 기준 년(여분필드2) / 월(여분필드3): 퀵 바에서 수정. 비어 있거나 형식이 맞지 않으면 현재 년월
$cf_2_year = date('Y');
$cf_2_month = date('n');
if (isset($config['cf_2']) && preg_match('/(\d{4})/', $config['cf_2'], $m)) {
    $cf_2_year = $m[1];
}
if (isset($config['cf_3']) && preg_match('/^\d{1,2}$/', trim($config['cf_3'])) && (int) $config['cf_3'] >= 1 && (int) $config['cf_3'] <= 12) {
    $cf_2_month = (int) $config['cf_3'];
} elseif (isset($config['cf_2']) && preg_match('/(\d{1,2})\s*월/', $config['cf_2'], $m)) {
    $cf_2_month = (int) $m[1];
}
$cf_2_date = $cf_2_year . '년 ' . $cf_2_month . '월';
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="/css/landing.css?V=2" />
<link rel="stylesheet" type="text/css" href="/css/aos.css" />
<script type="text/javascript" src="/js/aos.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<style>
    .s-inner {
        max-width: 1600px !important;
        width: 1600px !important;
        position: relative;
        margin-left: auto;
        margin-right: auto;
    }


    /* 타블렛 가로 */
    @media all and (max-width:1599px) {
        .s-inner {
            width: 96% !important;
        }
    }
</style>

<div id="ld_sec1" class="p-Part">
    <div class="s-inner">
        <div class="top">
            <h4 data-aos="fade-up" data-aos-delay="200">소음순, 수술 경험이 많은 병원이 <div style="color:yellow; display: inline;"><span>중</span><span>요</span><span>한</span> <span>이</span><span>유</span>?</div>
            </h4>
            <h3 data-aos="fade-up" data-aos-delay="200">보이지 않는 곳일수록, <br class="br976"><span>더 섬세해야 합니다.</span></h3>
        </div>
        <div class="line" data-aos="fade-up" data-aos-delay="200"><img src="/images/landing/line.png" alt=""></div>
        <div class="mid">
            <p data-aos="fade-up" data-aos-delay="200"><b style="color:yellow;">소음순 수술</b>은 개인마다 형태가 다르고, <br>좌우 비대칭·조직 두께·피부 탄력까지 고려해야 하는 <br class="br480"><b style="color:yellow;">고난도 시술</b>입니다. <br><b>수술 경험이 많을수록</b> 다양한 케이스에 대한 판단력이 쌓이고, <br><b>자연스러운 결과와 빠른 회복</b>으로 이어집니다.</p>
            <h3 data-aos="fade-up" data-aos-delay="200">소음순 수술, <br class="br768">결과의 차이는 경험에서 결정됩니다.</h3>
        </div>
        <div class="line2" data-aos="fade-up" data-aos-delay="200"></div>
        <div class="bot">
            <div class="tt" data-aos="fade-up" data-aos-delay="200">
                <h4><span>소</span><span>음</span><span>순</span> <span>수</span><span>술</span> 경험, 숫자로 확인하세요</h4>
                <h3>르네가 쌓아온 <br class="br768">수술 경험의 차이</h3>
            </div>
            <div class="count" data-aos="fade-up" data-aos-delay="200">
                <?php if ($cf_1_is_num) { ?>
                    <h3><span class="count-num" data-target="<?php echo (int) $cf_1_digits; ?>">0</span> 건</h3>
                <?php } else { ?>
                    <h3><span><?php echo htmlspecialchars($cf_1_count, ENT_QUOTES, 'UTF-8'); ?></span> 건</h3>
                <?php } ?>
                <p>(<?php echo htmlspecialchars($cf_2_date, ENT_QUOTES, 'UTF-8'); ?> 기준)</p>
            </div>
        </div>
    </div>
</div>

<script>
    AOS.init({
        duration: 800,
    });

    document.addEventListener('DOMContentLoaded', function() {
        const counter = document.querySelector('#ld_sec1 .count-num');

        if (!counter) {
            console.log('카운트 요소를 찾을 수 없습니다.');
            return;
        }

        const target = Number(counter.getAttribute('data-target'));
        let started = false;

        function animateCount() {
            if (started) return;
            started = true;

            const duration = 2000;
            const startTime = performance.now();

            function update(currentTime) {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);

                const value = Math.floor(target * progress);
                counter.textContent = value.toLocaleString('ko-KR');

                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    counter.textContent = target.toLocaleString('ko-KR');
                }
            }

            requestAnimationFrame(update);
        }

        // 화면에 나타나면 카운트 시작
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    animateCount();
                    observer.unobserve(counter);
                }
            });
        }, {
            threshold: 0
        });

        observer.observe(counter);
    });
</script>

<div id="ld_sec2">
    <div class="lt"><img src="/images/landing/ld_sec2_img.jpg" alt=""></div>
    <div class="rt ">
        <div class="txt" data-aos="fade-up" data-aos-delay="200">
            <h4>20년 이상의 임상 경험을 보유한<br> 여성 산부인과 전문의</h4>
            <h3>황인아 <span>대표원장</span></h3>
        </div>
        <div class="cont" data-aos="fade-up" data-aos-delay="200">
            <ul>
                <li>· 유럽여성성형학회 시니어 멤버</li>
                <li>· 수술/비수술적 성형과정 이수</li>
                <li>· 대한여성성의학회 대음순, 소음순수술 관련 강의 다수</li>
            </ul>
        </div>
        <div class="cert" data-aos="fade-up" data-aos-delay="200">
            <ul>
                <li><img src="/images/landing/cert01.jpg" alt=""></li>
                <li><img src="/images/landing/cert02.jpg" alt=""></li>
            </ul>
        </div>
    </div>
</div>

<div id="ld_sec3" class="p-Part pb0">
    <div class="s-inner">
        <div class="tt">
            <h3 data-aos="fade-up" data-aos-delay="200"><span>여성 산부인과 전문의 4인 협진 시스템</span> 으로<br> 개인의 상태에 맞는 수술 계획을 제안합니다.</h3>
        </div>
        <div class="doctor">
            <ul>
                <li data-aos="fade-up" data-aos-delay="200">
                    <div class="img"><img src="/images/landing/doctor1.png" alt=""></div>
                    <div class="txt">
                        <p>산부인과 전문의</p>
                        <h3>탁지영 <span>원장</span></h3>
                        <p class="mt10">· 브라질리언제모</p>
                        <p>· 와이존미백</p>
                        <p>· 질레이저</p>
                    </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="300">
                    <div class="img"><img src="/images/landing/doctor2.png" alt=""></div>
                    <div class="txt">
                        <p>산부인과 전문의</p>
                        <h3>이지영 <span>원장</span></h3>
                        <p class="mt10">· 질레이저</p>
                        <p>· 질필러</p>
                        <p>· 브라질리언</p>
                    </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="400">
                    <div class="img"><img src="/images/landing/doctor3.png" alt=""></div>
                    <div class="txt">
                        <p>산부인과 전문의</p>
                        <h3>황인아 <span>원장</span></h3>
                        <p class="mt10">· 소음순수술</p>
                        <p>· 대음순수술</p>
                        <p>· 회음성형</p>
                    </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="500">
                    <div class="img"><img src="/images/landing/doctor4.png" alt=""></div>
                    <div class="txt">
                        <p>산부인과 전문의</p>
                        <h3>김수정 <span>원장</span></h3>
                        <p class="mt10">· 소음순수술</p>
                        <p>· 질레이저</p>
                        <p>· 질필러</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="b_box">
        <div class="s-inner" data-aos="fade-up" data-aos-delay="200">
            <h3>여성의 몸은 같은 여성이 가장 잘 이해합니다.</h3>
            <p><b>여성 수술 중점 병원</b> 르네여성의원은 <br class="br976"><b>여성 산부인과 전문의</b>가 세심하고 신중하게 접근합니다.</p>
        </div>
    </div>
</div>

<div id="ld_sec4" class="p-Part">
    <div class="s-inner">
        <div class="tt">
            <h4 data-aos="fade-up" data-aos-delay="200">레이저보다 업그레이드된 <span>대</span><span>학</span><span>병</span><span>원</span><span>급</span> 장비</h4>
            <h3 data-aos="fade-up" data-aos-delay="200">베살리우스 <br class="br768">공명파 장비 사용!</h3>
        </div>
        <div class="img" data-aos="zoom-in" data-aos-delay="200"><img src="/images/landing/ld_sec4_img.png" alt=""></div>
        <ul class="checklist">
            <li data-aos="fade-up" data-aos-delay="200"><img src="/images/landing/check.png" alt="">
                <p>조직 손상을 줄이기 위한 <br><b>미세 절개 방식</b></p>
            </li>
            <li data-aos="fade-up" data-aos-delay="400"><img src="/images/landing/check.png" alt="">
                <p><b>절개와 지혈</b>을<br> 동시에 진행</p>
            </li>
            <li data-aos="fade-up" data-aos-delay="600"><img src="/images/landing/check.png" alt="">
                <p>부담은 줄이고, <br><b>회복까지 고려한 수술</b></p>
            </li>
        </ul>
    </div>
</div>

<div id="ld_sec5" class="p-Part">
    <div class="s-inner">
        <div class="top">
            <h3 data-aos="fade-up" data-aos-delay="200">수술 결과는 <br class="br768">디테일에서 결정됩니다!</h3>
            <p data-aos="fade-up" data-aos-delay="200"><b>개인의 상태에 따라 수술 방법은 달라져야 합니다.</b><br>개인의 형태와 상태에 따라 적합한 수술 방식을 선택하고, <br class="br768">필요 시 복합적으로 적용합니다.</p>
        </div>
        <div class="cont">
            <div class="howto" data-aos="fade-up" data-aos-delay="200">
                <div class="title">
                    <p>자연스러운 라인을 형성하는 <b>변연절개법</b></p>
                </div>
                <ul>
                    <li><img src="/images/landing/before01.jpg" alt=""></li>
                    <li><img src="/images/landing/after01.jpg" alt=""></li>
                </ul>
            </div>
            <div class="howto" data-aos="fade-up" data-aos-delay="200">
                <div class="title">
                    <p>늘어지고 주름진 부분은 <b>쐐기절제법</b></p>
                </div>
                <ul>
                    <li><img src="/images/landing/before02.jpg" alt=""></li>
                    <li><img src="/images/landing/after02.jpg" alt=""></li>
                </ul>
            </div>
            <div class="howto" data-aos="fade-up" data-aos-delay="200">
                <div class="title">
                    <p>흉터없는 타이트닝은 <b>피부박리법</b></p>
                </div>
                <ul>
                    <li><img src="/images/landing/before03.jpg" alt=""></li>
                    <li><img src="/images/landing/after03.jpg" alt=""></li>
                </ul>
            </div>
        </div>
        <div class="dot" data-aos="fade-up" data-aos-delay="200"><img src="/images/landing/dots.png" alt=""></div>
        <div class="detail">
            <h3 data-aos="fade-up" data-aos-delay="200">르네만의 남다른 <br class="br768"><span>디테일 4가지!</span></h3>
            <ul>
                <li data-aos="fade-up" data-aos-delay="300">
                    <div class="img"><img src="/images/landing/detail_icon01.png" alt=""></div>
                    <div class="txt">
                        <h4>DETAIL 01</h4>
                        <h3>미세봉합사 적용</h3>
                        <p>얼굴 성형에 사용하는 머리카락보다 가는 미세봉합사를 사용하여 수술 마무리까지 섬세하게 진행합니다.</p>
                    </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="500">
                    <div class="img"><img src="/images/landing/detail_icon02.png" alt=""></div>
                    <div class="txt">
                        <h4>DETAIL 02</h4>
                        <h3>매몰봉합</h3>
                        <p>지퍼올리듯 단단히 결합시키는 봉합으로, 매끈한 모양을 유지하며 외부 환경으로부터 상처를 보호하는 봉합법을 사용합니다.</p>
                    </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="700">
                    <div class="img"><img src="/images/landing/detail_icon03.png" alt=""></div>
                    <div class="txt">
                        <h4>DETAIL 03</h4>
                        <h3>개인 맞춤 봉합</h3>
                        <p>흡수 가능한 고가의 봉합사를 사용하지만 환자분의 편의와 빠른 회복을 위해 10일 후 봉합사를 제거합니다.</p>
                    </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="900">
                    <div class="img"><img src="/images/landing/detail_icon04.png" alt=""></div>
                    <div class="txt">
                        <h4>DETAIL 04</h4>
                        <h3>더마본드 코팅 기본 제공</h3>
                        <p>기본으로 더마본트 코팅을 제공하여 환부에 물이 닿지 않도록 수술 초기 상처를 보호하고 출혈과 감염을 막아줍니다.</p>
                    </div>
                </li>
            </ul>
        </div>
        <a href="https://reneclinic.co.kr/pg/bbs/board.php?bo_table=comm07" data-aos="fade-up" data-aos-delay="200">
            <p>르네 소음순수술 <br class="br768"><b>전후사진 보러가기</b></p> <img src="/images/landing/click.png" alt="">
        </a>
    </div>
</div>

<div id="ld_sec6">
    <div class="s-inner p-Part">
        <div class="top" data-aos="fade-up" data-aos-delay="200">
            <p>대음순 수술과<br> 소음순 수술을 동시에</p>
            <h3>와이존의 <br class="br768">총체적 재구성</h3>
        </div>
        <div class="mid" data-aos="fade-up" data-aos-delay="200">
            <p><b>르네는 단순한 절제가 아닌, 와이존 전체 균형을 고려합니다.</b><br> 소음순만이 문제가 아닙니다.<br> <b>전반적인 와이존 리모델링</b>을 통해 <br class="br480">탄력있고 매끈한 상태를 회복하세요.</p>
        </div>
        <ul>
            <li data-aos="fade-up" data-aos-delay="200">
                <p>대음순 수술 및 <br class="br976">필러 병행 가능</p>
            </li>
            <li data-aos="fade-up" data-aos-delay="200">
                <p>전체적인 라인과 <br class="br976">탄력까지 균형있게</p>
            </li>
            <li data-aos="fade-up" data-aos-delay="200">
                <p>관련 학회 강의<br class="br976"> 경험 보유 의료진</p>
            </li>
        </ul>
    </div>
</div>
<div class="pic_list">
    <ul>
        <li><img src="/images/landing/ld_sec6_img01.jpg" alt=""></li>
        <li><img src="/images/landing/ld_sec6_img02.jpg" alt=""></li>
        <li><img src="/images/landing/ld_sec6_img03.jpg" alt=""></li>
        <li><img src="/images/landing/ld_sec6_img04.jpg" alt=""></li>
        <li><img src="/images/landing/ld_sec6_img05.jpg" alt=""></li>
        <li><img src="/images/landing/ld_sec6_img06.jpg" alt=""></li>
        <li><img src="/images/landing/ld_sec6_img07.jpg" alt=""></li>
    </ul>
</div>


<script>
    $('.pic_list ul').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 0,
        speed: 5000,
        cssEase: 'linear',
        arrows: false,
        dots: false,
        infinite: true,
        pauseOnHover: false,
        pauseOnFocus: false,
        responsive: [{
                breakpoint: 1280,
                settings: {
                    slidesToShow: 4
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    speed: 4000
                }
            }
        ]
    });
</script>


<div id="ld_sec7" class="p-Part">
    <div class="s-inner">
        <div class="cont">
            <div class="top">
                <h4 data-aos="fade-up" data-aos-delay="200">타병원 수술 후 <span>실</span><span>패</span><span>케</span><span>이</span><span>스</span></h4>
                <h3 data-aos="fade-up" data-aos-delay="200">재수술 100건 이상!</h3>
            </div>
            <ul>
                <li data-aos="fade-up" data-aos-delay="200">
                    <p><b>심한 흉터 및 <br>비대칭</b>으로 <br>심적 고통을 받는 분</p>
                </li>
                <li data-aos="fade-up" data-aos-delay="200">
                    <p>정상적 구조를 <br>잃어서 <br><b>재구축이 필요하신 분</b></p>
                </li>
            </ul>
            <h3 data-aos="fade-up" data-aos-delay="200">르네는 재수술에 자신있는 병원입니다.</h3>
        </div>
    </div>
</div>

<div id="ld_sec8" class="p-Part">
    <div class="s-inner" data-aos="zoom-in" data-aos-delay="200">
        <div class="top">
            <h3>상담 후 바로 <br class="br976"><span>당일 수술 가능!</span></h3>
        </div>
        <p>고민하고 또 고민해서 결심했다면, <br class="br768"><b>더 기다릴 필요 없습니다!</b><br><span><b>당일상담 → 당일 수술로 빠르게</b></span> 해결하세요.</p>
        <div class="box">
            <p>※ 수술 시간 사전 예약 필수 · 카카오톡 또는 전화로 예약 가능</p>
        </div>
    </div>
</div>

<div id="ld_sec9" class="p-Part">
    <div class="inner">
        <div class="top" data-aos="fade-up" data-aos-delay="200">
            <h4>병원급 수술실 기준을 철저하게 갖춘</h4>
            <h3>기본이 다른 <br class="br768">르네의 수술환경</h3>
        </div>
        <ul>
            <li data-aos="fade-up" data-aos-delay="200">
                <div class="img"><img src="/images/landing/ld_sec9_img01.jpg" alt=""></div>
                <div class="txt">
                    <h3>헤파필터 공기 정화</h3>
                    <p>수술실 내 공기를 상시 정화. 감염 위험을 원천 차단합니다.</p>
                </div>
            </li>
            <li data-aos="fade-up" data-aos-delay="200">
                <div class="img"><img src="/images/landing/ld_sec9_img02.jpg" alt=""></div>
                <div class="txt">
                    <h3>비상 대비 전기 보조장치</h3>
                    <p>정전 등 응급 상황에서도 수술이 중단 없이 안전하게 진행됩니다.</p>
                </div>
            </li>
            <li data-aos="fade-up" data-aos-delay="200">
                <div class="img"><img src="/images/landing/ld_sec9_img03.jpg" alt=""></div>
                <div class="txt">
                    <h3>혈압·산소포화도 실시간 모니터링</h3>
                    <p>수술 내내 환자 상태를 정밀 체크. 이상 징후를 즉각 감지합니다.</p>
                </div>
            </li>
            <li data-aos="fade-up" data-aos-delay="200">
                <div class="img"><img src="/images/landing/ld_sec9_img04.jpg" alt=""></div>
                <div class="txt">
                    <h3>산소 공급 & 기관삽관장비</h3>
                    <p>응급 상황 대비 장비를 완비. 어떤 상황에도 즉각 대응 가능합니다.</p>
                </div>
            </li>
        </ul>
    </div>
</div>


<div id="ld_sec10" class="p-Part">
    <div class="s-inner">
        <div class="t_box">
            <div class="talk" data-aos="fade-up" data-aos-delay="200">
                <p>"혹시... 수술 중에 깨면 어떡하죠?"</p>
            </div>
            <div class="talk talk2" data-aos="fade-up" data-aos-delay="200">
                <p>"수술 끝나고 깨지 않을까 걱정이에요."</p>
            </div>
        </div>
        <div class="top">
            <h4 data-aos="fade-up" data-aos-delay="200">그 걱정, 이제 내려놓으세요!</h4>
            <h3 data-aos="fade-up" data-aos-delay="200">르네만의 안전한 마취방식</h3>
        </div>
        <ul>
            <li data-aos="fade-up" data-aos-delay="200">
                <img src="/images/landing/check.png" alt="">
                <h3>깊게 잠들고 <br class="br976">통증은 적게</h3>
                <p>수술 후 금방 눈뜰 수 있는<br> 마취방식을 사용합니다.</p>
            </li>
            <li data-aos="fade-up" data-aos-delay="400">
                <img src="/images/landing/check.png" alt="">
                <h3> 중독 걱정 <br class="br976">ZERO</h3>
                <p>프로포폴 NO!<br> 부작용이 적은 프리세덱스 사용</p>
            </li>
            <li data-aos="fade-up" data-aos-delay="600">
                <img src="/images/landing/check.png" alt="">
                <h3>회복실에서 <br class="br976">신속하게</h3>
                <p>지연 각성 부작용이 적은 마취로 <br> 신속하게 의식을 회복합니다.</p>
            </li>
        </ul>
        <div class="p_img" data-aos="fade-up" data-aos-delay="200"><img src="/images/landing/ld_sec10_img.png" alt=""></div>
        <div class="p_box" data-aos="fade-up" data-aos-delay="200">
            <h3>프리세덱스 (Dexmedetomidine)</h3>
            <p>프로포폴 대신 사용하는 마취 진정 약물로,<br class="br976"> 중독 우려 없이 자연수면에 가까운 진정 상태를 유도합니다.<br> <b>부작용 적은 고가의 마취약제 프리세덱스는 <br class="br976">호흡 억제가 적고 회복이 빠른 것이 특징입니다.</b></p>
        </div>
    </div>
</div>


<div id="ld_sec11" class="p-Part">
    <div class="s-inner">
        <div class="top">
            <h4 data-aos="fade-up" data-aos-delay="200">수술 후가 더욱 중요합니다!</h4>
            <h3 data-aos="fade-up" data-aos-delay="200">꼼꼼한 사후관리는 <br class="br976">역시 르네</h3>
            <p data-aos="fade-up" data-aos-delay="200">합병증부터 재수술까지, <br class="br768"><b>비용 걱정 없이 르네가 끝까지 책임집니다.</b></p>
        </div>
        <div class="cont">
            <ul data-aos="fade-up" data-aos-delay="200">
                <li>
                    <h4>CARE 01</h4>
                    <div class="dot"></div>
                    <div data-aos="zoom-in" data-aos-delay="400">
                        <h3>합병증 완벽 케어</h3>
                        <p>출혈, 혈종, 염증 등 <br>수술 후 발생할 수 있는<br class="br768"> 모든 합병증에 <br>신속하게 대응합니다.</p>
                    </div>
                </li>
                <li>
                    <h4>CARE 02</h4>
                    <div class="dot"></div>
                    <div data-aos="zoom-in" data-aos-delay="600">
                        <h3>재수술비 부담 없음</h3>
                        <p>재수술이 필요한 경우, <br>수술 비용 추가 없이 진행합니다.<br class="br768"> <br>결과로 책임집니다.</p>
                    </div>
                </li>
                <li>
                    <h4>CARE 03</h4>
                    <div class="dot"></div>
                    <div data-aos="zoom-in" data-aos-delay="800">
                        <h3>외래 소독·처치비 무료</h3>
                        <p>내원 시 소독 및 처치 비용을<br> 받지 않습니다.<br class="br768"><br> 회복 과정 전체를 지원합니다.</p>
                        <span>(*보험 약처방은 처방료 발생)</span>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>


<div id="ld_sec12" class="p-Part">
    <div class="s-inner">
        <div class="cont">
            <div class="top">
                <h4 data-aos="fade-up" data-aos-delay="200">결과가 마음에 들지 않으면?</h4>
                <h3 data-aos="fade-up" data-aos-delay="200">1년 이내 무상 재교정</h3>
            </div>
            <ul>
                <li data-aos="fade-up" data-aos-delay="200">
                    <p>회복 과정에서 생긴 <br><b>1~2mm 오차도<br> 그냥 넘기지않습니다.</b></p>
                </li>
                <li data-aos="fade-up" data-aos-delay="200">
                    <p>기존 수술 범위 내<br> <b>1년 내 재교정은 <br>비용부담 없음</b><span>(추가 범위 비용 발생)</span></p>
                </li>
            </ul>
            <h3 data-aos="fade-up" data-aos-delay="200">끝까지 책임지는 르네 여성의원</h3>
        </div>
    </div>
</div>

<div id="ld_sec13" class="p-Part">
    <div class="s-inner">
        <div class="top">
            <h4 data-aos="fade-up" data-aos-delay="200">궁금했던 모든 것, 바로 알려드립니다</h4>
            <h3 data-aos="fade-up" data-aos-delay="200">실시간 카톡 상담으로<br class="br768"> 고민 끝!</h3>
            <p data-aos="fade-up" data-aos-delay="200"><b>실제 상담 고객의 카카오톡 대화 내용</b>입니다.</p>
        </div>
        <ul class="count" data-aos="fade-up" data-aos-delay="200">
            <li>
                <h3>30,000 +</h3>
                <p>누적상담</p>
            </li>
            <li>
                <h3>98%</h3>
                <p>만족도</p>
            </li>
            <li>
                <h3>당일</h3>
                <p>답변완료</p>
            </li>
        </ul>
    </div>
    <div class="kakao_wrap" data-aos="fade-up" data-aos-delay="200">
        <ul class="kakao_slider">
            <li><img src="/images/landing/kko_01.jpg" alt=""></li>
            <li><img src="/images/landing/kko_02.jpg" alt=""></li>
            <li><img src="/images/landing/kko_03.jpg" alt=""></li>
            <li><img src="/images/landing/kko_04.jpg" alt=""></li>
            <li><img src="/images/landing/kko_05.jpg" alt=""></li>
            <li><img src="/images/landing/kko_01.jpg" alt=""></li>
            <li><img src="/images/landing/kko_02.jpg" alt=""></li>
            <li><img src="/images/landing/kko_03.jpg" alt=""></li>
            <li><img src="/images/landing/kko_04.jpg" alt=""></li>
            <li><img src="/images/landing/kko_05.jpg" alt=""></li>
        </ul>
    </div>
</div>

<script>
    $('.kakao_slider').slick({
        centerMode: true,
        centerPadding: '15%',
        slidesToShow: 3,
        arrows: false,
        dots: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 800,
        pauseOnHover: false,
        pauseOnFocus: false,
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    centerPadding: '10%'
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    centerPadding: '15%'
                }
            }
        ]
    });
</script>


<div id="ld_sec14" class="p-Part">
    <div class="s-inner">
        <div class="top">
            <h4 data-aos="fade-up" data-aos-delay="200"><img src="/images/landing/naver.png" alt=""> 네이버 플레이스 실제 후기</h4>
            <h3 data-aos="fade-up" data-aos-delay="200">직접 경험한 분들의 이야기</h3>
        </div>
        <div class="star" data-aos="fade-up" data-aos-delay="200">
            <img src="/images/landing/fivestsars.png" alt="">
            <p>별점 4.8점 · 리뷰수 675건</p>
        </div>
    </div>
    <div class="review_wrap" data-aos="fade-up" data-aos-delay="200">
        <ul class="review_slider">
            <li><img src="/images/landing/n_review01.jpg" alt=""></li>
            <li><img src="/images/landing/n_review02.jpg" alt=""></li>
            <li><img src="/images/landing/n_review03.jpg" alt=""></li>
            <li><img src="/images/landing/n_review04.jpg" alt=""></li>
            <li><img src="/images/landing/n_review05.jpg" alt=""></li>
            <li><img src="/images/landing/n_review06.jpg" alt=""></li>
            <li><img src="/images/landing/n_review07.jpg" alt=""></li>
            <li><img src="/images/landing/n_review01.jpg" alt=""></li>
            <li><img src="/images/landing/n_review02.jpg" alt=""></li>
            <li><img src="/images/landing/n_review03.jpg" alt=""></li>
            <li><img src="/images/landing/n_review04.jpg" alt=""></li>
            <li><img src="/images/landing/n_review05.jpg" alt=""></li>
            <li><img src="/images/landing/n_review06.jpg" alt=""></li>
            <li><img src="/images/landing/n_review07.jpg" alt=""></li>
        </ul>
    </div>
</div>

<script>
    $('.review_slider').slick({
        centerMode: true,
        slidesToShow: 4,
        arrows: false,
        dots: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 800,
        pauseOnHover: false,
        pauseOnFocus: false,
        responsive: [{
                breakpoint: 1480,
                settings: {
                    slidesToShow: 3,
                }
            },
            {
                breakpoint: 980,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                }
            }
        ]
    });
</script>


<div id="ld_sec15" class="p-Part">
    <div class="s-inner">
        <div class="lt">
            <div class="top">
                <h4 data-aos="fade-up" data-aos-delay="200">더 고민하기 전에 나에게 맞는 수술 방법이 있는지 <br>상담으로 확인해보세요!</h4>
                <h3 data-aos="fade-up" data-aos-delay="200">전담 상담 시스템 운영</h3>
            </div>
            <ul class="bot" data-aos="fade-up" data-aos-delay="200">
                <li>
                    <p>담당 원장님<br> 담당 상담직원<br> 1:1 배정</p>
                </li>
                <li>
                    <p>카카오톡 <br> 실시간 상담 가능</p>
                </li>
                <li>
                    <p>수술전·후<br> 지속적 관리</p>
                </li>
            </ul>
        </div>
        <div class="rt">
            <ul>
                <li data-aos="fade-up" data-aos-delay="200">
                    <a href="tel:01023655040">
                        <div class="img"><img src="/images/landing/c_icon01.png" alt=""></div>
                        <div class="txt">
                            <h3>상담팀장 전화</h3>
                            <p>010.2365.5040</p>
                        </div>
                    </a>
                </li>
                <li data-aos="fade-up" data-aos-delay="400">
                    <a href="https://naver.me/5c8DIt68" target="_blank">
                        <div class="img"><img src="/images/landing/c_icon02.png" alt=""></div>
                        <div class="txt">
                            <p>네이버 예약 바로가기</p>
                        </div>
                    </a>
                </li>
                <li data-aos="fade-up" data-aos-delay="600">
                    <a href="http://pf.kakao.com/_Xexmjj/chat" target="_blank">
                        <div class="img"><img src="/images/landing/c_icon03.png" alt=""></div>
                        <div class="txt">
                            <p style="color:#381e1f;">실시간 카톡 상담</p>
                        </div>
                    </a>
                </li>
                <li data-aos="fade-up" data-aos-delay="800">
                    <a href="https://reneclinic.co.kr/pg/bbs/board.php?bo_table=comm02_new" target="_blank">
                        <div class="img"><img src="/images/landing/c_icon04.png" alt=""></div>
                        <div class="txt">
                            <p>온라인 상담</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div id="ld_sec16" class="p-Part">
    <div class="inner">
        <div class="top">
            <h3 data-aos="zoom-in" data-aos-delay="200">르네여성의원은 <br class="br768"><span>범어역 3번 출구에서<br> 70m 거리</span>에 위치하여 있습니다.</h3>
            <ul>
                <li data-aos="zoom-in" data-aos-delay="200">
                    <h4>2호선 범어역</h4>
                    <p>3번 출구 도보 2분</p>
                </li>
                <li data-aos="zoom-in" data-aos-delay="200">
                    <h4>차량 이용시</h4>
                    <p>동대구역 10분 · 대구공항 20분</p>
                </li>
            </ul>
        </div>
        <div class="map-wrap" data-aos="fade-up" data-aos-delay="200">
            <!-- * 카카오맵 - 지도퍼가기 -->
            <!-- 1. 지도 노드 -->
            <div id="daumRoughmapContainer1777267214016" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%; height:100%;"></div>

            <!--
                2. 설치 스크립트
                * 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
            -->
            <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

            <!-- 3. 실행 스크립트 -->
            <script charset="UTF-8">
                new daum.roughmap.Lander({
                    "timestamp": "1777267214016",
                    "key": "msgkm4hkfai"
                }).render();
            </script>
        </div>
        <ul class="link">
            <li data-aos="fade-up" data-aos-delay="200"><a href="https://kko.to/Gk2G04SWXS" target="_blank"><img src="/images/landing/kakao.png" alt="">카카오맵 길찾기</a></li>
            <li data-aos="fade-up" data-aos-delay="200"><a href="" target="_blank"><img src="/images/landing/navermap.png" alt="">네이버지도 길찾기</a></li>
        </ul>
    </div>
</div>


<ul id="Quick2">
    <li><a href="https://reneclinic.co.kr/pg/bbs/board.php?bo_table=comm07"><img src="/images/landing/quick01.png">
            <p>전후사진 <br>보러가기</p>
        </a></li>
    <li><a href="https://reneclinic.co.kr/"><img src="/images/landing/quick02.png">
            <p>홈페이지 <br>바로가기</p>
        </a></li>
</ul>

<div class="footer2">
    <div class="s-inner">
        <ul>
            <li><span>병원명</span> 대구르네여성의원</li>
            <li><span>대표</span> 황인아</li>
            <li><span>사업자등록번호</span> 254-24-01015</li>
            <li><span>주소</span> 대구광역시 동대구로 311 범어애플타워 3층-4층</li>
            <li><span>대표전화</span> 053.753.5040 </li>
        </ul>
        <p>Copyright ⓒ 2017 RENE CLINIC. All Right Reserved.</p>
    </div>
</div>