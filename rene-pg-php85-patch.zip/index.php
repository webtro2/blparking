<?php include "inc/head.php"; ?>
<?php include "inc/link.php"; ?>
<?php include "inc/top.php"; ?>
<?php include_once(G5_LIB_PATH . '/latest.lib.php'); ?>
<?php include_once(G5_BBS_PATH . '/newwin.inc.php'); ?>
<?php
$cf_1_count = isset($config['cf_1']) && trim($config['cf_1']) !== '' ? trim($config['cf_1']) : '1,232';
$main_surgery_count = is_numeric(str_replace(',', '', $cf_1_count)) ? number_format((float)str_replace(',', '', $cf_1_count)) : $cf_1_count;


$cf_2_year = date('Y');
$cf_2_month = date('n');
if (isset($config['cf_2']) && preg_match('/(\d{4})/', $config['cf_2'], $m)) {
    $cf_2_year = $m[1];
}
if (isset($config['cf_3']) && preg_match('/^\d{1,2}$/', trim($config['cf_3'])) && (int) $config['cf_3'] >= 1 && (int) $config['cf_3'] <= 12) {
    $cf_2_month = (int) $config['cf_3'];
} elseif (isset($config['cf_2']) && preg_match('/(\d{1,2})\s*월/', $config['cf_2'], $m)) {
    $cf_2_month = (int) $m[1];
}
$cf_2_date = $cf_2_year . '년 ' . $cf_2_month . '월';
?>



<!-- mVisual -->
<section id="mvWrap">
    <div id="mVisual" class="mvWrap">
        <article class="mv_slider mv1">
            <div class="inner">
                <div class="mtxt">
                    <dl class="tit" data-aos="fade-up" data-aos-delay="100">
                        <dd>소음순수술 <p class="st1">※ <?php echo htmlspecialchars($cf_2_date, ENT_QUOTES, 'UTF-8'); ?> 기준</p>
                        </dd>
                        <dt><?php echo $main_surgery_count; ?><span class="fw-L">건</span></dt>
                    </dl>
                    <h2 data-aos="fade-up" data-aos-delay="200">소음순수술 경험, 숫자로 확인하세요</h2>
                    <p class="t1" data-aos="fade-up" data-aos-delay="300">개인의 형태와 불편함의 원인을 충분히 살펴 <br>자연스러운 균형과 기능적인 편안함을 함께 고려합니다.</p>
                </div>
                <div class="img"><img src="/images/main/mv-img1.png"></div>
            </div>
        </article>

        <article class="mv_slider mv2">
            <div class="inner">
                <div class="mtxt">
                    <dl class="tit" data-aos="fade-up" data-aos-delay="100">
                        <dt>탄력 있는 변화의 시작 <br>다시 찾는 자신감</dt>
                    </dl>
                    <h2 data-aos="fade-up" data-aos-delay="200">르네여성의원만의 정교하고 섬세한 질성형</h2>
                    <p class="t1" data-aos="fade-up" data-aos-delay="300">서서히 잊혀졌던 내 몸의 탄력과 깊은 감동을 <br>지금 바로 되찾아드립니다.</p>
                </div>
            </div>
        </article>
    </div>

    <div class="mvControl">
        <div class="in-box">
            <div class="mvProgress"><span></span></div>
            <button type="button" class="mvPrev">prev</button>
            <p class="num"><span class="mvNow">1</span> / <span class="mvTotal">2</span></p>
            <button type="button" class="mvNext">next</button>
        </div>
    </div>
</section>
<!-- //mVisual -->



<section id="mBg1">

    <div id="mIntro" class="p-Part">
        <div id="mTitle" class="inner">
            <h2>여성의 모든 순간을 위한 케어</h2>
            <h3 class="fc-M1">여성의 오늘을 살피고, 앞으로의 건강까지 생각합니다</h3>
        </div>

        <div class="contWrap">

            <div class="txt">
                <p class="eng fc-M2">A Message from RENE</p>
                <ul>
                    <li>르네여성병원은 여성의 몸과 마음을 세심하게 이해하는 진료를 지향합니다.</li>
                    <li>
                        여성질환부터 검진, 여성성형, 갱년기까지 다양한 고민을 폭넓게 살피며,<br>
                        충분한 상담을 통해 개인의 상태와 필요에 맞는 진료 방향을 함께 찾아갑니다.
                    </li>
                    <li>여성의 건강한 오늘과 더 편안한 내일을 위해 늘 가까이에서 함께하겠습니다.</li>
                </ul>
            </div>

            <div class="introImg introImg01">
                <img src="/images/main/mintro-img1.png" alt="르네여성병원 내부">
            </div>

            <div class="introImg introImg02">
                <img src="/images/main/mintro-img2.png" alt="">
            </div>

        </div>
    </div>


    <div id="mLabia">
        <div class="inner">
            <div id="mTitle">
                <div>
                    <p class="eng fc-M2">RENE SPECIAL CLINIC</p>
                    <h2>1,000례 이상의 수술 경험 <br>대학병원급 의료장비 보유 </h2>
                    <p class="t1">풍부한 수술 경험을 바탕으로 여의사가 직접 <br>상담부터 시술·수술까지 세심하게 진행하며, <br>수술 후 경과 확인과 사후 관리까지 체계적으로 이어갑니다.</p>
                </div>
                <div class="mBtn">
                    <a href="javascript:GoPage('labiaplasty1')" class="active"><span>소음순성형이란?</span></a>
                    <a href="javascript:GoPage('labiaplasty9')"><span>수술 전후 사진</span></a>
                </div>
            </div>
            <div class="contWrap">
                <div class="in-box bg1">
                    <h3>최소절개 <br>소음순수술</h3>
                    <dl>
                        <dt>최소절개 소음순수술</dt>
                        <dd>개인의 형태와 기능적인 부분을 함께 고려한 최소 절개와 미세봉합을 통해 조직 손상을 줄이고 자연스러운 라인과 안정적인 회복을 추구</dd>
                        <a href="javascript:GoPage('labiaplasty2')"></a>
                    </dl>
                </div>
                <div class="in-box bg2">
                    <h3>소음순수술 <br>진행과정</h3>
                    <dl>
                        <dt>소음순수술 진행과정</dt>
                        <dd>개인의 형태와 불편함을 세심하게 확인한 뒤 충분한 상담과 진단을 바탕으로 수술 범위와 방향을 계획하고 디자인부터 회복 관리까지 체계적인 진행</dd>
                        <a href="javascript:GoPage('labiaplasty3')"></a>
                    </dl>
                </div>
                <div class="in-box bg3">
                    <h3>대음순 수술 <br>& 리프팅</h3>
                    <dl>
                        <dt>대음순 수술 & 리프팅</dt>
                        <dd>늘어짐과 볼륨 감소 정도를 확인하고 개인별 형태와 피부 탄력을 고려해 불필요한 조직 정리와 볼륨 보완을 통해 자연스럽고 균형 잡힌 라인 개선을 추구</dd>
                        <a href="javascript:GoPage('labiaplasty4')"></a>
                    </dl>
                </div>
                <div class="in-box bg4">
                    <h3>음핵 리프팅</h3>
                    <dl>
                        <dt>음핵 리프팅</dt>
                        <dd>음핵 주변의 피부와 조직 상태를 확인하고 개인의 구조와 불편함을 고려해 과도한 조직을 정교하게 정리하여 자연스러운 형태와 기능적인 편안함을 함께 추구</dd>
                        <a href="javascript:GoPage('labiaplasty5')"></a>
                    </dl>
                </div>
                <div class="in-box bg5">
                    <h3>레이저 미백</h3>
                    <dl>
                        <dt>레이저 미백</dt>
                        <dd>색소 침착 부위의 피부 상태와 색소 정도를 세밀하게 확인하고 개인별 피부 특성에 맞춘 레이저 적용으로 보다 맑고 균일한 피부톤 개선을 추구</dd>
                        <a href="javascript:GoPage('labiaplasty6')"></a>
                    </dl>
                </div>
                <div class="in-box bg6">
                    <h3>재수술 프로그램</h3>
                    <dl>
                        <dt>재수술 프로그램</dt>
                        <dd>이전 수술 후 남은 불편함과 형태적인 문제를 확인하고 기존 조직과 흉터, 좌우 균형을 고려한 맞춤 재수술 계획으로 자연스러운 형태와 기능 회복을 추구</dd>
                        <a href="javascript:GoPage('labiaplasty7')"></a>
                    </dl>
                </div>
            </div>
            <div class="labiaControl">
                <div class="in-box">
                    <div class="mvProgress"><span></span></div>
                    <button type="button" class="mvPrev">prev</button>
                    <p class="num"><span class="mvNow">1</span> / <span class="mvTotal">6</span></p>
                    <button type="button" class="mvNext">next</button>
                </div>
            </div>

        </div>
    </div>

</section>





<?php if ($is_member) { ?>
    <div id="mReview" class="p-Part-b login-on">
    <?php } else { ?>
        <div id="mReview" class="p-Part-b">
        <?php } ?>
        <div id="mTitle" class="inner">
            <h2>고민의 순간부터 변화 이후까지</h2>
            <p class="t1">혼자 고민했던 불편함과 수술을 결정하기까지의 과정, <br>그리고 변화 이후의 일상을 실제 후기를 통해 확인해보세요.</p>
        </div>

        <div class="contWrap">


            <div class="reviewTrack">
                <?php echo latest('review', 'comm03', 8, 99); ?>

                <!-- <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div>
            <div class="in-box">
                <div class="logout">
                    <h3>소음순수술 리얼후기</h3>
                    <li class="icon"><img src="/images/main/mreview-icon.png"></li>
                    <li class="t1">실제 수술 경험이 담긴 <br>생생한 후기를 <br>로그인 후 확인해보세요.</li>
                    <li class="btn"><a href="#"><span>로그인</span></a></li>
                </div>
                <div class="login">
                    <h3>만족도 높은 소음순 수술 고민하지 마세요</h3>
                    <li class="t1">진짜 진작 할걸 지금 한 걸 후회합니다. 직장 다녀서 저는 토요일 수술했는데 하루 이틀 정도만 따끔따끔하고 피는 3일 정도 소량으로 묻어나오는 정도였습니다.</li>
                    <li class="btn"><a href="#"><span>자세히보기</span></a></li>
                </div>
            </div> -->

            </div>

        </div>

        <div id="moreBtn"><a href="javascript:GoPage('labiaplasty8')"><span>More View</span></a></div>
        </div>






        <div id="mLaser" class="p-Part-b inner">
            <div id="mTitle">
                <div>
                    <p class="eng fc-M2">RENE SPECIAL CLINIC</p>
                    <h2>탄력부터 감각까지, <br>섬세한 케어와 변화</h2>
                    <p class="t1">개인의 상태와 불편함을 세심하게 살펴 <br>충분한 상담을 바탕으로 <br><br class="br1024">탄력과 기능적인 개선을 함께 고려합니다. </p>
                </div>
                <div class="mBtn">
                    <a href="javascript:GoPage('vaginalrepair1')" class="active"><span>질성형이란?</span></a>
                    <a href="javascript:GoPage('vaginalrepair2')"><span>르네 질성형수술</span></a>
                </div>
            </div>

            <div class="contWrap">
                <ul class="in-box">
                    <a href="javascript:GoPage('vaginalrepair3')" aria-label="비비브 2.0">
                        <li class="tit"><span>깊은 탄력</span></li>
                        <h3>비비브 2.0</h3>
                        <li class="img"><img src="/images/main/mlaser-img1.png" alt="비비브 2.0 레이저"></li>
                        <li class="t1"><span>고주파를 이용한 질 탄력 · 볼륨 개선</span></li>
                    </a>
                </ul>
                <ul class="in-box">
                    <a href="javascript:GoPage('vaginalrepair4')" aria-label="베스타">
                        <li class="tit"><span>질벽 탄력</span></li>
                        <h3>베스타</h3>
                        <li class="img"><img src="/images/main/mlaser-img2.png" alt="베스타 레이저"></li>
                        <li class="t1"><span>레이저를 이용한 질 점막 탄력 개선</span></li>
                    </a>
                </ul>
                <ul class="in-box">
                    <a href="javascript:GoPage('vaginalrepair5')" aria-label="소노케어">
                        <li class="tit"><span>보습·탄력</span></li>
                        <h3>소노케어</h3>
                        <li class="img"><img src="/images/main/mlaser-img3.png" alt="소노케어 레이저"></li>
                        <li class="t1"><span>나노초음파를 이용한 보습·탄력 케어</span></li>
                    </a>
                </ul>
                <ul class="in-box">
                    <a href="javascript:GoPage('vaginalrepair6')" aria-label="질필러">
                        <li class="tit"><span>볼륨·축소</span></li>
                        <h3>질필러</h3>
                        <li class="img"><img src="/images/main/mlaser-img4.png" alt="질필러"></li>
                        <li class="t1"><span>콜라겐 필러를 이용한 질 볼륨 · 축소 개선</span></li>
                    </a>
                </ul>
                <ul class="in-box">
                    <a href="javascript:GoPage('vaginalrepair7')" aria-label="오르네샷">
                        <li class="tit"><span>감각개선</span></li>
                        <h3>오르네샷</h3>
                        <li class="img"><img src="/images/main/mlaser-img5.png" alt="오르네샷"></li>
                        <li class="t1"><span>자가혈 성분을 활용한 여성 감각 개선</span></li>
                    </a>
                </ul>
                <ul class="in-box">
                    <a href="javascript:GoPage('vaginalrepair8')" aria-label="리비브">
                        <li class="tit"><span>콜라겐재생</span></li>
                        <h3>리비브</h3>
                        <li class="img"><img src="/images/main/mlaser-img6.png" alt="리비브"></li>
                        <li class="t1"><span>멀티웨이브 고주파를 이용한 콜라겐 · 탄력 개선</span></li>
                    </a>
                </ul>
            </div>

        </div>



        <div class="reneMarquee">
            <div class="reneMarquee-track">
                <span>RENE Women’s Clinic</span>
            </div>
        </div>





        <div id="mYoutube" class="p-Part">
            <div id="mTitle">
                <h2>여성을 이해하는 건강 이야기, RENE</h2>
                <p class="t1">평소 궁금했지만 쉽게 묻기 어려웠던 여성 건강 이야기를 <br class="br480">알기 쉽게 전해드립니다.</p>
                <li class="mbtn"><a href="javascript:GoPage('youtube')"><span>여의사의 산부인과 이야기.</span></a></li>
            </div>

            <div id="youtubeWrap">
                <div class="youtubeInner">

                    <?php
                    if (!function_exists('get_youtube_latest_videos')) {
                        function get_youtube_latest_videos($channel_id, $limit = 5)
                        {
                            $cache_dir = defined('G5_DATA_PATH') ? G5_DATA_PATH . '/cache' : dirname(__FILE__) . '/pg/data/cache';
                            if (!is_dir($cache_dir)) {
                                @mkdir($cache_dir, 0755, true);
                            }
                            $cache_file = $cache_dir . '/yt_long_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $channel_id) . '.json';
                            $cache_time = 3600;

                            $cached_videos = array();
                            if (file_exists($cache_file)) {
                                $cached = @file_get_contents($cache_file);
                                if ($cached) {
                                    $data = json_decode($cached, true);
                                    if (!empty($data) && is_array($data)) {
                                        $cached_videos = $data;
                                        if (!empty($cached_videos) && (time() - filemtime($cache_file) < $cache_time)) {
                                            return array_slice($cached_videos, 0, $limit);
                                        }
                                    }
                                }
                            }

                            $feed_url = 'https://www.youtube.com/feeds/videos.xml?channel_id=' . urlencode($channel_id);
                            $xml_content = '';

                            if (function_exists('curl_init')) {
                                $ch = curl_init();
                                curl_setopt($ch, CURLOPT_URL, $feed_url);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
                                curl_setopt($ch, CURLOPT_TIMEOUT, 3);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                                curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
                                $xml_content = curl_exec($ch);
                                unset($ch);
                            }

                            if (!$xml_content) {
                                $xml_content = @file_get_contents($feed_url);
                            }

                            $long_videos = array();
                            if ($xml_content) {
                                $xml = @simplexml_load_string($xml_content);
                                if ($xml && isset($xml->entry)) {
                                    foreach ($xml->entry as $entry) {
                                        $link = '';
                                        if (isset($entry->link)) {
                                            foreach ($entry->link as $l) {
                                                $attrs = $l->attributes();
                                                if (isset($attrs['href'])) {
                                                    $href = (string)$attrs['href'];
                                                    if ((string)$attrs['rel'] === 'alternate') {
                                                        $link = $href;
                                                        break;
                                                    }
                                                    if (!$link) $link = $href;
                                                }
                                            }
                                        }
                                        if (strpos($link, '/shorts/') !== false) continue;

                                        $title = (string)$entry->title;
                                        if (stripos($title, '#shorts') !== false) continue;

                                        $yt = $entry->children('yt', true);
                                        $video_id = (string)$yt->videoId;
                                        if ($video_id) {
                                            $long_videos[] = array(
                                                'id' => $video_id,
                                                'title' => $title
                                            );
                                        }
                                    }
                                }
                            }

                            $result = array();
                            $seen = array();
                            foreach (array_merge($long_videos, $cached_videos) as $item) {
                                if (empty($item['id']) || isset($seen[$item['id']])) continue;
                                $seen[$item['id']] = true;
                                $result[] = $item;
                                if (count($result) >= $limit) break;
                            }

                            if (count($result) < $limit) {
                                $videos_url = 'https://www.youtube.com/@reneclinic_daegu/videos';
                                $html_page = '';

                                if (function_exists('curl_init')) {
                                    $ch2 = curl_init();
                                    curl_setopt($ch2, CURLOPT_URL, $videos_url);
                                    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
                                    curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, true);
                                    curl_setopt($ch2, CURLOPT_MAXREDIRS, 5);
                                    curl_setopt($ch2, CURLOPT_CONNECTTIMEOUT, 2);
                                    curl_setopt($ch2, CURLOPT_TIMEOUT, 4);
                                    curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, true);
                                    curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Accept-Language: ko-KR,ko;q=0.9,en;q=0.8'));
                                    curl_setopt($ch2, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
                                    $html_page = curl_exec($ch2);
                                    unset($ch2);
                                }
                                if (!$html_page) {
                                    $html_page = @file_get_contents($videos_url);
                                }

                                if ($html_page) {
                                    $found_web = array();
                                    if (preg_match_all('/"videoId":"([a-zA-Z0-9_-]{11})".*?"lockupMetadataViewModel":\{"title":\{"content":"([^"]+)"/s', $html_page, $matches)) {
                                        foreach ($matches[1] as $k => $vid) {
                                            if (isset($found_web[$vid])) continue;
                                            $raw_t = $matches[2][$k];
                                            $t = json_decode('"' . $raw_t . '"');
                                            if (!$t) {
                                                $t = strip_tags(html_entity_decode($raw_t, ENT_QUOTES, 'UTF-8'));
                                            }
                                            $found_web[$vid] = trim($t);
                                        }
                                    }

                                    foreach ($found_web as $vid => $vtitle) {
                                        if (isset($seen[$vid])) continue;
                                        if (stripos($vtitle, '#shorts') !== false) continue;
                                        $seen[$vid] = true;
                                        $result[] = array(
                                            'id' => $vid,
                                            'title' => $vtitle ? $vtitle : '르네여성의원 유튜브 영상'
                                        );
                                        if (count($result) >= $limit) break;
                                    }
                                }
                            }

                            if (!empty($result)) {
                                @file_put_contents($cache_file, json_encode($result, JSON_UNESCAPED_UNICODE));
                                return $result;
                            }

                            return !empty($cached_videos) ? array_slice($cached_videos, 0, $limit) : array();
                        }
                    }

                    $yt_channel_id = 'UC-jDMqzWRJj16_HHyi4OX1Q';
                    $yt_video_list = get_youtube_latest_videos($yt_channel_id, 5);
                    ?>

                    <div class="youtube-slider">
                        <?php foreach ($yt_video_list as $yt_item) { ?>
                            <div class="youtube-item">
                                <iframe src="https://www.youtube.com/embed/<?php echo htmlspecialchars($yt_item['id']); ?>" loading="lazy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                                <div class="youtube-title"><?php echo htmlspecialchars($yt_item['title']); ?></div>
                            </div>
                        <?php } ?>
                    </div>

                    <button type="button" class="youtube-prev"></button>
                    <button type="button" class="youtube-next"></button>

                </div>
            </div>

        </div>








        <div id="mDoctor" class="p-Part">

            <div id="mTitle">
                <h2>여성의 마음까지 이해하는 <br class="br976">4인의 산부인과 전문의</h2>
                <p class="t1">르네여성의원은 산부인과 전문의 4인의 협진 시스템을 바탕으로 <br>충분한 상담을 통해 한 분 한 분에게 필요한 진료 방향을 함께 찾아갑니다.</p>
            </div>

            <div id="mdoctorWrap">
                <section class="slider-cont">
                    <div class="cont">
                        <div class="txt">
                            <div class="in-box">
                                <h3>김수정 원장</h3>
                                <p class="t2 fc-M1">산부인과전문의</p>
                                <p class="dot"></p>
                                <ul>
                                    <li>연세대학교 원주의과대학 졸업</li>
                                    <li>경북대학교 인턴 수료</li>
                                    <li>경북대학교 산부인과 전공의 수료</li>
                                </ul>
                                <ul>
                                    <li>대한산부인과학회 정회원</li>
                                    <li>대한초음파학회 정회원</li>
                                    <li>대한폐경기학회 정회원</li>
                                </ul>
                                <div id="mTitle">
                                    <div class="mBtn">
                                        <a href="javascript:GoPage('vaginalrepair1')" class="active"><span>약력·진료스케줄</span></a>
                                        <a href="javascript:GoPage('dr-kim')"><span>칼럼보기</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="img"><img src="/images/main/mdoctor-img1-on.png"></div>
                    </div>
                    <div class="cont">
                        <div class="txt">
                            <div class="in-box">
                                <h3>탁지영 원장</h3>
                                <p class="t2 fc-M1">산부인과전문의</p>
                                <p class="dot"></p>
                                <ul>
                                    <li>경북대학교병원 산부인과 전문의 취득</li>
                                    <li>경북대학교병원 산부인과 전공의 수료</li>
                                    <li>경북대학교병원 수련의</li>
                                    <li>경북대학교 의학전문대학원 의학석사</li>
                                    <li>전) 블루미 의원 원장</li>
                                </ul>
                                <ul>
                                    <li>대한산부인과학회 정회원</li>
                                    <li>대한여성성의학회 정회원</li>
                                    <li>대한폐경학회 정회원</li>
                                </ul>
                                <div id="mTitle">
                                    <div class="mBtn">
                                        <a href="javascript:GoPage('vaginalrepair1')" class="active"><span>약력·진료스케줄</span></a>
                                        <a href="javascript:GoPage('dr-tak')"><span>칼럼보기</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="img"><img src="/images/main/mdoctor-img2-on.png"></div>
                    </div>
                    <div class="cont">
                        <div class="txt">
                            <div class="in-box">
                                <h3>이지영 원장</h3>
                                <p class="t2 fc-M1">산부인과전문의</p>
                                <p class="dot"></p>
                                <ul>
                                    <li>영남대학교 의과대학 졸업</li>
                                    <li>경북대학교 의과대학 대학원 졸업 의학석사</li>
                                    <li>경북대학교병원 산부인과 전공의</li>
                                    <li>경북대학교병원 산부인과 임상강사</li>
                                    <li>전) 미래여성병원 과장</li>
                                </ul>
                                <ul>
                                    <li>대한산부인과학회 정회원</li>
                                    <li>대한산부인과초음파학회 정회원</li>
                                    <li>대한모체태아의학회 정회원</li>
                                </ul>
                                <div id="mTitle">
                                    <div class="mBtn">
                                        <a href="javascript:GoPage('vaginalrepair1')" class="active"><span>약력·진료스케줄</span></a>
                                        <a href="javascript:GoPage('dr-lee')"><span>칼럼보기</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="img"><img src="/images/main/mdoctor-img3-on.png"></div>
                    </div>
                    <div class="cont">
                        <div class="txt">
                            <div class="in-box">
                                <h3>황인아 원장</h3>
                                <p class="t2 fc-M1">산부인과전문의</p>
                                <p class="dot"></p>
                                <ul>
                                    <li>경북대학교 의과대학 졸업</li>
                                    <li>경북대학교 인턴 수료</li>
                                    <li>경북대학교 의과대학 대학원 졸업 의학석사</li>
                                    <li>경북대학교 산부인과 전공의 수료</li>
                                    <li>전) 시지 파티마병원 과장</li>
                                    <li>전) 미즈맘병원 산부인과 원장</li>
                                    <li>전) 황인아산부인과 원장</li>
                                </ul>
                                <ul>
                                    <li>대한폐경학회 폐경 전문 과정 이수</li>
                                    <li>E.S.A.G 유럽여성성형학회 시니어 멤버</li>
                                    <li>국제여성성건강학회(ISSWSH) 정회원</li>
                                </ul>
                                <div id="mTitle">
                                    <div class="mBtn">
                                        <a href="javascript:GoPage('intro1')" class="active"><span>약력·진료스케줄</span></a>
                                        <a href="javascript:GoPage('dr-hwang')"><span>칼럼보기</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="img"><img src="/images/main/mdoctor-img4-on.png"></div>
                    </div>
                </section>
                <section class="slider-nav">
                    <div class="img">
                        <img src="/images/main/mdoctor-img2.png">
                        <p class="t1">탁지영 원장</p>
                    </div>
                    <div class="img">
                        <img src="/images/main/mdoctor-img3.png">
                        <p class="t1">이지영 원장</p>
                    </div>
                    <div class="img">
                        <img src="/images/main/mdoctor-img4.png">
                        <p class="t1">황인아 원장</p>
                    </div>
                    <div class="img">
                        <img src="/images/main/mdoctor-img1.png">
                        <p class="t1">김수정 원장</p>
                    </div>
                </section>

                <div class="drControl">
                    <div class="in-box">
                        <div class="mvProgress"><span></span></div>
                        <button type="button" class="mvPrev">prev</button>
                        <p class="num"><span class="mvNow">1</span> / <span class="mvTotal">6</span></p>
                        <button type="button" class="mvNext">next</button>
                    </div>
                </div>

            </div>

        </div>





        <div id="mClinic" class="p-Part">
            <div class="inner">
                <div class="titWrap">
                    <div id="mTitle">
                        <h2>여성의 고민은 같아 보여도, <br>필요한 진료는 모두 다릅니다.</h2>
                        <p class="t1">풍부한 임상 경험과 섬세한 진료로 <br class="br480">여성의 고민을 더 세심하게 살핍니다.</p>
                    </div>
                    <div class="slick-control">
                        <div class="custom-arrows">
                            <button class="prevArrow rank-prev"></button>
                            <button class="nextArrow rank-next"></button>
                        </div>
                    </div>
                </div>
                <div class="mClinicSlick" data-aos="fade-left" data-aos-delay="200">
                    <div class="box">
                        <a href="javascript:GoPage('breast1')">
                            <li class="img"><img src="/images/main/mclinic-img1.png" alt="유방갑상선센터"></li>
                            <dl>
                                <dt><span class="fc-M1">유방·갑상선</span>센터</dt>
                                <dd>여성에게 중요한 유방과 갑상선 건강을 <br>정기적인 검진과 진료로 세심하게 살펴봅니다.</dd>
                            </dl>
                        </a>
                    </div>
                    <div class="box">
                        <a href="javascript:GoPage('waxing1')">
                            <li class="img"><img src="/images/main/mclinic-img2.png" alt="여성제모클리닉"></li>
                            <dl>
                                <dt><span class="fc-M1">여성제모</span>클리닉</dt>
                                <dd>민감한 부위까지 피부 상태를 고려해 <br>보다 깔끔하고 편안한 제모를 도와드립니다.</dd>
                            </dl>
                        </a>
                    </div>
                    <div class="box">
                        <a href="javascript:GoPage('checkup1')">
                            <li class="img"><img src="/images/main/mclinic-img3.png" alt="여성검진센터"></li>
                            <dl>
                                <dt><span class="fc-M1">여성검진</span>센터</dt>
                                <dd>현재의 건강 상태를 확인하고 <br>여성의 생애주기에 맞는 검진을 제공합니다.</dd>
                            </dl>
                        </a>
                    </div>
                    <div class="box">
                        <a href="javascript:GoPage('climac1')">
                            <li class="img"><img src="/images/main/mclinic-img4.png" alt="갱년기클리닉"></li>
                            <dl>
                                <dt><span class="fc-M1">갱년기</span>클리닉</dt>
                                <dd>몸과 마음에 나타나는 다양한 변화를 살펴 <br>갱년기 시기의 건강관리를 함께합니다.</dd>
                            </dl>
                        </a>
                    </div>
                    <div class="box">
                        <a href="javascript:GoPage('clinic1')">
                            <li class="img"><img src="/images/main/mclinic-img5.png" alt="여성질환클리닉"></li>
                            <dl>
                                <dt><span class="fc-M1">여성질환</span>클리닉</dt>
                                <dd>여성에게 나타나는 다양한 증상을 세심하게 살펴 <br>건강한 일상을 위한 진료를 함께합니다.</dd>
                            </dl>
                        </a>
                    </div>

                </div>
            </div>
        </div>






        <div id="mLocation" class="inner p-Part-b">
            <div id="mTitle">
                <h2>진료의 시작부터 회복까지 <br class="br976">세심하게 함께하는 것</h2>
                <h3 class="fc-M1">르네여성의원이 생각하는 프리미엄 여성 진료입니다.</h3>
            </div>

            <div class="contWrap">
                <div class="mMap">
                    <!-- * 카카오맵 - 지도퍼가기 -->
                    <!-- 1. 지도 노드 -->
                    <div id="daumRoughmapContainer1790817882605" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100%"></div>
                    <!--
			2. 설치 스크립트
			* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
		-->
                    <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://t1.kakaocdn.net/kakaomapweb/roughmap/loader/prod/roughmapLoader.js"></script>

                    <!-- 3. 실행 스크립트 -->
                    <script charset="UTF-8">
                        new daum.roughmap.Lander({
                            "timestamp": "1790817882605",
                            "key": "2hwgxcmnqsg"
                        }).render();
                    </script>
                </div>
                <div class="cont">
                    <div class="in-box">
                        <div class="text">
                            <h3 class="tit">오시는 길</h3>
                            <div class="txt">
                                <dl>
                                    <dt>대구시 동대구로 311 범어애플타워 3층, 4층</dt>
                                    <dd class="st1">※ 지하철 2호선 범어역 3번출구 [도보 1분]</dd>
                                </dl>
                            </div>
                        </div>
                        <div class="text">
                            <h3 class="tit">진료안내</h3>
                            <div class="txt">
                                <h3 class="tel fc-M1">053) 753-5040</h3>
                                <dl class="dl-tel">
                                    <dd>유방·갑상선센터</dd>
                                    <dt>053) 753-5030</dt>
                                </dl>
                                <ul class="link">
                                    <li class="bg1"><a href="javascript:GoPage('kakao')"><span>카톡상담</span></a></li>
                                    <li class="bg2"><a href="javascript:GoPage('comm2')"><span>온라인상담</span></a></li>
                                    <li class="bg3"><a href="javascript:GoPage('naver')"><span>진료예약</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="text">
                            <h3 class="tit">진료시간</h3>
                            <div class="txt">
                                <ul class="hour">
                                    <li><span>월 · 목</span> AM 10:00 - PM 8:00</li>
                                    <li><span>화 · 수 · 금</span> AM 10:00 - PM 6:00</li>
                                    <li><span>토요일</span> AM 10:00 - PM 2:00</li>
                                    <li><span>점심시간</span> PM 1:00 - PM 2:00</li>
                                    <li><span>휴진일</span> 일요일·공휴일</li>
                                </ul>
                                <dl>
                                    <dd class="st1">※ 토요일은 점심시간 없이 진료합니다.</dd>
                                </dl>
                            </div>
                        </div>
                        <div class="text">
                            <h3 class="tit">주차안내</h3>
                            <div class="txt">
                                <ul class="pk">
                                    <li><span>애플타워 지하주차장</span> 본원 건물 지하주차장</li>
                                    <li><span>애플2타워 주차장</span> 수성구 동대구로 59길 8-12 [도보 1분]</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <script type="text/javascript" src="/js/main.js"></script>
        <?php include "inc/bottom.php"; ?>