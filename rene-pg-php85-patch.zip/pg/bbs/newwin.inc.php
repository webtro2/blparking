<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

$sql = " select * from {$g5['new_win_table']}
          where '" . G5_TIME_YMDHIS . "' between nw_begin_time and nw_end_time
            and nw_device IN ( 'both', 'pc' )
          order by nw_id desc ";
$result = sql_query($sql, false);

$popups = array();
if ($result) {
    while ($row = sql_fetch_array($result)) {
        $popups[] = $row;
    }
}
$popup_cnt = count($popups);
?>
<script>
    // 자바스크립트에서 사용하는 전역변수 선언
    var g5_url = "<?php echo G5_URL ?>";
    var g5_bbs_url = "<?php echo G5_BBS_URL ?>";
    var g5_is_member = "<?php echo isset($is_member) ? $is_member : ''; ?>";
    var g5_is_admin = "<?php echo isset($is_admin) ? $is_admin : ''; ?>";
    var g5_is_mobile = "<?php echo G5_IS_MOBILE ?>";
    var g5_bo_table = "<?php echo isset($bo_table) ? $bo_table : ''; ?>";
    var g5_sca = "<?php echo isset($sca) ? $sca : ''; ?>";
    var g5_editor = "<?php echo ($config['cf_editor'] && $board['bo_use_dhtml_editor']) ? $config['cf_editor'] : ''; ?>";
    var g5_cookie_domain = "<?php echo G5_COOKIE_DOMAIN ?>";
    <?php if (defined('G5_IS_ADMIN')) { ?>
        var g5_admin_url = "<?php echo G5_ADMIN_URL; ?>";
    <?php } ?>
</script>
<script src="<?php echo get_versioned_asset_url(G5_JS_URL . '/common.js'); ?>"></script>
<script type="text/javascript" src="<?= G5_JS_URL ?>/popevent.js"></script>

<!-- font awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">


<style>
    #pop_win a {
        text-decoration: none;
    }

    #popchange {
        position: relative;
        left: 0px;
        top: 0px;
        width: 100%;
        margin: 0;
        padding: 0px;
        text-align: center;
        visibility: visible;
        z-index: 9999;
    }

    #popchange ul {
        list-style: none;
        aspect-ratio: 500/707;
        position: relative;
        overflow: hidden;
    }

    #popchange ul img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    #popchange ul>li {
        position: absolute;
        top: 0;
        left: 0;
        text-align: center;
        display: block;
        width: 100%;
        height: 100%;
        aspect-ratio: 500/707;
        background: #fff;
        overflow: hidden;
        min-height: 1px;
    }

    #popchange ul>li>p {}

    #popchange ul>li br {
        display: none !important;
    }

    #divMenu {
        position: relative;
        margin: 0;
        text-align: center;
        visibility: visible;
        width: 100%;
    }

    .pagination {
        list-style: none;
        background: transparent;
        width: 100%;
        display: flex;
        height: 100%;
        flex-wrap: wrap;
    }

    .pagination li {
        position: relative;
        width: 25%;
        height: 40px;
        padding: 0px;
        color: #fff;
        background: #000;
        text-align: center;
        cursor: pointer;
        opacity: 1.0;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: all .5s ease;
        -webkit-transition: all .5s ease;
        background: #eee;
    }

    .pagination li:hover {
        color: #000;
        background: ;
        opacity: 1.0;
    }

    li.current {
        background: #A57C6F;
        color: #fff;
        opacity: 1.0;
    }

    .pagination li p {
        color: #fff;
        text-align: center;
        display: block;
        width: 100%;
        font-size: 14px;
    }

    .pagination li p.p1 {
        color: #444;
        text-align: center;
        display: block;
        width: 100%;
        font-size: 16px;
        font-weight: 500;
        word-break: keep-all;
    }

    .pagination li.current p,
    .pagination li.current p.p1 {
        font-weight: 700;
        color: #fff;
    }

    #footerfix {
        position: relative;
        left: 0px;
        top: 0px;
        z-index: 99999999;
    }

    .hd_pops_footer {
        padding: 0;
        background: transparent;
        color: #fff;
        text-align: left;
        position: relative;
        height: 36px;
        width: 100%;
        clear: both;
        background-color: transparent;
    }

    #pop_win {
        width: 500px;
        /*width: 70vh;*/
        position: fixed;
        z-index: 9999;
        left: 50%;
        top: 60px;
        transform: translate(-50%, 0);
        padding-top: 30px;
        max-height: 90vh;
        overflow-y: auto;
    }

    #pop_win::-webkit-scrollbar {
        display: none;
    }

    .hd_pops_footer {
        position: absolute;
        right: 0;
        top: -32px;
        bottom: auto;
        top: 0;
    }

    .hd_pops_close {
        float: right;
        clear: both;
        border: 0;
        cursor: pointer;
    }

    .hd_pops_close i {
        font-size: 24px;
        color: #fff;
        padding: 3px 10px;
    }

    .hd_pops_footer .hd_pops_close {
        background: transparent;
        padding-top: 0;
        padding-right: 0;
    }

    .hd_pops_reject {
        border: 0;
        cursor: pointer;
        position: relative;
        font-size: 12px;
        position: absolute;
        right: 40px;
        background: none !important;
    }

    .hd_pops_reject:hover::after {
        content: '';
        position: absolute;
        background-color: #fff;
        width: 80%;
        height: 1px;
        bottom: 1px;
        right: 5px;
    }

    .pop_bg {
        width: 100%;
        height: 100%;
        display: block;
        background-color: rgba(0, 0, 0, 0.6);
        position: fixed;
        left: 0;
        top: 0;
        z-index: 2999;
    }

    .pop_bg.off {
        display: none;
    }

    @media all and (max-width:1024px) {
        #divMenu {
            max-height: 100%;
        }

        .pagination li p.p1 {
            font-size: 16px;
        }
    }

    @media all and (max-width:830px) {
        #pop_win {}

        #divMenu {
            width: 100%;
            display: block;
        }

        #popchange {}

        .pagination {
            width: 100%;
            flex-wrap: wrap;
        }

        .pagination li {
            width: 50%;
        }

        .pagination li p {
            font-size: 11px;
        }

        .pagination li p.p1 {
            font-size: 13px;
        }
    }

    @media all and (max-width:568px) {
        #pop_win {
            width: 70vw;
            top: 40px;
        }

        #popchange {}

        .pagination {
            flex-wrap: wrap;
            gap: 0;
            height: auto;
        }

        .pagination li {
            width: 33.333%;
            margin: 0;
            height: 30px;
        }

        .hd_pops_footer {
            top: 0;
        }



    }
</style>
<!-- 팝업레이어 시작 { -->
<?php if ($popup_cnt > 0) { ?>
    <?php if (empty($_COOKIE["pop_win"])) { ?>

        <div id="pop_win">
            <div id="popchange" style="z-index:2005;">
                <ul id="changes">
                    <?php
                    foreach ($popups as $i => $nw) {
                        echo "<li>";
                        echo conv_content($nw['nw_content'], 1);
                        echo "</li>";
                    } ?>
                </ul>
            </div>
            <div id="divMenu">
                <ul id="pagination" class="pagination">
                    <?php
                    foreach ($popups as $i => $nw2) {
                    ?>
                        <li onmouseover="popchange.pos(<?php echo $i; ?>)">
                            <p class="p1"><?php echo htmlspecialchars($nw2['nw_subject']); ?></p>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <div class="hd_pops_footer">
                <button type="button" class="hd_pops_reject" style="color: #fff; padding: 5px 10px"><i class="fa fa-check-square" aria-hidden="true"></i> &nbsp;<strong>24</strong>시간 동안 창 닫기</button>
                <button type="button" class="hd_pops_close"><i class="fa fa-times" aria-hidden="true"></i></button>
            </div>


        </div>

        <div class="pop_bg"></div>
    <?php } ?>


    <script type="text/javascript">
        var popchange = new TINY.fader.fade('popchange', {
            id: 'changes',
            auto: 1,
            resume: true,
            navid: 'pagination',
            activeclass: 'current',
            visible: true,
            position: 0
        });
    </script>
    <script>
        $(function() {
            $(".hd_pops_reject").click(function() {
                $("#pop_win").hide();
                $('.pop_bg').addClass('off');
                set_cookie('pop_win', 1, 24, g5_cookie_domain);
            });

            $('.hd_pops_close').click(function() {
                $("#pop_win").hide();
                $('.pop_bg').addClass('off');
            });
            $("#hd").css("z-index", 1000);
        });
    </script>
<?php } ?>
<!-- } 팝업레이어 끝 -->