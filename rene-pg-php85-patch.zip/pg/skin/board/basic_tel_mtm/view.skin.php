<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="' . $board_skin_url . '/style.css">', 0);
if ($is_admin && !$view['wr_1'])
    sql_fetch(" update $write_table set wr_1='확인중' where wr_id='{$view['wr_id']}' ");
?>

<script src="<?php echo G5_JS_URL; ?>/viewimageresize.js"></script>

<!-- 게시물 읽기 시작 { -->

<!-- 게시물 상단 버튼 시작 { -->
<div class="board-btn bo-v-btn-wrap">
    <div class="bo-v-btn-left">
        <?php if ($update_href) { ?><a href="<?php echo $update_href ?>" class="btn-bo-modify">수정</a><?php } ?>
        <?php if ($delete_href) { ?><a href="<?php echo $delete_href ?>" class="btn-bo-delete" onclick="del(this.href); return false;">삭제</a><?php } ?>
        <?php if ($copy_href) { ?><a href="<?php echo $copy_href ?>" class="btn-bo-copy" onclick="board_move(this.href); return false;">복사</a><?php } ?>
        <?php if ($move_href) { ?><a href="<?php echo $move_href ?>" class="btn-bo-move" onclick="board_move(this.href); return false;">이동</a><?php } ?>
    </div>
    <div class="bo-v-btn-right">
        <?php if ($search_href) { ?><a href="<?php echo $search_href ?>" class="btn-bo-search">검색목록</a><?php } ?>
        <a href="<?php echo $list_href ?>" class="btn-bo-list" title="목록">목록</a>
        <?php if ($reply_href) { ?><a href="<?php echo $reply_href ?>" class="btn-bo-reply" title="답변">답변</a><?php } ?>
        <?php if ($write_href) { ?>
            <a href="<?php echo $write_href ?>" class="btn-bo-write" title="글쓰기">글쓰기</a>
        <?php } else if ($bo_table == "comm02" || $bo_table == "comm03") { ?>
            <a href="/pg/bbs/write.php?bo_table=<?php echo $bo_table ?>" class="btn-bo-write" title="글쓰기">글쓰기</a>
        <?php } ?>
    </div>
</div>
<!-- } 게시물 상단 버튼 끝 -->

<article id="bo_v" style="width:<?php echo $width; ?>">
    <header>
        <h2 id="bo-v-title">
            <span class="bo-v-tit">
                <?php if ($view['ca_name']) { ?>
                    <span class="bo-v-cate">[<?php echo $view['ca_name']; ?>]</span>
                    <?php echo $view['ca_name']; ?> 전화상담 신청
                <?php } else { ?>
                    <?php echo get_text($view['wr_subject']); ?>
                <?php } ?>
            </span>
        </h2>
    </header>
    <section id="bo-v-info">
        <h2>페이지 정보</h2>
        <div class="profile-info">
            <?php if ($board['bo_use_sideview'] && function_exists('get_member_profile_img')) { ?>
                <span class="pf-img"><?php echo get_member_profile_img($view['mb_id']) ?></span>
            <?php } ?>
            <strong><span class="sound_only">작성자</span><?php echo $view['name'] ?><?php if ($is_ip_view) {
                                                                                        echo "<span class=\"article-ip\">[{$ip}]</span>";
                                                                                    } ?></strong>
        </div>
        <div class="article-info">
            <strong class="article-comment"><span class="sound_only">답변</span><a href="#bo_vc"><?php echo number_format($view['wr_comment']) ?>건</a></strong>
            <strong class="article-hit"><span class="sound_only">조회</span><?php echo number_format($view['wr_hit']) ?>회</strong>
            <strong class="article-date"><span class="sound_only">작성일</span><?php echo str_replace("-", ".", date("y-m-d H:i", strtotime($view['wr_datetime']))); ?></strong>
        </div>
    </section>

    <section id="bo_v_atc">
        <h2 id="bo_v_atc_title">본문</h2>
        <?php if (isset($view['wr_2']) && $view['wr_2']) { ?><p class="info"><b>전화번호</b> : <?php echo get_text($view['wr_2']); ?></p><?php } ?>
        <?php if (isset($view['wr_3']) && $view['wr_3']) { ?><p class="info"><b>희망날짜</b> : <?php echo get_text($view['wr_3']); ?></p><?php } ?>
        <?php if (isset($view['wr_4']) && $view['wr_4']) { ?><p class="info"><b>희망시간</b> : <?php echo get_text($view['wr_4']); ?></p><?php } ?>
        <?php if (isset($view['ca_name']) && $view['ca_name']) { ?><p class="info"><b>상담분야</b> : <?php echo get_text($view['ca_name']); ?></p><?php } ?>

        <?php
        // 파일 이미지 출력
        $v_img_count = count($view['file']);
        if ($v_img_count) {
            echo "<div id=\"bo_v_img\">\n";
            foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
                if (isset($view['file'][$i]['view']) && $view['file'][$i]['view']) {
                    echo get_view_thumbnail($view['file'][$i]['view']);
                }
            }
            echo "</div>\n";
        }
        ?>

        <!-- 본문 내용 시작 { -->
        <?php if (trim($view['content']) && $view['content'] != '전화상담 신청') { ?>
            <div id="bo_v_con"><?php echo get_view_thumbnail($view['content']); ?></div>
        <?php } ?>
        <!-- } 본문 내용 끝 -->

        <?php if ($is_signature) { ?><p><?php echo $signature ?></p><?php } ?>

        <!--  추천 비추천 시작 { -->
        <?php if ($good_href || $nogood_href) { ?>
            <div id="bo_v_act">
                <?php if ($good_href) { ?>
                    <span class="bo_v_act_gng">
                        <a href="<?php echo $good_href . '&amp;' . $qstr ?>" id="good_button" class="bo_v_good"><span class="sound_only">추천</span><strong><?php echo number_format($view['wr_good']) ?></strong></a><b id="bo_v_act_good"></b>
                    </span>
                <?php } ?>
                <?php if ($nogood_href) { ?>
                    <span class="bo_v_act_gng">
                        <a href="<?php echo $nogood_href . '&amp;' . $qstr ?>" id="nogood_button" class="bo_v_nogood"><span class="sound_only">비추천</span><strong><?php echo number_format($view['wr_nogood']) ?></strong></a><b id="bo_v_act_nogood"></b>
                    </span>
                <?php } ?>
            </div>
            <?php } else {
            if ($board['bo_use_good'] || $board['bo_use_nogood']) {
            ?>
                <div id="bo_v_act">
                    <?php if ($board['bo_use_good']) { ?><span class="bo_v_good"><span class="sound_only">추천</span><strong><?php echo number_format($view['wr_good']) ?></strong></span><?php } ?>
                    <?php if ($board['bo_use_nogood']) { ?><span class="bo_v_nogood"><span class="sound_only">비추천</span><strong><?php echo number_format($view['wr_nogood']) ?></strong></span><?php } ?>
                </div>
        <?php
            }
        }
        ?>
        <!-- }  추천 비추천 끝 -->
    </section>

    <?php
    $cnt = 0;
    if ($view['file']['count']) {
        foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
            if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view'])
                $cnt++;
        }
    }
    ?>

    <?php if ($cnt) { ?>
        <!-- 첨부파일 시작 { -->
        <section id="bo_v_file">
            <h2>첨부파일</h2>
            <ul>
                <?php
                // 가변 파일
                foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
                    if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view']) {
                ?>
                        <li>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <a href="<?php echo $view['file'][$i]['href']; ?>" class="view_file_download">
                                <strong><?php echo $view['file'][$i]['source'] ?></strong>
                            </a>
                            <?php echo $view['file'][$i]['content'] ?> (<?php echo $view['file'][$i]['size'] ?>)
                            <span class="bo_v_file_cnt"><?php echo $view['file'][$i]['download'] ?>회 다운로드 | DATE : <?php echo $view['file'][$i]['datetime'] ?></span>
                        </li>
                <?php
                    }
                }
                ?>
            </ul>
        </section>
        <!-- } 첨부파일 끝 -->
    <?php } ?>

    <?php if (array_filter($view['link'])) { ?>
        <!-- 관련링크 시작 { -->
        <section id="bo_v_link">
            <h2>관련링크</h2>
            <ul>
                <?php
                // 링크
                $cnt = 0;
                for ($i = 1; $i <= count($view['link']); $i++) {
                    if ($view['link'][$i]) {
                        $cnt++;
                        $link = cut_str($view['link'][$i], 70);
                ?>
                        <li>
                            <i class="fa fa-link" aria-hidden="true"></i> <a href="<?php echo $view['link_href'][$i] ?>" target="_blank">

                                <strong><?php echo $link ?></strong>
                            </a>
                            <span class="bo_v_link_cnt"><?php echo $view['link_hit'][$i] ?>회 연결</span>
                        </li>
                <?php
                    }
                }
                ?>
            </ul>
        </section>
        <!-- } 관련링크 끝 -->
    <?php } ?>

    <!-- 게시물 하단 버튼 시작 { -->
    <div class="board-btn bo-v-btn-wrap">
        <div class="bo-v-btn-left">
            <?php if ($update_href) { ?><a href="<?php echo $update_href ?>" class="btn-bo-modify">수정</a><?php } ?>
            <?php if ($delete_href) { ?><a href="<?php echo $delete_href ?>" class="btn-bo-delete" onclick="del(this.href); return false;">삭제</a><?php } ?>
            <?php if ($copy_href) { ?><a href="<?php echo $copy_href ?>" class="btn-bo-copy" onclick="board_move(this.href); return false;">복사</a><?php } ?>
            <?php if ($move_href) { ?><a href="<?php echo $move_href ?>" class="btn-bo-move" onclick="board_move(this.href); return false;">이동</a><?php } ?>
        </div>
        <div class="bo-v-btn-right">
            <?php if ($search_href) { ?><a href="<?php echo $search_href ?>" class="btn-bo-search">검색목록</a><?php } ?>
            <a href="<?php echo $list_href ?>" class="btn-bo-list" title="목록">목록</a>
            <?php if ($reply_href) { ?><a href="<?php echo $reply_href ?>" class="btn-bo-reply" title="답변">답변</a><?php } ?>
            <?php if ($write_href) { ?>
                <a href="<?php echo $write_href ?>" class="btn-bo-write" title="글쓰기">글쓰기</a>
            <?php } else if ($bo_table == "comm02" || $bo_table == "comm03") { ?>
                <a href="/pg/bbs/write.php?bo_table=<?php echo $bo_table ?>" class="btn-bo-write" title="글쓰기">글쓰기</a>
            <?php } ?>
        </div>
    </div>
    <!-- } 게시물 하단 버튼 끝 -->

    <?php
    // 코멘트 입출력
    include_once(G5_BBS_PATH . '/view_comment.php');
    ?>

</article>
<!-- } 게시판 읽기 끝 -->

<script>
    <?php if ($board['bo_download_point'] < 0) { ?>
        $(function() {
            $("a.view_file_download").click(function() {
                if (!g5_is_member) {
                    alert("다운로드 권한이 없습니다.\n회원이시라면 로그인 후 이용해 보십시오.");
                    return false;
                }

                var msg = "파일을 다운로드 하시면 포인트가 차감(<?php echo number_format($board['bo_download_point']) ?>점)됩니다.\n\n포인트는 게시물당 한번만 차감되며 다음에 다시 다운로드 하셔도 중복하여 차감하지 않습니다.\n\n그래도 다운로드 하시겠습니까?";

                if (confirm(msg)) {
                    var href = $(this).attr("href") + "&js=on";
                    $(this).attr("href", href);

                    return true;
                } else {
                    return false;
                }
            });
        });
    <?php } ?>

    function board_move(href) {
        window.open(href, "boardmove", "left=50, top=50, width=500, height=550, scrollbars=1");
    }
</script>

<script>
    $(function() {
        $("a.view_image").click(function() {
            window.open(this.href, "large_image", "location=yes,links=no,toolbar=no,top=10,left=10,width=10,height=10,resizable=yes,scrollbars=no,status=no");
            return false;
        });

        // 추천, 비추천
        $("#good_button, #nogood_button").click(function() {
            var $tx;
            if (this.id == "good_button")
                $tx = $("#bo_v_act_good");
            else
                $tx = $("#bo_v_act_nogood");

            excute_good(this.href, $(this), $tx);
            return false;
        });

        // 이미지 리사이즈
        $("#bo_v_atc").viewimageresize();
    });

    function excute_good(href, $el, $tx) {
        $.post(
            href, {
                js: "on"
            },
            function(data) {
                if (data.error) {
                    alert(data.error);
                    return false;
                }

                if (data.count) {
                    $el.find("strong").text(number_format(String(data.count)));
                    if ($tx.attr("id").search("nogood") > -1) {
                        $tx.text("이 글을 비추천하셨습니다.");
                        $tx.fadeIn(200).delay(2500).fadeOut(200);
                    } else {
                        $tx.text("이 글을 추천하셨습니다.");
                        $tx.fadeIn(200).delay(2500).fadeOut(200);
                    }
                }
            }, "json"
        );
    }
</script>
<!-- } 게시글 읽기 끝 -->