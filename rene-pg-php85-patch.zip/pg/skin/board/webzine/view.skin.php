<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="' . $board_skin_url . '/style.css">', 0);
?>

<script src="<?php echo G5_JS_URL; ?>/viewimageresize.js"></script>

<!-- 커스텀 { -->
<link rel="stylesheet" href="<?php echo $board_skin_url ?>/css/magic-check.css">
<!-- } -->




<div id="bo_list">
    <?php  if ($bo_table == "bfaf") { ?>
        <div class="title aos-init aos-animate" data-aos="fade-up" data-aos-duration="800">
            <span><img src="/images/e_txt.png" alt=""></span>
            <h3>전후사례</h3>
        </div>
    <?php  } ?>
    <ul class="titles font-b font-18"><?php echo cut_str(get_text($view['wr_subject']), 999); ?></ul>
    <ul class="main_lists_date v_top_hd">


        <li><img src="<?php echo $board_skin_url ?>/img/calendar.svg"></li>
        <li class="divmt-05"><?php echo $view['datetime2'] ?>　</li>

        <li><img src="<?php echo $board_skin_url ?>/img/eye.svg"></li>
        <li class="divmt-05"><?php echo $view['wr_hit'] ?>　</li>

        <?php if ($category_name) { ?>
            <li class="divmt-05 v_cates"><?php echo $view['ca_name']; ?></li>
            <li class="v_cates"><img src="<?php echo $board_skin_url ?>/img/tag.svg"></li>
        <?php } ?>

        <div class="cb"></div>
    </ul>
    <ul class="view_img_cont">

        <?php if ($view['wr_10']) { ?>
            <div class="video-container">
                <iframe width="100%" src="https://www.youtube.com/embed/<?php echo $view['wr_10']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <br><br>
        <?php } ?>

        <?php echo get_view_thumbnail($view['content']); ?>
        <br><br>
    </ul>
    <ul>
        <?php
        $cnt = 0;
        if ($view['file']['count']) {
            foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
                if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view'])
                    $cnt++;
            }
        }
        ?>

        <?php if ($cnt) { ?>
            <!-- 첨부파일 시작 { -->
            <div class="file_divs">
                <?php
                // 가변 파일
                foreach ($view['file'] as $i => $view_file) {
                if (!is_int($i) || !is_array($view_file)) continue;
                    if (isset($view['file'][$i]['source']) && $view['file'][$i]['source'] && !$view['file'][$i]['view']) {
                ?>
                        <li class="fl" style="margin-right:20px;">
                            <a href="<?php echo $view['file'][$i]['href'];  ?>" class="view_file_download" style="font-size:12px;">
                                <b><?php echo $view['file'][$i]['source'] ?> <?php echo $view['file'][$i]['content'] ?></b> (<?php echo $view['file'][$i]['size'] ?>)
                            </a>
                        </li>
                <?php
                    }
                }
                ?>
                <div class="cb"></div>
            </div>
            <!-- } 첨부파일 끝 -->
        <?php } ?>
    </ul>

    <?php if (isset($view['link'][1]) && $view['link'][1]) { ?>
        <ul>

            <div class="file_divs">
                <?php
                // 링크
                $cnt = 0;
                for ($i = 1; $i <= count($view['link']); $i++) {
                    if ($view['link'][$i]) {
                        $cnt++;
                        $link = cut_str($view['link'][$i], 70);
                ?>

                        <li class="fl" style="margin-right:20px;">
                            <a href="<?php echo $view['link_href'][$i] ?>" class="view_file_download" target="_blank" style="font-size:12px;">
                                <b><?php echo $link ?></b> (<?php echo $view['link_hit'][$i] ?>회 연결)
                            </a>
                        </li>

                <?php
                    }
                }
                ?>

                <div class="cb"></div>
            </div>

        </ul>
    <?php } ?>


    <ul class="view_img_btn" style="display:block !important;">
        <a href="<?php echo $list_href ?>" title="목록" alt="목록" class="bbs_adm_btn">
            <img src="<?php echo $board_skin_url ?>/img/menu.svg">
        </a>

        <?php if ($update_href) { ?>
            　<a href="<?php echo $update_href ?>" title="수정" alt="수정" class="bbs_adm_btn">
                <img src="<?php echo $board_skin_url ?>/img/settings.svg">
            </a>
        <?php } ?>

        <?php if ($delete_href) { ?>
            　<a href="<?php echo $delete_href ?>" onclick="del(this.href); return false;" title="삭제" alt="삭제" class="bbs_adm_btn">
                <img src="<?php echo $board_skin_url ?>/img/trash.svg">
            </a>
        <?php } ?>

        <?php if ($write_href) { ?>
            　<a href="<?php echo $write_href ?>" title="등록" alt="등록" class="bbs_adm_btn">
                <img src="<?php echo $board_skin_url ?>/img/edit.svg">
            </a>
        <?php } ?>


    </ul>
    <div class="cb"></div>
</div>


<script>
    <?php if ($board['bo_download_point'] < 0) { ?>
        $(function() {
            $("a.view_file_download").click(function() {
                if (!g5_is_member) {
                    alert("다운로드 권한이 없습니다.\n회원이시라면 로그인 후 이용해 보십시오.");
                    return false;
                }

                var msg = "파일을 다운로드 하시면 포인트가 차감(<?php echo number_format($board['bo_download_point']) ?>점)됩니다.\n\n포인트는 게시물당 한번만 차감되며 다음에 다시 다운로드 하셔도 중복하여 차감하지 않습니다.\n\n그래도 다운로드 하시겠습니까?";

                if (confirm(msg)) {
                    var href = $(this).attr("href") + "&js=on";
                    $(this).attr("href", href);

                    return true;
                } else {
                    return false;
                }
            });
        });
    <?php } ?>

    function board_move(href) {
        window.open(href, "boardmove", "left=50, top=50, width=500, height=550, scrollbars=1");
    }
</script>

<script>
    $(function() {
        $("a.view_image").click(function() {
            window.open(this.href, "large_image", "location=yes,links=no,toolbar=no,top=10,left=10,width=10,height=10,resizable=yes,scrollbars=no,status=no");
            return false;
        });

        // 추천, 비추천
        $("#good_button, #nogood_button").click(function() {
            var $tx;
            if (this.id == "good_button")
                $tx = $("#bo_v_act_good");
            else
                $tx = $("#bo_v_act_nogood");

            excute_good(this.href, $(this), $tx);
            return false;
        });

        // 이미지 리사이즈
        $("#bo_v_atc").viewimageresize();
    });

    function excute_good(href, $el, $tx) {
        $.post(
            href, {
                js: "on"
            },
            function(data) {
                if (data.error) {
                    alert(data.error);
                    return false;
                }

                if (data.count) {
                    $el.find("strong").text(number_format(String(data.count)));
                    if ($tx.attr("id").search("nogood") > -1) {
                        $tx.text("이 글을 비추천하셨습니다.");
                        $tx.fadeIn(200).delay(2500).fadeOut(200);
                    } else {
                        $tx.text("이 글을 추천하셨습니다.");
                        $tx.fadeIn(200).delay(2500).fadeOut(200);
                    }
                }
            }, "json"
        );
    }
</script>
<!-- } 게시글 읽기 끝 -->

<!-- SEO / AEO / GEO - Article / BlogPosting Schema.org JSON-LD -->
<?php
$site_domain = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');

$view_subject = isset($view['wr_subject']) ? get_text($view['wr_subject']) : '';
$view_content_clean = isset($view['wr_content']) ? preg_replace("/<(.*?)\>/", "", $view['wr_content']) : '';
$view_content_clean = preg_replace("/&nbsp;/", " ", $view_content_clean);
$view_description = cut_str(trim(get_text($view_content_clean)), 200);

// 게시글 이미지 수집 (첨부파일, 유튜브, 본문 <img>)
$view_images = array();

$current_bo_table = isset($bo_table) ? $bo_table : '';
if (isset($view['file'][0]['file']) && $view['file'][0]['file']) {
    $img_path = G5_DATA_URL . '/file/' . $current_bo_table . '/' . $view['file'][0]['file'];
    if (strpos($img_path, 'http') !== 0) {
        $img_path = $site_domain . '/' . ltrim($img_path, '/');
    }
    $view_images[] = $img_path;
}

if (isset($view['wr_10']) && $view['wr_10']) {
    $view_images[] = 'https://img.youtube.com/vi/' . $view['wr_10'] . '/maxresdefault.jpg';
}

if (isset($view['content']) && preg_match_all("/<img[^>]*src=[\"']?([^\"'>]+)[\"']?[^>]*>/i", $view['content'], $matches)) {
    foreach ($matches[1] as $img_src) {
        if (strpos($img_src, 'http') !== 0) {
            $img_src = $site_domain . '/' . ltrim($img_src, '/');
        }
        if (!in_array($img_src, $view_images)) {
            $view_images[] = $img_src;
        }
    }
}

// 작성자 (카테고리명 / 원장명 또는 작성자)
$author_name = (isset($view['ca_name']) && $view['ca_name']) ? $view['ca_name'] : (isset($view['name']) ? clean_xss_tags($view['name']) : '르네의원');
$published_date = (isset($view['wr_datetime']) && $view['wr_datetime']) ? date('c', strtotime($view['wr_datetime'])) : date('c');

$current_wr_id = isset($wr_id) ? $wr_id : (isset($view['wr_id']) ? $view['wr_id'] : '');
$current_page_url = G5_BBS_URL . '/board.php?bo_table=' . $current_bo_table . '&wr_id=' . $current_wr_id;
if (strpos($current_page_url, 'http') !== 0) {
    $current_page_url = $site_domain . '/' . ltrim($current_page_url, '/');
}

$schema_article = array(
    "@context" => "https://schema.org",
    "@type" => "BlogPosting",
    "mainEntityOfPage" => array(
        "@type" => "WebPage",
        "@id" => $current_page_url
    ),
    "headline" => $view_subject,
    "description" => $view_description,
    "articleBody" => cut_str(trim(get_text($view_content_clean)), 1000),
    "datePublished" => $published_date,
    "dateModified" => $published_date,
    "author" => array(
        "@type" => "Person",
        "name" => $author_name
    ),
    "publisher" => array(
        "@type" => "MedicalBusiness",
        "name" => "르네의원",
        "url" => $site_domain,
        "logo" => array(
            "@type" => "ImageObject",
            "url" => $site_domain . "/images/logo.png"
        )
    )
);

if (!empty($view_images)) {
    $schema_article["image"] = (count($view_images) === 1) ? $view_images[0] : $view_images;
}
?>
<script type="application/ld+json">
    <?php echo json_encode($schema_article, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>
</script>