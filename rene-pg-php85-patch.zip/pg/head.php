<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once(G5_PATH . '/head.sub.boa.php');
include_once(G5_LIB_PATH . '/latest.lib.php');
include_once(G5_LIB_PATH . '/outlogin.lib.php');
include_once(G5_LIB_PATH . '/poll.lib.php');
include_once(G5_LIB_PATH . '/visit.lib.php');
include_once(G5_LIB_PATH . '/connect.lib.php');
include_once(G5_LIB_PATH . '/popular.lib.php');


$s_num = "";
$p_num = "";

$login = "/pg/bbs/login.php";
$login2 = "/pg/bbs/login_check.php";
$register = "/pg/bbs/register.php";
$register2 = "/pg/bbs/register_form.php";
$register3 = "/pg/bbs/register_result.php";
$cert = "/pg/bbs/member_cert_refresh.php";
$search = "/pg/bbs/search.php";
$confirm = "/pg/bbs/member_confirm.php";
$faq = "/pg/bbs/faq.php";

$mstr = strtok($_SERVER['REQUEST_URI'], '?');

if ($bo_table == "comm01") {
    $s_num = "9";
    $p_num = "1";
} elseif ($bo_table == "comm02_renew") {
    $s_num = "9";
    $p_num = "2";
} elseif ($bo_table == "comm05") {
    $s_num = "9";
    $p_num = "3";
} elseif ($bo_table == "comm09") {
    $s_num = "9";
    $p_num = "5";
} elseif ($bo_table == "comm03") {
    $s_num = "2";
    $p_num = "8";
} elseif ($bo_table == "comm07") {
    $s_num = "2";
    $p_num = "9";
} elseif ($bo_table == "comm6") {
    $s_num = "4";
    $p_num = "6";
} elseif ($mstr == $login) {
    $s_num = "10";
    $p_num = "1";
} elseif ($mstr == $confirm) {
    $s_num = "10";
    $p_num = "2";
} elseif ($mstr == $login2) {
    $s_num = "10";
    $p_num = "1";
} elseif ($mstr == $register) {
    $s_num = "10";
    $p_num = "2";
} elseif ($mstr == $register2) {
    $s_num = "10";
    $p_num = "2";
} elseif ($mstr == $register3) {
    $s_num = "10";
    $p_num = "2";
} elseif ($fm_id == "6") {
    $s_num = "9";
    $p_num = "4";
}
?>



<?php include "../../inc/head.php"; ?>
<?php include "../../inc/link.php"; ?>
<?php include "../../inc/top.php"; ?>
<?php include "../../inc/s_visual_board.php"; ?>


<!-- Sub Content -->
<div id="subContent">
    <div id="pageCont" class="inner" style="font-size:15px;">
        <h3 id="subTitle"><span class="vis_dep02"></span></h3>