<div id="Quick">
	<a href="javascript:GoPage('comm2')" class="bg0"><span>온라인상담</span></a>
	<a href="javascript:GoPage('kakao')" class="bg1"><span>카카오톡상담</span></a>
	<a href="javascript:GoPage('naver')" class="bg2"><span>네이버</span></a>
	<a href="javascript:GoPage('youtube')" class="bg3"><span>유투브</span></a>
	<a href="javascript:GoPage('face')" class="bg4"><span>카카오톡상담</span></a>
</div>

<div id="labiaLanding">
	<a href="javascript:GoPage('labia-landing')"><span>소음술수술 상세보기</span></a>
</div>



	<footer id="footer">
	<div class="inner">
		<div id="f-logo">
			<img src="/images/common/f-logo.png">
		</div>
		<div id="f-info">
			<ul class="cont">
				<li><p>의료기관명</p> 대구르네여성의원</li>
				<li><p>대표자명</p> 황인아</li>
				<li><p>주소</p> 대구시 동대구로 311 범어애플타워 3층, 4층</li>
				<li ><p>대표번호</p>  <span class="fc-M1 fw-M">053) 753-5040</span></li>
				<li><p>유방·갑상선센터</p>  053) 753-5030</li>
				<li><p>사업자등록번호</p>  254-24-01015</li>
			</ul>
			<ul class="sns">
				<li><a href="javascript:GoPage('kakao')" class="bg1"></a></li>
				<li><a href="javascript:GoPage('blog')" class="bg2"></a></li>
				<li ><a href="javascript:GoPage('youtube')" class="bg3"></a></li>
				<li ><a href="javascript:GoPage('face')" class="bg4"></a></li>
			</ul>
		</div>		
	</div>
	<div id="f-bottom">
	<div class="inner">
			<p class="copy">© RENE CLINIC. All Right Reserved. <a href="https://www.webtro.co.kr" target="_blank" class="webtro">Design by WEBTRO</a></p>
			<ul>
				<li><a href="javascript:GoPage('privacy')">개인정보처리방침</a></li>
				<li><a href="javascript:GoPage('terms')">이용약관</a></li>
				<li><a href="javascript:GoPage('comm1')">병원소식</a></li>
			</ul>
		</div>
	</div>
	</footer>


</div>

<script>
   AOS.init({
     duration: 600,
     offset: 0,
     delay: 100,
     easing: 'ease-out-quad',
   });
</script>

<script type="text/javascript">
	$(document).ready(function() {
		subFunc.snb("<?= $s_num ?? '' ?>", "<?= $p_num ?? '' ?>");
	});
</script>




</body>
</html>
