
<div class="s_visual">
	<div class="s_visual_in">
		<div class="sv_tit">
			<p  data-aos="fade-up" data-aos-delay="100" class="eng"><span>RENE WOMEN’S CLINIC</span></p>
			<h2 data-aos="fade-up" data-aos-delay="200"><span class="vis_dep01"></span></h2>				
			<p class="t1"  data-aos="fade-up" data-aos-delay="300"><span>섬세한 시선과 깊이 있는 진료로 <br class="br480">여성의 삶을 바라봅니다.</span></p>
		</div>
	</div>
</div>


<div id="subContent">
	<div class="sub_menu_wrap">
		<div class="in">
			<div class="m_home"><a href="javascript:GoPage('main')"></a></div>
			<div class="m_1dep_box m_dep_box">
				<div class="m_dep_tit"><span class="vis_dep01"></span></div>
				<?php  include "../../inc/s_gnb0.php" ?>
			</div>
			<div class="m_2dep_box m_dep_box">
				<div class="m_dep_tit"><span class="vis_dep02"></span></div>
				<?php  include "../../inc/s_gnb$s_num.php" ?>
			</div>
			<?php if(isset($t_num) && $t_num != ''): ?>
			<div class="m_3dep_box m_dep_box">
				<div class="m_dep_tit"><span class="vis_dep03"></span></div>
				<?php  include "../../inc/s_gnb$s_num-$t_num.php" ?>
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>
