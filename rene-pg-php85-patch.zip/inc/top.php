<header id="header">


    <div id="gnb_pc">
        <ul class="gnb">
            <li class="gnb_dp1">
                <div><a href="javascript:GoPage('labia-landing')">소음순수술</a></div>
            </li>
            <li class="gnb_dp1">
                <div><a href="javascript:GoPage('labiaplasty8')">수술후기</a></div>
            </li>
            <li class="gnb_dp1">
                <div><a href="javascript:GoPage('vaginalrepair1')">레이저시술</a></div>
                <?php  include "s_gnb3.php" ?>
            </li>
            <li class="gnb_dp1">
                <div><a href="javascript:GoPage('naver')">진료예약</a></div>
            </li>
            <li class="gnb_dp1">
                <div><a href="javascript:GoPage('comm2')">온라인상담</a></div>
            </li>
            <li class="gnb_dp1">
                <div><a href="javascript:GoPage('intro4')">오시는 길</a></div>
            </li>
        </ul>
    </div>



    <h1 id="logo">
        <a href="javascript:GoPage('main')" class="logo" alt="르네여성의원">르네여성의원</a>
    </h1>



    <div id="topRight">

        <div id="topTel">
            <li class="pc">
                <p>053.753.5040</p>
            </li>
            <li class="mo"><a href="tel:0537535040">전화번호 053-753-5040</a></li>
        </div>


        <div id="topLogin">
            <ul class="">
                <?php  if (!empty($member['mb_id'])) { ?>
                    <li><a href="javascript:GoPage('logout')">로그아웃</a></li>
                    <?php  if (!empty($is_admin)) { ?>
                        <li><a href="/pg/adm/">관리자</a></li>
                    <?php  } else { ?>
                        <li><a href="javascript:GoPage('mypage')">정보수정</a></li>
                    <?php  } ?>
                <?php  } else { ?>
                    <li><a href="javascript:GoPage('login')">로그인</a></li>
                    <li><a href="javascript:GoPage('join')">회원가입</a></li>
                <?php  } ?>
            </ul>
            <!-- <ul>
			<li><a href="javascript:GoPage('login')">로그인</a></li>
			<li><a href="javascript:GoPage('join')">회원가입</a></li>
		</ul> -->
        </div>



        <div id="topLang">
            <div class="t-lang">
                <button type="button" class="lang-btn">
                    <span>KOR</span>
                </button>
                <ul class="lang-list">
                    <li><a href="javascript:GoPage('eng')">ENG</a></li>
                    <li><a href="javascript:GoPage('chn')">CHN</a></li>
                </ul>
            </div>
        </div>

    </div>



    <div id="allmenuWrap">
        <div id="allmenu">
            <a href="#" id="navtoggler">
                <div class="bar"><span class="t"></span><span class="m"></span><span class="b"></span></div>
            </a>
        </div>
        <nav id="fullscreenmenu">
            <?php  include "nav.php" ?>
        </nav>
    </div>


    <div class="menuToggle hd_full hd_mbx"><span class="t"></span><span class="m"></span><span class="b"></span></div>


    <div id="gnb_mo" class="fullmenu">
        <div id="moLogin">
            <!-- <ul class="">
			<?php  if (!empty($member['mb_id'])) { ?>
				<li><a href="javascript:GoPage('logout')">로그아웃</a></li>
			<?php  if (!empty($is_admin)) { ?>
				<li><a href="/pg/adm/">관리자</a></li>
			<?php  } else { ?>
				<li><a href="javascript:GoPage('mypage')">정보수정</a></li>
			<?php  } ?>
			 <?php  } else { ?>
				<li><a href="javascript:GoPage('login')">로그인</a></li>
				<li><a href="javascript:GoPage('join')">회원가입</a></li>
			 <?php  } ?>
		</ul> -->
            <ul>
                <li><a href="javascript:GoPage('login')">로그인</a></li>
                <li><a href="javascript:GoPage('join')">회원가입</a></li>
            </ul>
        </div>
        <?php  include "nav.php" ?>
    </div>

</header>


<div id="content">