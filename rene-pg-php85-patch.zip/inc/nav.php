<ul class="gnb">

  <!--  -->
  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('intro1')">병원소개</a></div>
    <?php  include "s_gnb1.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('labiaplasty1')">소음순성형</a></div>
    <?php  include "s_gnb2.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('vaginalrepair1')">질성형·성감개선</a></div>
    <?php  include "s_gnb3.php" ?>
  </li>

  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('breast1')">유방·갑상선센터</a></div>
    <?php  include "s_gnb4.php" ?>
  </li>


  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('waxing1')">여성제모클리닉</a></div>
    <?php  include "s_gnb5.php" ?>
  </li>



  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('checkup1')">여성 검진</a></div>
    <?php  include "s_gnb6.php" ?>
  </li>



  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('climac1')">갱년기클리닉</a></div>
    <?php  include "s_gnb7.php" ?>
  </li>


  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('clinic1')">여성질환클리닉</a></div>
    <?php  include "s_gnb8.php" ?>
  </li>



  <li class="gnb_dp1">
    <div><a href="javascript:GoPage('comm1')">커뮤니티</a></div>
    <?php  include "s_gnb9.php" ?>
  </li>


</ul>
