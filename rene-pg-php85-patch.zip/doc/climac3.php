<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "갱년기 필수검진";
$page_canonical = "https://reneclinic.co.kr/doc/climac3.php"
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "7";
	$p_num = "3";
	$category = "갱년기 필수검진";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-climac3.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">갱년기 건강을 지키는 첫걸음, <br>정기적인 검진과 체계적인 관리</h2>
			<ul class="t1">
				<li>갱년기는 여성호르몬의 변화로 신체 전반에 다양한 변화가 나타나는 시기로 <br>골다공증과 심혈관질환 등 여러 건강 문제의 위험이 높아질 수 있습니다. </li>
				<li>개인의 증상과 건강 상태에 맞는 검진을 통해 변화를 조기에 확인하고 적절한 예방과  <br>관리로 건강하고활기찬 삶을 유지하는 것이 중요합니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>


	<section id="climac3" class="s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>갱년기 검진 종류</h2>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="30%">
					<col width="70%">
                </colgroup>
                <thead>
                    <tr>
						<th>검사명</th>
						<th>검사내용</th>
					</tr>
                </thead>
                <tbody>
					 <tr>
						<th>병력 확인 및 진찰</th>
						<td class="left">과거 병력을 파악하고 현재 상태에 대한 더 좋은 대응 방안을 찾습니다.<br>
						수술력, 투약기록, 가족력 등을 확인하여 전반적인 문제점을 알고 재정비하는 시간을 갖습니다.</td>
					</tr>
					<tr>
						<th>혈액검사</th>
						<td class="left">현재의 호르몬 수치를 파악하여 갱년기의 어디쯤에 와 있는지를 가늠합니다.<br>
						그 밖에도 간기능검사, 콜레스테롤 검사, 빈혈검사, 비타민디 검사 등을 통해 알지 못했던 몸의 상태를 파악하고
						추후 호르몬치료가 필요할 경우 치료에 적합한 상태인지를 알 수 있습니다.</td>
					</tr>
					<tr>
						<th>자궁경부 세포진검사</th>
						<td class="left">자궁경부암 조기 발견을 위해 꼭 필요한 검사입니다. (국가검진가능)<br>
						매년 확인하기를 권유드리며, 자궁경부확대경, HPV검사 등을 추가하여 더 정확하게 검사 가능합니다.</td>
					</tr>
					<tr>
						<th>자궁/난소 초음파</th>
						<td class="left">자궁 내막이 정상적으로 유지되는지를 확인하고 자궁과 난소의 혹을 볼 수 있는 검사입니다.<br>
						호르몬제 복용시 자궁내막증식증, 자궁내막암의 위험도 판단을 위해 꼭 필요합니다.</td>
					</tr>
					<tr>
						<th>유방촬영술</th>
						<td class="left">유방암에 대한 가장 기본적인 검사로, 유방을 눌러서 찍는 엑스레이 검사입니다. (국가검진가능)</td>
					</tr>
					<tr>
						<th>유방초음파</th>
						<td class="left">유방의 혹을 확인할 수 있는 검사입니다. 필요 시 바로 조직검사를 추가하여 암을 진단할 수 있습니다.<br>
						유방촬영술 결과가 치밀유방으로 나오거나, 호르몬제를 복용중인 경우라면 필수적인 검사입니다.</td>
					</tr>
					<tr>
						<th>골밀도검사</th>
						<td class="left">폐경 후에는 골밀도가 급격히 감소하며 쉽게 골다공증이 생깁니다.<br>
							이에 대한 파악과 예방, 조기 치료가 꼭 필요합니다.</td>
					</tr>
                </tbody>
            </table>
        </div>
		</div>
	</section>





	<section id="climac3" class="subBG m-Part p-Part-b">
	<div class="s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>갱년기 검진 종류</h2>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="30%">
					<col width="70%">
                </colgroup>
                <thead>
                    <tr>
						<th>검사명</th>
						<th>검사내용</th>
					</tr>
                </thead>
                <tbody>
				<tr>
					<th>자궁경부 세포진검사(액상검사)</th>
					<td class="left">자궁경부 외부, 내부의 세포를 채취하는 가장 기본적인검사입니다.</td>
				</tr>
				<tr>
					<th>자궁경부확대경 검사</th>
					<td class="left">특수 사진기로 자궁경부를 확대 촬영하여 이상유무를 판독하는 검사입니다.</td>
				</tr>
				<tr>
					<th>인유두종바이러스(HPV)검사</th>
					<td class="left">자궁경부암을 유발하는 인유두종바이러스의 위험도와 종류를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>STD12종 검사 (질염/성병균 검사)</th>
					<td class="left">성병의 원인이 되는 원인균, 바이러스를 정확히 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>자궁/난소 초음파 검사</th>
					<td class="left">자궁과 난소의 모양과 크기, 종양의 유무를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>유방 촬영술</th>
					<td class="left">유방촬영술은 유방암 진단의 가장 기본적인 검사 방법입니다. 유방암의 초기 특징인 미세한 석회화까지 발견을 할 수 있어 꼭 필요한 검사라고 할 수 있습니다.</td>
				</tr>
				<tr>
					<th>유방 초음파 검사</th>
					<td class="left"> 7.5MHz 이상의 선형 탐촉자를 이용한 고해상도 초음파 기기를 이용하여 유방 질환을 진단하는 검사입니다. 검사의 방법이 매우 간편하고, 검사로 인한 방사선피폭의 위험이 없으므로 모든 연령층의 여성에게 반복적으로 사용할 수 있는 검사방법입니다.</td>
				</tr>
				<tr>
					<th>골밀도검사</th>
					<td class="left">폐경 후에는 골밀도가 급격히 감소하며 쉽게 골다공증이 생깁니다.<br>
						이에 대한 파악과 예방, 조기 치료가 꼭 필요합니다.</td>
				</tr>
				<tr>
					<th>기초혈액검사 + 호르몬검사</th>
					<td class="left">혈액 속의 유형성분인 혈구를 분석해 검사하고 각 호르몬의 검사를 통하여 배란에 관계되는 호르몬의 이상유무를 확인하는 검사입니다.</td>
				</tr>
				<tr>
					<th>난소암 혈액검사</th>
					<td class="left">혈액검사로 난소암에서 올라가는 수치들을 검사하여 이들을 종합하여 위험도를 산정하는 검사입니다.</td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>
	</section>






<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>갱년기 검진, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기 검진은 언제부터 받는 것이 좋나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 40대 중후반부터 갱년기 변화가 시작될 수 있으므로 생리주기가 불규칙해지거나 안면홍조, 수면장애 등의 증상이 나타난다면 검진을 고려하는 것이 좋습니다. 특별한 증상이 없더라도 연령과 개인의 건강 상태에 맞는 정기검진이 중요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">여성호르몬 검사만으로 갱년기를 진단할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>여성호르몬 수치는 생리주기와 검사 시점에 따라 달라질 수 있어 한 번의 혈액검사만으로 갱년기를 정확하게 판단하기는 어렵습니다. 일반적으로 나이, 월경 변화, 증상 등을 종합적으로 평가하며, 필요한 경우 호르몬 검사를 추가로 시행합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기 증상이 없어도 검진을 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>갱년기 증상이 뚜렷하지 않더라도 폐경 전후에는 골밀도 감소와 심혈관질환 위험요인의 변화가 나타날 수 있습니다. 따라서 특별한 불편함이 없어도 연령과 건강 상태에 맞춰 필요한 검진을 받는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">골밀도 검사는 갱년기 여성이라면 모두 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>모든 갱년기 여성에게 즉시 골밀도 검사가 필요한 것은 아닙니다. 일반적으로 65세 이상 여성에게 권고되며, 65세 미만의 폐경 여성도 조기폐경이나 골절 위험요인이 있다면 검사를 고려할 수 있습니다.</p>
                </div>
            </div>


			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기 검진 결과에 이상이 있으면 치료가 필요한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>검진 결과에 따라 호르몬 변화, 골밀도 저하, 대사질환 위험요인 등을 확인하고 적절한 관리 방향을 결정합니다. 모든 이상 소견이 약물치료로 이어지는 것은 아니며, 개인의 건강 상태에 따라 생활습관 개선, 추가 검사 또는 치료를 진행할 수 있습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
