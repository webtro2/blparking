<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "비비브 2.0";
$page_canonical = "https://reneclinic.co.kr/doc/vaginalrepair3.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "3";
	$category = "비비브 2.0";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-vaginal3.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">시간이 지나며 달라진 탄력, <br>비비브 2.0으로 섬세하게</h2>
			<ul class="t1">
				<li>비비브 2.0은 여성의 질 내부 조직에 고주파(RF) 에너지를 전달하여 콜라겐의 재형성을 유도하고, <br>질 조직의 탄력 개선을 돕는 비수술적 시술입니다.</li>
				<li>절개나 봉합 없이 진행되며, 개인의 질 이완 정도와 조직 상태를 고려하여 시술합니다.</li>
				<li>출산과 노화 등으로 저하된 질 탄력과 여성의 기능적인 고민을 세심하게 살펴, 보다 편안하고 건강한 일상을 위한 개선을 추구합니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>고주파 에너지로 질 내부의 탄력과 건강한 변화</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>비비브 2.0은 고주파 에너지와 특허받은 냉각 기술을 결합하여 조직 표면의 열 손상 위험을 줄이면서 <br>내부에 에너지를 전달하도록 설계된 의료기기입니다. </li>
			<li>비절개 방식으로 회복에 대한 부담이 비교적 적으며, 편안한 시술 환경과 체계적인 사후 관리를 통해 환자 중심의 진료를 추구합니다.</li>
		</ul>
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>콜라겐 재형성 유도</li>
				<li>냉각 기술로 <br>점막 보호</li>
				<li>비절개 고주파 시술</li>
				<li>질 조직 탄력 관리</li>
				<li>점진적인 조직 변화</li>				
				<li>상태별 맞춤 상담</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">비비브는 에너지를 안전하게 피부 깊은 층까지 전달하기 때문에 <br>
개인의 상태에 따라 1회 시술로 질 내부 탄력 및 쿠션감 개선을 목표로 할 수 있습니다.</p>
	</div>
</section>



<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>비비브 2.0, <br class="br480">이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>성감이 떨어지신 분</p></li>
				<li><p>수술이 부담스러운 분</p></li>
				<li><p>질이 건조해져 고통을 느끼시는 분</p></li>
				<li><p>질방귀를 경험하신 분</p></li>
				<li><p>탄력저하를 느끼시는 분</p></li>
				<li><p>케겔 운동을 하기 어려우신 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>



<section class="subBG p-Part-b">
<div id="labia2-2" class=" s-inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>비비브2.0 시술 후 <br class="br480">질 콜라겐의 변화</h2>
		<p class="t1">시술 후 열 자극을 받은 기존 콜라겐 섬유가 재배열되고, 시간이 지나면서 새로운 콜라겐 생성이 촉진되어 <br>질 조직의 탄력과 탄탄함을 개선하는 데 도움을 줄 수 있습니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4 vaginal3">
			<li>
				<h3><p>에너지 조사</p></h3>
				<img src="/images/sub/vaginal3-2-img1.png">
				<p class="t1">질 표면은 차갑게 보호하면서 고온의 에너지를 질 점막하 조직에 조사하여 히팅합니다.</p>
			</li>
			<li>
				<h3><p>콜라겐 생성</p></h3>
				<img src="/images/sub/vaginal3-2-img2.png">
				<p class="t1">고온의 에너지로 질 점막하 조직에서는 자극 반응이 유도하며 시술 30일부터 피부 조직 내에서 세포가 활성화되고 콜라겐이 생성되기 시작합니다.</p>
			</li>
			<li>
				<h3><p>질 탄력 및 볼륨업</p></h3>
				<img src="/images/sub/vaginal3-2-img3.png">
				<p class="t1">질 콜라겐 복구 과정은 시술 후 30~90일까지 계속 되어 통통하게 차오르는 효과를 경험하실 수 있습니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>






<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>비비브2.0, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시 통증이 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>개인의 상태에 따라 시술 중 느껴지는 감각에는 차이가 있을 수 있으며, 마취 여부 또한 의료진의 판단에 따라 달라질 수 있습니다. 일부 환자분들은 따뜻한 느낌을 받았다고 표현하기도 합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 후 일상생활 복귀는 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 후, 즉시 일상생활 복귀가 가능합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술은 몇 회를 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 횟수는 개인의 상태와 목표에 따라 달라질 수 있으며, 의료진 상담 후 결정됩니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">비비브 2.0 시술 후 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>비비브 2.0은 절개 없이 진행하는 고주파 시술이지만, 개인의 조직 상태와 민감도에 따라 일시적인 열감, 불편감, 경미한 통증, 분비물 증가 등이 나타날 수 있습니다. <br>시술 전 산부인과 전문의와 충분한 상담을 통해 적합성을 확인하는 것이 중요합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
