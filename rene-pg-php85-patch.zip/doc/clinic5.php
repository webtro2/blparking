<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "방광염";
$page_canonical = "https://reneclinic.co.kr/doc/clinic5.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "5";
	$category = "방광염";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic5.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">배뇨장애와 생식기 통증을 동반하므로 치료가 꼭 필요합니다.</h2>
			<ul class="t1">
				<li>방광염은 세균이 요도를 거쳐 방광에 감염되어 염증을 일으키는 질환으로 심하게 되면 신장까지 염증이 생기는 신우신염이 발생될 수 있습니다.</li>
				<li>여성의 경우는 남성보다 요도가 짧아 쉽게 발생됩니다.</li>
				<li>소변을 보는 횟수가 잦아지고 통증이 생기는 것이 특징이며 탁하거나 붉은색의 소변을 보기도 합니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>방광염의 원인</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>방광염은 주로 대장균과 같은 세균이 요도를 통해 방광으로 침입하여 염증을 일으키는 질환입니다.</li>
			<li>여성은 남성보다 요도가 짧고 항문과 가까워 세균 감염에 취약하며 성관계, 폐경 이후 호르몬 변화, 배뇨 습관 등 다양한 요인이 <br>발병 위험을 높일 수 있습니다.</li>
		</ul>		
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>신경계 질환</li>				
				<li>스트레스</li>
				<li>면역력 저하</li>
				<li>세균 침입</li>
				<li>방광의 자극</li>
			</ul>
	</div>
		<div class="clinicTxt pt0">
		<p class="t2 fc-bl">반복되는 방광염, 생활습관 개선과 정확한 원인 확인이 중요합니다.</p>
	</div>
</section>




<section id="clinicIntro" class="subBG m-Part p-Part-b">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>방광염 예방법</h2>
			<p class="t1">방광염은 생활습관과 위생 관리에 신경 쓰는 것만으로도 발생 위험을 줄이는 데 도움이 될 수 있습니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>충분한 수분 섭취</dt>
						<dd>평소 물을 충분히 마셔 소변 배출을 원활하게 하고, 요로 내 세균이 배출될 수 있도록 돕습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>소변 참지 않기</dt>
						<dd>소변이 마려울 때 오래 참지 않고 규칙적으로 배뇨하여 방광에 소변이 장시간 머무르지 않도록 합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>올바른 배변 위생 관리</dt>
						<dd>배변 후에는 앞에서 뒤쪽 방향으로 닦아 항문 주변 세균이 요도로 이동할 가능성을 줄입니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>성관계 후 배뇨 습관</dt>
						<dd>성관계 후 소변을 보는 습관은 방광염 예방에 도움이 될 수 있으며, 외음부를 자극 없이 청결하게 관리합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>자극적인 세정제 사용 자제</dt>
						<dd>향이 강한 여성청결제나 질 내부 세정은 피하고, 외음부를 부드럽게 씻어 불필요한 자극을 줄입니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>통기성 좋은 속옷 착용</dt>
						<dd>통기성이 좋은 속옷을 착용하고 젖은 의류는 빠르게 교체하여 외음부를 쾌적하게 유지합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>





<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>방광염 자가진단</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>소변이 자주 마렵다</p></li>
				<li><p>소변볼 때 찌릿찌릿 아프다</p></li>
				<li><p>소변이 시원하지 않다</p></li>
				<li><p>소변이 붉게 보인다</p></li>
				<li><p>아랫배가 묵직하게 아프다</p></li>
			</ul>
		</div>
	</div>
</div>







<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>방광염, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">방광염 검사는 어떻게 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>주로 소변검사를 통해 염증과 세균 감염 여부를 확인합니다. 증상이 반복되거나 복잡한 감염이 의심되는 경우 소변배양검사 등을 추가로 시행할 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">방광염은 어떻게 치료하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>세균성 방광염은 주로 항생제를 사용하여 치료합니다. 감염의 정도와 원인균, 개인의 건강 상태에 따라 약물의 종류와 복용 기간이 달라질 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">방광염은 자연적으로 좋아질 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>경미한 방광염은 자연적으로 호전되기도 하지만, 감염이 지속되거나 악화될 수 있습니다. 증상이 반복되거나 심해진다면 정확한 진단과 치료가 필요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">방광염 치료는 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>단순 급성 방광염은 일반적으로 3~5일 정도 항생제 치료를 진행하지만, 약물과 감염 상태에 따라 기간이 달라질 수 있습니다.</p>
                </div>
            </div>

			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">방광염과 질염은 어떻게 다른가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>방광염은 주로 빈뇨, 배뇨통, 잔뇨감이 나타나며, 질염은 질 분비물 변화와 가려움증, 냄새 등이 특징적입니다. 증상이 겹칠 수 있어 정확한 검사가 필요합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
