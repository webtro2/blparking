<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "임신/피임";
$page_canonical = "https://reneclinic.co.kr/doc/clinic1.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "1";
	$category = "임신/피임";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic1.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">생명의 시작, 새로운 여정, <br>임신의 모든 것</h2>
			<ul class="t1">
				<li>임신은 하나의 정자와 난자가 만나 수정되는 순간부터 시작되어 약 10개월(40주) 동안 <br>새로운 생명이 엄마의 자궁 속에서 안전하게 자라나는 신비롭고 위대한 과정입니다.</li>
				<li>임신 초기부터 출산 전까지 산모와 태아의 건강 상태를 세심하게 살피고, 임신 주수에 맞는 <br>정기적인 검진과 체계적인 관리를 통해 건강하고 안전한 출산을 준비하는 것이 중요합니다.</li>
			</ul>
		</div>
	</div>






	<section id="climac2" class="s-inner p-Part">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>임신 자각증상</h2>
			<p class="t1">임신이 의심된다면 가능한 빨리 임신테스트기를 이용해 자가진단 해본 뒤, <br>임신반응을 보이면 산부인과에 내원하셔서 진단을 받아보시는 것이 좋습니다.</p>
			
		</div>
		<div class="clima2-img">
			<ul class="flex-Box">
				<li>
					<h3><p>생리불순</p></h3>
					<img src="/images/sub/clinic1-1-img1.png">
					<p class="t1">임신이 예상된다면 가장 먼저 확인하는 증상 중 하나입니다. 생리불순이 있는 경우는 마지막 성관계 후 2주가 지나면 임신 여부를 확인할 수 있습니다.</p>
				</li>
				<li>
					<h3><p>가슴통증</p></h3>
					<img src="/images/sub/clinic1-1-img2.png">
					<p class="t1">임신 호르몬에 의하여 나타나는 증상으로 생리 전 증상처럼 유방이 꽉 차고 커지는 느낌이 들거나 유두 통증이 있을 수 있으며 유두의 색도 진해지기 시작합니다.</p>
				</li>
				<li>
					<h3><p>감정기복</p></h3>
					<img src="/images/sub/clinic1-1-img3.png">
					<p class="t1">호르몬의 변화로 감기에 걸린것 처럼 몸이 무거워지고 피곤하며 짜증이 나는 등 감정기복이 생기고 일의 능률도 떨어집니다.</p>
				</li>
				<li>
					<h3><p>잦은 배뇨 / 질 분비물</p></h3>
					<img src="/images/sub/clinic1-1-img4.png">
					<p class="t1">자궁이 커지면서 방광을 압박하게 되어 아랫배가 묵직하면서 소변이 자주 마렵고 질 분비물이 많아집니다.</p>
				</li>
				<li>
					<h3><p>부정출혈</p></h3>
					<img src="/images/sub/clinic1-1-img5.png">
					<p class="t1">임신낭이 자궁내막에 착상하면서 복통과 함께 소량의 출혈만 보일 수 있습니다. 출혈 때문에 생리로 오해하는 분도 계시는데, 정확한 검진을 받아보는 것이 좋습니다.</p>
				</li>
				<li>
					<h3><p>입덧증세</p></h3>
					<img src="/images/sub/clinic1-1-img6.png">
					<p class="t1">임신초기에는 속이 메스껍고 소화불량으로 입덧증세가 있을 수 있습니다. 위장질환으로 생각되어 내과에서 진료를 받다가 임신을 알게 되는 경우도 있습니다.</p>
				</li>
			</ul>
		</div>
	</section>




	<section id="climac3" class="subBG m-Part p-Part-b">
	<div class="s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>임신 진단 방법</h2>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="18%">
					<col width="22%">
					<col width="60%">
                </colgroup>
                <thead>
                    <tr>
						<th>진단방법</th>
						<th>진단시기</th>
						<th>내용</th>
					</tr>
                </thead>
                <tbody>
				
				<tr>
					<th>혈액검사</th>
					<td>성관계 10-12일 후</td>
					<td class="left">임신 진단을 위한 가장 빠른 방법으로 관계 후 최소 10일 지나면 확인이 가능합니다.
하지만 관계 당일에 배란된 것이 아니라면 임신 초기로 음성 결과가 나올 수 있으므로 관계 일로부터 시일이 지날수록 검사의 정확도가 높아집니다.</td>
				</tr>
				<tr>
					<th>임신 테스트기</th>
					<td>성관계 13-14일 후</td>
					<td class="left">
					소변 테스트기는 임신 시 증가하는 융모성선자극호르몬의 반응으로 임신을 진단하는 키트입니다.
대개 수정 후 10일이 지나면 소변 내 반응을 확인할 수 있으니 임신 주수가 지날수록 농도가 높아지므로 관계 후 최소 2주가 지나거나 생리 예정일을 지난 후 검사를 하는 것이 바람직합니다.
아침 첫 소변으로 테스트하고, 5분 후에 판독하는 것이 정확합니다.
					</td>
				</tr>
				<tr>
					<th>초음파검사</th>
					<td>성관계 21일 후</td>
					<td class="left">소변이나 혈액 검사 상 양성이 나오면 정상 임신 판단 여부 및 정확한 임신 주수 진단을 위해 초음파 검사가 필요합니다.
보통 관계 후 3주(의학적 임신 5주) 정도 지난 후에 초음파 상 확인이 가능합니다.
초음파로 정확한 임신의 확인을 한 후 산전검사나 임신의 상담이 이루어 집니다.</td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>
	</section>






<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>임신, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신이 확인되면 언제 산부인과에 방문해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>임신테스트기에서 양성 반응이 확인되면 산부인과에 방문하여 임신 여부와 위치를 확인하는 것이 좋습니다. 일반적으로 임신 5~6주경 질초음파를 통해 자궁 내 임신낭을 확인할 수 있으며, 검사 시기는 개인의 상태에 따라 달라질 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신 중에도 운동이나 일상생활이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>특별한 합병증이 없는 임신이라면 가벼운 걷기, 수영 등 적절한 운동과 일상생활이 가능합니다. 다만 출혈, 복통, 조기진통 위험 등 특별한 상황이 있다면 담당 의료진과 상담하여 활동 범위를 조절해야 합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신 중 질 출혈이나 복통이 있으면 어떻게 해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>임신 초기에는 소량의 출혈이나 가벼운 복통이 나타날 수 있지만, 유산이나 자궁외임신 등의 가능성도 있어 의료진의 확인이 필요합니다. 특히 출혈이 많거나 심한 복통, 어지럼증 등이 동반된다면 즉시 진료를 받아야 합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신 준비 중 엽산은 언제부터 복용해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>엽산은 태아의 신경관 결손 위험을 낮추는 데 중요한 영양소로, 일반적으로 임신 최소 1개월 전부터 임신 초기까지 하루 400μg의 엽산 섭취를 권장합니다. 다만 개인의 건강 상태나 과거 임신력에 따라 필요한 용량이 달라질 수 있습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>





<?php include "../inc/clinic-marquee.php"; ?>






	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic1-2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">건강한 선택과 미래를 위한 계획 <br>피임의 모든 것</h2>
			<ul class="t1">
				<li>피임이란 원하지 않는 임신을 예방하기 위한 여러 방법을 말합니다.</li>
				<li>여성의 사회적, 경제적 지위가 높아지고 가족 계획이 보편화되어 가고 있으며, <br>특히 여성의 성생활에 대한 의식구조가 변화하고 있습니다.</li>
				<li>르네여성의원은 원하지 않는 임신을 미리 예방할 수 있도록 나에게 꼭 맞는 피임방법과 <br>올바른 피임 지식을 알려드리고 있습니다.</li>
			</ul>
		</div>
	</div>






	<section id="climac2" class="s-inner p-Part">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>피임의 종류</h2>
			<p class="t1">피임 방법은 종류에 따라 효과와 유지 기간, 사용 방법이 다르며 개인의 건강 상태와 임신 계획에 따라 적합한 방법도 달라집니다</p>
			
		</div>
		<div class="clima2-img">
			<ul class="flex-Box">
				<li>
					<h3><p>콘돔</p></h3>
					<img src="/images/sub/clinic1-2-img1.png">
					<p class="t1">정자가 여성의 생식기 내부로 들어가는 것을 물리적으로 차단하는 방법입니다. 호르몬을 사용하지 않으며, 올바르게 사용하면 임신 예방과 성매개감염 위험 감소에 도움이 됩니다.</p>
				</li>
				<li>
					<h3><p>경구피임약</p></h3>
					<img src="/images/sub/clinic1-2-img2.png">
					<p class="t1">여성호르몬을 조절하여 배란을 억제하는 피임 방법으로, 매일 일정한 시간에 복용해야 합니다. 종류에 따라 복용 일정이 다르며 올바른 복용이 중요합니다.</p>
				</li>
				<li>
					<h3><p>미레나·카일리나</p></h3>
					<img src="/images/sub/clinic1-2-img3.png">
					<p class="t1">자궁 내부에 작은 장치를 삽입하여 호르몬을 방출하는 피임 방법입니다. 제품에 따라 약 5~8년간 피임 효과가 유지되며 월경량 감소에도 도움이 될 수 있습니다.</p>
				</li>
				<li>
					<h3><p>루프</p></h3>
					<img src="/images/sub/clinic1-2-img4.png">
					<p class="t1">자궁 내 정치 삽입, 호르몬을 사용하지 않고 구리의 작용으로 수정을 방해하는 피임 방법입니다. 제품에 따라 약 5~10년 이상 장기간 피임이 가능하며 월경량이나 생리통이 증가할 수 있습니다.</p>
				</li>
				<li>
					<h3><p>임플라논</p></h3>
					<img src="/images/sub/clinic1-2-img5.png">
					<p class="t1">팔 안쪽 피부 아래에 작은 막대 형태의 피임제를 삽입하여 호르몬을 지속적으로 방출합니다. 장기간 피임 효과가 유지되며 제품과 허가 기준에 따라 사용 기간이 다릅니다.</p>
				</li>
				<li>
					<h3><p>응급피임약</p></h3>
					<img src="/images/sub/clinic1-2-img6.png">
					<p class="t1">피임하지 않은 성관계나 피임 실패 후 임신 가능성을 낮추기 위해 사용하는 약물입니다. 종류에 따라 성관계 후 72~120시간 이내 복용하며, 가능한 한 빨리 의료진과 상담하는 것이 중요합니다.</p>
				</li>
			</ul>
		</div>
	</section>






<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>피임,  이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">어떤 피임 방법이 가장 효과적인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>피임 방법은 개인의 건강 상태, 연령, 출산 경험, 향후 임신 계획 등에 따라 달라질 수 있습니다. 자궁 내 장치와 피하 이식형 피임제는 일반적인 사용에서 99% 이상의 높은 피임 효과를 보이지만, 개인에게 적합한 방법을 선택하기 위해서는 산부인과 전문의와 상담하는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">출산 경험이 없어도 자궁 내 장치를 사용할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네, 출산 경험이 없는 여성도 자궁 내 장치를 사용할 수 있습니다. 다만 자궁의 크기와 형태, 건강 상태 등을 확인한 후 적합한 장치를 선택해야 하며, 삽입 과정에서 일시적인 통증이나 불편함이 발생할 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">자궁 내 장치 삽입 시 통증이 심한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>통증의 정도는 개인마다 차이가 있으며, 삽입 과정에서 생리통과 비슷한 복부 통증이나 경련이 발생할 수 있습니다. 대부분 일시적이지만 통증이 심하거나 지속되는 경우에는 진료를 통해 상태를 확인하는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">피하 이식형 피임제는 얼마나 오래 효과가 유지되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>피하 이식형 피임제는 팔 안쪽 피부 아래에 작은 막대 형태의 장치를 삽입하는 방법으로, 제품에 따라 약 3~5년간 피임 효과가 유지됩니다. 매일 피임약을 복용할 필요가 없어 장기간 피임을 원하는 여성에게 적합할 수 있습니다.</p>
                </div>
            </div>


			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">피임 장치를 제거하면 바로 임신이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>자궁 내 장치와 피하 이식형 피임제는 제거 후 일반적으로 가임력이 빠르게 회복됩니다. 다만 실제 임신까지 걸리는 시간은 개인의 연령과 건강 상태, 배란 기능 등에 따라 차이가 있을 수 있습니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">피임 시술 후 부작용이 발생할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>피임 방법에 따라 부정출혈, 생리주기 변화, 복부 불편감, 두통 등의 증상이 나타날 수 있습니다. 대부분의 증상은 시간이 지나면서 완화될 수 있지만, 심한 복통이나 과다출혈, 발열 등의 증상이 발생하면 즉시 진료를 받아야 합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>





</div>
</div>
<?php include "../inc/bottom.php"; ?>
