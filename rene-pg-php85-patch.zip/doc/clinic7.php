<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "임신중절수술";
$page_canonical = "https://reneclinic.co.kr/doc/clinic7.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "7";
	$category = "임신중절수술";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic7.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">임신 초기에 시행하는 <br>의료적 임신중단 방법</h2>
			<ul class="t1">
				<li>임신중절수술은 자궁 내의 임신 조직을 제거하는 의료적 시술입니다.</li>
				<li>본원에서는 수면마취 하에 흡인소파술(Vacuum Aspiration & Curettage) 방식으로 진행되며
개인의 건강상태, 임신 주수에 따라 준비 과정과 회복 과정이 달라질 수 있어 사전에 정확한 진단이 필요합니다.</li>
				<li>본원에서는 10주미만의 초기 산모만 임신중절수술을 시행하고 있습니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>





<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class=" inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>임신중절수술 진행 과정</h2>
		<p class="t1">본원에서는 수면마취 하에 흡인소파술(Vacuum Aspiration & Curettage) 방식으로 진행됩니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4">
			<li>
				<h3><p>초음파 검사</p></h3>
				<img src="/images/sub/clinic7-1-img1.png">
				<p class="t1 ">임신 위치(자궁내/자궁외), 주수를 정확하게 확인합니다. <br>
임신 10주 이하일 때 수술이 가능합니다.</p>
			</li>
			<li>
				<h3><p>수면마취</p></h3>
				<img src="/images/sub/clinic7-1-img2.png">
				<p class="t1 ">전문적인 수면마취로 통증과 불안을 최소화하며, 수술 중 산소공급 및 지속적 모니터링을 진행합니다.</p>
			</li>
			<li>
				<h3><p>흡인소파술</p></h3>
				<img src="/images/sub/clinic7-1-img3.png">
				<p class="t1 ">자궁경부를 부드럽게 연 후, 흡인기구로 임신조직을 안전하게 제거하고 필요 시 소파를 통해 잔여 조직을 정리합니다.
시술 시간은 약 10~30분 정도입니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>


<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>임신중절수술 후 주의사항</h2>
		</div>
		<div class="txtList">
			<ul>							
				<li><p>수술 당일 무리한 활동·운동 피하기</p></li>
				<li><p>질출혈이 생길 수 있어 생리대 사용 (탐폰·생리컵은 2주간 피하기)</p></li>
				<li><p>오염 위험 있는 탕목욕·수영·사우나는 2주간 금지</p></li>	
				<li><p>복통·과다출혈·발열·냄새나는 분비물 발생 시 즉시 병원 방문</p></li>
				<li><p>성관계는 2주 이상 회복 후 가능</p></li>
				<li><p>1~2주 후 자궁 회복 확인을 위한 검진 반드시 내원</p></li>
			</ul>
		</div>
	</div>
</div>








<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>임신중절수술, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신중절수술은 언제까지 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>임신 초기일수록 안전성이 높습니다. <br>
일반적인 흡인·소파술은 임신 초기에 가능한 수술법으로 주수가 더 진행되면 방법이 달라지거나 난이도가 높아질 수 있습니다.
따라서 가능한 빠르게 초음파로 임신 주수를 확인하는 것이 중요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">수술이 많이 아픈가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>수술은 수면마취로 진행되기 때문에 과정 중 통증은 느끼지 않습니다. <br>
이후에는 생리통처럼 뻐근한 느낌이 있을 수 있으나 대부분 약물로 조절이 됩니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">수술 후 회복은 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>대부분 당일 귀가가 가능하며 일상생활 복귀도 비교적 빠릅니다.
다만 무리한 활동·운동은 2~3일 피하는 것이 좋고, 성관계·탐폰 사용·탕목욕은 약 2주 정도 금지합니다. <br>
감염예방을 위해 항생제가 처방되며, 1~2주 후 자궁 회복 확인을 위한 내원이 권장됩니다.</p>
                </div>
            </div>


            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">수술 후 다시 임신이 되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>정상적으로 회복되면 향후 임신에는 대부분 문제가 없습니다. <br>
자궁에 심한 염증이나 합병증이 발생하지 않는 한, 임신 가능성이나 임신 유지 능력이 크게 떨어지지 않습니다.
단, 수술 후 일정 기간은 피임을 확실히 하는 것이 필요합니다.</p>
                </div>
            </div>



        </div>
    </div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
