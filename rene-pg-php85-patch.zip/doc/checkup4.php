<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "성병검진";
$page_canonical = "https://reneclinic.co.kr/doc/checkup4.php"
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "6";
	$p_num = "4";
	$category = "성병검진";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-checkup4.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">특별한 증상이 없어도 세심하게, <br>건강을 지키는 성병검진</h2>
			<ul class="t1">
				<li>성병검진은 성접촉을 통해 전파될 수 있는 다양한 감염성 질환의 감염 여부를 확인하고, <br>조기 발견과 적절한 치료를 돕기 위한 검사입니다.</li>
				<li>일부 성매개감염은 특별한 증상 없이 진행되기도 하며, 치료가 늦어질 경우 골반염이나 난임 등 합병증으로 이어질 수 있습니다. 르네여성의원은 개인의 증상과 건강 상태, 감염 위험요인을 고려하여 필요한 검사를 안내하고 여성의 생식 건강을 세심하게 살핍니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>성병검진의 중요성</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>특별한 증상을 보이지 않는 경우도 있어 더욱 더 검진과 예방이 필요합니다.</li>
			<li>의학이 발전되고 진단기술이 발전되면서 기존에 잘 몰랐던 새로운 성병균들이 발견되었고, 이는 매독, 에이즈처럼 중대한 위험을 가진다기보다는 '잦은 질염', '성관계를 통해 전파되고 재감염되는 염증'의 형태로 나타나게 됩니다.</li>
			<li>전체 성인의 50% 이상이 한 번 이상 감염될 정도로 흔한 질병이지만, 오래 방치될 경우 만성염증으로 인해 불임, 습관유산, 조기진통, 골반염 등이 생길 수 있습니다.</li>
		</ul>		
	</div>
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>무증상 감염 확인</li>
				<li>여성 생식 건강 보호</li>
				<li>추가 감염 전파 예방</li>
				<li>개인별 맞춤 검사</li>
			</ul>
	</div>
		<div class="clinicTxt pt0">
		<p class="t2 fc-bl">성매개감염은 가려움이나 분비물 변화, 통증 등의 증상이 나타날 수 있지만 특별한 증상 없이 감염이 지속되는 경우도 있습니다.</p>
	</div>
</section>





<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>평소와 다른 질 분비물이나 냄새가 나타나는 분</p></li>
				<li><p>외음부 가려움, 통증, 따가움이 반복되는 분</p></li>
				<li><p>성관계 후 통증이나 비정상적인 출혈이 있는 분</p></li>
				<li><p>새로운 성 파트너가 생겼거나 감염이 걱정되는 분</p></li>
				<li><p>성 파트너의 성매개감염이 확인된 분</p></li>
				<li><p>특별한 증상은 없지만 감염 여부를 확인하고 싶은 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>





<section id="clinicIntro" class="subBG p-Part-b">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>성병검진 주요 항목</h2>
			<p class="t1">감염을 일으키는 원인균과 바이러스에 따라 검사 방법이 달라지며, <br>분비물·소변·혈액 검사 등을 통해 감염 여부를 확인합니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box w4">
				<li>
					<dl>
						<dt>클라미디아 검사</dt>
						<dd>클라미디아균 감염 여부와 자궁경부염, 골반염 등의 원인 확인</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>임질 검사</dt>
						<dd>임균 감염 여부와 비정상적인 분비물, 배뇨통 등의 원인 확인</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>트리코모나스 검사</dt>
						<dd>트리코모나스 원충 감염 여부와 가려움증, 질 분비물 이상 확인</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>매독 검사</dt>
						<dd>혈액검사를 통한 매독 감염 여부 및 질환 진행 상태 평가</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>HIV 검사</dt>
						<dd>혈액검사를 통한 HIV 감염 여부 확인 및 조기 진단</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>B형간염 검사</dt>
						<dd>B형간염 바이러스 감염 여부와 면역 상태 및 항체 확인</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>HPV 검사</dt>
						<dd>고위험 인유두종바이러스 감염 여부와 자궁경부암 위험 평가</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>생식기 헤르페스 검사</dt>
						<dd>생식기 물집이나 궤양 등 병변의 헤르페스 바이러스 감염 확인</dd>
					</dl>
				</li>				
			</ul>
		</div>
	</div>
</div>
</section>





<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>성병검사, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">	

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">증상이 없어도 성병검진을 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네. 클라미디아나 임질 등 일부 성매개감염은 증상이 없는 경우도 많습니다. 성생활과 연령, 감염 위험요인 등에 따라 증상이 없어도 정기적인 검사가 권장될 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">성병검진은 어떤 방법으로 진행하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>검사 항목에 따라 질 분비물이나 자궁경부 검체, 소변, 혈액 등을 채취합니다. 모든 검사를 한 번에 시행하는 것은 아니며 증상과 감염 위험요인에 따라 필요한 항목을 결정합니다..</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">성병이 발견되면 완치할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>클라미디아, 임질, 매독 등은 적절한 항생제 치료로 완치를 기대할 수 있습니다. 반면 헤르페스나 HIV 등 일부 바이러스 감염은 지속적인 치료와 관리가 필요합니다. 감염 종류에 따라 치료 방법이 다릅니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">성병이 발견되면 파트너도 검사받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>감염 종류에 따라 성 파트너의 검사와 치료가 필요할 수 있습니다. 치료 후 재감염을 예방하기 위해 파트너 관리와 성관계 재개 시점에 대한 의료진의 안내를 따르는 것이 중요합니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검진 시 주요 항목을 모두 검사하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>아니요. 모든 항목을 일괄적으로 검사하는 것은 아닙니다. 개인의 증상과 건강 상태, 감염 위험요인 등을 고려하여 의료진과의 상담을 통해 필요한 검사 항목을 선택하여 진행합니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리 중에도 성병검진을 받을 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>혈액검사나 일부 소변검사는 생리 중에도 가능하지만, 질 분비물 검사 등은 출혈 상태에 따라 검체 채취나 검사 일정의 조정이 필요할 수 있습니다. 증상이 심하다면 생리가 끝날 때까지 진료를 미루지 말고 상담받는 것이 좋습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>





</div>
</div>
<?php include "../inc/bottom.php"; ?>
