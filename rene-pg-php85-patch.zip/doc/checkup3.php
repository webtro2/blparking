<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "산전검진";
$page_canonical = "https://reneclinic.co.kr/doc/checkup3.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "6";
	$p_num = "3";
	$category = "산전검진";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>

	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-checkup3.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">산모와 태아의 건강을 위한 <br>가장 기본적인 산전검진</h2>
			<ul class="t1">
				<li>산전검진은 임신을 준비하는 단계부터 임신 중 출산 전까지 산모와 태아의 건강 상태를 체계적으로 확인하는 중요한 검사입니다.</li>
				<li>르네여성의원은 임신 전 건강 상태를 점검하고, 임신 주수에 따른 적절한 검사를 통해 태아의 성장과 발달, 산모의 건강 변화를 세심하게 살펴 건강한 임신과 출산을 준비할 수 있도록 돕습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>산전검사의 중요성</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>임신 중에는 산모의 신체에 다양한 변화가 나타나며, 태아 역시 주수에 따라 성장하고 발달합니다.</li>
			<li>정기적인 산전검진은 산모의 건강과 태아의 발달 상태를 확인하고 임신 중 발생할 수 있는 위험요인을 조기에 발견하여 <br>적절하게 관리하는 데 도움을 줍니다.</li>
		</ul>		
	</div>
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>예방접종 및 면역 상태 확인</li>
				<li>임신 전·후 건강 <br>상태 확인</li>
				<li>태아의 성장과 <br>발달 확인</li>
				<li>임신 합병증 <br>조기 발견</li>
				<li>건강한 임신·출산 준비</li>
			</ul>
	</div>
</section>






<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>임신을 준비하며 건강 상태를 확인하고 싶은 분</p></li>
				<li><p>임신이 확인되어 초기 검진이 필요한 분</p></li>
				<li><p>태아의 성장과 발달 상태를 확인하고 싶은 분</p></li>
				<li><p>고령 임신이나 고위험 임신으로 관리가 필요한 분</p></li>
				<li><p>임신성 당뇨 등 임신 합병증이 걱정되는 분</p></li>
				<li><p>건강한 출산을 위해 정기적인 검진이 필요한 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>





<section class="subBG p-Part-b ">
	<div id="checkup2" class=" s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">BASIC CHECKUP</p>
			<h2>임신 전·후 주요 검진 항목</h2>
			<p class="t1">아래의 표를 바탕으로 산전검진이 진행되지만, 환자상태에 따라 맞춤형 검사 프로그램을 만들어드립니다.</p>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
					<col width="20%">
					<col width="30%">
					<col width="50%">
				</colgroup>
                <thead>
                    <tr>
						<th>시기</th>
						<th>검사명</th>
						<th>검사내용</th>
					</tr>
                </thead>
                <tbody>
				<tr>
					<td rowspan="5">임신 전 기본 검사</td>
					<th>자궁·난소 초음파</th>
					<td class="left">자궁근종, 난소낭종 등 자궁 및 난소의 건강 상태 확인</td>
				</tr>
				<tr>
					<th>기초 혈액검사</th>
					<td class="left">혈액형, Rh 인자, 빈혈 등 기본적인 건강 상태 확인</td>
				</tr>
				<tr>
					<th>감염성 질환 및 항체 검사</th>
					<td class="left">풍진·수두 항체, B형간염, 매독, HIV 등 감염 및 면역 상태 확인</td>
				</tr>
				<tr>
					<th>자궁경부암 검사</th>
					<td class="left">자궁경부 세포 이상 및 필요에 따른 HPV 감염 여부 확인</td>
				</tr>
				<tr>
					<th>갑상선·혈당 검사</th>
					<td class="left">갑상선 기능과 혈당 이상 여부 확인</td>
				</tr>
				<tr>
					<td rowspan="6">임신 초기 기본 검사</td>
					<th>병력 청취</th>
					<td class="left">내과적질환, 수술력, 가족력, 산과력등 문진</td>
				</tr>
				<tr>
					<th>골반 진찰</th>
					<td class="left">냉, 성병, 자궁기형, 정맥류, 골반 크기 등</td>
				</tr>
				<tr>
					<th>초음파 검사</th>
					<td class="left">정상 임신 여부, 태아 크기, 심박동, 쌍태 유무, 자궁, 난소 기타 이상소견 유무 확인</td>
				</tr>
				<tr>
					<th>자궁경부 세포진검사</th>
					<td class="left">자궁경부암 조기 발견을 위한 필수 검진</td>
				</tr>
				<tr>
					<th>소변 검사</th>
					<td class="left">당뇨, 단백뇨, 혈뇨, 세균 유무</td>
				</tr>
				<tr>
					<th>혈액 검사</th>
					<td class="left">빈혈, 혈액형, 간염, 매독, 에이즈, 풍진검사 간/신장/갑상선 기능검사</td>
				</tr>
				<tr>
					<td rowspan="3">11 ~ 13주</td>
					<td class="left" colspan="2">임신초기 기형아선별 혈액검사 (PAPP-A, free B-hCG)</td>
				</tr>
				<tr>
					<td class="left" colspan="2">임신초기 정밀 초음파 검사 (태아 목투명대, 코뼈등)</td>
				</tr>
				<tr>
					<td class="left" colspan="2">융모막 검사 (필요시)</td>
				</tr>
				<tr>
					<td rowspan="2">15 ~ 18주</td>
					<td class="left" colspan="2">임신중기 기형아선별 혈액검사 (QUAD 검사)</td>
				</tr>
				<tr>
					<td class="left" colspan="2">양수검사 (필요시)</td>
				</tr>
				<tr>
					<td>20 ~ 24주</td>
					<td class="left" colspan="2">임신중기 정밀 초음파 검사</td>
				</tr>
				<tr>
					<td rowspan="4">24 ~ 28주</td>
					<th>임신성 당뇨 선별 혈액검사</th>
					<td class="left"></td>
				</tr>
				<tr>
					<th>혈액 검사</th>
					<td class="left">빈혈 유무</td>
				</tr>
				<tr>
					<th>소변 검사</th>
					<td class="left">당뇨, 단백뇨 유무</td>
				</tr>
				<tr>
					<th>입체초음파</th>
					<td class="left"></td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>
</section>






<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>산전검사, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">	

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신이 확인되면 언제 산부인과에 방문해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>임신테스트기에서 양성이 확인되면 산부인과에 내원하여 임신 위치와 상태를 확인하는 것이 좋습니다. 일반적으로 마지막 생리 시작일 기준 임신 5~6주경에 초음파로 자궁 내 임신 여부를 확인할 수 있으며, 확인 시기는 개인마다 다를 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신 전 검사를 받았다면 임신 후에도 검사가 필요한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네. 임신 전 검사와 임신 후 산전검사는 목적이 다릅니다. 임신 후에는 태아의 성장과 발달, 산모의 건강 변화 등을 확인해야 하므로 주수에 맞는 산전검사가 필요합니다. 일부 중복 검사는 기존 결과에 따라 조정될 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">산전검사는 모두 필수로 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>산모의 기본 건강검사와 임신성 당뇨 선별검사 등 일반적으로 권장되는 검사들이 있습니다. 반면 NIPT와 같은 염색체 이상 선별검사는 충분한 설명을 듣고 선택할 수 있으며, 정밀검사 여부도 개인의 건강 상태와 검사 결과에 따라 달라집니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">태아 정밀초음파는 언제 받나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 임신 18~22주경에 시행하며, 태아의 뇌, 심장, 척추, 복부 및 사지 등 주요 신체 구조를 살펴봅니다. 다만 모든 선천적 이상을 발견할 수 있는 것은 아닙니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">임신성 당뇨 검사는 언제 진행하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 임신 24~28주에 선별검사를 진행합니다. 당뇨병 위험요인이 있거나 과거 임신성 당뇨를 경험한 경우에는 임신 초기부터 추가 검사를 고려할 수 있습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>





</div>
</div>
<?php include "../inc/bottom.php"; ?>
