<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "갱년기증상";
$page_canonical = "https://reneclinic.co.kr/doc/climac1.php"
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "7";
	$p_num = "2";
	$category = "갱년기증상";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>






	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-climac2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">몸과 마음에 찾아오는 변화, <br>다양한 갱년기 증상</h2>
			<ul class="t1">
				<li>갱년기에는 여성호르몬의 감소와 호르몬 균형의 변화로 인해 신체적·정서적으로 다양한 증상이 나타날 수 있습니다.</li>
				<li>안면홍조, 발한, 수면장애, 감정 기복, 질 건조감 등 증상의 종류와 정도는 개인마다 다르며, 일상생활에 불편함을 줄 수 있어 자신의 몸 상태를 이해하고 적절하게 관리하는 것이 중요합니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>


	<section id="climac2" class="s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>호르몬 변화가 시작되는 시기</h2>
			<p class="t1">여성호르몬의 변화로 월경주기가 불규칙해지고 안면홍조나 발한, 피로감, 감정 기복 등의 <br>증상이 나타날 수 있습니다.</p>
			
		</div>
		<div class="clima2-img">
			<ul class="flex-Box">
				<li>
					<h3><p>안면홍조</p></h3>
					<img src="/images/sub/climac2-1-img1.png">
					<p class="t1">얼굴, 목 등 가슴 위쪽 부위에 열감이 오르고 붉어지는 증상으로 갑자기 발생하여 1-5분 정도 지속됩니다.</p>
				</li>
				<li>
					<h3><p>땀 흘림</p></h3>
					<img src="/images/sub/climac2-1-img2.png">
					<p class="t1">안면홍조 이후에 동반되어 나타나는 경우가 많으며 땀을 흘리는 양이 늘어 옷이 젖는다 합니다.</p>
				</li>
				<li>
					<h3><p>수면 장애</p></h3>
					<img src="/images/sub/climac2-1-img3.png">
					<p class="t1">잠이 잘 안 오고 자주 깨고, 한 번 깨면 다시 잠들기 어렵습니다.</p>
				</li>
				<li>
					<h3><p>가슴 두근거림</p></h3>
					<img src="/images/sub/climac2-1-img4.png">
					<p class="t1">안면 홍조와 동반되는 경우가 있고, 스트레스가 심한 상황에서 두드러집니다. 건강에 대한 염려와 불안감으로 이어질 수 있습니다.</p>
				</li>
				<li>
					<h3><p>우울감, 짜증</p></h3>
					<img src="/images/sub/climac2-1-img5.png">
					<p class="t1">몸의 변화, 사회적인 위치 변화, 자녀의 성장과 독립 등과 더불어 많은 변화 때문에 심리적인 영향을 받을 수 있습니다.</p>
				</li>
				<li>
					<h3><p>체중 증가</p></h3>
					<img src="/images/sub/climac2-1-img6.png">
					<p class="t1">전체 체중이 늘기도 하지만 체지방률이 특히 증가합니다. 복부지방 축적이 늘어나면서 각종 성인병의 원인이 될 수 있습니다.</p>
				</li>
			</ul>
		</div>
	</section>





<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class="inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>신체적·정서적 불편함이 두드러지는 시기</h2>
		<p class="t1">폐경 전후로 여성호르몬이 감소하면서 안면홍조와 야간 발한, 수면장애 등이 심해질 수 있으며 <br>질 건조감이나 배뇨 불편감이 동반되기도 합니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box breast1">
			<li>
				<h3><p>질 건조감</p></h3>
				<img src="/images/sub/climac2-2-img1.png">
				<p class="t1">여성호르몬 감소로 질 점막이 얇아지고 수분과 윤활 기능이 저하되어 건조함, 가려움, 따가움 등의 불편함이 나타날 수 있습니다.</p>
			</li>
			<li>
				<h3><p>성교통</p></h3>
				<img src="/images/sub/climac2-2-img2.png">
				<p class="t1">질 점막의 탄력과 윤활 기능이 감소하면서 성관계 시 마찰로 인한 통증이나 자극이 발생하여 성생활에 불편함을 느낄 수 있습니다.</p>
			</li>
			<li>
				<h3><p>피부 탄력 감소</p></h3>
				<img src="/images/sub/climac2-2-img3.png">
				<p class="t1">에스트로겐 감소로 피부의 콜라겐과 수분함량이 줄어들면서 탄력이 저하되고, 피부 건조와 잔주름 등의 변화가 나타날 수 있습니다.</p>
			</li>
			<li>
				<h3><p>근골격계 통증</p></h3>
				<img src="/images/sub/climac2-2-img4.png">
				<p class="t1">호르몬 변화와 노화 등의 영향으로 관절과 근육에 뻣뻣함이나 통증이 나타날 수 있으며, 특히 허리와 무릎, 어깨 등에 불편함을 느끼기도 합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>






	<section id="climac2" class="s-inner p-Part">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>장기적인 건강 관리가 <br class="br480">중요한 시기</h2>
			<p class="t1">폐경 이후 에스트로겐 감소가 지속되면서 골밀도 저하와 골다공증 위험이 증가하고, <br>질과 요로의 위축성 변화 등 장기적인 건강 문제가 나타날 수 있습니다.</p>
			
		</div>
		<div class="clima2-img">
			<ul class="flex-Box">
				<li>
					<h3><p>골다공증</p></h3>
					<img src="/images/sub/climac2-3-img1.png">
					<p class="t1">폐경 이후 에스트로겐 감소로 골밀도가 빠르게 낮아지면서 뼈가 약해지고, 골다공증과 골절의 위험이 증가할 수 있습니다.</p>
				</li>
				<li>
					<h3><p>심혈관 질환</p></h3>
					<img src="/images/sub/climac2-3-img2.png">
					<p class="t1">폐경 이후 호르몬 변화와 노화 등의 영향으로 혈중 콜레스테롤과 혈관 건강에 변화가 생기면서 심혈관질환의 발생 위험이 높아질 수 있습니다.</p>
				</li>
				<li>
					<h3><p>치매 질환</p></h3>
					<img src="/images/sub/climac2-3-img3.png">
					<p class="t1">폐경 이후 노화와 다양한 건강 요인의 영향으로 인지기능이 저하될 수 있으며, 고령으로 접어들수록 치매 발생 위험에 대한 지속적인 관리가 중요합니다.</p>
				</li>
			</ul>
		</div>
	</section>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
