<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "생리불순";
$page_canonical = "https://reneclinic.co.kr/doc/clinic3.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "8";
	$p_num = "3";
	$category = "생리불순";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-clinic3.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">반복되는 생리불순, <br>원인에 맞는 진단과 치료</h2>
			<ul class="t1">
				<li>보통 정상적으로 여겨지는 생리주기는 21-40일 정도 입니다.</li>
				<li>대부분 한달 전후로 며칠 정도의 차이로 주기가 달라지는 것은 문제가 없으나 지속적으로 한 달에 두번 이상 생리를 하거나 2-3개월간 생리가 없는 경우 특별한 문제가 없는지 확인하고 주기 조절을 고려해야 합니다.</li>
				<li>일시적인 변화일 수도 있지만 증상이 반복된다면 정확한 검사를 통해 원인을 확인하고 적절하게 관리하는 것이 중요합니다.</li>
			</ul>
		</div>
	</div>


<?php include "../inc/clinic-marquee.php"; ?>





<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>생리불순의 원인</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>생리불순은 여성호르몬의 변화뿐 아니라 스트레스, 체중 변화, 생활습관, 난소 및 갑상선 기능 이상 등 다양한 원인으로 발생할 수 있습니다.</li>
			<li>일시적인 호르몬 변화로 나타나기도 하지만 자궁암처럼 생명을 위협하는 질환에 의해서 발생할 수 있기때문에 증상이 나타난다면 <br>가까운 병원을 방문해 진찰받는 것이 좋습니다.</li>
			<li>조기에 진단하고 치료하게 된다면 불임이나 자궁암 이전 등의 심각한 합병증의 위험을 낮출 수 있습니다.</li>
		</ul>		
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>스트레스</li>				
				<li>수면 부족</li>
				<li>급격한<br class="br480">체중 변화</li>
				<li>다낭성난소<br class="br480">증후군</li>
				<li>갑상선 기능 이상</li>
				<li>난소 기능 저하</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">반복되는 생리불순이나 장기간 무월경이 나타난다면 <br>호르몬검사와 초음파검사 등을 통해 원인을 확인하는 것이 중요합니다.</p>
	</div>
</section>









<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class="s-inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>생리불순 검사 및 진단</h2>
		<p class="t1">생리불순은 증상의 양상과 발생 원인이 다양하기 때문에 정확한 진단이 중요합니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box labia4">
			<li>
				<h3><p>문진 및 상담</p></h3>
				<img src="/images/sub/clinic3-1-img1.png">
				<p class="t1">생리주기, 출혈량, 생리 기간과 동반 증상을 확인하고 생활습관 및 복용 약물 등을 파악합니다.</p>
			</li>
			<li>
				<h3><p>초음파검사</p></h3>
				<img src="/images/sub/clinic3-1-img2.png">
				<p class="t1">자궁과 난소의 상태를 확인하여 자궁근종, 자궁내막 이상, 난소질환 등의 가능성을 살펴봅니다.</p>
			</li>
			<li>
				<h3><p>혈액 및 호르몬검사</p></h3>
				<img src="/images/sub/clinic3-1-img3.png">
				<p class="t1">필요에 따라 임신 여부와 갑상선 기능, 프로락틴, 난소 관련 호르몬 등을 확인합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>






<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>생리불순, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리주기가 불규칙하면 반드시 치료해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일시적인 변화라면 경과를 관찰할 수 있지만, 불규칙한 생리가 반복되거나 장기간 지속된다면 원인 확인을 위한 진료가 필요합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리를 몇 달 동안 하지 않으면 병원에 가야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>기존에 규칙적이던 생리가 3개월 이상 없거나 원래 불규칙하던 생리가 6개월 이상 없다면 검사를 권장합니다. 임신 가능성도 먼저 확인해야 합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리불순이 있으면 임신이 어려운가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>배란이 불규칙한 경우 임신 가능성이 낮아질 수 있지만, 생리불순이 반드시 난임을 의미하지는 않습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리불순 검사는 어떻게 진행하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>생리주기와 증상을 확인한 후 필요에 따라 초음파검사, 임신검사, 호르몬검사 등을 시행하여 원인을 파악합니다.</p>
                </div>
            </div>

			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">피임약으로 생리불순을 치료할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>원인에 따라 호르몬 피임약이 생리주기 조절에 도움이 될 수 있습니다. 다만 모든 생리불순에 적합한 것은 아니므로 상담 후 사용해야 합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
