<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "르네 검진패키지";
$page_canonical = "https://reneclinic.co.kr/doc/checkup1.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "6";
	$p_num = "1";
	$category = "르네 검진패키지";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont" class="pb0">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>




	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-checkup1.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">여성의 건강한 삶을 위한 <br>르네만의 맞춤 검진 프로그램</h2>
			<ul class="t1">
				<li>여성의 건강은 나이와 생활환경, 신체 변화에 따라 세심한 관리가 필요합니다. </li>
				<li>르네여성의원은 개인의 건강 상태와 검진 목적에 맞춰 선택할 수 있는 다양한 검진 패키지를 통해 여성의 건강을 체계적으로 살피고, 질환의 조기 발견과 예방을 돕습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>


	<div id="checkup1" class="flex-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>기본검진 패키지</h2>
			<dl>
				<dt class="fc-M1">여성 건강관리의 시작, 꼭 필요한 기본검진</dt>
				<dd>여성 건강을 정기적으로 확인하고 싶은 분들을 위한 기본 검진 프로그램으로 <br class="br1280">주요 건강 상태를 점검하고 질환의 조기 발견을 돕습니다.</dd>
			</dl>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="25%">
					<col width="75%">
                </colgroup>
                <thead>
                    <tr>
                        <th>종류</th>
                        <th>내용</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
					<th>액상 검사</th>
					<td class="left">자궁경부 외부, 내부의 세포를 채취하는 가장 기본적인검사입니다.</td>
				</tr>
				<tr>
					<th>초음파 검사</th>
					<td class="left">자궁과 난소의 모양과 크기, 종양의 유무를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>자궁경부확대경 검사</th>
					<td class="left">특수 사진기로 자궁경부를 확대 촬영하여 이상유무를 판독하는 검사입니다.</td>
				</tr>
				<tr>
					<th>인유두종바이러스 검사</th>
					<td class="left">자궁경부암을 유발하는 인유두종바이러스의 위험도와 종류를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>STD 12종 검사</th>
					<td class="left">성병의 원인이 되는 원인균, 바이러스를 정확히 파악하는 검사입니다.</td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>






<section class="subBG2 p-Part-b m-Part">
	<div id="checkup1" class="flex-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>프리미엄 패키지</h2>
			<dl>
				<dt class="fc-M1">한층 더 세심하게 살펴보는 여성 건강</dt>
				<dd>기본적인 건강 확인을 넘어 보다 폭넓은 검진을 원하는 분들을 위한 프로그램으로 <br class="br1280">여성 건강과 관련된 다양한 항목을 종합적으로 살펴봅니다.</dd>
			</dl>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="25%">
					<col width="75%">
                </colgroup>
                <thead>
                    <tr>
                        <th>종류</th>
                        <th>내용</th>
                    </tr>
                </thead>
                <tbody>
				<tr>
					<th>액상 검사</th>
					<td class="left">자궁경부 외부, 내부의 세포를 채취하는 가장 기본적인검사입니다.</td>
				</tr>
				<tr>
					<th>초음파 검사</th>
					<td class="left">자궁과 난소의 모양과 크기, 종양의 유무를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>자궁경부확대경 검사</th>
					<td class="left">특수 사진기로 자궁경부를 확대 촬영하여 이상유무를 판독하는 검사입니다.</td>
				</tr>
				<tr>
					<th>인유두종바이러스 검사</th>
					<td class="left">자궁경부암을 유발하는 인유두종바이러스의 위험도와 종류를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>STD 12종 검사</th>
					<td class="left">성병의 원인이 되는 원인균, 바이러스를 정확히 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>난소암 혈액검사</th>
					<td class="left">혈액검사로 난소암에서 올라가는 수치들을 검사하여 이들을 종합하여 위험도를 산정하는 검사입니다.</td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>
</section>






	<div id="checkup1" class="flex-Box s-inner p-Part">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>VIP 패키지</h2>
			<dl>
				<dt class="fc-M1">여성 건강을 더욱 폭넓고 정밀하게</dt>
				<dd>자신의 건강 상태를 더욱 면밀하게 확인하고 싶은 분들을 위한 종합 검진 프로그램으로 <br class="br1280">다양한 검진 항목을 통해 건강 상태를 폭넓게 점검합니다.</dd>
			</dl>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="25%">
					<col width="75%">
                </colgroup>
                <thead>
                    <tr>
                        <th>종류</th>
                        <th>내용</th>
                    </tr>
                </thead>
                <tbody>
                   <tr>
					<th>액상 검사</th>
					<td class="left">자궁경부 외부, 내부의 세포를 채취하는 가장 기본적인검사입니다.</td>
				</tr>
				<tr>
					<th>초음파 검사</th>
					<td class="left">자궁과 난소의 모양과 크기, 종양의 유무를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>자궁경부확대경 검사</th>
					<td class="left">특수 사진기로 자궁경부를 확대 촬영하여 이상유무를 판독하는 검사입니다.</td>
				</tr>
				<tr>
					<th>인유두종바이러스 검사</th>
					<td class="left">자궁경부암을 유발하는 인유두종바이러스의 위험도와 종류를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>STD 12종 검사</th>
					<td class="left">성병의 원인이 되는 원인균, 바이러스를 정확히 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>난소암 혈액검사</th>
					<td class="left">혈액검사로 난소암에서 올라가는 수치들을 검사하여 이들을 종합하여 위험도를 산정하는 검사입니다.</td>
				</tr>
				<tr>
					<th>난소나이 검사</th>
					<td class="left">검사를 통해 난소의 기능이 얼마나 남았는지 간접적으로 난소의 나이를 추정하는 검사입니다.</td>
				</tr>
				<tr>
					<th>호르몬 검사</th>
					<td class="left">각 호르몬의 검사를 통하여 배란에 관계되는 호르몬의 이상유무를 확인하는 검사입니다.</td>
				</tr>
				<tr>
					<th>기초혈액 검사</th>
					<td class="left">혈액 속의 유형성분인 혈구를 분석하는 검사입니다.</td>
				</tr>
				<tr>
					<th>유방 촬영술</th>
					<td class="left">유방촬영술은 유방암 진단의 가장 기본적인 검사 방법입니다. 유방암의 초기 특징인 미세한 석회화까지 발견을 할 수 있어 꼭 필요한 검사라고 할 수 있습니다.</td>
				</tr>
				<tr>
					<th>유방 초음파 검사</th>
					<td class="left"> 7.5MHz 이상의 선형 탐촉자를 이용한 고해상도 초음파 기기를 이용하여 유방 질환을 진단하는 검사입니다. 검사의 방법이 매우 간편하고, 검사로 인한 방사선피폭의 위험이 없으므로 모든 연령층의 여성에게 반복적으로 사용할 수 있는 검사방법입니다.</td>
				</tr>
				<tr>
					<th>골밀도검사</th>
					<td class="left">폐경 후에는 골밀도가 급격히 감소하며 쉽게 골다공증이 생깁니다.<br>
						이에 대한 파악과 예방, 조기 치료가 꼭 필요합니다.</td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>






<section class="subBG2 p-Part-b m-Part">
	<div id="checkup1" class="flex-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>갱년기 패키지</h2>
			<dl>
				<dt class="fc-M1">갱년기 건강을 위한 세심한 검진</dt>
				<dd>갱년기 전후 나타나는 신체적 변화와 건강 상태를 살펴보는 프로그램으로 <br class="br1280">호르몬 변화와 관련된 건강 문제를 확인하고 체계적인 건강관리를 돕습니다.</dd>
			</dl>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
                    <col width="25%">
					<col width="75%">
                </colgroup>
                <thead>
                    <tr>
                        <th>종류</th>
                        <th>내용</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
					<th>자궁경부 세포진검사(액상검사)</th>
					<td class="left">자궁경부 외부, 내부의 세포를 채취하는 가장 기본적인검사입니다.</td>
				</tr>
				<tr>
					<th>자궁경부확대경 검사</th>
					<td class="left">특수 사진기로 자궁경부를 확대 촬영하여 이상유무를 판독하는 검사입니다.</td>
				</tr>
				<tr>
					<th>인유두종바이러스(HPV)검사</th>
					<td class="left">자궁경부암을 유발하는 인유두종바이러스의 위험도와 종류를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>STD12종 검사 (질염/성병균 검사)</th>
					<td class="left">성병의 원인이 되는 원인균, 바이러스를 정확히 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>자궁/난소 초음파 검사</th>
					<td class="left">자궁과 난소의 모양과 크기, 종양의 유무를 파악하는 검사입니다.</td>
				</tr>
				<tr>
					<th>유방 촬영술</th>
					<td class="left">유방촬영술은 유방암 진단의 가장 기본적인 검사 방법입니다. 유방암의 초기 특징인 미세한 석회화까지 발견을 할 수 있어 꼭 필요한 검사라고 할 수 있습니다.</td>
				</tr>
				<tr>
					<th>유방 초음파 검사</th>
					<td class="left"> 7.5MHz 이상의 선형 탐촉자를 이용한 고해상도 초음파 기기를 이용하여 유방 질환을 진단하는 검사입니다. 검사의 방법이 매우 간편하고, 검사로 인한 방사선피폭의 위험이 없으므로 모든 연령층의 여성에게 반복적으로 사용할 수 있는 검사방법입니다.</td>
				</tr>
				<tr>
					<th>골밀도검사</th>
					<td class="left">폐경 후에는 골밀도가 급격히 감소하며 쉽게 골다공증이 생깁니다.<br>
						이에 대한 파악과 예방, 조기 치료가 꼭 필요합니다.</td>
				</tr>
				<tr>
					<th>기초혈액검사 + 호르몬검사</th>
					<td class="left">혈액 속의 유형성분인 혈구를 분석해 검사하고 각 호르몬의 검사를 통하여 배란에 관계되는 호르몬의 이상유무를 확인하는 검사입니다.</td>
				</tr>
				<tr>
					<th>난소암 혈액검사</th>
					<td class="left">혈액검사로 난소암에서 올라가는 수치들을 검사하여 이들을 종합하여 위험도를 산정하는 검사입니다.</td>
				</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>
</section>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
