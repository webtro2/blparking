<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "레이저 미백";
$page_canonical = "https://reneclinic.co.kr/doc/labiaplasty6.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "6";
	$category = "레이저 미백";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>




	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-labia6.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">미백치료로 더 환한 아름다움</h2>
			<ul class="t1">
				<li>소음순수술 후에도 회색, 갈색으로 착색, 변형된 부분이 일부 남아있을 경우 레이저를 활용한 미백시술을 하실 수 있습니다.</li>
				<li>미백레이저는 3회의 기본시술로 이루어지며, 소음순 뿐만 아니라 대음순의 색소 개선, 탄력 효과를 함께 기대할 수 있습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>





<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>르네여성의원의 <br class="br480">레이저 미백 시술</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>르네여성의원은 소음순과 대음순의 색소침착으로 고민하는 여성들을 위해 개인별 피부 상태에 맞춘 레이저 미백시술을 진행합니다.</li>
			<li>소음순수술 후에도 남아 있는 갈색 또는 회색빛 색소침착을 비롯해 외음부의 칙칙하고 불균일한 피부 톤 개선을 목표로 합니다.</li> 
			<li>일반적으로 3회 시술을 기본으로 하며, 필요에 따라 피부 탄력까지 함께 고려한 맞춤형 케어를 제공합니다.</li>
		</ul>
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>색소침착 개선</li>
				<li>짧은 시술시간</li>
				<li>통증 부담 완화</li>
				<li>단계별 맞춤 관리</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">여성의 민감한 부위인 만큼 더욱 세심한 접근이 필요합니다. </p>
		<p class="t2 fc-bl">르네여성의원은 개인마다 다른 색소침착의 정도와 피부 상태를 꼼꼼하게 살펴, 자연스럽고 균일한 피부 톤을 위한 <br>맞춤 시술을 진행합니다.</p>
	</div>
</section>







<section id="clinicIntro" class="subBG p-Part-b m-Part">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>레이저 미백이 필요한 경우</h2>
			<p class="t1">소음순과 대음순의 색소침착으로 고민하고 있다면 <br>섬세한 레이저 미백으로 균일하고 자연스러운 피부 톤을 가꿔보세요.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>소음순의 색소침착이 고민인 경우</dt>
						<dd>소음순 피부가 갈색이나 회색빛으로 착색되어 칙칙하고 불균일한 피부 톤이 신경 쓰이는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>대음순의 피부 톤 개선을 원하는 경우</dt>
						<dd>대음순 주변의 색소침착으로 피부 톤이 고르지 않아 보다 균일하고 자연스러운 피부색을 원하는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>소음순수술 후 착색이 남아 있는 경우</dt>
						<dd>소음순수술 후 충분한 회복 기간이 지났음에도 기존의 색소침착이 남아 있어 추가적인 개선을 원하는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>반복적인 마찰로 착색이 발생한 경우</dt>
						<dd>속옷이나 꽉 끼는 의류 등 반복적인 마찰과 자극으로 외음부 주변의 색소침착이 신경 쓰이는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>호르몬 변화로 피부색이 달라진 경우</dt>
						<dd>임신, 출산, 노화 등으로 외음부 피부색에 변화가 생겨 색소침착의 개선 가능성을 상담받고 싶은 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>외음부의 전반적인 피부 톤 관리가 필요한 경우</dt>
						<dd>소음순과 대음순 주변의 칙칙한 피부 톤을 개선하여 보다 맑고 균일한 피부 상태를 원하는 경우</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>











<div id="another" class="inner p-Part">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>함께할 수 있는 시술</h2>
		<p class="t1">함께하면 더욱 만족스러운 변화를 기대할 수 있는 시술을 소개합니다.</p>
	</div>
	<div class="flex-Box labia2">
		<div class="box bg1">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>소음순수술</dt>
				<dd>피부가 지나치게 두껍고 착색이 심한 경우, 수술적 교정을 함께 해야 효과를 볼 수 있습니다.</dd>
			</dl>
		</div>
		<div class="box bg2">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>외음부 타이트닝 레이저</dt>
				<dd>피부가 얇고 처지는 경우, 레이저 시술로 콜라겐을 회복하여 탄력을 줄 수 있습니다.</dd>
			</dl>
		</div>
		<div class="box bg4">
			<p class="eng">Synergy Effect</p>
			<dl>
				<dt>비비브/베스타 <br>(타이트닝 레이저)</dt>
				<dd>성감향상과 요실금 개선에 도움이 되고, 처짐을 방지합니다.</dd>
			</dl>
		</div>
	</div>
</div>





<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>레이저 미백, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시 통증은 어느 정도인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 전 마취크림을 도포하여 통증에 대한 부담을 줄일 수 있습니다. 시술 중 가벼운 따끔거림이나 열감이 느껴질 수 있으나, 통증의 정도는 개인의 피부 상태와 민감도에 따라 차이가 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">레이저 미백시술은 몇 회 정도 받아야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 3회를 기본으로 시술하며, 색소침착의 정도와 피부 상태에 따라 필요한 횟수는 달라질 수 있습니다. 시술 효과는 개인마다 차이가 있으므로 의료진과 상담하여 적절한 시술 계획을 결정합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순수술을 받지 않아도 미백시술이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네, 소음순수술 여부와 관계없이 레이저 미백시술을 고려할 수 있습니다. 소음순뿐 아니라 대음순의 색소침착도 상담할 수 있으며, 피부 상태와 색소침착의 원인을 확인한 후 시술 가능 여부를 결정합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">레이저 미백시술 후 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 후 일시적인 붉어짐, 열감, 따가움, 부종 등이 나타날 수 있으며 피부 상태에 따라 회복 과정이 다를 수 있으므로 시술 전 충분한 상담이 필요합니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
