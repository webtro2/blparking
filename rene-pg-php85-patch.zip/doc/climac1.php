<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "갱년기란";
$page_canonical = "https://reneclinic.co.kr/doc/climac1.php"
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "7";
	$p_num = "1";
	$category = "갱년기란";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>




	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-climac1.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">여성의 새로운 변화, <br>건강하게 준비하는 갱년기</h2>
			<ul class="t1">
				<li>갱년기는 여성의 난소 기능이 점차 감소하면서 여성호르몬 분비에 변화가 나타나는 자연스러운 생리적 전환기입니다. 이 시기에는 안면홍조, 발한, 수면장애, 감정 변화 등 다양한 신체적·정신적 증상이 나타날 수 있으며, 개인에 따라 증상의 정도와 지속 기간이 다르게 나타납니다.</li>
				<li>르네여성의원은 갱년기에 나타나는 다양한 변화를 세심하게 살피고, 개인의 건강 상태와 증상에 따른 맞춤형 진료를 통해 건강한 일상을 유지할 수 있도록 돕습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>갱년기가 나타나는 이유</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>여성은 나이가 들면서 난소의 기능이 점차 저하되고, 에스트로겐과 프로게스테론 등 여성호르몬의 분비가 불규칙해지다가 감소하게 됩니다.</li>
			<li>이러한 호르몬 변화는 체온 조절, 수면, 감정, 생식기 및 뼈 건강 등 신체의 여러 기능에 영향을 미쳐 다양한 갱년기 증상을 유발합니다. <br>특히 에스트로겐 감소는 안면홍조, 질 건조증, 골밀도 저하 등과 밀접한 관련이 있습니다.</li>
		</ul>		
	</div>
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>노화에 따른 난소 기능 감소</li>
				<li>에스트로겐 분비의 변동과 감소</li>
				<li>신체적·정서적 <br>변화 발생</li>
			</ul>
	</div>
</section>




<section id="clinicIntro" class="subBG p-Part-b m-Part">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>갱년기 관리방법</h2>
			<p class="t1">갱년기는 누구나 경험할 수 있는 자연스러운 변화이지만 <br>어떻게 관리하느냐에 따라 일상생활의 불편함과 삶의 질이 달라질 수 있습니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>규칙적인 운동</dt>
						<dd>걷기, 근력운동 등 꾸준한 신체활동으로 근육과 뼈 건강을 유지하고 체중 관리에 도움을 줍니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>균형 잡힌 영양 섭취</dt>
						<dd>칼슘, 비타민 D, 단백질 등 필수 영양소를 충분히 섭취하여 골밀도와 전반적인 건강을 관리합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>충분한 수면과 휴식</dt>
						<dd>규칙적인 수면 습관과 편안한 휴식으로 피로를 줄이고 수면의 질을 개선하도록 노력합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>스트레스 및 감정 관리</dt>
						<dd>명상과 취미활동, 적절한 휴식을 통해 불안감과 우울감 등 정서적 변화를 관리합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>정기적인 건강검진</dt>
						<dd>골밀도 검사와 여성 건강검진 등을 통해 갱년기 이후 발생할 수 있는 건강 문제를 조기에 확인합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>개인별 맞춤 치료</dt>
						<dd>증상의 정도와 건강 상태를 고려하여 호르몬 치료 등 적절한 치료방법을 전문의와 상담합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>





<div id="climac1-3" class="p-Part s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>폐경과 갱년기, <br class="br480">어떻게 다를까요?</h2>
			<p class="t1">폐경과 갱년기는 비슷한 의미로 사용되지만 의학적으로는 서로 다른 개념입니다.</p>
		</div>
		<ul class="contWrap flex-Box">
			<li>
				<h3><p>폐경(완경)</p></h3>
				<img src="/images/sub/climac1-3-img1.png">
				<p class="t1">난소 기능의 변화로 월경이 완전히 중단되는 것을 의미합니다. 일반적으로 다른 원인 없이 12개월 연속 월경이 없을 때 자연폐경으로 판단하며, 국내 여성은 평균적으로 50세 전후에 경험합니다.</p>
			</li>		
			<li>
				<h3><p>갱년기</p></h3>
				<img src="/images/sub/climac1-3-img2.png">
				<p class="t1">폐경 전후에 나타나는 신체적 전환기로 여성호르몬의 변화로 신체적·정서적 증상이 나타나는 시기를 의미합니다. 대체로 40대 중후반부터 시작될 수 있으며, 폐경 이후에도 증상이 일정 기간 지속될 수 있습니다. </p>
			</li>		
		</ul>
</div>





<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>갱년기, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기는 보통 몇 살부터 시작되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>갱년기는 일반적으로 40대 중후반부터 시작되며, 평균적으로 50세 전후에 폐경을 경험합니다. 개인에 따라 시작 시기와 증상의 정도가 다르며, 생리주기의 변화와 함께 다양한 신체적·정서적 증상이 나타날 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기에는 어떤 증상이 나타나나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>대표적으로 안면홍조, 발한, 수면장애, 가슴 두근거림, 피로감, 감정 기복 등이 나타날 수 있습니다. 또한 질 건조감, 성교통, 관절통 등이 동반되기도 하며, 장기적으로 골밀도 감소와 심혈관 건강에도 영향을 줄 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">생리가 불규칙하면 갱년기가 시작된 건가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>생리주기의 변화는 갱년기 초기 증상 중 하나이지만, 반드시 갱년기를 의미하는 것은 아닙니다. 스트레스, 갑상선질환, 임신 등 다양한 원인으로 발생할 수 있으므로 전문의 상담을 통해 원인을 확인하는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기가 지나면 증상도 자연스럽게 사라지나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>안면홍조나 발한 등의 증상은 시간이 지나면서 완화되는 경우가 많지만, 개인에 따라 수년간 지속되기도 합니다. 질 건조감이나 비뇨생식기 증상은 치료 없이 지속되거나 악화될 수 있으므로 불편함이 있다면 적절한 관리가 필요합니다.</p>
                </div>
            </div>


			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갱년기 증상은 생활습관 개선만으로 관리할 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>규칙적인 운동과 균형 잡힌 식사, 충분한 수면, 체중 관리 등은 갱년기 건강 유지에 도움이 됩니다. 다만 증상이 심하거나 일상생활에 불편함이 지속된다면 생활습관 개선과 함께 전문적인 검사 및 치료를 고려하는 것이 좋습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
