<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "소노케어";
$page_canonical = "https://reneclinic.co.kr/doc/vaginalrepair5.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "5";
	$category = "소노케어";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>



	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-vaginal5.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">통증과 자극 없이 피부 속 깊은 곳까지, <br>프리미엄 초음파 케어 소노케어</h2>
			<ul class="t1">
				<li>소노케어는 강한 열이나 물리적인 자극을 주어 손상을 입히는 기존 방식과 달리, <br>고밀도 초음파 에너지를 이용해 세포를 미세하게 마사지하고 활성화하는 비수술적 <br>안티에이징·재생 장비입니다.</li>
				<li>탄력 개선, 흉터 완화, 보습 및 염증 완화 목적으로 널리 쓰이며, 자극이나 붉어짐이 거의 없어 <br>민감한 부위에도 편안하게 시술받을 수 있는 것이 큰 장점입니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>멀티 프리퀀시 초음파의 공명 작용과 콜라겐 생성 메커니즘</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>소노케어는 다중 주파수(Multi-frequency) 초음파 에너지를 피부 및 점막 깊은 조직에 교차 전달하여 <br>세포 단위의 미세한 진동(공명 현상)을 일으킵니다.</li>
			<li>이 진동 에너지가 노화되거나 손상된 세포를 자극하여 콜라겐 합성을 촉진하고, 체내 히알루론산 분포를 균일하게 유도하여 <br>피부와 점막 조직을 촘촘하고 건강하게 리모델링해 줍니다.</li>
		</ul>
	</div>	
	<div class="circleList labia2">
			<ul class="flex-Box">
				<li>탄력 강화<br>(콜라겐 생성)</li>				
				<li>피부 · 점막<br>재생 및 보습</li>
				<li>부종 및 염증 완화</li>
				<li>통증 및 자극 제로<br>(무통증 케어)</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">자극 걱정 없이 건강하고 탄탄하게, 소노케어 맞춤 솔루션</p>
	</div>
</section>





<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>소노케어,  <br class="br480">이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>파트너와의 관계에서 조금더 밀착감을 느끼고 싶은 분</p></li>
				<li><p>질 내 탄력이 떨어진 것이 고민인 분</p></li>
				<li><p>관계 시 건조하고, 통증이 많아 고민인 분</p></li>
				<li><p>탄력 개선을 원하지만 통증이나 후유증이 걱정되어 망설이고 있는 분</p></li>
				<li><p>지속적으로 건강 관리를 받고 싶은 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>





<section id="clinicIntro" class="subBG p-Part-b">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>르네여성의원의 소노케어 시술</h2>
			<p class="t1">소노케어는 고밀도 초음파로 통증과 자극 없이 세포를 활성화하고 콜라겐 생성을 촉진하며 <br>붓기와 염증을 완화하며 다른 레이저와 병행 시 회복과 시너지 효과를 높여줍니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>외음부, 질 내외 모두 치료가능</dt>
						<dd>겉과 속을 아우르는 입체적인 초음파 에너지가 탄력과 수분감을 회복시키며, 절개나 통증 없이 안전하게 통합적인 Y존 케어를 완성합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>콜라겐 생성 & 탄력 강화</dt>
						<dd>고밀도 초음파 진동이 세포를 활성화하여 콜라겐 합성을 촉진하고, 늘어진 조직의 탄력과 자생력을 높여줍니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>부종 및 염증 완화</dt>
						<dd>미세한 초음파 공명 작용을 통해 체내 불필요한 부종과 염증 물질을 완화하여 편안한 회복을 돕습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>골반저근까지 치료 가능</dt>
						<dd>미세 초음파 에너지가 깊은 근육층의 재생과 혈류를 촉진하여, 노화나 출산으로 약화된 Y존의 근본적인 힘과 탄력을 되찾아 줍니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>예민한 부위 맞춤 케어</dt>
						<dd>피부와 점막 조직에 자극을 최소화한 인체 친화적 방식으로, 예민하고 민감한 부위도 부담 없이 관리할 수 있습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>빠른 일상 복귀</dt>
						<dd>시술 직후 겉으로 드러나는 멍이나 흔적, 자국이 전혀 남지 않으며 시술 당일 부부관계도 가능합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>





<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>소노케어, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소노케어 시술 시간은 얼마나 걸리나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>소노케어 시술은 보통 10~15분 내외로 진행됩니다. 별도의 마취가 필요하지 않으며, 시술 후 회복을 위한 긴 대기 시간 없이 당일 일상생활로 복귀할 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 후 관리는 어떻게 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>시술 후 특별한 회복 과정은 필요하지 않으며, 대부분 바로 일상생활이 가능합니다. 다만 시술 직후에는 질 내부가 일시적으로 민감해질 수 있으므로 성관계는 약 3시간 이후를 권장하며, 불편감이 있다면 의료진의 안내에 따라 충분히 휴식하는 것이 좋습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 후 효과는 언제부터 볼 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>질 건조감이나 불편함은 시술 직후부터 변화를 느끼는 경우도 있습니다. 탄력 개선은 콜라겐 재생 과정에 따라 서서히 나타날 수 있으며, 일반적으로 3~6개월에 걸쳐 변화를 기대할 수 있습니다. 효과와 유지 기간은 개인의 상태에 따라 차이가 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시 많이 아픈가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>소노케어는 초음파 에너지를 이용하는 비침습적 시술로, 통증 부담이 비교적 적어 별도의 마취 없이 진행하는 경우가 많습니다. 시술 중에는 따뜻한 열감이나 가벼운 자극이 느껴질 수 있으며, 개인의 민감도에 따라 불편함의 정도는 다를 수 있습니다.</p>
                </div>
            </div>

			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소노케어 시술 후 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>소노케어는 절개 없이 진행하는 시술이지만 부작용이 전혀 없는 것은 아닙니다. 시술 후 일시적인 열감, 붓기, 통증 또는 자극감이 나타날 수 있으며 드물게 감염 등의 문제가 발생할 수 있습니다. 증상이 지속되거나 심해지는 경우에는 의료진의 진료를 받는 것이 좋습니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>



</div>
</div>
<?php include "../inc/bottom.php"; ?>
