<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "갑상선질환";
$page_canonical = "https://reneclinic.co.kr/doc/breast2.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "4";
	$p_num = "2";
	$category = "갑상선질환";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>





	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-breast2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">우리 몸의 균형을 조절하는 갑상선, <br>건강의 작은 변화를 살피다</h2>
			<ul class="t1">
				<li>갑상선은 목 앞쪽에 위치한 나비 모양의 기관으로, 신체의 대사와 체온, 에너지 사용을 <br>조절하는 갑상선호르몬을 분비합니다.</li>
				<li>갑상선 질환은 호르몬 분비 이상이나 갑상선 조직의 변화로 발생하며 초기에는 뚜렷한 증상이 <br>없을 수 있어 증상과 위험 요인에 따른 적절한 검사와 진단이 중요합니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>갑상선 질환의 종류</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>갑상선 질환은 갑상선호르몬의 분비 이상이나 갑상선 조직의 변화에 따라 다양한 형태로 나타납니다.</li>
			<li>대표적으로 갑상선기능항진증, 갑상선기능저하증, 갑상선염, 갑상선결절 등이 있으며, <br>질환에 따라 증상과 치료 방법이 달라 정확한 진단과 적절한 관리가 중요합니다.</li>
		</ul>		
	</div>
		
	<div class=" mt50">
            <table class="tb-style1">
                <colgroup>
                    <col width="">
					<col width="">
					<col width="42%">
                </colgroup>
                <thead>
                    <tr>
                        <th colspan="2">병명</th>
						<th>모양과 증상</th>
						<th>호르몬 생산량</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
					<td colspan="2">갑상선 기능항진증</td>
					<td>전체적으로 커짐</td>
					<td>많음</td>
				</tr>
				<tr>
					<td colspan="2">갑상선 기능저하증</td>
					<td>전체적으로 커짐</td>
					<td>적음</td>
				</tr>
				<tr>
					<td colspan="2">단순 갑상선종(비대)</td>
					<td>전체적으로 커짐</td>
					<td>정상</td>
				</tr>
				<tr>
					<td rowspan="4">갑상선염</td>
					<td>하시모토</td>
					<td>전체적으로 울퉁불퉁하게 커짐</td>
					<td>적거나 정상</td>
				</tr>
				<tr>
					<td>아급성</td>
					<td>전체적으로 울퉁불퉁하게 커짐</td>
					<td>변화가 많음</td>
				</tr>
				<tr>
					<td>산후</td>
					<td>전체적으로 울퉁불퉁하게 커짐</td>
					<td>변화가 많음</td>
				</tr>
				<tr>
					<td>화농성</td>
					<td>전체적으로 울퉁불퉁하게 커짐</td>
					<td>정상 또는 변화가 있음</td>
				</tr>
				<tr>
					<td rowspan="3">갑상선 결절</td>
					<td>양성종양</td>
					<td>전체적으로 커짐</td>
					<td>정상</td>
				</tr>
				<tr>
					<td>악성종양(암)</td>
					<td>전체적으로 커짐</td>
					<td>정상</td>
				</tr>
				<tr>
					<td>낭종</td>
					<td>전체적으로 커짐</td>
					<td>정상</td>
				</tr>
                </tbody>
            </table>
        </div>
</section>





<section class="subBG p-Part-b m-Part">
<div id="labia2-2" class="inner">
	<div class="clinicTit center">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>갑상선 암 진단방법</h2>
		<p class="t1">갑상선암은 초기에는 뚜렷한 증상이 없는 경우가 많아 정확한 검사를 통한 진단이 중요합니다.</p>
	</div>
	<div class="contWrap">
		<ul class="flex-Box breast1">
			<li>
				<h3><p>임상증상</p></h3>
				<img src="/images/sub/breast2-2-img1.png">
				<p class="t1">목의 멍울, 부종, 목소리 변화, 삼킴 곤란 등 갑상선 관련 증상을 확인합니다.</p>
			</li>
			<li>
				<h3><p>혈액검사</p></h3>
				<img src="/images/sub/breast2-2-img2.png">
				<p class="t1">갑상선호르몬과 갑상선자극호르몬 수치를 측정하여 갑상선 기능을 평가합니다.</p>
			</li>
			<li>
				<h3><p>초음파 검사</p></h3>
				<img src="/images/sub/breast2-2-img3.png">
				<p class="t1">갑상선 결절의 크기와 모양, 내부 구조 등을 관찰하여 악성 가능성을 평가합니다.</p>
			</li>
			<li>
				<h3><p>초음파유도 세침 흡인생검</p></h3>
				<img src="/images/sub/breast2-2-img4.png">
				<p class="t1">가느다란 바늘로 결절의 세포를 채취하여 암이 의심되는지 확인합니다.</p>
			</li>
		</ul>
	</div>
</div>
</section>







<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>갑상선암 자가진단</h2>
			<p class="t1">아래 항목과 같은 증상이 있는 경우 병원을 찾아 검사를 받아보시기를 권장합니다.</p>
		</div>
		<div class="txtList">
			<ul>
				<li><p>목에 움직이지 않는 딱딱한 덩어리가 만져진다.</p></li>
				<li><p>가족 중 갑상선암 환자가 있다.</p></li>
				<li><p>침을 삼킬때 이물감이 느껴진다.</p></li>
				<li><p>갑자기 이유 없이 체중변화가 나타난다.</p></li>
				<li><p>충분히 휴식을 취했는데도 피로감이 있고 무기력하다.</p></li>
				<li><p>생리양의 변화가 생기거나 생리불순이 생긴다.</p></li>
				<li><p>호흡이 가빠지고 잔기침이 잦아지고 목소리가 변한다.</p></li>
			</ul>
		</div>
	</div>
</div>







<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>갑상선 질환, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갑상선 질환은 어떤 증상이 나타나나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>갑상선 기능에 이상이 생기면 피로감, 체중 변화, 두근거림, 추위나 더위에 대한 민감성 등이 나타날 수 있습니다. 다만 초기에는 특별한 증상이 없는 경우도 있어 정확한 검사를 통해 확인하는 것이 중요합니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갑상선 결절이 발견되면 모두 암인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>갑상선 결절은 대부분 양성이며, 결절이 발견되었다고 해서 반드시 암을 의미하는 것은 아닙니다. 초음파검사로 크기와 모양 등을 확인하고, 필요에 따라 세침흡인검사를 시행하여 악성 가능성을 평가합니다.</p>
                </div>
            </div>


			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갑상선 질환이 있으면 반드시 약을 복용해야 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>갑상선 질환의 종류와 기능 이상 정도에 따라 치료 방법이 달라집니다. 약물치료가 필요한 경우도 있지만, 특별한 치료 없이 정기적인 검사와 경과 관찰만 진행하는 경우도 있습니다.</p>
                </div>
            </div>

			
            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">갑상선 질환은 완치가 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>질환의 종류와 원인에 따라 치료 경과가 다릅니다. 일부 갑상선염은 자연적으로 회복되기도 하며, 갑상선기능저하증 등은 장기간 약물치료가 필요할 수 있습니다. 정확한 진단과 꾸준한 관리가 중요합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
