<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "오르네샷";
$page_canonical = "https://reneclinic.co.kr/doc/vaginalrepair7.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "3";
	$p_num = "7";
	$category = "오르네샷";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>





	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-vaginal7.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">내 몸의 혈액에서 시작되는 변화, <br>여성의 섬세한 감각을 깨우다</h2>
			<ul class="t1">
				<li>오르네샷은 본인의 혈액에서 혈소판과 성장인자가 포함된 성분을 분리·농축하여 클리토리스 등 필요한 부위에 주입하는 시술입니다.</li>
			<li>자가혈액의 재생 관련 성분을 활용해 조직 환경의 개선을 유도하고, 둔화된 감각과 여성의 성적 만족도 개선에 도움을 주는 것을 목적으로 합니다. 개인의 신체 상태와 고민을 고려하여 섬세하게 진행하는 여성 성감개선 시술입니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>




<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>자가혈액 속 성장인자를 활용한 감각개선</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>우리 몸의 혈액에는 조직 회복 과정에 관여하는 혈소판과 다양한 성장인자가 포함되어 있습니다.</li>
			<li>오르네샷은 채혈한 혈액을 원심분리하여 이러한 성분이 포함된 혈장 등을 분리한 뒤, 클리토리스와 주변 조직에 주입하는 방식입니다.</li>
			<li>주입된 혈소판 유래 성장인자의 작용을 통해 국소 조직 환경과 혈류 개선을 유도하고, 감각 반응과 성적 만족도의 변화를 기대하는 원리입니다.</li>
		</ul>
	</div>	
	<ul class="vaginal7-img flex-Box">
		<li><img src="/images/sub/vaginal7-img1.png"></li>
		<li><img src="/images/sub/vaginal7-img2.png"></li>
		<li><img src="/images/sub/vaginal7-img3.png"></li>
	</ul>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">여성을 가장 잘 아는 르네여성의원이 제안하는 단 하나의 솔루션 <br>
어디서도 경험할 수 없었던 르네만의 독보적 오르네샷으로 새로운 느낌과 일상의 변화를 만나보세요.</p>
	</div>
</section>



<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>오르네샷,  <br class="br480">이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>클리토리스의 감각이 떨어지거나 <br class="br480">예전만큼 민감하지 않을 때</p></li>
				<li><p>자위를 해도 오르가즘에 이르는 시간이 길어질 때</p></li>
				<li><p>남편만 즐거운 것 같고 나는 도무지 즐겁지 않을 때</p></li>
				<li><p>요도 주변의 탄력이 떨어져 요실금 증상이 나타날 때</p></li>
			</ul>
		</div>
	</div>
</div>
</section>





<section id="clinicIntro" class="subBG p-Part-b">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>르네여성의원의 오르네샷 효과</h2>
			<p class="t1">일반적인 시술과 달리, 오직 여성을 위해 맞춤 설계된 르네여성의원만의 특별한 케어</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>여성 감각 개선</dt>
						<dd>둔화된 민감 부위의 감각 반응을 개선하고 섬세한 자극에 대한 반응을 높이는 것을 목표로 합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>질 탄력 개선 유도</dt>
						<dd>성장인자의 작용을 활용하여 질 조직의 탄력과 회복 환경 개선을 목표로 합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>질 건조증 개선 기대</dt>
						<dd>질 점막의 조직 환경 개선을 통해 건조함과 불편감 완화 가능성을 기대합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>요실금 증상 완화 기대</dt>
						<dd>복압성 요실금 증상 개선 가능성이 연구되고 있으나 치료 효과는 확립되지 않았습니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>조직 회복 촉진 유도</dt>
						<dd>혈소판 유래 성장인자를 활용해 국소 조직의 회복과 재생 관련 반응을 유도합니다.</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>성생활 만족도 개선</dt>
						<dd>감각 및 신체적 불편함의 개선 가능성을 바탕으로 성생활 만족도 향상을 기대합니다.</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>오르네샷, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">오르네샷은 어떤 시술인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>오르네샷은 본인의 혈액을 채취한 후 원심분리 과정을 통해 혈소판과 성장인자가 포함된 성분을 추출하여 클리토리스 및 주변 조직에 주입하는 시술입니다. 자가혈액을 사용하므로 외부 물질에 의한 알레르기 반응의 우려가 상대적으로 낮으며, 조직 환경 개선과 여성의 감각 및 성적 만족도 향상을 기대할 수 있습니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시간과 횟수는 어떻게 되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>오르네샷은 채혈부터 혈액 분리, 주입 과정까지 일반적으로 약 30~60분 정도 소요될 수 있습니다. 1개월 간격으로 총 3회 시술하는 것을 권장하며, 개인의 신체 상태와 시술 후 반응에 따라 횟수와 간격은 조정될 수 있습니다.</p>
                </div>
            </div>


            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">시술 시 통증이 심한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>통증을 줄이기 위해 국소마취 또는 마취크림 등을 사용할 수 있습니다. 시술 중 따끔함이나 압박감이 느껴질 수 있으며, 통증의 정도는 개인마다 차이가 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">오르네샷 시술 후 부작용은 없나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>본인의 혈액에서 추출한 성분을 사용하더라도 부작용이 전혀 없는 것은 아닙니다. 시술 부위의 통증, 붓기, 멍, 출혈, 감염 등이 발생할 수 있으며, 시술 전 충분한 상담을 통해 주의사항과 발생 가능한 부작용을 확인해야 합니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
