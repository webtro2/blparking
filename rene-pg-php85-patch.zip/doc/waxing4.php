<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "제모시 주의사항";
$page_canonical = "https://reneclinic.co.kr/doc/waxing4.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "5";
	$p_num = "4";
	$category = "제모시 주의사항";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="waxing4" class="flex-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>시술 <span class="fc-M2">전</span> 주의사항</h2>
			<p class="t1">안전하고 효과적인 레이저 시술을 위해 피부 상태를 <br>확인하고, 시술에 영향을 줄 수 있는 자극을 피하는 등 <br>충분한 사전 준비가 필요합니다.</p>
		</div>
		<div class="contWrap">
			<ul class="numList">
				<li><p>시술 부위의 털은 일반적으로 시술 하루 전 면도해 주세요. 피부에 상처가 생기지 않도록 주의해야 합니다.</p></li>
				<li><p>시술 전 최소 6주 동안 왁싱이나 족집게 등으로 털을 뿌리째 제거하는 행동은 피해주세요.</p></li>
				<li><p>시술 전 약 2~4주 동안 태닝을 피하고, 강한 자외선에 노출되지 않도록 주의해 주세요.</p></li>
				<li><p>시술 전에는 스크럽, 필링 등 피부에 자극을 줄 수 있는 관리를 피하고 피부를 청결하게 유지해 주세요.</p></li>
				<li><p>광과민성 약물 복용, 피부질환, 염증, 상처 등이 있는 경우 시술 전 의료진에게 반드시 알려주세요.</p></li>
			</ul>
		</div>
	</div>


	
<?php include "../inc/clinic-marquee.php"; ?>



	<div id="waxing4" class="flex-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>시술 <span class="fc-M1">후</span> 주의사항</h2>
			<p class="t1">시술 후 피부는 일시적으로 민감해질 수 있으므로 <br>적절한 진정과 보습 관리가 중요하며 주의사항을 준수하여 <br>피부 자극과 부작용을 예방해야 합니다.</p>
		</div>
		<div class="contWrap">
			<ul class="numList v2">
				<li><p>시술 후 붉어짐이나 열감, 가벼운 부기가 나타날 수 있으며, 냉찜질하면 증상 완화에 도움이 됩니다.</p></li>
				<li><p>시술 후 24~48시간 동안 뜨거운 목욕, 사우나, 찜질방 등 피부에 열 자극을 주는 활동은 피해주세요.</p></li>
				<li><p>피부가 건조하고 민감해질 수 있으므로 자극이 적은 보습제를 사용하여 촉촉하게 유지해 주세요.</p></li>
				<li><p>시술 후 수일간 스크럽, 때밀기, 강한 마사지 등을 피하고 피부를 긁거나 문지르지 않도록 주의해 주세요.</p></li>
				<li><p>시술 후 털은 수일에서 수주에 걸쳐 자연스럽게 빠질 수 있습니다. 이때 억지로 털을 뽑거나 왁싱하지 마세요.</p></li>
				<li><p>시술 후 약 1주일간은 시술 부위의 자극과 회복을 고려하여 성관계를 피하는 것이 좋습니다.</p></li>
				<li><p>심한 통증, 물집, 화상, 지속적인 붉어짐이나 색소 변화 등이 발생하면 즉시 의료진에게 문의해 주세요.</p></li>
			</ul>
		</div>
	</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
