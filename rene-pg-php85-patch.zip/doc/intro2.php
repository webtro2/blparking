<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "진료시간안내";
$page_canonical = "https://reneclinic.co.kr/doc/intro2.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "1";
	$p_num = "2";
	$category = "진료시간안내";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<!-- <h3 id="subTitle"><span class="vis_dep02"></span></h3>-->


	<div id="intro2" class="s-inner">
		<div id="sTitle" class="center">
			<h2>진료시간</h2>
		</div>
		<div class="contWrap">
			<ul class="box">
				<li class="day">월 · 목요일</li>
				<li class="hour pc fc-M1">AM 10:00 ~ PM 08:00</li>
				<li class="hour mo fc-M1">10:00 ~ 20:00</li>
				<li class="t1">야간진료</li>
			</ul>
			<ul class="box">
				<li class="day">화 · 수 · 금요일</li>
				<li class="hour pc fc-M1">AM 10:00 ~ PM 06:00</li>
				<li class="hour mo fc-M1">10:00 ~ 18:00</li>
			</ul>
			<ul class="box">
				<li class="day">토요일</li>
				<li class="hour pc fc-M1">AM 10:00 ~ PM 02:00</li>
				<li class="hour mo fc-M1">10:00 ~ 14:00</li>
				<li class="t1">점심시간 없이</li>
			</ul>
			<ul class="box">
				<li class="day">점심시간</li>
				<li class="hour pc fc-M1">PM 01:00 ~ PM 02:00</li>
				<li class="hour mo fc-M1">13:00 ~ 14:00</li>
			</ul>
		</div>
		<p class="off-day">※ 일요일·공휴일은 휴진입니다.</p>
	</div>



	<div id="intro2-2" class="s-inner">
		<div id="sTitle"class="center">
			<h2>진료상담 및 예약</h2>
		</div>
		<div class="contWrap">
			<ul class="box bg1">
				<li class="tit">온라인 상담</li>
				<li class="icon"><img src="/images/sub/intro2-2-icon1.png"></li>
				<li class="link"><a href="javascript:GoPage('comm2')"><span>바로가기</span></a></li>
			</ul>
			<ul class="box bg2">
				<li class="tit">전화상담 신청</li>
				<li class="icon"><img src="/images/sub/intro2-2-icon2.png"></li>
				<li class="link"><a href="javascript:GoPage('comm3')"><span>바로가기</span></a></li>
			</ul>			
			<ul class="box bg3">
				<li class="tit fc-bl">카카오톡 상담</li>
				<li class="icon"><img src="/images/sub/intro2-2-icon3.png"></li>
				<li class="link"><a href="javascript:GoPage('kakao')"><span>바로가기</span></a></li>
			</ul>
			<ul class="box bg4">
				<li class="tit">네이버 예약</li>
				<li class="icon"><img src="/images/sub/intro2-2-icon4.png"></li>
				<li class="link"><a href="javascript:GoPage('naver')"><span>바로가기</span></a></li>
			</ul>
		</div>
	</div>


</div>
</div>
<?php include "../inc/bottom.php"; ?>
