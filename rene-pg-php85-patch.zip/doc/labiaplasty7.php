<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "재수술 프로그램";
$page_canonical = "https://reneclinic.co.kr/doc/labiaplasty7.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "2";
	$p_num = "7";
	$category = "재수술 프로그램";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>





	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-labia7.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">첫 수술의 아쉬움까지 세심하게 살펴, 자연스러운 균형과 편안함을 다시 찾아드립니다.</h2>
			<ul class="t1">
				<li>타 병원에서 소음순 및 대음순 수술을 받았지만 수술 후 모양이나 디자인이 만족스럽지 않거나, 후유증으로 불편함을 겪고 있다면 재수술 상담을 통해 개선 가능성을 확인할 수 있습니다.</li>
				<li>르네여성의원은 충분한 상담과 정밀한 진찰을 통해 심미적인 균형과 기능적인 편안함을 함께 고려한 맞춤 재수술을 진행합니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>르네여성의원의 재수술 프로그램</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>르네여성의원은 기존 수술 부위의 상태와 조직의 회복 정도, 불편함의 원인을 세심하게 살펴 개인에게 적합한 재수술 방향을 제안합니다.</li>
			<li>일반적으로 첫 수술 후 조직이 충분히 안정되는 최소 6개월 이후 재수술을 고려하며, <br>염증이나 기타 문제가 있는 경우에는 해당 치료를 우선적으로 진행한 후 재수술 여부를 결정합니다.</li>
			<li>또한 재수술은 첫 수술보다 조직 상태와 흉터, 남아 있는 피부의 양 등을 더욱 면밀하게 살펴야 합니다. </li>
		</ul>		
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>충분한 상담과 진단</li>
				<li>불편함과 후유증 개선</li>
				<li>현실적인 수술 목표 설정</li>
				<li>안전을 최우선으로 고려</li>
			</ul>
	</div>
	<div class="clinicTxt pt0">
		<p class="t2 fc-bl">한 번의 아쉬움이 또 다른 고민이 되지 않도록, 더욱 신중하고 섬세하게 접근합니다.</p>
	</div>
</section>





<section id="clinicIntro" class="subBG p-Part-b m-Part">
<div class="s-inner">
	<div id="labia1-2" class="">
		<div class="clinicTit center">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>재수술이 필요한 경우</h2>
			<p class="t1">첫 수술 후에도 남아 있는 불편함과 아쉬움, 세심한 진단을 통해 개선 방향을 찾아드립니다.</p>
		</div>
		<div class="numBox">
			<ul class="flex-Box">
				<li>
					<dl>
						<dt>수술 후 불규칙한 흉터가 남은 경우</dt>
						<dd>봉합 과정이나 조직 회복의 영향으로 소음순 가장자리에 울퉁불퉁한 톱니 모양의 흉터가 남아 형태가 고르지 않은 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>소음순 비후와 비대칭이 남아 있는 경우</dt>
						<dd>수술 후에도 소음순의 두께나 크기가 불균형하여 좌우 비대칭이 남아 있거나 비대해진 형태가 지속되는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>염증으로 인한 통증이나 변형이 발생한 경우</dt>
						<dd>수술 후 염증이나 회복 과정의 문제로 통증이 지속되거나 흉터와 조직 변형으로 불편함이 발생한 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>과도한 절제로 비대칭이 발생한 경우</dt>
						<dd>소음순 조직이 지나치게 절제되어 좌우 길이나 모양에 차이가 생기고 자연스러운 균형이 무너진 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>수술 후에도 기능적인 불편함이 지속되는 경우</dt>
						<dd>수술 이후에도 속옷과의 마찰, 당김, 이물감 등 일상생활에서 불편함이 지속되어 개선을 원하는 경우</dd>
					</dl>
				</li>
				<li>
					<dl>
						<dt>수술 후 디자인과 모양이 만족스럽지 않은 경우</dt>
						<dd>기대했던 형태와 실제 수술 결과에 차이가 있거나, 소음순의 전체적인 라인과 외음부의 조화를 개선하고 싶은 경우</dd>
					</dl>
				</li>
			</ul>
		</div>
	</div>
</div>
</section>







<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>재수술 프로그램, <br class="br480">이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="true">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순·대음순 재수술은 언제부터 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>일반적으로 첫 수술 후 최소 6개월 정도 경과하여 조직이 충분히 회복되고 형태가 안정된 후 재수술을 고려합니다. 다만 기존 수술 방법과 조직 상태, 흉터 및 염증 여부에 따라 재수술 시기는 달라질 수 있으므로 정확한 진찰과 상담을 통해 결정합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">다른 병원에서 수술받았어도 재수술이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네, 타 병원에서 수술받은 경우에도 재수술 상담이 가능합니다. 기존 수술 부위의 흉터와 조직 상태, 비대칭 정도 등을 면밀하게 확인한 후 재수술 가능 여부와 개선 범위를 결정합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">소음순을 너무 많이 절제한 경우에도 재수술이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>과도한 절제로 소음순이 짧아지거나 비대칭이 발생한 경우에도 재수술을 고려할 수 있습니다. 다만 남아 있는 조직의 양과 피부 상태에 따라 교정 방법 및 개선 범위에 제한이 있을 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">염증이나 통증이 남아 있어도 재수술이 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>염증이나 감염이 있는 경우에는 해당 문제에 대한 진단과 치료를 우선적으로 진행해야 합니다. 염증이 가라앉고 조직이 충분히 회복된 후 재수술 여부를 결정하며, 통증의 원인에 따라 별도의 치료가 필요할 수 있습니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">재수술 후 회복기간과 주의사항은 어떻게 되나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>재수술은 기존 흉터와 조직 상태에 따라 회복기간이 달라질 수 있습니다. 수술 후에는 마찰과 압박을 줄이고 격한 운동이나 성관계 등은 의료진이 안내한 기간 동안 피해야 합니다. 정기적인 경과 확인을 통해 회복 상태를 살피는 것이 중요합니다.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">재수술 시 발생할 수 있는 부작용은 무엇인가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>재수술 후 출혈, 부종, 감염, 흉터, 비대칭, 감각 변화 등이 발생할 수 있습니다. 특히 기존 수술로 인한 흉터와 조직 손상이 있는 경우 교정에 한계가 있거나 추가적인 문제가 발생할 가능성이 있으므로 충분한 상담과 신중한 수술 계획이 필요합니다.</p>
                </div>
            </div>


        </div>
    </div>
</div>






</div>
</div>
<?php include "../inc/bottom.php"; ?>
