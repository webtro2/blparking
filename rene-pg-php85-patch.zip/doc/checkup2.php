<?php
require_once(__DIR__ . '/../inc/_common.php');
$page_title = "웨딩검진";
$page_canonical = "https://reneclinic.co.kr/doc/checkup2.php" 
?>

<?php include "../inc/head.php"; ?>
<?php include "../inc/link.php"; ?>
<?php include "../inc/top.php"; ?>

<?php 
	$s_num = "6";
	$p_num = "2";
	$category = "웨딩검진";
?>

<!-- visual -->
<?php include "../inc/s_visual.php"; ?>
<!-- END visual -->

<div id="pageCont">
<h3 id="subTitle"><span class="vis_dep02"></span></h3>


	<div id="clinicTop" >
		<div id="topimg"><img src="/images/sub/clinictop-checkup2.png"></div>
		<div id="topcont">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2 class="fc-bl">새로운 시작을 위한 준비, <br>건강부터 세심하게</h2>
			<ul class="t1">
				<li>웨딩검진은 결혼을 앞둔 여성의 건강 상태를 확인하고, 향후 임신과 출산에 영향을 줄 수 있는 <br>건강 문제를 미리 살펴보는 검진입니다.</li>
				<li>르네여성의원은 개인의 건강 상태와 임신 계획 등을 고려하여 여성질환부터 감염성 질환, 자궁 및 <br>난소 건강까지 체계적으로 확인하고 건강한 미래를 준비할 수 있도록 돕습니다.</li>
			</ul>
		</div>
	</div>



<?php include "../inc/clinic-marquee.php"; ?>



<section id="clinicIntro" class="center s-inner">
	<div class="clinicTit">
		<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
		<h2>웨딩검진의 필요성</h2>
	</div>
	<div class="clinicTxt">
		<ul>
			<li>여성질환은 특별한 증상이 없더라도 발견되는 경우가 있으며, 임신을 계획하고 있다면 미리 확인해야 할 건강 상태도 있습니다.</li>
			<li>웨딩검진을 통해 현재의 건강 상태를 점검하고 필요한 예방접종이나 치료, 건강관리 계획을 세울 수 있습니다.</li>
		</ul>		
	</div>
		<div class="circleList labia2">
			<ul class="flex-Box">
				<li>여성질환 조기 발견</li>
				<li>임신 전 건강관리</li>
				<li>감염성 질환 확인</li>
			</ul>
	</div>
</section>






<section class="m-Part">
<div id="recomm" >
	<div class="in-Box s-inner">
		<div class="clinicTit">
			<p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
			<h2>이런 분께 추천드립니다</h2>
		</div>
		<div class="txtList">
			<ul>
				<li><p>결혼을 앞두고 여성 건강 상태를 확인하고 싶은 분</p></li>
				<li><p>결혼 후 임신과 출산을 계획하고 있는 분</p></li>
				<li><p>평소 생리불순이나 생리통이 심한 분</p></li>
				<li><p>자궁과 난소의 건강 상태가 궁금한 분</p></li>
				<li><p>성매개감염 등 감염성 질환 검사가 필요한 분</p></li>
			</ul>
		</div>
	</div>
</div>
</section>








<section class="subBG p-Part-b ">
	<div id="checkup2" class=" s-inner">
		<div class="clinicTit center">
			<p class="eng fc-M2">BASIC CHECKUP</p>
			<h2>웨딩검진 항목</h2>
			<p class="t1">여성의 생식 건강과 전반적인 건강 상태를 확인하기 위한 검사들로 <br>개인의 병력과 건강 상태, 임신 계획에 따라 필요한 검진 항목을 선택하여 진행합니다.</p>
		</div>
		<div class="contWrap">
			 <div class="">
            <table class="tb-style1">
                <colgroup>
						<col width="30%">
						<col width="23.33%">
						<col width="23.33%">
						<col width="23.33%">
				</colgroup>
                <thead>
                    <tr>
                        <th>구분</th>
						<th>웨딩검진<br>(성경험X)</th>
						<th>웨딩검진<br>(성경험O)</th>
						<th>웨딩스페셜검진<br>(정밀냉검사 포함)</th>
                    </tr>
                </thead>
                <tbody>
					<tr>
						<th>초음파</th>
						<td class="point"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<th>질초음파</th>
						<td></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>빈혈검사, 혈액검사, 소변검사</th>
						<td class="point"></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>갑상선, 간, 신장 기능검사</th>
						<td class="point"></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>당검사, 비타민D 검사</th>
						<td class="point"></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>풍진항체검사</th>
						<td class="point"></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>A형, B형, C형 간염 항체검사</th>
						<td class="point"></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>에이즈/매독검사</th>
						<td></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>액상자궁경부암검사</th>
						<td></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
                    <tr>
						<th>자궁경부확대촬영</th>
						<td></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>인유두종바이러스(HPV)</th>
						<td></td>
						<td class="point"></td>
						<td class="point"></td>
					</tr>
					<tr>
						<th>냉검사</th>
						<td></td>
						<td class="point"></td>
						<td></td>
					</tr>
					<tr>
						<th>정밀냉검사</th>
						<td></td>
						<td></td>
						<td class="point"></td>
					</tr>
                </tbody>
            </table>
        </div>
		</div>
	</div>
</section>




<div id="faqBG" class="p-Part">
    <div class="s-inner">
        <div class="clinicTit  center">
            <p class="eng fc-M2">RENE WOMEN’S CLINIC</p>
            <h2>웨딩검진, 이런 점이 궁금해요!</h2>
            <p class="t1">진료 및 상담 과정에서 환자분들이 가장 궁금해하시는 질문을 모아 <br>알기 쉽게 답변해 드립니다.</p>
        </div>

        <div class="faq-list">

	

            <div class="faq-item active">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">결혼 예정이 아니어도 웨딩검진을 받을 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네. 웨딩검진은 결혼 여부와 관계없이 여성 건강 상태를 확인하거나 임신을 준비하는 분들도 받을 수 있습니다. 개인의 건강 상태와 검진 목적에 따라 필요한 검사 항목을 선택할 수 있습니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">웨딩검진은 생리 중에도 가능한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>검사 항목에 따라 차이가 있습니다. 자궁경부 세포검사 등은 생리혈의 영향을 받을 수 있어 생리 기간을 피해 진행하는 것이 좋습니다. <br>혈액검사 등 일부 검사는 가능하므로 예약 전 문의해 주세요.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검진 전 금식이 필요한가요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>자궁 및 난소 초음파, 자궁경부 세포검사 등은 일반적으로 금식이 필요하지 않습니다. 다만 혈당 등 일부 혈액검사 항목에 따라 금식이 필요할 수 있으므로 검진 전 안내를 확인해 주세요.</p>
                </div>
            </div>

			<div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">성경험이 없어도 검진을 받을 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>네. 성경험이 없는 경우에도 상담과 필요한 검사를 받을 수 있습니다. 자궁경부 세포검사나 질식 초음파 등은 개인의 상태와 검사 필요성을 고려하여 시행 여부 및 검사 방법을 결정합니다.</p>
                </div>
            </div>

            <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">웨딩검진을 받으면 임신 가능성도 알 수 있나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>웨딩검진은 임신 전 건강 상태와 관련 위험요인을 확인하는 데 도움을 주지만, 검진 결과만으로 임신 가능 여부나 향후 임신 성공을 정확하게 판단할 수는 없습니다. 필요에 따라 별도의 가임력 평가와 상담이 진행될 수 있습니다.</p>
                </div>
            </div>

			 <div class="faq-item">
                <button type="button" class="faq-question" aria-expanded="false">
                    <span class="faq-q">Q</span>
                    <span class="faq-tit">검진 결과 이상이 발견되면 어떻게 하나요?</span>
                    <span class="faq-arrow"></span>
                </button>
                <div class="faq-answer">
                    <p>검사 결과를 바탕으로 의료진과 상담하여 필요한 추가 검사, 치료 또는 추적관찰을 진행합니다. 임신을 계획하는 경우에는 검사 결과와 치료 일정 등을 고려하여 적절한 임신 준비 시기를 안내합니다.</p>
                </div>
            </div>

        </div>
    </div>
</div>




</div>
</div>
<?php include "../inc/bottom.php"; ?>
